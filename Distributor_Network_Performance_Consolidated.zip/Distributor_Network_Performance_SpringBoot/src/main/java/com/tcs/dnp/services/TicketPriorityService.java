package com.tcs.dnp.services;

import com.tcs.dnp.model.TicketPriority;
import com.tcs.dnp.repository.TicketPriorityRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketPriorityService extends AbstractCrudService<TicketPriority, Long> {
    public TicketPriorityService(TicketPriorityRepository repository) {
        super(repository, TicketPriority.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.Role;
import com.tcs.dnp.repository.RoleRepository;
import org.springframework.stereotype.Service;

@Service
public class RoleService extends AbstractCrudService<Role, Long> {
    public RoleService(RoleRepository repository) {
        super(repository, Role.class);
    }
}

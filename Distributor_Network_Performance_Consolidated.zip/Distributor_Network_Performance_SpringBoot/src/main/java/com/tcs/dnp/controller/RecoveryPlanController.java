package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.RecoveryPlan;
import com.tcs.dnp.services.RecoveryPlanService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/recovery-plans")
public class RecoveryPlanController {
    private final RecoveryPlanService service;

    public RecoveryPlanController(RecoveryPlanService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RecoveryPlan> create(@Valid @RequestBody RecoveryPlan model) {
        RecoveryPlan saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/recovery-plans/" + saved.getRecoveryPlanId())).body(saved);
    }

    @GetMapping("/{id}")
    public RecoveryPlan get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RecoveryPlan> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public RecoveryPlan update(@PathVariable Long id, @Valid @RequestBody RecoveryPlan model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.Invoice;
import org.springframework.data.jpa.repository.JpaRepository;
import com.tcs.dnp.model.locking.LockTimeouts;
import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface InvoiceRepository extends JpaRepository<Invoice, Long> {

    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = LockTimeouts.HINT_LOCK_TIMEOUT, value = LockTimeouts.PESSIMISTIC_TIMEOUT_MS))
    @Query("select i from Invoice i where i.invoiceId = :id")
    Optional<Invoice> findByIdForUpdate(@Param("id") Long id);
}

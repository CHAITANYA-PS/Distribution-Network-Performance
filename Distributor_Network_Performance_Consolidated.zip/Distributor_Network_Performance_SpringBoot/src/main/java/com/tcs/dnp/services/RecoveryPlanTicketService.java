package com.tcs.dnp.services;

import com.tcs.dnp.model.RecoveryPlanTicket;
import com.tcs.dnp.repository.RecoveryPlanTicketRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanTicketService extends AbstractCrudService<RecoveryPlanTicket, Long> {
    public RecoveryPlanTicketService(RecoveryPlanTicketRepository repository) {
        super(repository, RecoveryPlanTicket.class);
    }
}

package com.tcs.dnp.services;

import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.stereotype.Component;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.TransactionDefinition;
import org.springframework.transaction.support.TransactionTemplate;

import java.util.function.Supplier;

/**
 * Programmatic transaction functions for multi-step business operations that must commit or
 * roll back as one unit (use {@code @Transactional} on service methods for the simple cases).
 */
@Component
public class TransactionalExecutor {
    private final PlatformTransactionManager txManager;

    public TransactionalExecutor(PlatformTransactionManager txManager) {
        this.txManager = txManager;
    }

    /** Joins an existing transaction or starts one. Any RuntimeException rolls it back. */
    public <T> T execute(Supplier<T> work) {
        return template(TransactionDefinition.PROPAGATION_REQUIRED, false).execute(s -> work.get());
    }

    /** Read-only transaction. */
    public <T> T executeReadOnly(Supplier<T> work) {
        return template(TransactionDefinition.PROPAGATION_REQUIRED, true).execute(s -> work.get());
    }

    /** Always starts a separate transaction (e.g. audit logging that must survive an outer rollback). */
    public <T> T executeInNewTransaction(Supplier<T> work) {
        return template(TransactionDefinition.PROPAGATION_REQUIRES_NEW, false).execute(s -> work.get());
    }

    /**
     * Runs the work in a fresh transaction and retries it when another transaction updated the same
     * row first (optimistic lock failure). After {@code maxAttempts} the exception is rethrown (HTTP 409).
     */
    public <T> T executeWithOptimisticRetry(int maxAttempts, Supplier<T> work) {
        if (maxAttempts < 1) {
            throw new IllegalArgumentException("maxAttempts must be >= 1");
        }
        ObjectOptimisticLockingFailureException last = null;
        for (int attempt = 1; attempt <= maxAttempts; attempt++) {
            try {
                return executeInNewTransaction(work);
            } catch (ObjectOptimisticLockingFailureException e) {
                last = e;
            }
        }
        throw last;
    }

    private TransactionTemplate template(int propagation, boolean readOnly) {
        TransactionTemplate t = new TransactionTemplate(txManager);
        t.setPropagationBehavior(propagation);
        t.setReadOnly(readOnly);
        return t;
    }
}

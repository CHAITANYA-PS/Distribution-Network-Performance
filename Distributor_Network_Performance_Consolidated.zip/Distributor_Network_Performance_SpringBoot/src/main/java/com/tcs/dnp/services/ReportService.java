package com.tcs.dnp.services;

import com.tcs.dnp.model.Report;
import com.tcs.dnp.repository.ReportRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportService extends AbstractCrudService<Report, Long> {
    public ReportService(ReportRepository repository) {
        super(repository, Report.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.OutstandingPaymentView;
import com.tcs.dnp.repository.OutstandingPaymentViewRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OutstandingPaymentViewService extends ReadOnlyViewService<OutstandingPaymentView, Long> {
    private final OutstandingPaymentViewRepository repository;

    public OutstandingPaymentViewService(OutstandingPaymentViewRepository repository) {
        super("OutstandingPaymentView");
        this.repository = repository;
    }

    @Override
    protected List<OutstandingPaymentView> findAllRows() {
        return repository.findAll();
    }

    @Override
    protected Optional<OutstandingPaymentView> findRow(Long id) {
        return repository.findById(id);
    }
}

package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="movement_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class MovementType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="movement_type_id")
 private Long movementTypeId;
 @Column(name="movement_type_name")
 private String movementTypeName;
 @Column(name="movement_direction")
 private String movementDirection;
}
package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="region",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Region implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="region_id")
 private Long regionId;
 @Column(name="region_name")
 private String regionName;
 @Column(name="description")
 private String description;
}
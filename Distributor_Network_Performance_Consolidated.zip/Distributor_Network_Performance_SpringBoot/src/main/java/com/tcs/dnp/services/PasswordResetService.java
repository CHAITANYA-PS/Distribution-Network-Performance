package com.tcs.dnp.services;

import com.tcs.dnp.model.PasswordReset;
import com.tcs.dnp.repository.PasswordResetRepository;
import org.springframework.stereotype.Service;

@Service
public class PasswordResetService extends AbstractCrudService<PasswordReset, Long> {
    public PasswordResetService(PasswordResetRepository repository) {
        super(repository, PasswordReset.class);
    }
}

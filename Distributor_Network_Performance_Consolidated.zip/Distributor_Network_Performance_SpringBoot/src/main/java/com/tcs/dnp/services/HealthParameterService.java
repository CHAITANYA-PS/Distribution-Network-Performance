package com.tcs.dnp.services;

import com.tcs.dnp.model.HealthParameter;
import com.tcs.dnp.repository.HealthParameterRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterService extends AbstractCrudService<HealthParameter, Long> {
    public HealthParameterService(HealthParameterRepository repository) {
        super(repository, HealthParameter.class);
    }
}

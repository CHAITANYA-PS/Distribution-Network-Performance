package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="credit_risk_assessment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CreditRiskAssessment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="risk_assessment_id")
 private Long riskAssessmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="credit_limit_id")
 private Long creditLimitId;
 @Column(name="risk_score")
 private BigDecimal riskScore;
 @Column(name="assessed_by")
 private Long assessedBy;
 @Column(name="assessed_at")
 private OffsetDateTime assessedAt;
}
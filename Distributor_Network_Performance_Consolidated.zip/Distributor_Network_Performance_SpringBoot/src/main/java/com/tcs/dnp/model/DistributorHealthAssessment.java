package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_health_assessment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorHealthAssessment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="assessment_id")
 private Long assessmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="parameter_weight_id")
 private Long parameterWeightId;
 @Column(name="reporting_period_id")
 private Long reportingPeriodId;
 @Column(name="score")
 private BigDecimal score;
 @Column(name="assessed_by")
 private Long assessedBy;
 @Column(name="assessed_at")
 private OffsetDateTime assessedAt;
 @Column(name="remarks")
 private String remarks;
}
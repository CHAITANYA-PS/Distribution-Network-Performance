package com.tcs.dnp.services;

import com.tcs.dnp.model.RecoveryManager;
import com.tcs.dnp.repository.RecoveryManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryManagerService extends AbstractCrudService<RecoveryManager, Long> {
    public RecoveryManagerService(RecoveryManagerRepository repository) {
        super(repository, RecoveryManager.class);
    }
}

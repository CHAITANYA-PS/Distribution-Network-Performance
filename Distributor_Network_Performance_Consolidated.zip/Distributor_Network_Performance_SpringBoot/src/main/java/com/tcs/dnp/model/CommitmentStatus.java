package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="commitment_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CommitmentStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="commitment_status_id")
 private Long commitmentStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="is_terminal")
 private Boolean isTerminal;
}
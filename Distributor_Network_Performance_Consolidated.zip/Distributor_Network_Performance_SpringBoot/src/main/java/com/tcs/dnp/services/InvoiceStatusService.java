package com.tcs.dnp.services;

import com.tcs.dnp.model.InvoiceStatus;
import com.tcs.dnp.repository.InvoiceStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceStatusService extends AbstractCrudService<InvoiceStatus, Long> {
    public InvoiceStatusService(InvoiceStatusRepository repository) {
        super(repository, InvoiceStatus.class);
    }
}

package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="distributor_credit_limit",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorCreditLimit implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="credit_limit_id")
 private Long creditLimitId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="credit_limit")
 private BigDecimal creditLimit;
 @Column(name="valid_from")
 private LocalDate validFrom;
 @Column(name="valid_to")
 private LocalDate validTo;
 @Column(name="approved_by")
 private Long approvedBy;
}
package com.tcs.dnp.services;

import com.tcs.dnp.model.TicketComment;
import com.tcs.dnp.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCommentService extends AbstractCrudService<TicketComment, Long> {
    public TicketCommentService(TicketCommentRepository repository) {
        super(repository, TicketComment.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.HealthParameterWeight;
import com.tcs.dnp.repository.HealthParameterWeightRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterWeightService extends AbstractCrudService<HealthParameterWeight, Long> {
    public HealthParameterWeightService(HealthParameterWeightRepository repository) {
        super(repository, HealthParameterWeight.class);
    }
}

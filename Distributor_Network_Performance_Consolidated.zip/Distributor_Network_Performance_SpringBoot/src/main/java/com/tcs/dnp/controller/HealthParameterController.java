package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.HealthParameter;
import com.tcs.dnp.services.HealthParameterService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/health-parameters")
public class HealthParameterController {
    private final HealthParameterService service;

    public HealthParameterController(HealthParameterService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<HealthParameter> create(@Valid @RequestBody HealthParameter model) {
        HealthParameter saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/health-parameters/" + saved.getParameterId())).body(saved);
    }

    @GetMapping("/{id}")
    public HealthParameter get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<HealthParameter> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public HealthParameter update(@PathVariable Long id, @Valid @RequestBody HealthParameter model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

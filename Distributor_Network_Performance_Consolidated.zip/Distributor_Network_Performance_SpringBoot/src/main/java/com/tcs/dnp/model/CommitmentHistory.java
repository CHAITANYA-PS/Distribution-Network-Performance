package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="commitment_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CommitmentHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="history_id")
 private Long historyId;
 @Column(name="commitment_id")
 private Long commitmentId;
 @Column(name="action")
 private String action;
 @Column(name="action_by")
 private Long actionBy;
 @Column(name="remarks")
 private String remarks;
 @Column(name="action_at")
 private OffsetDateTime actionAt;
}
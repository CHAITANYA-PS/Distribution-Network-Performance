package com.tcs.dnp.services;

import com.tcs.dnp.model.ExchangeHistory;
import com.tcs.dnp.repository.ExchangeHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeHistoryService extends AbstractCrudService<ExchangeHistory, Long> {
    public ExchangeHistoryService(ExchangeHistoryRepository repository) {
        super(repository, ExchangeHistory.class);
    }
}

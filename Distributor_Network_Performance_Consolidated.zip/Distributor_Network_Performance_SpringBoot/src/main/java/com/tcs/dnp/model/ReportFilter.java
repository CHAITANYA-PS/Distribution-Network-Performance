package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="report_filter",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ReportFilter implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="report_filter_id")
 private Long reportFilterId;
 @Column(name="report_id")
 private Long reportId;
 @Column(name="filter_name")
 private String filterName;
}
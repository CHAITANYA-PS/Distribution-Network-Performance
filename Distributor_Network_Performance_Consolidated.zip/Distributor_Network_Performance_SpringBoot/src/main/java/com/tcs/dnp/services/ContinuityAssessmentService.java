package com.tcs.dnp.services;

import com.tcs.dnp.model.ContinuityAssessment;
import com.tcs.dnp.repository.ContinuityAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityAssessmentService extends AbstractCrudService<ContinuityAssessment, Long> {
    public ContinuityAssessmentService(ContinuityAssessmentRepository repository) {
        super(repository, ContinuityAssessment.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.Manufacturer;
import com.tcs.dnp.repository.ManufacturerRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerService extends AbstractCrudService<Manufacturer, Long> {
    public ManufacturerService(ManufacturerRepository repository) {
        super(repository, Manufacturer.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.DistributorCategory;
import com.tcs.dnp.repository.DistributorCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorCategoryService extends AbstractCrudService<DistributorCategory, Long> {
    public DistributorCategoryService(DistributorCategoryRepository repository) {
        super(repository, DistributorCategory.class);
    }
}

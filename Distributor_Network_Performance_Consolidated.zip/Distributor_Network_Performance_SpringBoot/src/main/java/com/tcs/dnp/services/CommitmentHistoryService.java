package com.tcs.dnp.services;

import com.tcs.dnp.model.CommitmentHistory;
import com.tcs.dnp.repository.CommitmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentHistoryService extends AbstractCrudService<CommitmentHistory, Long> {
    public CommitmentHistoryService(CommitmentHistoryRepository repository) {
        super(repository, CommitmentHistory.class);
    }
}

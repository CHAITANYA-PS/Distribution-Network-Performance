package com.tcs.dnp.services;

import com.tcs.dnp.model.ReportFilter;
import com.tcs.dnp.repository.ReportFilterRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterService extends AbstractCrudService<ReportFilter, Long> {
    public ReportFilterService(ReportFilterRepository repository) {
        super(repository, ReportFilter.class);
    }
}

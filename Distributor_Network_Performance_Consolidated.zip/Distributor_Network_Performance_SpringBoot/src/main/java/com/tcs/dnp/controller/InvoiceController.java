package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.Invoice;
import com.tcs.dnp.services.InvoiceService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/invoices")
public class InvoiceController {
    private final InvoiceService service;

    public InvoiceController(InvoiceService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Invoice> create(@Valid @RequestBody Invoice model) {
        Invoice saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/invoices/" + saved.getInvoiceId())).body(saved);
    }

    @GetMapping("/{id}")
    public Invoice get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Invoice> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Invoice update(@PathVariable Long id, @Valid @RequestBody Invoice model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

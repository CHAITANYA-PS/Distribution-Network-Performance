package com.tcs.dnp.services;

import com.tcs.dnp.model.MeasurementUnit;
import com.tcs.dnp.repository.MeasurementUnitRepository;
import org.springframework.stereotype.Service;

@Service
public class MeasurementUnitService extends AbstractCrudService<MeasurementUnit, Long> {
    public MeasurementUnitService(MeasurementUnitRepository repository) {
        super(repository, MeasurementUnit.class);
    }
}

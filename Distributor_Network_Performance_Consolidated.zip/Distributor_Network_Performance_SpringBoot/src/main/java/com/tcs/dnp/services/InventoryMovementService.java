package com.tcs.dnp.services;

import com.tcs.dnp.model.InventoryMovement;
import com.tcs.dnp.repository.InventoryMovementRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryMovementService extends AbstractCrudService<InventoryMovement, Long> {
    public InventoryMovementService(InventoryMovementRepository repository) {
        super(repository, InventoryMovement.class);
    }
}

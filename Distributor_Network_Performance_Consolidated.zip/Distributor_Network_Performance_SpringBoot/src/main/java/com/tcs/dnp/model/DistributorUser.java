package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="distributor_user",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorUser implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="distributor_id")
 private Long distributorId;
}
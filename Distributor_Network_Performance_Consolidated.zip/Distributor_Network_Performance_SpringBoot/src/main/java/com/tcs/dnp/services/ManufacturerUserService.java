package com.tcs.dnp.services;

import com.tcs.dnp.model.ManufacturerUser;
import com.tcs.dnp.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerUserService extends AbstractCrudService<ManufacturerUser, Long> {
    public ManufacturerUserService(ManufacturerUserRepository repository) {
        super(repository, ManufacturerUser.class);
    }
}

package com.tcs.dnp.model.locking;

import org.springframework.orm.ObjectOptimisticLockingFailureException;

import java.util.Objects;

/**
 * Optimistic locking function: compares the version a client sent with the version stored in the
 * database and raises {@link ObjectOptimisticLockingFailureException} (mapped to HTTP 409) on mismatch.
 * A client that sends no version opts out of the early check; Hibernate still protects the flush.
 */
public final class OptimisticLockGuard {
    private OptimisticLockGuard() {
    }

    public static void verify(Class<?> entityType, Object id, Long clientVersion, Long storedVersion) {
        if (clientVersion != null && !Objects.equals(clientVersion, storedVersion)) {
            throw new ObjectOptimisticLockingFailureException(entityType, id);
        }
    }
}

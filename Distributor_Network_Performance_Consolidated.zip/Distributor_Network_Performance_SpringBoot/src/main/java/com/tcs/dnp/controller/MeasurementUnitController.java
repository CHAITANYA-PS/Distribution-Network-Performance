package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.MeasurementUnit;
import com.tcs.dnp.services.MeasurementUnitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/measurement-units")
public class MeasurementUnitController {
    private final MeasurementUnitService service;

    public MeasurementUnitController(MeasurementUnitService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<MeasurementUnit> create(@Valid @RequestBody MeasurementUnit model) {
        MeasurementUnit saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/measurement-units/" + saved.getMeasurementUnitId())).body(saved);
    }

    @GetMapping("/{id}")
    public MeasurementUnit get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<MeasurementUnit> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public MeasurementUnit update(@PathVariable Long id, @Valid @RequestBody MeasurementUnit model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

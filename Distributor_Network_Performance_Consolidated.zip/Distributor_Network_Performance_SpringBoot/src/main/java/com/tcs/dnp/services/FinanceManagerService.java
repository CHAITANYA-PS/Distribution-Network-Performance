package com.tcs.dnp.services;

import com.tcs.dnp.model.FinanceManager;
import com.tcs.dnp.repository.FinanceManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class FinanceManagerService extends AbstractCrudService<FinanceManager, Long> {
    public FinanceManagerService(FinanceManagerRepository repository) {
        super(repository, FinanceManager.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.EmissionFactor;
import com.tcs.dnp.repository.EmissionFactorRepository;
import org.springframework.stereotype.Service;

@Service
public class EmissionFactorService extends AbstractCrudService<EmissionFactor, Long> {
    public EmissionFactorService(EmissionFactorRepository repository) {
        super(repository, EmissionFactor.class);
    }
}

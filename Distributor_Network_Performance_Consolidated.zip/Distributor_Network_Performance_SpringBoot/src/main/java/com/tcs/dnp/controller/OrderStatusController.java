package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.OrderStatus;
import com.tcs.dnp.services.OrderStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/order-statuses")
public class OrderStatusController {
    private final OrderStatusService service;

    public OrderStatusController(OrderStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<OrderStatus> create(@Valid @RequestBody OrderStatus model) {
        OrderStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/order-statuses/" + saved.getOrderStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public OrderStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<OrderStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public OrderStatus update(@PathVariable Long id, @Valid @RequestBody OrderStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

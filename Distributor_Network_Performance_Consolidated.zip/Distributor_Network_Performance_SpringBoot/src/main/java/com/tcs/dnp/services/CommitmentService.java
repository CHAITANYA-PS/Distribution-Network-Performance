package com.tcs.dnp.services;

import com.tcs.dnp.model.Commitment;
import com.tcs.dnp.repository.CommitmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentService extends AbstractCrudService<Commitment, Long> {
    public CommitmentService(CommitmentRepository repository) {
        super(repository, Commitment.class);
    }
}

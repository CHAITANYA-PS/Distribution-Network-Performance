package com.tcs.dnp.services;

import com.tcs.dnp.model.Region;
import com.tcs.dnp.repository.RegionRepository;
import org.springframework.stereotype.Service;

@Service
public class RegionService extends AbstractCrudService<Region, Long> {
    public RegionService(RegionRepository repository) {
        super(repository, Region.class);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.MovementType;
import com.tcs.dnp.services.MovementTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/movement-types")
public class MovementTypeController {
    private final MovementTypeService service;

    public MovementTypeController(MovementTypeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<MovementType> create(@Valid @RequestBody MovementType model) {
        MovementType saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/movement-types/" + saved.getMovementTypeId())).body(saved);
    }

    @GetMapping("/{id}")
    public MovementType get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<MovementType> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public MovementType update(@PathVariable Long id, @Valid @RequestBody MovementType model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.DistributorOrder;
import com.tcs.dnp.repository.DistributorOrderRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorOrderService extends AbstractCrudService<DistributorOrder, Long> {
    public DistributorOrderService(DistributorOrderRepository repository) {
        super(repository, DistributorOrder.class);
    }
}

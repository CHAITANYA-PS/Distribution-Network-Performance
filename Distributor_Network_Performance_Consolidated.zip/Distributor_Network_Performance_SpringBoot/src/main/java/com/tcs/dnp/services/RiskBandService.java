package com.tcs.dnp.services;

import com.tcs.dnp.model.RiskBand;
import com.tcs.dnp.repository.RiskBandRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskBandService extends AbstractCrudService<RiskBand, Long> {
    public RiskBandService(RiskBandRepository repository) {
        super(repository, RiskBand.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.DistributorUser;
import com.tcs.dnp.repository.DistributorUserRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorUserService extends AbstractCrudService<DistributorUser, Long> {
    public DistributorUserService(DistributorUserRepository repository) {
        super(repository, DistributorUser.class);
    }
}

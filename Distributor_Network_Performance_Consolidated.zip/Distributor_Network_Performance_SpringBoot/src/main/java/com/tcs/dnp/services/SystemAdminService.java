package com.tcs.dnp.services;

import com.tcs.dnp.model.SystemAdmin;
import com.tcs.dnp.repository.SystemAdminRepository;
import org.springframework.stereotype.Service;

@Service
public class SystemAdminService extends AbstractCrudService<SystemAdmin, Long> {
    public SystemAdminService(SystemAdminRepository repository) {
        super(repository, SystemAdmin.class);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.TransportEmissionView;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

/** Read-only repository: a view cannot be saved or deleted. */
public interface TransportEmissionViewRepository extends Repository<TransportEmissionView, Long> {
    List<TransportEmissionView> findAll();

    Optional<TransportEmissionView> findById(Long id);
}

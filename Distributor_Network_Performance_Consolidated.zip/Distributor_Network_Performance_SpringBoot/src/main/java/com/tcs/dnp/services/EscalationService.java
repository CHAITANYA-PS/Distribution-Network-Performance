package com.tcs.dnp.services;

import com.tcs.dnp.model.Escalation;
import com.tcs.dnp.repository.EscalationRepository;
import org.springframework.stereotype.Service;

@Service
public class EscalationService extends AbstractCrudService<Escalation, Long> {
    public EscalationService(EscalationRepository repository) {
        super(repository, Escalation.class);
    }
}

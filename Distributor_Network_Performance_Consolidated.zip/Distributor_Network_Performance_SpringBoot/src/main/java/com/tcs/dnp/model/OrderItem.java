package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="order_item",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class OrderItem implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="order_item_id")
 private Long orderItemId;
 @Column(name="order_id")
 private Long orderId;
 @Column(name="product_id")
 private Long productId;
 @Column(name="quantity")
 private BigDecimal quantity;
 @Column(name="unit_price")
 private BigDecimal unitPrice;
}
package com.tcs.dnp.services;

import com.tcs.dnp.model.MovementType;
import com.tcs.dnp.repository.MovementTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class MovementTypeService extends AbstractCrudService<MovementType, Long> {
    public MovementTypeService(MovementTypeRepository repository) {
        super(repository, MovementType.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.OrderStatus;
import com.tcs.dnp.repository.OrderStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusService extends AbstractCrudService<OrderStatus, Long> {
    public OrderStatusService(OrderStatusRepository repository) {
        super(repository, OrderStatus.class);
    }
}

package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="risk_level",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RiskLevel implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="risk_level_id")
 private Long riskLevelId;
 @Column(name="risk_level_name")
 private String riskLevelName;
 @Column(name="severity_rank")
 private Integer severityRank;
}
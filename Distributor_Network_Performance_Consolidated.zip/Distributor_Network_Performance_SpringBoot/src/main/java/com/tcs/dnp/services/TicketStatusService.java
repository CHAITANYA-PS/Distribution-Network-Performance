package com.tcs.dnp.services;

import com.tcs.dnp.model.TicketStatus;
import com.tcs.dnp.repository.TicketStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusService extends AbstractCrudService<TicketStatus, Long> {
    public TicketStatusService(TicketStatusRepository repository) {
        super(repository, TicketStatus.class);
    }
}

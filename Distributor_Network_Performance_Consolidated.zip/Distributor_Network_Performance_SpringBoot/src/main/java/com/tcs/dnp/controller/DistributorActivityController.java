package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.DistributorActivity;
import com.tcs.dnp.services.DistributorActivityService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor-activities")
public class DistributorActivityController {
    private final DistributorActivityService service;

    public DistributorActivityController(DistributorActivityService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DistributorActivity> create(@Valid @RequestBody DistributorActivity model) {
        DistributorActivity saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributor-activities/" + saved.getActivityId())).body(saved);
    }

    @GetMapping("/{id}")
    public DistributorActivity get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<DistributorActivity> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public DistributorActivity update(@PathVariable Long id, @Valid @RequestBody DistributorActivity model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

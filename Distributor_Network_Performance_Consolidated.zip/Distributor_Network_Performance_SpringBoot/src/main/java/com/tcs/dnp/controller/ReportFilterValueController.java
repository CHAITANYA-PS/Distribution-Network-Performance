package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.ReportFilterValue;
import com.tcs.dnp.services.ReportFilterValueService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/report-filter-values")
public class ReportFilterValueController {
    private final ReportFilterValueService service;

    public ReportFilterValueController(ReportFilterValueService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ReportFilterValue> create(@Valid @RequestBody ReportFilterValue model) {
        ReportFilterValue saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/report-filter-values/" + saved.getReportFilterValueId())).body(saved);
    }

    @GetMapping("/{id}")
    public ReportFilterValue get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ReportFilterValue> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ReportFilterValue update(@PathVariable Long id, @Valid @RequestBody ReportFilterValue model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

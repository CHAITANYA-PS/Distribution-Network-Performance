package com.tcs.dnp.services;

import com.tcs.dnp.model.PaymentStatus;
import com.tcs.dnp.repository.PaymentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentStatusService extends AbstractCrudService<PaymentStatus, Long> {
    public PaymentStatusService(PaymentStatusRepository repository) {
        super(repository, PaymentStatus.class);
    }
}

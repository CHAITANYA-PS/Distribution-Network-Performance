package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.FinanceManager;
import com.tcs.dnp.services.FinanceManagerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/finance-managers")
public class FinanceManagerController {
    private final FinanceManagerService service;

    public FinanceManagerController(FinanceManagerService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<FinanceManager> create(@Valid @RequestBody FinanceManager model) {
        FinanceManager saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/finance-managers/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public FinanceManager get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<FinanceManager> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public FinanceManager update(@PathVariable Long id, @Valid @RequestBody FinanceManager model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

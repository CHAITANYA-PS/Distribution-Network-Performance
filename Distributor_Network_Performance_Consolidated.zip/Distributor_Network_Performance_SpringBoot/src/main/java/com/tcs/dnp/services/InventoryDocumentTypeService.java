package com.tcs.dnp.services;

import com.tcs.dnp.model.InventoryDocumentType;
import com.tcs.dnp.repository.InventoryDocumentTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentTypeService extends AbstractCrudService<InventoryDocumentType, Long> {
    public InventoryDocumentTypeService(InventoryDocumentTypeRepository repository) {
        super(repository, InventoryDocumentType.class);
    }
}

package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="continuity_assessment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ContinuityAssessment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="continuity_assessment_id")
 private Long continuityAssessmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="continuity_status_id")
 private Long continuityStatusId;
 @Column(name="risk_level_id")
 private Long riskLevelId;
 @Column(name="assessed_by")
 private Long assessedBy;
 @Column(name="assessment_date")
 private OffsetDateTime assessmentDate;
 @Column(name="remarks")
 private String remarks;
}
package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="department",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Department implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="department_id")
 private Long departmentId;
 @Column(name="department_name")
 private String departmentName;
}
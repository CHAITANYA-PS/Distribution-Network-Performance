package com.tcs.dnp.services;

import com.tcs.dnp.model.VehicleType;
import com.tcs.dnp.repository.VehicleTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class VehicleTypeService extends AbstractCrudService<VehicleType, Long> {
    public VehicleTypeService(VehicleTypeRepository repository) {
        super(repository, VehicleType.class);
    }
}

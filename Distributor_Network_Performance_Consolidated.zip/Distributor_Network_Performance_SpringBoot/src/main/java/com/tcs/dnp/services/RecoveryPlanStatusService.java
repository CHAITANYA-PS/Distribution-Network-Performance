package com.tcs.dnp.services;

import com.tcs.dnp.model.RecoveryPlanStatus;
import com.tcs.dnp.repository.RecoveryPlanStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanStatusService extends AbstractCrudService<RecoveryPlanStatus, Long> {
    public RecoveryPlanStatusService(RecoveryPlanStatusRepository repository) {
        super(repository, RecoveryPlanStatus.class);
    }
}

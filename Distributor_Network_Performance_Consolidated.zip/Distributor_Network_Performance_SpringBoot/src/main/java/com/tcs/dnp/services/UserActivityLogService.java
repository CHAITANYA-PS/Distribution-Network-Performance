package com.tcs.dnp.services;

import com.tcs.dnp.model.UserActivityLog;
import com.tcs.dnp.repository.UserActivityLogRepository;
import org.springframework.stereotype.Service;

@Service
public class UserActivityLogService extends AbstractCrudService<UserActivityLog, Long> {
    public UserActivityLogService(UserActivityLogRepository repository) {
        super(repository, UserActivityLog.class);
    }
}

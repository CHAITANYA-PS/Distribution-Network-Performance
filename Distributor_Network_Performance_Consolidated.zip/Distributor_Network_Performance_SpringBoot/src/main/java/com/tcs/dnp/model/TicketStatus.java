package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="ticket_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_status_id")
 private Long ticketStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="sequence_number")
 private Integer sequenceNumber;
 @Column(name="is_terminal")
 private Boolean isTerminal;
}
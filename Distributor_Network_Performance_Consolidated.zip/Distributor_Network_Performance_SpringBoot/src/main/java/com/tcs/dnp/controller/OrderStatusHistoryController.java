package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.OrderStatusHistory;
import com.tcs.dnp.services.OrderStatusHistoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/order-status-histories")
public class OrderStatusHistoryController {
    private final OrderStatusHistoryService service;

    public OrderStatusHistoryController(OrderStatusHistoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<OrderStatusHistory> create(@Valid @RequestBody OrderStatusHistory model) {
        OrderStatusHistory saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/order-status-histories/" + saved.getOrderStatusHistoryId())).body(saved);
    }

    @GetMapping("/{id}")
    public OrderStatusHistory get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<OrderStatusHistory> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public OrderStatusHistory update(@PathVariable Long id, @Valid @RequestBody OrderStatusHistory model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.ContinuityStatusType;
import com.tcs.dnp.repository.ContinuityStatusTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityStatusTypeService extends AbstractCrudService<ContinuityStatusType, Long> {
    public ContinuityStatusTypeService(ContinuityStatusTypeRepository repository) {
        super(repository, ContinuityStatusType.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.Department;
import com.tcs.dnp.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService extends AbstractCrudService<Department, Long> {
    public DepartmentService(DepartmentRepository repository) {
        super(repository, Department.class);
    }
}

package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="warehouse",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Warehouse implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="warehouse_id")
 private Long warehouseId;
 @Column(name="warehouse_code")
 private String warehouseCode;
 @Column(name="warehouse_name")
 private String warehouseName;
 @Column(name="region_id")
 private Long regionId;
 @Column(name="location")
 private String location;
 @Column(name="capacity")
 private BigDecimal capacity;
 @Column(name="status")
 private String status;
}
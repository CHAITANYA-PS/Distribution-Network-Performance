package com.tcs.dnp.services;

import com.tcs.dnp.model.NotificationType;
import com.tcs.dnp.repository.NotificationTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationTypeService extends AbstractCrudService<NotificationType, Long> {
    public NotificationTypeService(NotificationTypeRepository repository) {
        super(repository, NotificationType.class);
    }
}

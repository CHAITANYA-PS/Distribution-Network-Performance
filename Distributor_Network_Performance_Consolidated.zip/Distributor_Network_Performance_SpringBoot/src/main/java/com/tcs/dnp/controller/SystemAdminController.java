package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.SystemAdmin;
import com.tcs.dnp.services.SystemAdminService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/system-admins")
public class SystemAdminController {
    private final SystemAdminService service;

    public SystemAdminController(SystemAdminService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<SystemAdmin> create(@Valid @RequestBody SystemAdmin model) {
        SystemAdmin saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/system-admins/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public SystemAdmin get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<SystemAdmin> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public SystemAdmin update(@PathVariable Long id, @Valid @RequestBody SystemAdmin model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

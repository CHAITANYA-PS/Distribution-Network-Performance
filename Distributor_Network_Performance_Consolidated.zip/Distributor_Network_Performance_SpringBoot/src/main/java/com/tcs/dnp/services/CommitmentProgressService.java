package com.tcs.dnp.services;

import com.tcs.dnp.model.CommitmentProgress;
import com.tcs.dnp.repository.CommitmentProgressRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentProgressService extends AbstractCrudService<CommitmentProgress, Long> {
    public CommitmentProgressService(CommitmentProgressRepository repository) {
        super(repository, CommitmentProgress.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.ShipmentItem;
import com.tcs.dnp.repository.ShipmentItemRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentItemService extends AbstractCrudService<ShipmentItem, Long> {
    public ShipmentItemService(ShipmentItemRepository repository) {
        super(repository, ShipmentItem.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.ActivityType;
import com.tcs.dnp.repository.ActivityTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ActivityTypeService extends AbstractCrudService<ActivityType, Long> {
    public ActivityTypeService(ActivityTypeRepository repository) {
        super(repository, ActivityType.class);
    }
}

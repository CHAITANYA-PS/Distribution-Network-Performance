package com.tcs.dnp.services;

import com.tcs.dnp.model.Notification;
import com.tcs.dnp.repository.NotificationRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationService extends AbstractCrudService<Notification, Long> {
    public NotificationService(NotificationRepository repository) {
        super(repository, Notification.class);
    }
}

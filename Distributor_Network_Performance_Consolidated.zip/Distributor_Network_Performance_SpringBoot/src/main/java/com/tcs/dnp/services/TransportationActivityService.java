package com.tcs.dnp.services;

import com.tcs.dnp.model.TransportationActivity;
import com.tcs.dnp.repository.TransportationActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class TransportationActivityService extends AbstractCrudService<TransportationActivity, Long> {
    public TransportationActivityService(TransportationActivityRepository repository) {
        super(repository, TransportationActivity.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.Category;
import com.tcs.dnp.repository.CategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CategoryService extends AbstractCrudService<Category, Long> {
    public CategoryService(CategoryRepository repository) {
        super(repository, Category.class);
    }
}

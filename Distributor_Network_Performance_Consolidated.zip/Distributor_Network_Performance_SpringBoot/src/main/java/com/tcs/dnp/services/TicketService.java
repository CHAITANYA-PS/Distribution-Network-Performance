package com.tcs.dnp.services;

import com.tcs.dnp.model.Ticket;
import com.tcs.dnp.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketService extends AbstractCrudService<Ticket, Long> {
    public TicketService(TicketRepository repository) {
        super(repository, Ticket.class);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.CreditRiskAssessment;
import com.tcs.dnp.repository.CreditRiskAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CreditRiskAssessmentService extends AbstractCrudService<CreditRiskAssessment, Long> {
    public CreditRiskAssessmentService(CreditRiskAssessmentRepository repository) {
        super(repository, CreditRiskAssessment.class);
    }
}

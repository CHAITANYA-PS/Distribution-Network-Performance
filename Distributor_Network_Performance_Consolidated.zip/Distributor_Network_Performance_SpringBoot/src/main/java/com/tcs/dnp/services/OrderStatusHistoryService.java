package com.tcs.dnp.services;

import com.tcs.dnp.model.OrderStatusHistory;
import com.tcs.dnp.repository.OrderStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusHistoryService extends AbstractCrudService<OrderStatusHistory, Long> {
    public OrderStatusHistoryService(OrderStatusHistoryRepository repository) {
        super(repository, OrderStatusHistory.class);
    }
}

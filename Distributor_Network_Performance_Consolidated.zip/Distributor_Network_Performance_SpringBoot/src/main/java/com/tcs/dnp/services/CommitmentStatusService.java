package com.tcs.dnp.services;

import com.tcs.dnp.model.CommitmentStatus;
import com.tcs.dnp.repository.CommitmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentStatusService extends AbstractCrudService<CommitmentStatus, Long> {
    public CommitmentStatusService(CommitmentStatusRepository repository) {
        super(repository, CommitmentStatus.class);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.ShipmentItem;
import com.tcs.dnp.services.ShipmentItemService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/shipment-items")
public class ShipmentItemController {
    private final ShipmentItemService service;

    public ShipmentItemController(ShipmentItemService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ShipmentItem> create(@Valid @RequestBody ShipmentItem model) {
        ShipmentItem saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/shipment-items/" + saved.getShipmentItemId())).body(saved);
    }

    @GetMapping("/{id}")
    public ShipmentItem get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ShipmentItem> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ShipmentItem update(@PathVariable Long id, @Valid @RequestBody ShipmentItem model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

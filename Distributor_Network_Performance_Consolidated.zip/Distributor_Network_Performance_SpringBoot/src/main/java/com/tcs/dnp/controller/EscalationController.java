package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.Escalation;
import com.tcs.dnp.services.EscalationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/escalations")
public class EscalationController {
    private final EscalationService service;

    public EscalationController(EscalationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Escalation> create(@Valid @RequestBody Escalation model) {
        Escalation saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/escalations/" + saved.getEscalationId())).body(saved);
    }

    @GetMapping("/{id}")
    public Escalation get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Escalation> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Escalation update(@PathVariable Long id, @Valid @RequestBody Escalation model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

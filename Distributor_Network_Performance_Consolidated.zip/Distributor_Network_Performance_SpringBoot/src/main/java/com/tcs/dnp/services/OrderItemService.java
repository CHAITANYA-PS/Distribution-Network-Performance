package com.tcs.dnp.services;

import com.tcs.dnp.model.OrderItem;
import com.tcs.dnp.repository.OrderItemRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService extends AbstractCrudService<OrderItem, Long> {
    public OrderItemService(OrderItemRepository repository) {
        super(repository, OrderItem.class);
    }
}

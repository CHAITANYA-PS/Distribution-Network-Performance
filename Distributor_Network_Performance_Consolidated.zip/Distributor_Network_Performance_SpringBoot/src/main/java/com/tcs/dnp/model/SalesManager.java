package com.tcs.dnp.model;
import com.tcs.dnp.model.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="sales_manager",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class SalesManager implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="region_id")
 private Long regionId;
}
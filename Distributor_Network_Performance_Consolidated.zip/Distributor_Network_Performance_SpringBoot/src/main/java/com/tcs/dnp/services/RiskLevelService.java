package com.tcs.dnp.services;

import com.tcs.dnp.model.RiskLevel;
import com.tcs.dnp.repository.RiskLevelRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskLevelService extends AbstractCrudService<RiskLevel, Long> {
    public RiskLevelService(RiskLevelRepository repository) {
        super(repository, RiskLevel.class);
    }
}

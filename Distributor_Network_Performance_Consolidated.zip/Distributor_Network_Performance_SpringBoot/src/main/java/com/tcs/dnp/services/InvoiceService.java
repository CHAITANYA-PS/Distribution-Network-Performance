package com.tcs.dnp.services;

import com.tcs.dnp.model.Invoice;
import com.tcs.dnp.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService extends AbstractCrudService<Invoice, Long> {
    public InvoiceService(InvoiceRepository repository) {
        super(repository, Invoice.class);
    }
}

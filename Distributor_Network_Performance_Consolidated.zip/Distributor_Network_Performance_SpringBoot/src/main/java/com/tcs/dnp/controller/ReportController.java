package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.Report;
import com.tcs.dnp.services.ReportService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/reports")
public class ReportController {
    private final ReportService service;

    public ReportController(ReportService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Report> create(@Valid @RequestBody Report model) {
        Report saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/reports/" + saved.getReportId())).body(saved);
    }

    @GetMapping("/{id}")
    public Report get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Report> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Report update(@PathVariable Long id, @Valid @RequestBody Report model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

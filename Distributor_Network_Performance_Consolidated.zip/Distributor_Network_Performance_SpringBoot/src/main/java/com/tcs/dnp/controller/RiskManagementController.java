package com.tcs.dnp.controller;

import jakarta.validation.Valid;
import com.tcs.dnp.model.CreditRiskAssessment;
import com.tcs.dnp.services.CreditRiskAssessmentService;
import com.tcs.dnp.model.DistributorCreditLimit;
import com.tcs.dnp.services.DistributorCreditLimitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

/** Credit risk assessments and credit limits. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/risk-management")
public class RiskManagementController {
    private final CreditRiskAssessmentService creditRiskAssessmentService;
    private final DistributorCreditLimitService distributorCreditLimitService;

    public RiskManagementController(CreditRiskAssessmentService creditRiskAssessmentService, DistributorCreditLimitService distributorCreditLimitService) {
        this.creditRiskAssessmentService = creditRiskAssessmentService;
        this.distributorCreditLimitService = distributorCreditLimitService;
    }

    @PostMapping("/assessments")
    public ResponseEntity<CreditRiskAssessment> createCreditRiskAssessment(@Valid @RequestBody CreditRiskAssessment model) {
        CreditRiskAssessment saved = creditRiskAssessmentService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/risk-management/assessments/" + saved.getRiskAssessmentId())).body(saved);
    }

    @GetMapping("/assessments")
    public List<CreditRiskAssessment> getAllCreditRiskAssessment() {
        return creditRiskAssessmentService.getAll();
    }

    @GetMapping("/assessments/{id}")
    public CreditRiskAssessment getCreditRiskAssessment(@PathVariable Long id) {
        return creditRiskAssessmentService.get(id);
    }

    @PutMapping("/assessments/{id}")
    public CreditRiskAssessment updateCreditRiskAssessment(@PathVariable Long id, @Valid @RequestBody CreditRiskAssessment model) {
        return creditRiskAssessmentService.update(id, model);
    }

    @DeleteMapping("/assessments/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCreditRiskAssessment(@PathVariable Long id) {
        creditRiskAssessmentService.delete(id);
    }

    @PostMapping("/credit-limits")
    public ResponseEntity<DistributorCreditLimit> createDistributorCreditLimit(@Valid @RequestBody DistributorCreditLimit model) {
        DistributorCreditLimit saved = distributorCreditLimitService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/risk-management/credit-limits/" + saved.getCreditLimitId())).body(saved);
    }

    @GetMapping("/credit-limits")
    public List<DistributorCreditLimit> getAllDistributorCreditLimit() {
        return distributorCreditLimitService.getAll();
    }

    @GetMapping("/credit-limits/{id}")
    public DistributorCreditLimit getDistributorCreditLimit(@PathVariable Long id) {
        return distributorCreditLimitService.get(id);
    }

    @PutMapping("/credit-limits/{id}")
    public DistributorCreditLimit updateDistributorCreditLimit(@PathVariable Long id, @Valid @RequestBody DistributorCreditLimit model) {
        return distributorCreditLimitService.update(id, model);
    }

    @DeleteMapping("/credit-limits/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteDistributorCreditLimit(@PathVariable Long id) {
        distributorCreditLimitService.delete(id);
    }
}

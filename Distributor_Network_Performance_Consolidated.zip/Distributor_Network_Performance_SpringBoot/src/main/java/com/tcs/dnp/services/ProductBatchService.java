package com.tcs.dnp.services;

import com.tcs.dnp.model.ProductBatch;
import com.tcs.dnp.repository.ProductBatchRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductBatchService extends AbstractCrudService<ProductBatch, Long> {
    public ProductBatchService(ProductBatchRepository repository) {
        super(repository, ProductBatch.class);
    }
}

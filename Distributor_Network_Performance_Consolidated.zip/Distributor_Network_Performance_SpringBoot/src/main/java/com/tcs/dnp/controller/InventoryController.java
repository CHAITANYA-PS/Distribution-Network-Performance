package com.tcs.dnp.controller;

import jakarta.validation.Valid;
import com.tcs.dnp.model.Product;
import com.tcs.dnp.services.ProductService;
import com.tcs.dnp.model.WarehouseStock;
import com.tcs.dnp.services.WarehouseStockService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

/** Inventory: products and warehouse stock. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/inventory")
public class InventoryController {
    private final ProductService productService;
    private final WarehouseStockService warehouseStockService;

    public InventoryController(ProductService productService, WarehouseStockService warehouseStockService) {
        this.productService = productService;
        this.warehouseStockService = warehouseStockService;
    }

    @PostMapping("/products")
    public ResponseEntity<Product> createProduct(@Valid @RequestBody Product model) {
        Product saved = productService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/inventory/products/" + saved.getProductId())).body(saved);
    }

    @GetMapping("/products")
    public List<Product> getAllProduct() {
        return productService.getAll();
    }

    @GetMapping("/products/{id}")
    public Product getProduct(@PathVariable Long id) {
        return productService.get(id);
    }

    @PutMapping("/products/{id}")
    public Product updateProduct(@PathVariable Long id, @Valid @RequestBody Product model) {
        return productService.update(id, model);
    }

    @DeleteMapping("/products/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteProduct(@PathVariable Long id) {
        productService.delete(id);
    }

    @PostMapping("/stocks")
    public ResponseEntity<WarehouseStock> createWarehouseStock(@Valid @RequestBody WarehouseStock model) {
        WarehouseStock saved = warehouseStockService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/inventory/stocks/" + saved.getWarehouseStockId())).body(saved);
    }

    @GetMapping("/stocks")
    public List<WarehouseStock> getAllWarehouseStock() {
        return warehouseStockService.getAll();
    }

    @GetMapping("/stocks/{id}")
    public WarehouseStock getWarehouseStock(@PathVariable Long id) {
        return warehouseStockService.get(id);
    }

    @PutMapping("/stocks/{id}")
    public WarehouseStock updateWarehouseStock(@PathVariable Long id, @Valid @RequestBody WarehouseStock model) {
        return warehouseStockService.update(id, model);
    }

    @DeleteMapping("/stocks/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteWarehouseStock(@PathVariable Long id) {
        warehouseStockService.delete(id);
    }
}

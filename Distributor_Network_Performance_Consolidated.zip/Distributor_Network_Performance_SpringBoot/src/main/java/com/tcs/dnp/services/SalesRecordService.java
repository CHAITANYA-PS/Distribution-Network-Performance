package com.tcs.dnp.services;

import com.tcs.dnp.model.SalesRecord;
import com.tcs.dnp.repository.SalesRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesRecordService extends AbstractCrudService<SalesRecord, Long> {
    public SalesRecordService(SalesRecordRepository repository) {
        super(repository, SalesRecord.class);
    }
}

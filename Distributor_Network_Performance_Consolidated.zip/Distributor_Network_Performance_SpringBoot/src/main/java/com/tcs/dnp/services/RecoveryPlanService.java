package com.tcs.dnp.services;

import com.tcs.dnp.model.RecoveryPlan;
import com.tcs.dnp.repository.RecoveryPlanRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanService extends AbstractCrudService<RecoveryPlan, Long> {
    public RecoveryPlanService(RecoveryPlanRepository repository) {
        super(repository, RecoveryPlan.class);
    }
}

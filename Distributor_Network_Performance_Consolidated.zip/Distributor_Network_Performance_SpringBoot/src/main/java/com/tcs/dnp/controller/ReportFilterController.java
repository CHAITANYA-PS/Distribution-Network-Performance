package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.ReportFilter;
import com.tcs.dnp.services.ReportFilterService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/report-filters")
public class ReportFilterController {
    private final ReportFilterService service;

    public ReportFilterController(ReportFilterService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ReportFilter> create(@Valid @RequestBody ReportFilter model) {
        ReportFilter saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/report-filters/" + saved.getReportFilterId())).body(saved);
    }

    @GetMapping("/{id}")
    public ReportFilter get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ReportFilter> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ReportFilter update(@PathVariable Long id, @Valid @RequestBody ReportFilter model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.model.SalesManager;
import com.tcs.dnp.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesManagerService extends AbstractCrudService<SalesManager, Long> {
    public SalesManagerService(SalesManagerRepository repository) {
        super(repository, SalesManager.class);
    }
}

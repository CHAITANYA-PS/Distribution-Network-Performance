package com.tcs.dnp.services;

import com.tcs.dnp.model.DistributorHealthAssessment;
import com.tcs.dnp.repository.DistributorHealthAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorHealthAssessmentService extends AbstractCrudService<DistributorHealthAssessment, Long> {
    public DistributorHealthAssessmentService(DistributorHealthAssessmentRepository repository) {
        super(repository, DistributorHealthAssessment.class);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.Distributor;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.jdbc.AutoConfigureTestDatabase;
import org.springframework.boot.test.autoconfigure.orm.jpa.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class DistributorRepositoryTest {
    @Autowired DistributorRepository repository;

    private Distributor d(String code, String status) {
        return Distributor.builder().distributorCode(code).distributorName("N-" + code).status(status).build();
    }

    @Test void save_find_update_delete() {
        Distributor saved = repository.saveAndFlush(d("R1", "ACTIVE"));
        assertNotNull(saved.getDistributorId());
        assertEquals(0L, saved.getVersion());
        assertTrue(repository.findById(saved.getDistributorId()).isPresent());
        saved.setDistributorName("Changed");
        Distributor updated = repository.saveAndFlush(saved);
        assertEquals(1L, updated.getVersion());
        repository.deleteById(saved.getDistributorId());
        repository.flush();
        assertFalse(repository.existsById(saved.getDistributorId()));
    }

    @Test void derivedFinders() {
        repository.saveAndFlush(d("R2", "ACTIVE"));
        repository.saveAndFlush(d("R3", "INACTIVE"));
        assertTrue(repository.existsByDistributorCode("R2"));
        assertFalse(repository.existsByDistributorCode("NOPE"));
        assertEquals("R3", repository.findByDistributorCode("R3").orElseThrow().getDistributorCode());
        assertEquals(1, repository.findByStatus("INACTIVE").size());
    }
}

package com.tcs.dnp.services;

import com.tcs.dnp.exception.BusinessRuleException;
import com.tcs.dnp.exception.ResourceNotFoundException;
import com.tcs.dnp.model.ExchangeRequest;
import com.tcs.dnp.repository.ExchangeRequestRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** ExchangeRequest rows are updated under a PESSIMISTIC_WRITE lock, so update() must use findByIdForUpdate. */
@ExtendWith(MockitoExtension.class)
class ExchangeRequestServiceTest {
    @Mock ExchangeRequestRepository repository;
    @InjectMocks ExchangeRequestService service;

    private ExchangeRequest valid() {
        ExchangeRequest s = new ExchangeRequest();
        s.setRequestedQuantity(new BigDecimal("2"));
        return s;
    }

    @Test
    void create_valid_saves() {
        when(repository.save(any(ExchangeRequest.class))).thenAnswer(a -> a.getArgument(0));
        assertNotNull(service.create(valid()));
    }

    @Test
    void create_invalid_rejected() {
        ExchangeRequest s = new ExchangeRequest();
        s.setRequestedQuantity(BigDecimal.ZERO);
        assertThrows(BusinessRuleException.class, () -> service.create(s));
        verify(repository, never()).save(any());
    }

    @Test
    void update_takesRowLock() {
        ExchangeRequest existing = new ExchangeRequest();
        existing.setExchangeId(1L);
        existing.setVersion(2L);
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(ExchangeRequest.class))).thenAnswer(a -> a.getArgument(0));
        ExchangeRequest r = service.update(1L, valid());
        assertEquals(2L, r.getVersion());
        verify(repository).findByIdForUpdate(1L);
        verify(repository, never()).findById(any());
    }

    @Test
    void update_missing_notFound() {
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(1L, valid()));
    }
}

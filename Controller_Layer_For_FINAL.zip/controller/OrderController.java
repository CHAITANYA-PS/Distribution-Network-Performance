package controller;
import dto.DistributorOrderDTO;
import services.DistributorOrderService;
public class OrderController extends BaseController<DistributorOrderDTO>{ public OrderController(DistributorOrderService s){super(s);} }
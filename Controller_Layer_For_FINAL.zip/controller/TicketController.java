package controller;
import dto.TicketDTO;
import services.TicketService;
public class TicketController extends BaseController<TicketDTO>{ public TicketController(TicketService s){super(s);} }
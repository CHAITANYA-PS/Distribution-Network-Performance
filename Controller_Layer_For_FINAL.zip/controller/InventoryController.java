package controller;
import dto.ProductDTO;
import services.ProductService;
public class InventoryController extends BaseController<ProductDTO>{ public InventoryController(ProductService s){super(s);} }
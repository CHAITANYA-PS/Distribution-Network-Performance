package controller;
import dto.AppUserDTO;
import services.AppUserService;
public class UserController extends BaseController<AppUserDTO>{ public UserController(AppUserService s){super(s);} }
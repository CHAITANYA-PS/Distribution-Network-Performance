package controller;
import dto.RecoveryPlanDTO;
import services.RecoveryPlanService;
public class RecoveryPlanController extends BaseController<RecoveryPlanDTO>{ public RecoveryPlanController(RecoveryPlanService s){super(s);} }
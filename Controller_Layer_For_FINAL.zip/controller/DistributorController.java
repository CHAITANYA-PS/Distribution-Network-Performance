package controller;
import dto.DistributorDTO;
import services.DistributorService;
public class DistributorController extends BaseController<DistributorDTO>{ public DistributorController(DistributorService s){super(s);} }
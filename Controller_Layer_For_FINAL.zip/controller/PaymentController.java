package controller;
import dto.PaymentDTO;
import services.PaymentService;
public class PaymentController extends BaseController<PaymentDTO>{ public PaymentController(PaymentService s){super(s);} }
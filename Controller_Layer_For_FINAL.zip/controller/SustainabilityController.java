package controller;
import dto.CommitmentDTO;
import services.CommitmentService;
public class SustainabilityController extends BaseController<CommitmentDTO>{ public SustainabilityController(CommitmentService s){super(s);} }
package controller;
import dto.CreditRiskAssessmentDTO;
import services.CreditRiskAssessmentService;
public class RiskManagementController extends BaseController<CreditRiskAssessmentDTO>{ public RiskManagementController(CreditRiskAssessmentService s){super(s);} }
package controller;

import java.util.List;
import services.GenericService;

public class BaseController<T> {
    protected final GenericService<T> service;
    public BaseController(GenericService<T> service){this.service=service;}
    public T create(T dto){return service.create(dto);}
    public T update(Long id,T dto){return service.update(id,dto);}
    public T getById(Long id){return service.getById(id);}
    public List<T> getAll(){return service.getAll();}
    public boolean delete(Long id){return service.delete(id);}
    public long count(){return service.count();}
}
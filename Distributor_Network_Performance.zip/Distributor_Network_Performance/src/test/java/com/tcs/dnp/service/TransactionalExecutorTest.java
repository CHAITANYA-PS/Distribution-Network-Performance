package com.tcs.dnp.service;

import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.transaction.PlatformTransactionManager;
import org.springframework.transaction.support.SimpleTransactionStatus;

import java.util.concurrent.atomic.AtomicInteger;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class TransactionalExecutorTest {
    @Mock PlatformTransactionManager tx;

    private TransactionalExecutor executor() {
        when(tx.getTransaction(any())).thenReturn(new SimpleTransactionStatus());
        return new TransactionalExecutor(tx);
    }

    @Test
    void execute_commitsOnSuccess() {
        assertEquals("ok", executor().execute(() -> "ok"));
        verify(tx).commit(any());
        verify(tx, never()).rollback(any());
    }

    @Test
    void execute_rollsBackOnRuntimeException() {
        TransactionalExecutor e = executor();
        assertThrows(IllegalStateException.class, () -> e.execute(() -> { throw new IllegalStateException("boom"); }));
        verify(tx).rollback(any());
        verify(tx, never()).commit(any());
    }

    @Test
    void retry_succeedsAfterOneConflict() {
        TransactionalExecutor e = executor();
        AtomicInteger calls = new AtomicInteger();
        String r = e.executeWithOptimisticRetry(3, () -> {
            if (calls.incrementAndGet() == 1) throw new ObjectOptimisticLockingFailureException("X", 1L);
            return "done";
        });
        assertEquals("done", r);
        assertEquals(2, calls.get());
    }

    @Test
    void retry_givesUpAfterMaxAttempts() {
        TransactionalExecutor e = executor();
        AtomicInteger calls = new AtomicInteger();
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> e.executeWithOptimisticRetry(2, () -> {
            calls.incrementAndGet();
            throw new ObjectOptimisticLockingFailureException("X", 1L);
        }));
        assertEquals(2, calls.get());
    }

    @Test
    void retry_rejectsInvalidAttempts() {
        assertThrows(IllegalArgumentException.class, () -> new TransactionalExecutor(tx).executeWithOptimisticRetry(0, () -> 1));
    }
}

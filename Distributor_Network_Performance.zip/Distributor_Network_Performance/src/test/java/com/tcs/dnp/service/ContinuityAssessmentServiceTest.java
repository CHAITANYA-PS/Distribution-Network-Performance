package com.tcs.dnp.service;

import com.tcs.dnp.exception.BusinessRuleException;
import com.tcs.dnp.exception.ResourceNotFoundException;
import com.tcs.dnp.entity.ContinuityAssessment;
import com.tcs.dnp.repository.ContinuityAssessmentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Logic-only test: the repository is a Mockito mock, no database is used. */
@ExtendWith(MockitoExtension.class)
class ContinuityAssessmentServiceTest {
    @Mock ContinuityAssessmentRepository repository;
    @InjectMocks ContinuityAssessmentService service;

    private ContinuityAssessment row(Long id, Long version) {
        ContinuityAssessment x = new ContinuityAssessment();
        x.setContinuityAssessmentId(id);
        x.setVersion(version);
        return x;
    }

    @Test
    void create_clearsClientIdAndVersion_thenSaves() {
        when(repository.save(any(ContinuityAssessment.class))).thenAnswer(a -> a.getArgument(0));
        ContinuityAssessment result = service.create(row(99L, 5L));
        assertNull(result.getContinuityAssessmentId());
        assertNull(result.getVersion());
        verify(repository).save(any(ContinuityAssessment.class));
    }

    @Test
    void create_nullBody_isRejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(null));
        verifyNoInteractions(repository);
    }

    @Test
    void get_existing_returnsRow() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertEquals(1L, service.get(1L).getContinuityAssessmentId());
    }

    @Test
    void get_missing_throwsNotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.get(2L));
    }

    @Test
    void getAll_returnsEveryRow() {
        when(repository.findAll()).thenReturn(List.of(row(1L, 0L), row(2L, 0L)));
        assertEquals(2, service.getAll().size());
    }

    @Test
    void update_existing_keepsPathIdAndStoredVersion() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        when(repository.save(any(ContinuityAssessment.class))).thenAnswer(a -> a.getArgument(0));
        ContinuityAssessment result = service.update(1L, row(null, null));
        assertEquals(1L, result.getContinuityAssessmentId());
        assertEquals(3L, result.getVersion());
    }

    @Test
    void update_staleVersion_raisesOptimisticLockFailure() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> service.update(1L, row(null, 2L)));
        verify(repository, never()).save(any(ContinuityAssessment.class));
    }

    @Test
    void update_missing_throwsNotFound() {
        when(repository.findById(9L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(9L, row(null, null)));
    }

    @Test
    void delete_existing_deletesById() {
        when(repository.existsById(1L)).thenReturn(true);
        service.delete(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void delete_missing_throwsNotFoundAndDeletesNothing() {
        when(repository.existsById(8L)).thenReturn(false);
        assertThrows(ResourceNotFoundException.class, () -> service.delete(8L));
        verify(repository, never()).deleteById(any());
    }
}

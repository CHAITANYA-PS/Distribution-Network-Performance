package com.tcs.dnp.service;

import com.tcs.dnp.exception.BusinessRuleException;
import com.tcs.dnp.exception.ResourceNotFoundException;
import com.tcs.dnp.entity.WarehouseStock;
import com.tcs.dnp.repository.WarehouseStockRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** WarehouseStock rows are updated under a PESSIMISTIC_WRITE lock, so update() must use findByIdForUpdate. */
@ExtendWith(MockitoExtension.class)
class WarehouseStockServiceTest {
    @Mock WarehouseStockRepository repository;
    @InjectMocks WarehouseStockService service;

    private WarehouseStock valid() {
        WarehouseStock s = new WarehouseStock();
        s.setReorderLevel(new BigDecimal("5"));
        return s;
    }

    @Test
    void create_valid_saves() {
        when(repository.save(any(WarehouseStock.class))).thenAnswer(a -> a.getArgument(0));
        assertNotNull(service.create(valid()));
    }

    @Test
    void create_invalid_rejected() {
        WarehouseStock s = new WarehouseStock();
        s.setReorderLevel(new BigDecimal("-1"));
        assertThrows(BusinessRuleException.class, () -> service.create(s));
        verify(repository, never()).save(any());
    }

    @Test
    void update_takesRowLock() {
        WarehouseStock existing = new WarehouseStock();
        existing.setWarehouseStockId(1L);
        existing.setVersion(2L);
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(WarehouseStock.class))).thenAnswer(a -> a.getArgument(0));
        WarehouseStock r = service.update(1L, valid());
        assertEquals(2L, r.getVersion());
        verify(repository).findByIdForUpdate(1L);
        verify(repository, never()).findById(any());
    }

    @Test
    void update_missing_notFound() {
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(1L, valid()));
    }
}

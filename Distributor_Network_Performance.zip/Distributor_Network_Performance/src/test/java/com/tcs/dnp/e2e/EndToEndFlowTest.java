package com.tcs.dnp.e2e;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Real controller -> service -> repository -> database (H2) flow. Nothing is mocked.
 * Covers CRUD, validation, business rules, optimistic locking and the JSON error model.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EndToEndFlowTest {
    @Autowired MockMvc mvc;
    @Autowired ObjectMapper json;

    static long distributorId;
    static long invoiceId;
    static long firstPaymentId;

    private JsonNode body(MvcResult r) throws Exception { return json.readTree(r.getResponse().getContentAsString()); }

    private String dist(String code, String name, Long version) {
        return "{\"distributorCode\":\"" + code + "\",\"distributorName\":\"" + name + "\"" +
                (version == null ? "" : ",\"version\":" + version) + "}";
    }

    @Test @Order(1) void createDistributor_returns201_withDefaultsAndVersion0() throws Exception {
        MvcResult r = mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content(dist("E2E-1", "First", null)))
                .andExpect(status().isCreated()).andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.status").value("ACTIVE")).andExpect(jsonPath("$.version").value(0)).andReturn();
        distributorId = body(r).get("distributorId").asLong();
    }

    @Test @Order(2) void readDistributor() throws Exception {
        mvc.perform(get("/api/v1/distributors/" + distributorId)).andExpect(status().isOk())
                .andExpect(jsonPath("$.distributorCode").value("E2E-1"));
        mvc.perform(get("/api/v1/distributors")).andExpect(status().isOk()).andExpect(jsonPath("$[0].distributorId").exists());
    }

    @Test @Order(3) void updateDistributor_bumpsVersion() throws Exception {
        mvc.perform(put("/api/v1/distributors/" + distributorId).contentType(MediaType.APPLICATION_JSON)
                        .content(dist("E2E-1", "Renamed", 0L).replace("}", ",\"status\":\"ACTIVE\"}")))
                .andExpect(status().isOk()).andExpect(jsonPath("$.distributorName").value("Renamed"))
                .andExpect(jsonPath("$.version").value(1));
    }

    @Test @Order(4) void staleUpdate_returns409ErrorModel() throws Exception {
        mvc.perform(put("/api/v1/distributors/" + distributorId).contentType(MediaType.APPLICATION_JSON)
                        .content(dist("E2E-1", "Stale", 0L).replace("}", ",\"status\":\"ACTIVE\"}")))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("OPTIMISTIC_LOCK_CONFLICT"));
    }

    @Test @Order(5) void invalidBody_returns400WithFieldErrors() throws Exception {
        mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.distributorName").exists());
    }

    @Test @Order(6) void duplicateCode_returns409() throws Exception {
        mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content(dist("E2E-1", "Dup", null)))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("DUPLICATE_RESOURCE"));
    }

    @Test @Order(7) void invoiceAndPayments_enforceOutstandingBalance() throws Exception {
        MvcResult inv = mvc.perform(post("/api/v1/invoices").contentType(MediaType.APPLICATION_JSON)
                .content("{\"invoiceNumber\":\"INV-E2E\",\"invoiceAmount\":1000}")).andExpect(status().isCreated()).andReturn();
        invoiceId = body(inv).get("invoiceId").asLong();
        String p = "{\"invoiceId\":" + invoiceId + ",\"amount\":%s}";
        MvcResult first = mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("600")))
                .andExpect(status().isCreated()).andReturn();
        firstPaymentId = body(first).get("paymentId").asLong();
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("500")))
                .andExpect(status().isUnprocessableEntity()).andExpect(jsonPath("$.code").value("BUSINESS_RULE_VIOLATION"));
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("400")))
                .andExpect(status().isCreated());
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("0")))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON)
                .content("{\"invoiceId\":999999,\"amount\":1}")).andExpect(status().isNotFound());
    }

    @Test @Order(8) void domainControllersShareTheSameData() throws Exception {
        mvc.perform(get("/api/v1/inventory/products")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/orders")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/users")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/sustainability/commitments")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/risk-management/assessments")).andExpect(status().isOk());
    }

    @Test @Order(9) void deletePayment_thenRowIsGone() throws Exception {
        mvc.perform(delete("/api/v1/payments/" + firstPaymentId)).andExpect(status().isNoContent());
        mvc.perform(get("/api/v1/payments/" + firstPaymentId)).andExpect(status().isNotFound());
    }

    @Test @Order(10) void deleteDistributor_thenNotFound() throws Exception {
        mvc.perform(delete("/api/v1/distributors/" + distributorId)).andExpect(status().isNoContent());
        MvcResult r = mvc.perform(get("/api/v1/distributors/" + distributorId)).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("RESOURCE_NOT_FOUND")).andReturn();
        assertEquals(404, body(r).get("status").asInt());
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.ReportFilter;
import com.tcs.dnp.repository.ReportFilterRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterService extends AbstractCrudService<ReportFilter, Long> {
    public ReportFilterService(ReportFilterRepository repository) {
        super(repository, ReportFilter.class);
    }
}

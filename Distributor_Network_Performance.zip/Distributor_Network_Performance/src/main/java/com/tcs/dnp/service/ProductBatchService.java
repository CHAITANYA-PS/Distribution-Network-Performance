package com.tcs.dnp.service;

import com.tcs.dnp.entity.ProductBatch;
import com.tcs.dnp.repository.ProductBatchRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductBatchService extends AbstractCrudService<ProductBatch, Long> {
    public ProductBatchService(ProductBatchRepository repository) {
        super(repository, ProductBatch.class);
    }
}

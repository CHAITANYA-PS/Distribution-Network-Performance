package com.tcs.dnp.service;

import com.tcs.dnp.entity.Role;
import com.tcs.dnp.repository.RoleRepository;
import org.springframework.stereotype.Service;

@Service
public class RoleService extends AbstractCrudService<Role, Long> {
    public RoleService(RoleRepository repository) {
        super(repository, Role.class);
    }
}

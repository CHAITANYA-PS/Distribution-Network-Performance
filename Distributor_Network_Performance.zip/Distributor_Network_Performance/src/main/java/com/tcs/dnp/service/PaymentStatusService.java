package com.tcs.dnp.service;

import com.tcs.dnp.entity.PaymentStatus;
import com.tcs.dnp.repository.PaymentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentStatusService extends AbstractCrudService<PaymentStatus, Long> {
    public PaymentStatusService(PaymentStatusRepository repository) {
        super(repository, PaymentStatus.class);
    }
}

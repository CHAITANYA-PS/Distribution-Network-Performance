package com.tcs.dnp.service;

import com.tcs.dnp.entity.ShipmentStatus;
import com.tcs.dnp.repository.ShipmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentStatusService extends AbstractCrudService<ShipmentStatus, Long> {
    public ShipmentStatusService(ShipmentStatusRepository repository) {
        super(repository, ShipmentStatus.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.Commitment;
import com.tcs.dnp.repository.CommitmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentService extends AbstractCrudService<Commitment, Long> {
    public CommitmentService(CommitmentRepository repository) {
        super(repository, Commitment.class);
    }
}

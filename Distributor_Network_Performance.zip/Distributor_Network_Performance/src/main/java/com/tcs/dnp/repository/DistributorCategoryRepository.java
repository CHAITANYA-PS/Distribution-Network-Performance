package com.tcs.dnp.repository;

import com.tcs.dnp.entity.DistributorCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorCategoryRepository extends JpaRepository<DistributorCategory, Long> {
}

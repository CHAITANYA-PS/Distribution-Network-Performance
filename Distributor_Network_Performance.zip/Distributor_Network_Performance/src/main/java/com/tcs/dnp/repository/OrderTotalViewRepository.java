package com.tcs.dnp.repository;

import com.tcs.dnp.entity.OrderTotalView;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

/** Read-only repository: a view cannot be saved or deleted. */
public interface OrderTotalViewRepository extends Repository<OrderTotalView, Long> {
    List<OrderTotalView> findAll();

    Optional<OrderTotalView> findById(Long id);
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.TransportationActivity;
import com.tcs.dnp.repository.TransportationActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class TransportationActivityService extends AbstractCrudService<TransportationActivity, Long> {
    public TransportationActivityService(TransportationActivityRepository repository) {
        super(repository, TransportationActivity.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.TransportEmissionView;
import com.tcs.dnp.repository.TransportEmissionViewRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class TransportEmissionViewService extends ReadOnlyViewService<TransportEmissionView, Long> {
    private final TransportEmissionViewRepository repository;

    public TransportEmissionViewService(TransportEmissionViewRepository repository) {
        super("TransportEmissionView");
        this.repository = repository;
    }

    @Override
    protected List<TransportEmissionView> findAllRows() {
        return repository.findAll();
    }

    @Override
    protected Optional<TransportEmissionView> findRow(Long id) {
        return repository.findById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.Manufacturer;
import com.tcs.dnp.repository.ManufacturerRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerService extends AbstractCrudService<Manufacturer, Long> {
    public ManufacturerService(ManufacturerRepository repository) {
        super(repository, Manufacturer.class);
    }
}

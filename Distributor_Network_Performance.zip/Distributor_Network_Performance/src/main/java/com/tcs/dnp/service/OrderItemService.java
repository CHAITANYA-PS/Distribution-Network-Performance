package com.tcs.dnp.service;

import com.tcs.dnp.entity.OrderItem;
import com.tcs.dnp.repository.OrderItemRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService extends AbstractCrudService<OrderItem, Long> {
    public OrderItemService(OrderItemRepository repository) {
        super(repository, OrderItem.class);
    }
}

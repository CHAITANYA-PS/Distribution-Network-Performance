package com.tcs.dnp.repository;

import com.tcs.dnp.entity.CommitmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentStatusRepository extends JpaRepository<CommitmentStatus, Long> {
}

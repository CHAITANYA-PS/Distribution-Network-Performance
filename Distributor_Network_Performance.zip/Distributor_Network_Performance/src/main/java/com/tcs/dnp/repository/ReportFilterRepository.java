package com.tcs.dnp.repository;

import com.tcs.dnp.entity.ReportFilter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportFilterRepository extends JpaRepository<ReportFilter, Long> {
}

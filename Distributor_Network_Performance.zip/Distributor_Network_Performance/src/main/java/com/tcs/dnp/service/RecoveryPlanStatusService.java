package com.tcs.dnp.service;

import com.tcs.dnp.entity.RecoveryPlanStatus;
import com.tcs.dnp.repository.RecoveryPlanStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanStatusService extends AbstractCrudService<RecoveryPlanStatus, Long> {
    public RecoveryPlanStatusService(RecoveryPlanStatusRepository repository) {
        super(repository, RecoveryPlanStatus.class);
    }
}

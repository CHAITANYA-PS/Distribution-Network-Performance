package com.tcs.dnp.service;

import com.tcs.dnp.entity.TicketComment;
import com.tcs.dnp.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCommentService extends AbstractCrudService<TicketComment, Long> {
    public TicketCommentService(TicketCommentRepository repository) {
        super(repository, TicketComment.class);
    }
}

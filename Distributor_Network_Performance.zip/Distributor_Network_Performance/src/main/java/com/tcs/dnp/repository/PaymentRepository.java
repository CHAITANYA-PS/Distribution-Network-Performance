package com.tcs.dnp.repository;

import com.tcs.dnp.entity.Payment;
import org.springframework.data.jpa.repository.JpaRepository;
import java.math.BigDecimal;
import java.util.List;
import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface PaymentRepository extends JpaRepository<Payment, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = "jakarta.persistence.lock.timeout", value = "5000"))
    @Query("select x from Payment x where x.paymentId = :id")
    Optional<Payment> findByIdForUpdate(@Param("id") Long id);


    @Query("select coalesce(sum(p.amount), 0) from Payment p where p.invoiceId = :invoiceId and p.paymentId <> :excludePaymentId")
    BigDecimal sumPaidForInvoiceExcluding(@Param("invoiceId") Long invoiceId, @Param("excludePaymentId") Long excludePaymentId);

    List<Payment> findByInvoiceId(Long invoiceId);
}

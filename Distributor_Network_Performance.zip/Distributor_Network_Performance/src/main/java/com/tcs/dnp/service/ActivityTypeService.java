package com.tcs.dnp.service;

import com.tcs.dnp.entity.ActivityType;
import com.tcs.dnp.repository.ActivityTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ActivityTypeService extends AbstractCrudService<ActivityType, Long> {
    public ActivityTypeService(ActivityTypeRepository repository) {
        super(repository, ActivityType.class);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.entity.Escalation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EscalationRepository extends JpaRepository<Escalation, Long> {
}

package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="payment_method",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class PaymentMethod implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="payment_method_id")
 private Long paymentMethodId;
 @Column(name="method_name")
 private String methodName;
}
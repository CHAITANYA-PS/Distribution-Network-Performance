package com.tcs.dnp.service;

import com.tcs.dnp.entity.UserSession;
import com.tcs.dnp.repository.UserSessionRepository;
import org.springframework.stereotype.Service;

@Service
public class UserSessionService extends AbstractCrudService<UserSession, Long> {
    public UserSessionService(UserSessionRepository repository) {
        super(repository, UserSession.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.exception.BusinessRuleException;
import com.tcs.dnp.entity.WarehouseStock;
import com.tcs.dnp.repository.WarehouseStockRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class WarehouseStockService extends AbstractCrudService<WarehouseStock, Long> {
    private final WarehouseStockRepository stocks;

    public WarehouseStockService(WarehouseStockRepository repository) {
        super(repository, WarehouseStock.class);
        this.stocks = repository;
    }

    @Override
    protected Optional<WarehouseStock> findForUpdate(Long id) {
        return stocks.findByIdForUpdate(id);
    }

    @Override
    protected void beforeCreate(WarehouseStock s) {
        checkReorderLevel(s);
    }

    @Override
    protected void beforeUpdate(Long id, WarehouseStock s, WarehouseStock existing) {
        checkReorderLevel(s);
    }

    private void checkReorderLevel(WarehouseStock s) {
        if (s.getReorderLevel() != null && s.getReorderLevel().signum() < 0) {
            throw new BusinessRuleException("Reorder level must not be negative");
        }
    }
}

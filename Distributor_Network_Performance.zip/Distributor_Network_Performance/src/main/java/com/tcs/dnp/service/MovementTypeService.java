package com.tcs.dnp.service;

import com.tcs.dnp.entity.MovementType;
import com.tcs.dnp.repository.MovementTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class MovementTypeService extends AbstractCrudService<MovementType, Long> {
    public MovementTypeService(MovementTypeRepository repository) {
        super(repository, MovementType.class);
    }
}

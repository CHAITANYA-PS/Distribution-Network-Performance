package com.tcs.dnp.repository;

import com.tcs.dnp.entity.RiskLevel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskLevelRepository extends JpaRepository<RiskLevel, Long> {
}

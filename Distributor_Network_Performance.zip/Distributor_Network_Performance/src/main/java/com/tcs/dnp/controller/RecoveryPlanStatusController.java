package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.RecoveryPlanStatus;
import com.tcs.dnp.service.RecoveryPlanStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/recovery-plan-statuses")
public class RecoveryPlanStatusController {
    private final RecoveryPlanStatusService service;

    public RecoveryPlanStatusController(RecoveryPlanStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RecoveryPlanStatus> create(@Valid @RequestBody RecoveryPlanStatus model) {
        RecoveryPlanStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/recovery-plan-statuses/" + saved.getRecoveryStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public RecoveryPlanStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RecoveryPlanStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public RecoveryPlanStatus update(@PathVariable Long id, @Valid @RequestBody RecoveryPlanStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

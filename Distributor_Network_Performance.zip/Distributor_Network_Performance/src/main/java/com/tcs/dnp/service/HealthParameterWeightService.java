package com.tcs.dnp.service;

import com.tcs.dnp.entity.HealthParameterWeight;
import com.tcs.dnp.repository.HealthParameterWeightRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterWeightService extends AbstractCrudService<HealthParameterWeight, Long> {
    public HealthParameterWeightService(HealthParameterWeightRepository repository) {
        super(repository, HealthParameterWeight.class);
    }
}

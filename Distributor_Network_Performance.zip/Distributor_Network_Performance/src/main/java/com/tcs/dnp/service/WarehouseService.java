package com.tcs.dnp.service;

import com.tcs.dnp.entity.Warehouse;
import com.tcs.dnp.repository.WarehouseRepository;
import org.springframework.stereotype.Service;

@Service
public class WarehouseService extends AbstractCrudService<Warehouse, Long> {
    public WarehouseService(WarehouseRepository repository) {
        super(repository, Warehouse.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.OrderTotalView;
import com.tcs.dnp.repository.OrderTotalViewRepository;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class OrderTotalViewService extends ReadOnlyViewService<OrderTotalView, Long> {
    private final OrderTotalViewRepository repository;

    public OrderTotalViewService(OrderTotalViewRepository repository) {
        super("OrderTotalView");
        this.repository = repository;
    }

    @Override
    protected List<OrderTotalView> findAllRows() {
        return repository.findAll();
    }

    @Override
    protected Optional<OrderTotalView> findRow(Long id) {
        return repository.findById(id);
    }
}

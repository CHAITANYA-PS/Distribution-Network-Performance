package com.tcs.dnp.service;

import com.tcs.dnp.entity.RiskLevel;
import com.tcs.dnp.repository.RiskLevelRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskLevelService extends AbstractCrudService<RiskLevel, Long> {
    public RiskLevelService(RiskLevelRepository repository) {
        super(repository, RiskLevel.class);
    }
}

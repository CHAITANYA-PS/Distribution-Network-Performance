package com.tcs.dnp.service;

import com.tcs.dnp.entity.Shipment;
import com.tcs.dnp.repository.ShipmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentService extends AbstractCrudService<Shipment, Long> {
    public ShipmentService(ShipmentRepository repository) {
        super(repository, Shipment.class);
    }
}

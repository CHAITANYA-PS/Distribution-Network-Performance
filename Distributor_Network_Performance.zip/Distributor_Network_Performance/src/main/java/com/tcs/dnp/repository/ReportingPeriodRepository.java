package com.tcs.dnp.repository;

import com.tcs.dnp.entity.ReportingPeriod;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportingPeriodRepository extends JpaRepository<ReportingPeriod, Long> {
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.CommitmentStatus;
import com.tcs.dnp.service.CommitmentStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/commitment-statuses")
public class CommitmentStatusController {
    private final CommitmentStatusService service;

    public CommitmentStatusController(CommitmentStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CommitmentStatus> create(@Valid @RequestBody CommitmentStatus model) {
        CommitmentStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/commitment-statuses/" + saved.getCommitmentStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public CommitmentStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<CommitmentStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public CommitmentStatus update(@PathVariable Long id, @Valid @RequestBody CommitmentStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

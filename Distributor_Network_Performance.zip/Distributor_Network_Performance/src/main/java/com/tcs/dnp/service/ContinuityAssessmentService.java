package com.tcs.dnp.service;

import com.tcs.dnp.entity.ContinuityAssessment;
import com.tcs.dnp.repository.ContinuityAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityAssessmentService extends AbstractCrudService<ContinuityAssessment, Long> {
    public ContinuityAssessmentService(ContinuityAssessmentRepository repository) {
        super(repository, ContinuityAssessment.class);
    }
}

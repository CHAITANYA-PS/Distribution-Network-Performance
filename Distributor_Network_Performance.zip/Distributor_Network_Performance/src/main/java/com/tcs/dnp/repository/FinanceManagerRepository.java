package com.tcs.dnp.repository;

import com.tcs.dnp.entity.FinanceManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinanceManagerRepository extends JpaRepository<FinanceManager, Long> {
}

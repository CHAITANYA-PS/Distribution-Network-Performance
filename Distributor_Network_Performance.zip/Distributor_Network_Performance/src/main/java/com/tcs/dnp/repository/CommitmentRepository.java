package com.tcs.dnp.repository;

import com.tcs.dnp.entity.Commitment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentRepository extends JpaRepository<Commitment, Long> {
}

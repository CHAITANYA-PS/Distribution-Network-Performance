package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.ContinuityAssessment;
import com.tcs.dnp.service.ContinuityAssessmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/continuity-assessments")
public class ContinuityAssessmentController {
    private final ContinuityAssessmentService service;

    public ContinuityAssessmentController(ContinuityAssessmentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ContinuityAssessment> create(@Valid @RequestBody ContinuityAssessment model) {
        ContinuityAssessment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/continuity-assessments/" + saved.getContinuityAssessmentId())).body(saved);
    }

    @GetMapping("/{id}")
    public ContinuityAssessment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ContinuityAssessment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ContinuityAssessment update(@PathVariable Long id, @Valid @RequestBody ContinuityAssessment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

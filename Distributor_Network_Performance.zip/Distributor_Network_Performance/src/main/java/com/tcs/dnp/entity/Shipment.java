package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDate;
@Entity @Table(name="shipment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Shipment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="shipment_id")
 private Long shipmentId;
 @Column(name="tracking_number")
 private String trackingNumber;
 @Column(name="warehouse_id")
 private Long warehouseId;
 @Column(name="shipment_status_id")
 private Long shipmentStatusId;
 @Column(name="dispatch_date")
 private LocalDate dispatchDate;
 @Column(name="delivery_date")
 private LocalDate deliveryDate;
}
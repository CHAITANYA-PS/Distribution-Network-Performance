package com.tcs.dnp.service;

import com.tcs.dnp.entity.InventoryAlert;
import com.tcs.dnp.repository.InventoryAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryAlertService extends AbstractCrudService<InventoryAlert, Long> {
    public InventoryAlertService(InventoryAlertRepository repository) {
        super(repository, InventoryAlert.class);
    }
}

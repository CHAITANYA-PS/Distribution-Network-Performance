package com.tcs.dnp.repository;

import com.tcs.dnp.entity.SalesManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesManagerRepository extends JpaRepository<SalesManager, Long> {
}

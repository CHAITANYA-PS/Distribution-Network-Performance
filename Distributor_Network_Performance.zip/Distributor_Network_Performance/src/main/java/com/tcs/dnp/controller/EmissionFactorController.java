package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.EmissionFactor;
import com.tcs.dnp.service.EmissionFactorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/emission-factors")
public class EmissionFactorController {
    private final EmissionFactorService service;

    public EmissionFactorController(EmissionFactorService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<EmissionFactor> create(@Valid @RequestBody EmissionFactor model) {
        EmissionFactor saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/emission-factors/" + saved.getEmissionFactorId())).body(saved);
    }

    @GetMapping("/{id}")
    public EmissionFactor get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<EmissionFactor> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public EmissionFactor update(@PathVariable Long id, @Valid @RequestBody EmissionFactor model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

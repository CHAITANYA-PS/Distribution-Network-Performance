package com.tcs.dnp.service;

import com.tcs.dnp.entity.DistributorOrder;
import com.tcs.dnp.repository.DistributorOrderRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorOrderService extends AbstractCrudService<DistributorOrder, Long> {
    public DistributorOrderService(DistributorOrderRepository repository) {
        super(repository, DistributorOrder.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.Product;
import com.tcs.dnp.repository.ProductRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductService extends AbstractCrudService<Product, Long> {
    public ProductService(ProductRepository repository) {
        super(repository, Product.class);
    }
}

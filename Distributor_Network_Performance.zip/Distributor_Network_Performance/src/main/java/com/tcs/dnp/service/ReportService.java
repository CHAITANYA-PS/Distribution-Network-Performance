package com.tcs.dnp.service;

import com.tcs.dnp.entity.Report;
import com.tcs.dnp.repository.ReportRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportService extends AbstractCrudService<Report, Long> {
    public ReportService(ReportRepository repository) {
        super(repository, Report.class);
    }
}

package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="continuity_status_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ContinuityStatusType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="continuity_status_id")
 private Long continuityStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="description")
 private String description;
}
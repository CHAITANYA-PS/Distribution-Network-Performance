package com.tcs.dnp.service;

import com.tcs.dnp.entity.ReportFilterValue;
import com.tcs.dnp.repository.ReportFilterValueRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterValueService extends AbstractCrudService<ReportFilterValue, Long> {
    public ReportFilterValueService(ReportFilterValueRepository repository) {
        super(repository, ReportFilterValue.class);
    }
}

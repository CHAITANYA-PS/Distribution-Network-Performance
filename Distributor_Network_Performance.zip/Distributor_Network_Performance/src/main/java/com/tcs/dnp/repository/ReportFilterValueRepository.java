package com.tcs.dnp.repository;

import com.tcs.dnp.entity.ReportFilterValue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportFilterValueRepository extends JpaRepository<ReportFilterValue, Long> {
}

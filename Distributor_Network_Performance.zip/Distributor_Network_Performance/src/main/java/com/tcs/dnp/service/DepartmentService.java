package com.tcs.dnp.service;

import com.tcs.dnp.entity.Department;
import com.tcs.dnp.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService extends AbstractCrudService<Department, Long> {
    public DepartmentService(DepartmentRepository repository) {
        super(repository, Department.class);
    }
}

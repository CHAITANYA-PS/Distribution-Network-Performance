package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.Region;
import com.tcs.dnp.service.RegionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/regions")
public class RegionController {
    private final RegionService service;

    public RegionController(RegionService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Region> create(@Valid @RequestBody Region model) {
        Region saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/regions/" + saved.getRegionId())).body(saved);
    }

    @GetMapping("/{id}")
    public Region get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Region> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Region update(@PathVariable Long id, @Valid @RequestBody Region model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

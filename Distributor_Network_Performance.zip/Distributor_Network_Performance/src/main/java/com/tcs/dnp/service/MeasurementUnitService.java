package com.tcs.dnp.service;

import com.tcs.dnp.entity.MeasurementUnit;
import com.tcs.dnp.repository.MeasurementUnitRepository;
import org.springframework.stereotype.Service;

@Service
public class MeasurementUnitService extends AbstractCrudService<MeasurementUnit, Long> {
    public MeasurementUnitService(MeasurementUnitRepository repository) {
        super(repository, MeasurementUnit.class);
    }
}

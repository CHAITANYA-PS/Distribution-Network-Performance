package com.tcs.dnp.service;

import com.tcs.dnp.entity.InventoryDocumentType;
import com.tcs.dnp.repository.InventoryDocumentTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentTypeService extends AbstractCrudService<InventoryDocumentType, Long> {
    public InventoryDocumentTypeService(InventoryDocumentTypeRepository repository) {
        super(repository, InventoryDocumentType.class);
    }
}

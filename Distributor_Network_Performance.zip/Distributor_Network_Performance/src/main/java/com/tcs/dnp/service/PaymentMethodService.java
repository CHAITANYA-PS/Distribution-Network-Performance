package com.tcs.dnp.service;

import com.tcs.dnp.entity.PaymentMethod;
import com.tcs.dnp.repository.PaymentMethodRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentMethodService extends AbstractCrudService<PaymentMethod, Long> {
    public PaymentMethodService(PaymentMethodRepository repository) {
        super(repository, PaymentMethod.class);
    }
}

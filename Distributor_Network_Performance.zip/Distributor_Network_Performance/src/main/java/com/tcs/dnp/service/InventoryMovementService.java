package com.tcs.dnp.service;

import com.tcs.dnp.entity.InventoryMovement;
import com.tcs.dnp.repository.InventoryMovementRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryMovementService extends AbstractCrudService<InventoryMovement, Long> {
    public InventoryMovementService(InventoryMovementRepository repository) {
        super(repository, InventoryMovement.class);
    }
}

package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="category",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Category implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="category_id")
 private Long categoryId;
 @Column(name="category_name")
 private String categoryName;
 @Column(name="description")
 private String description;
}
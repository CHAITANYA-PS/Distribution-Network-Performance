package com.tcs.dnp.service;

import com.tcs.dnp.entity.CommitmentHistory;
import com.tcs.dnp.repository.CommitmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentHistoryService extends AbstractCrudService<CommitmentHistory, Long> {
    public CommitmentHistoryService(CommitmentHistoryRepository repository) {
        super(repository, CommitmentHistory.class);
    }
}

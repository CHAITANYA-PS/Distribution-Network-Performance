package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.ExchangeRequest;
import com.tcs.dnp.service.ExchangeRequestService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/exchange-requests")
public class ExchangeRequestController {
    private final ExchangeRequestService service;

    public ExchangeRequestController(ExchangeRequestService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ExchangeRequest> create(@Valid @RequestBody ExchangeRequest model) {
        ExchangeRequest saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/exchange-requests/" + saved.getExchangeId())).body(saved);
    }

    @GetMapping("/{id}")
    public ExchangeRequest get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ExchangeRequest> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ExchangeRequest update(@PathVariable Long id, @Valid @RequestBody ExchangeRequest model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.Notification;
import com.tcs.dnp.repository.NotificationRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationService extends AbstractCrudService<Notification, Long> {
    public NotificationService(NotificationRepository repository) {
        super(repository, Notification.class);
    }
}

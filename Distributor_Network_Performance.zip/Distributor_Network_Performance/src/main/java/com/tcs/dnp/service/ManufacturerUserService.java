package com.tcs.dnp.service;

import com.tcs.dnp.entity.ManufacturerUser;
import com.tcs.dnp.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerUserService extends AbstractCrudService<ManufacturerUser, Long> {
    public ManufacturerUserService(ManufacturerUserRepository repository) {
        super(repository, ManufacturerUser.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.HealthAssessmentAlert;
import com.tcs.dnp.repository.HealthAssessmentAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthAssessmentAlertService extends AbstractCrudService<HealthAssessmentAlert, Long> {
    public HealthAssessmentAlertService(HealthAssessmentAlertRepository repository) {
        super(repository, HealthAssessmentAlert.class);
    }
}

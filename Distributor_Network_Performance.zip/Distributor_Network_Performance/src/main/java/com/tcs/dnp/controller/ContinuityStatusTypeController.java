package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.ContinuityStatusType;
import com.tcs.dnp.service.ContinuityStatusTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/continuity-status-types")
public class ContinuityStatusTypeController {
    private final ContinuityStatusTypeService service;

    public ContinuityStatusTypeController(ContinuityStatusTypeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ContinuityStatusType> create(@Valid @RequestBody ContinuityStatusType model) {
        ContinuityStatusType saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/continuity-status-types/" + saved.getContinuityStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public ContinuityStatusType get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ContinuityStatusType> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ContinuityStatusType update(@PathVariable Long id, @Valid @RequestBody ContinuityStatusType model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

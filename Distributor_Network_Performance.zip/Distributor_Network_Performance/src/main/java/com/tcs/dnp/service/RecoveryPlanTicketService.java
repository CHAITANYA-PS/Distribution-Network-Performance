package com.tcs.dnp.service;

import com.tcs.dnp.entity.RecoveryPlanTicket;
import com.tcs.dnp.repository.RecoveryPlanTicketRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanTicketService extends AbstractCrudService<RecoveryPlanTicket, Long> {
    public RecoveryPlanTicketService(RecoveryPlanTicketRepository repository) {
        super(repository, RecoveryPlanTicket.class);
    }
}

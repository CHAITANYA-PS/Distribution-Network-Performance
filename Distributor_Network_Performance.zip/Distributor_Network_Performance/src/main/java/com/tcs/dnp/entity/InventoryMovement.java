package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="inventory_movement",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InventoryMovement implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="movement_id")
 private Long movementId;
 @Column(name="inventory_document_id")
 private Long inventoryDocumentId;
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @Column(name="movement_type_id")
 private Long movementTypeId;
 @Column(name="quantity")
 private BigDecimal quantity;
 @Column(name="movement_date")
 private OffsetDateTime movementDate;
}
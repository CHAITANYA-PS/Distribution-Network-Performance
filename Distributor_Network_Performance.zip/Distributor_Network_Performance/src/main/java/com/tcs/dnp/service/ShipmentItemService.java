package com.tcs.dnp.service;

import com.tcs.dnp.entity.ShipmentItem;
import com.tcs.dnp.repository.ShipmentItemRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentItemService extends AbstractCrudService<ShipmentItem, Long> {
    public ShipmentItemService(ShipmentItemRepository repository) {
        super(repository, ShipmentItem.class);
    }
}

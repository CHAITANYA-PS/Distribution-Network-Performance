package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="transportation_activity",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TransportationActivity implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="transportation_activity_id")
 private Long transportationActivityId;
 @Column(name="shipment_id")
 private Long shipmentId;
 @Column(name="emission_factor_id")
 private Long emissionFactorId;
 @Column(name="origin")
 private String origin;
 @Column(name="destination")
 private String destination;
 @Column(name="distance_km")
 private BigDecimal distanceKm;
 @Column(name="activity_date")
 private LocalDate activityDate;
}
package com.tcs.dnp.repository;

import com.tcs.dnp.entity.RecoveryPlanTicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanTicketRepository extends JpaRepository<RecoveryPlanTicket, Long> {
}

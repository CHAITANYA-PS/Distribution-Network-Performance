package com.tcs.dnp.repository;

import com.tcs.dnp.entity.CommitmentProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentProgressRepository extends JpaRepository<CommitmentProgress, Long> {
}

package com.tcs.dnp.repository;

import com.tcs.dnp.entity.ContinuityStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityStatusTypeRepository extends JpaRepository<ContinuityStatusType, Long> {
}

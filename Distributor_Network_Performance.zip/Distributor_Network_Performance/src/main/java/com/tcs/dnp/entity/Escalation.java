package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="escalation",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Escalation implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="escalation_id")
 private Long escalationId;
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="escalated_to")
 private Long escalatedTo;
 @Column(name="escalation_level")
 private Integer escalationLevel;
 @Column(name="reason")
 private String reason;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
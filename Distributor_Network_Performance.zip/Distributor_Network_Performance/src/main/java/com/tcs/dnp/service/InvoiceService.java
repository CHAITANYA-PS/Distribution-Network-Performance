package com.tcs.dnp.service;

import com.tcs.dnp.entity.Invoice;
import com.tcs.dnp.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService extends AbstractCrudService<Invoice, Long> {
    public InvoiceService(InvoiceRepository repository) {
        super(repository, Invoice.class);
    }
}

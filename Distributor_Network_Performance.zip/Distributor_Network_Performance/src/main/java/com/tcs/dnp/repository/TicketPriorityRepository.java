package com.tcs.dnp.repository;

import com.tcs.dnp.entity.TicketPriority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketPriorityRepository extends JpaRepository<TicketPriority, Long> {
}

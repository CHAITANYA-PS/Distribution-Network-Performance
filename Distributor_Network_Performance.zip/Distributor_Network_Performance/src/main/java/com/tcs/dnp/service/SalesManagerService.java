package com.tcs.dnp.service;

import com.tcs.dnp.entity.SalesManager;
import com.tcs.dnp.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesManagerService extends AbstractCrudService<SalesManager, Long> {
    public SalesManagerService(SalesManagerRepository repository) {
        super(repository, SalesManager.class);
    }
}

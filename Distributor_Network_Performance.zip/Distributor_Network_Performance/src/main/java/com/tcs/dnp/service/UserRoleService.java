package com.tcs.dnp.service;

import com.tcs.dnp.entity.UserRole;
import com.tcs.dnp.repository.UserRoleRepository;
import org.springframework.stereotype.Service;

@Service
public class UserRoleService extends AbstractCrudService<UserRole, Long> {
    public UserRoleService(UserRoleRepository repository) {
        super(repository, UserRole.class);
    }
}

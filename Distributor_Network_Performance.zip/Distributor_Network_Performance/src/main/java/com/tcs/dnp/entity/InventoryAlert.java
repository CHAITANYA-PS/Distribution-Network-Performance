package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="inventory_alert",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InventoryAlert implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="alert_id")
 private Long alertId;
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @Column(name="alert_type")
 private String alertType;
 @Column(name="message")
 private String message;
 @Column(name="status")
 private String status;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
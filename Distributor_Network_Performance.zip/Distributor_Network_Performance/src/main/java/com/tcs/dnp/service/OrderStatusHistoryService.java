package com.tcs.dnp.service;

import com.tcs.dnp.entity.OrderStatusHistory;
import com.tcs.dnp.repository.OrderStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusHistoryService extends AbstractCrudService<OrderStatusHistory, Long> {
    public OrderStatusHistoryService(OrderStatusHistoryRepository repository) {
        super(repository, OrderStatusHistory.class);
    }
}

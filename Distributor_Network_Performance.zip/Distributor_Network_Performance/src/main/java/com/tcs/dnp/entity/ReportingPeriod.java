package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDate;
@Entity @Table(name="reporting_period",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ReportingPeriod implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="reporting_period_id")
 private Long reportingPeriodId;
 @Column(name="period_name")
 private String periodName;
 @Column(name="period_type")
 private String periodType;
 @Column(name="start_date")
 private LocalDate startDate;
 @Column(name="end_date")
 private LocalDate endDate;
}
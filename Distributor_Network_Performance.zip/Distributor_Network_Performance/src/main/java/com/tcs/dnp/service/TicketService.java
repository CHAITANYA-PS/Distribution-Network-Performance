package com.tcs.dnp.service;

import com.tcs.dnp.entity.Ticket;
import com.tcs.dnp.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketService extends AbstractCrudService<Ticket, Long> {
    public TicketService(TicketRepository repository) {
        super(repository, Ticket.class);
    }
}

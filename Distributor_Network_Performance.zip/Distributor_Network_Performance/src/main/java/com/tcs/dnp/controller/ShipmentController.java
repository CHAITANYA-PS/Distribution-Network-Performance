package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.Shipment;
import com.tcs.dnp.service.ShipmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/shipments")
public class ShipmentController {
    private final ShipmentService service;

    public ShipmentController(ShipmentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Shipment> create(@Valid @RequestBody Shipment model) {
        Shipment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/shipments/" + saved.getShipmentId())).body(saved);
    }

    @GetMapping("/{id}")
    public Shipment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Shipment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Shipment update(@PathVariable Long id, @Valid @RequestBody Shipment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

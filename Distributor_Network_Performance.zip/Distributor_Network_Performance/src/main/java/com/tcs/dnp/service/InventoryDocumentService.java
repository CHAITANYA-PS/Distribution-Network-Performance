package com.tcs.dnp.service;

import com.tcs.dnp.entity.InventoryDocument;
import com.tcs.dnp.repository.InventoryDocumentRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentService extends AbstractCrudService<InventoryDocument, Long> {
    public InventoryDocumentService(InventoryDocumentRepository repository) {
        super(repository, InventoryDocument.class);
    }
}

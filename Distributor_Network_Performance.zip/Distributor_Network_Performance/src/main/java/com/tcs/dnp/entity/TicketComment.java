package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="ticket_comment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketComment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="comment_id")
 private Long commentId;
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="comment_text")
 private String commentText;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
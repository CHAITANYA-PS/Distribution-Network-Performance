package com.tcs.dnp.repository;

import com.tcs.dnp.entity.InventoryAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryAlertRepository extends JpaRepository<InventoryAlert, Long> {
}

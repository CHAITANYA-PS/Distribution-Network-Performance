package com.tcs.dnp.repository;

import com.tcs.dnp.entity.HealthAssessmentAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthAssessmentAlertRepository extends JpaRepository<HealthAssessmentAlert, Long> {
}

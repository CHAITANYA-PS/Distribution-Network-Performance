package com.tcs.dnp.repository;

import com.tcs.dnp.entity.ProductBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductBatchRepository extends JpaRepository<ProductBatch, Long> {
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.TicketCategory;
import com.tcs.dnp.repository.TicketCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCategoryService extends AbstractCrudService<TicketCategory, Long> {
    public TicketCategoryService(TicketCategoryRepository repository) {
        super(repository, TicketCategory.class);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.DistributorCategory;
import com.tcs.dnp.repository.DistributorCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorCategoryService extends AbstractCrudService<DistributorCategory, Long> {
    public DistributorCategoryService(DistributorCategoryRepository repository) {
        super(repository, DistributorCategory.class);
    }
}

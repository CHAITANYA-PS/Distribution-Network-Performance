package com.tcs.dnp.service;

import com.tcs.dnp.entity.NotificationType;
import com.tcs.dnp.repository.NotificationTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationTypeService extends AbstractCrudService<NotificationType, Long> {
    public NotificationTypeService(NotificationTypeRepository repository) {
        super(repository, NotificationType.class);
    }
}

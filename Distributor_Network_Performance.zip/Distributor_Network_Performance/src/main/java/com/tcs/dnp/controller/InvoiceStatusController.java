package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.InvoiceStatus;
import com.tcs.dnp.service.InvoiceStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/invoice-statuses")
public class InvoiceStatusController {
    private final InvoiceStatusService service;

    public InvoiceStatusController(InvoiceStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InvoiceStatus> create(@Valid @RequestBody InvoiceStatus model) {
        InvoiceStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/invoice-statuses/" + saved.getInvoiceStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public InvoiceStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<InvoiceStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public InvoiceStatus update(@PathVariable Long id, @Valid @RequestBody InvoiceStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

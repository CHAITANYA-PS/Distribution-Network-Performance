package com.tcs.dnp.repository;

import com.tcs.dnp.entity.ContinuityAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityAssessmentRepository extends JpaRepository<ContinuityAssessment, Long> {
}

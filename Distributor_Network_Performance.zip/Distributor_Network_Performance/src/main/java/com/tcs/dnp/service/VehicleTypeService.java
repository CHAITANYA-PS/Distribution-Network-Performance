package com.tcs.dnp.service;

import com.tcs.dnp.entity.VehicleType;
import com.tcs.dnp.repository.VehicleTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class VehicleTypeService extends AbstractCrudService<VehicleType, Long> {
    public VehicleTypeService(VehicleTypeRepository repository) {
        super(repository, VehicleType.class);
    }
}

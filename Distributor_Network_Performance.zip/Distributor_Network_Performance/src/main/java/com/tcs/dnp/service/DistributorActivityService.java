package com.tcs.dnp.service;

import com.tcs.dnp.entity.DistributorActivity;
import com.tcs.dnp.repository.DistributorActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorActivityService extends AbstractCrudService<DistributorActivity, Long> {
    public DistributorActivityService(DistributorActivityRepository repository) {
        super(repository, DistributorActivity.class);
    }
}

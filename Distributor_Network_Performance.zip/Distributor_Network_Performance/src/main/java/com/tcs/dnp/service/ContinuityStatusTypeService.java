package com.tcs.dnp.service;

import com.tcs.dnp.entity.ContinuityStatusType;
import com.tcs.dnp.repository.ContinuityStatusTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityStatusTypeService extends AbstractCrudService<ContinuityStatusType, Long> {
    public ContinuityStatusTypeService(ContinuityStatusTypeRepository repository) {
        super(repository, ContinuityStatusType.class);
    }
}

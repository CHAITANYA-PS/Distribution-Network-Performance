package com.tcs.dnp.repository;

import com.tcs.dnp.entity.Distributor;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;

/** save / findById / findAll / deleteById come from JpaRepository; update is save() on an existing id. */
public interface DistributorRepository extends JpaRepository<Distributor, Long> {
    boolean existsByDistributorCode(String distributorCode);

    Optional<Distributor> findByDistributorCode(String distributorCode);

    List<Distributor> findByStatus(String status);
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.SalesRecord;
import com.tcs.dnp.repository.SalesRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesRecordService extends AbstractCrudService<SalesRecord, Long> {
    public SalesRecordService(SalesRecordRepository repository) {
        super(repository, SalesRecord.class);
    }
}

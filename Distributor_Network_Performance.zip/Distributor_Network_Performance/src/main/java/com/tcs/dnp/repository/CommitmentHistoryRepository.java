package com.tcs.dnp.repository;

import com.tcs.dnp.entity.CommitmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, Long> {
}

package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="recovery_plan",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryPlan implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="recovery_plan_id")
 private Long recoveryPlanId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="recovery_status_id")
 private Long recoveryStatusId;
 @Column(name="target_amount")
 private BigDecimal targetAmount;
 @Column(name="start_date")
 private LocalDate startDate;
 @Column(name="end_date")
 private LocalDate endDate;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
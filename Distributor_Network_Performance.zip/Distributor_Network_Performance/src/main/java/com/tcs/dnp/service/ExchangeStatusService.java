package com.tcs.dnp.service;

import com.tcs.dnp.entity.ExchangeStatus;
import com.tcs.dnp.repository.ExchangeStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeStatusService extends AbstractCrudService<ExchangeStatus, Long> {
    public ExchangeStatusService(ExchangeStatusRepository repository) {
        super(repository, ExchangeStatus.class);
    }
}

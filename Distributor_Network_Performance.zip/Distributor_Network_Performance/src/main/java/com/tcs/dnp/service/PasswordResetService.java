package com.tcs.dnp.service;

import com.tcs.dnp.entity.PasswordReset;
import com.tcs.dnp.repository.PasswordResetRepository;
import org.springframework.stereotype.Service;

@Service
public class PasswordResetService extends AbstractCrudService<PasswordReset, Long> {
    public PasswordResetService(PasswordResetRepository repository) {
        super(repository, PasswordReset.class);
    }
}

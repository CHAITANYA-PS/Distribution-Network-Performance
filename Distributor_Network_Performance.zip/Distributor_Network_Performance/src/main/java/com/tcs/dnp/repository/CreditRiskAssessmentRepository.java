package com.tcs.dnp.repository;

import com.tcs.dnp.entity.CreditRiskAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditRiskAssessmentRepository extends JpaRepository<CreditRiskAssessment, Long> {
}

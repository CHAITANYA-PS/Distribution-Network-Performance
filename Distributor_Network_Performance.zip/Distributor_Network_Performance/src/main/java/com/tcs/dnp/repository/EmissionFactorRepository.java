package com.tcs.dnp.repository;

import com.tcs.dnp.entity.EmissionFactor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmissionFactorRepository extends JpaRepository<EmissionFactor, Long> {
}

package com.tcs.dnp.service;

import com.tcs.dnp.entity.FinanceManager;
import com.tcs.dnp.repository.FinanceManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class FinanceManagerService extends AbstractCrudService<FinanceManager, Long> {
    public FinanceManagerService(FinanceManagerRepository repository) {
        super(repository, FinanceManager.class);
    }
}

package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="emission_factor",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class EmissionFactor implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="emission_factor_id")
 private Long emissionFactorId;
 @Column(name="vehicle_type_id")
 private Long vehicleTypeId;
 @Column(name="factor_value")
 private BigDecimal factorValue;
 @Column(name="unit")
 private String unit;
 @Column(name="valid_from")
 private LocalDate validFrom;
 @Column(name="valid_to")
 private LocalDate validTo;
}
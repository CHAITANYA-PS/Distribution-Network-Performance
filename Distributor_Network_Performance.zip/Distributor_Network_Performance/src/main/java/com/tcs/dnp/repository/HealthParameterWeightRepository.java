package com.tcs.dnp.repository;

import com.tcs.dnp.entity.HealthParameterWeight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterWeightRepository extends JpaRepository<HealthParameterWeight, Long> {
}

package com.tcs.dnp.repository;

import com.tcs.dnp.entity.DistributorOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorOrderRepository extends JpaRepository<DistributorOrder, Long> {
}

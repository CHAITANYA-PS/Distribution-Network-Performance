package com.tcs.dnp.repository;

import com.tcs.dnp.entity.Region;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RegionRepository extends JpaRepository<Region, Long> {
}

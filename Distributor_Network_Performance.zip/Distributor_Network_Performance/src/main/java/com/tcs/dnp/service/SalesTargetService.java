package com.tcs.dnp.service;

import com.tcs.dnp.entity.SalesTarget;
import com.tcs.dnp.repository.SalesTargetRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesTargetService extends AbstractCrudService<SalesTarget, Long> {
    public SalesTargetService(SalesTargetRepository repository) {
        super(repository, SalesTarget.class);
    }
}

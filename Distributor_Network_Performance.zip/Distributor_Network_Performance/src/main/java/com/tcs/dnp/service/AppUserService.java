package com.tcs.dnp.service;

import com.tcs.dnp.entity.AppUser;
import com.tcs.dnp.repository.AppUserRepository;
import org.springframework.stereotype.Service;

@Service
public class AppUserService extends AbstractCrudService<AppUser, Long> {
    public AppUserService(AppUserRepository repository) {
        super(repository, AppUser.class);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.UserSession;
import com.tcs.dnp.service.UserSessionService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/user-sessions")
public class UserSessionController {
    private final UserSessionService service;

    public UserSessionController(UserSessionService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<UserSession> create(@Valid @RequestBody UserSession model) {
        UserSession saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/user-sessions/" + saved.getSessionId())).body(saved);
    }

    @GetMapping("/{id}")
    public UserSession get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<UserSession> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public UserSession update(@PathVariable Long id, @Valid @RequestBody UserSession model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

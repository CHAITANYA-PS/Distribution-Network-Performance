package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.InventoryDocument;
import com.tcs.dnp.service.InventoryDocumentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory-documents")
public class InventoryDocumentController {
    private final InventoryDocumentService service;

    public InventoryDocumentController(InventoryDocumentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InventoryDocument> create(@Valid @RequestBody InventoryDocument model) {
        InventoryDocument saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/inventory-documents/" + saved.getInventoryDocumentId())).body(saved);
    }

    @GetMapping("/{id}")
    public InventoryDocument get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<InventoryDocument> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public InventoryDocument update(@PathVariable Long id, @Valid @RequestBody InventoryDocument model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

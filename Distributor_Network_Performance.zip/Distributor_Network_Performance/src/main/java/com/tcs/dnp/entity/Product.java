package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="product",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Product implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="product_id")
 private Long productId;
 @Column(name="sku")
 private String sku;
 @Column(name="product_name")
 private String productName;
 @Column(name="category_id")
 private Long categoryId;
 @Column(name="unit")
 private String unit;
 @Column(name="shelf_life_days")
 private Integer shelfLifeDays;
 @Column(name="status")
 private String status;
}
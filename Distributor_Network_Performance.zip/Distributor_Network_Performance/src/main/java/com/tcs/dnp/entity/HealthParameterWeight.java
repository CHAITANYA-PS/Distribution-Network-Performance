package com.tcs.dnp.entity;
import com.tcs.dnp.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="health_parameter_weight",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthParameterWeight implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="parameter_weight_id")
 private Long parameterWeightId;
 @Column(name="parameter_id")
 private Long parameterId;
 @Column(name="weight")
 private BigDecimal weight;
 @Column(name="valid_from")
 private LocalDate validFrom;
 @Column(name="valid_to")
 private LocalDate validTo;
}
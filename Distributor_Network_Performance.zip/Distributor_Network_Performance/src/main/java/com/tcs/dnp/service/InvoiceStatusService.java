package com.tcs.dnp.service;

import com.tcs.dnp.entity.InvoiceStatus;
import com.tcs.dnp.repository.InvoiceStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceStatusService extends AbstractCrudService<InvoiceStatus, Long> {
    public InvoiceStatusService(InvoiceStatusRepository repository) {
        super(repository, InvoiceStatus.class);
    }
}

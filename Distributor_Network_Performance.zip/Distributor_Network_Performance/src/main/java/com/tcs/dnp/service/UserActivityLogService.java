package com.tcs.dnp.service;

import com.tcs.dnp.entity.UserActivityLog;
import com.tcs.dnp.repository.UserActivityLogRepository;
import org.springframework.stereotype.Service;

@Service
public class UserActivityLogService extends AbstractCrudService<UserActivityLog, Long> {
    public UserActivityLogService(UserActivityLogRepository repository) {
        super(repository, UserActivityLog.class);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.Commitment;
import com.tcs.dnp.service.CommitmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/commitments")
public class CommitmentController {
    private final CommitmentService service;

    public CommitmentController(CommitmentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Commitment> create(@Valid @RequestBody Commitment model) {
        Commitment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/commitments/" + saved.getCommitmentId())).body(saved);
    }

    @GetMapping("/{id}")
    public Commitment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Commitment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Commitment update(@PathVariable Long id, @Valid @RequestBody Commitment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

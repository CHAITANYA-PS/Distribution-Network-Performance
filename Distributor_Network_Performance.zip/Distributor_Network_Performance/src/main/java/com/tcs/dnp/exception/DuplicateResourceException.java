package com.tcs.dnp.exception;

/** A unique business key already exists (HTTP 409). */
public class DuplicateResourceException extends RuntimeException {
    public DuplicateResourceException(String message) {
        super(message);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.entity.ActivityType;
import com.tcs.dnp.service.ActivityTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/activity-types")
public class ActivityTypeController {
    private final ActivityTypeService service;

    public ActivityTypeController(ActivityTypeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ActivityType> create(@Valid @RequestBody ActivityType model) {
        ActivityType saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/activity-types/" + saved.getActivityTypeId())).body(saved);
    }

    @GetMapping("/{id}")
    public ActivityType get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ActivityType> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ActivityType update(@PathVariable Long id, @Valid @RequestBody ActivityType model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.entity.RecoveryPlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanStatusRepository extends JpaRepository<RecoveryPlanStatus, Long> {
}

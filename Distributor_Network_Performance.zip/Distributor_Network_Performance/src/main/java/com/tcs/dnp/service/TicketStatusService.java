package com.tcs.dnp.service;

import com.tcs.dnp.entity.TicketStatus;
import com.tcs.dnp.repository.TicketStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusService extends AbstractCrudService<TicketStatus, Long> {
    public TicketStatusService(TicketStatusRepository repository) {
        super(repository, TicketStatus.class);
    }
}

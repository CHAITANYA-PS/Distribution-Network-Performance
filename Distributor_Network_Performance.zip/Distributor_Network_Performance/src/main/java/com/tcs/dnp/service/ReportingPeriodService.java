package com.tcs.dnp.service;

import com.tcs.dnp.entity.ReportingPeriod;
import com.tcs.dnp.repository.ReportingPeriodRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportingPeriodService extends AbstractCrudService<ReportingPeriod, Long> {
    public ReportingPeriodService(ReportingPeriodRepository repository) {
        super(repository, ReportingPeriod.class);
    }
}

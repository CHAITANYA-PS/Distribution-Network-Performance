package com.tcs.dnp.service;

import com.tcs.dnp.exception.BusinessRuleException;
import com.tcs.dnp.exception.DuplicateResourceException;
import com.tcs.dnp.entity.Distributor;
import com.tcs.dnp.repository.DistributorRepository;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.time.OffsetDateTime;

@Service
public class DistributorService extends AbstractCrudService<Distributor, Long> {
    static final String DEFAULT_STATUS = "ACTIVE";
    private final DistributorRepository distributors;

    public DistributorService(DistributorRepository repository) {
        super(repository, Distributor.class);
        this.distributors = repository;
    }

    @Override
    protected void beforeCreate(Distributor d) {
        if (distributors.existsByDistributorCode(d.getDistributorCode())) {
            throw new DuplicateResourceException("Distributor code already exists: " + d.getDistributorCode());
        }
        if (d.getStatus() == null || d.getStatus().isBlank()) {
            d.setStatus(DEFAULT_STATUS);
        }
        if (d.getOnboardingDate() == null) {
            d.setOnboardingDate(LocalDate.now());
        }
        OffsetDateTime now = OffsetDateTime.now();
        d.setCreatedAt(now);
        d.setUpdatedAt(now);
    }

    @Override
    protected void beforeUpdate(Long id, Distributor d, Distributor existing) {
        distributors.findByDistributorCode(d.getDistributorCode())
                .filter(other -> !other.getDistributorId().equals(id))
                .ifPresent(other -> {
                    throw new DuplicateResourceException("Distributor code already exists: " + d.getDistributorCode());
                });
        if (d.getStatus() == null || d.getStatus().isBlank()) {
            throw new BusinessRuleException("Distributor status must not be blank");
        }
        d.setCreatedAt(existing.getCreatedAt());
        d.setUpdatedAt(OffsetDateTime.now());
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.entity.RiskBand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskBandRepository extends JpaRepository<RiskBand, Long> {
}

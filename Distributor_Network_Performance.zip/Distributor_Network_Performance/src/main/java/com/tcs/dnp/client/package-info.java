/**
 * client package (placeholder to match the required project structure).
 */
package com.tcs.dnp.client;

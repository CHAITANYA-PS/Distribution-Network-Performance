/* Session guard lives in ../assets/dsphere-enhance.js */

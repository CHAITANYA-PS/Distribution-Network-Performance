"use strict";
(function(){
const $=(s,r=document)=>r.querySelector(s),$$=(s,r=document)=>[...r.querySelectorAll(s)];
const parts=location.pathname.split("/").filter(Boolean);
const file=decodeURIComponent(parts.pop()||"index.html");
const folder=parts.pop()||"";
const ROLE={Distributor:"distributor",Finance:"finance-manager",Manufacturer:"manufacturer",Recovery:"recovery-manager",Sales:"sales-manager"}[folder];
const HOME={Distributor:"Distributor",Finance:"Finance Manager",Manufacturer:"Manufacturer",Recovery:"Recovery Manager",Sales:"Sales Manager"}[folder]||"Dsphere";

/* session guard: send signed-out visitors to Login, others to their own workspace */
try{
 const u=JSON.parse(sessionStorage.getItem("dsphereAuthenticatedUser")||"null");
 if(!u){location.replace("../Login/index.html");return}
 if(ROLE&&u.role!==ROLE&&u.landingPage){location.replace(u.landingPage);return}
}catch(e){}

function toast(msg){let t=$("#toast")||$(".dashboard-toast");if(!t){t=document.createElement("div");t.id="toast";t.className="toast";document.body.appendChild(t)}
 t.textContent=msg;t.classList.add("show");t.style.opacity=1;clearTimeout(t._t);t._t=setTimeout(()=>{t.classList.remove("show");t.style.opacity=""},2200)}
window.DsphereUI={toast};

document.addEventListener("DOMContentLoaded",()=>{
 const body=document.body,top=$(".topbar"),side=$(".sidebar");

 /* logout: clear session */
 $$(".logout-button,.logout-btn,.logout").forEach(b=>b.addEventListener("click",()=>sessionStorage.removeItem("dsphereAuthenticatedUser"),true));

 /* header shadow on scroll + back to top */
 const tb=document.createElement("button");tb.id="dsTop";tb.type="button";tb.title="Back to top";tb.setAttribute("aria-label","Back to top");tb.textContent="↑";
 tb.onclick=()=>scrollTo({top:0,behavior:"smooth"});body.appendChild(tb);
 addEventListener("scroll",()=>{top?.classList.toggle("scrolled",scrollY>4);tb.classList.toggle("show",scrollY>400)},{passive:true});

 /* mobile navigation */
 if(side){
  const ov=document.createElement("div");ov.id="dsOverlay";body.appendChild(ov);
  const btn=document.createElement("button");btn.type="button";btn.className="dsphere-menu-btn";btn.textContent="☰";btn.setAttribute("aria-label","Open navigation");
  const brand=$(".brand",top);if(brand&&brand.parentNode)brand.parentNode.insertBefore(btn,brand);
  const set=o=>{body.classList.toggle("ds-nav-open",o);btn.setAttribute("aria-expanded",o)};
  btn.onclick=()=>set(!body.classList.contains("ds-nav-open"));ov.onclick=()=>set(false);
  addEventListener("keydown",e=>{if(e.key==="Escape")set(false)});
  side.addEventListener("click",e=>{if(e.target.closest("a"))set(false)});
 }

 /* sidebar: mark current page, open its group */
 const markNav=()=>$$(".sidebar a[href]").forEach(a=>{
  const h=(a.getAttribute("href")||"").split("#")[0];
  if(h&&decodeURIComponent(h)===file){a.classList.add("active");a.setAttribute("aria-current","page");a.closest(".nav-group")?.classList.add("open");
   const t=a.closest(".nav-group")?.querySelector(".nav-toggle");t?.classList.add("active");t?.setAttribute("aria-expanded","true")}});
 markNav();
 if(side){new MutationObserver(()=>{if(!side.dataset.m){side.dataset.m=1;markNav();delete side.dataset.m}}).observe(side,{childList:true,subtree:true})}

 /* breadcrumbs */
 const h1=$("main h1,main h2,.main h1,.main h2");const cur=($(".sidebar a.active")?.textContent.trim().replace(/\s+/g," ")||h1?.textContent.trim()||"").replace(/^[^\w]+\s*/,"");
 const host=$("main>.page-head,main>.head,main>.hero,.main>.page-head,.main>.head,main,.main");
 if(host&&cur&&!$(".dsphere-crumbs")){const n=document.createElement("nav");n.className="dsphere-crumbs";n.setAttribute("aria-label","Breadcrumb");
  const home=$(".sidebar a[href]")?.getAttribute("href")||"#";n.innerHTML=`<a href="${home}">${HOME}</a><span>›</span><span>${cur}</span>`;
  host.parentNode===(host.matches("main,.main")?host.parentNode:host.parentNode)&&(host.matches("main,.main")?host.prepend(n):host.parentNode.insertBefore(n,host))}

 /* footer */
 if(!$(".footer,.dsphere-footer")){const f=document.createElement("footer");f.className="dsphere-footer";f.textContent="Empowering Distributors | Enabling Sustainable Growth";
  const app=$(".app,.app-shell");(app&&app.parentNode||body).insertBefore(f,$("#toast,script",app?.parentNode)||null);}

 /* tooltips on chart bars */
 const tip=document.createElement("div");tip.id="dsTip";body.appendChild(tip);
 document.addEventListener("mousemove",e=>{const b=e.target.closest?.(".bar,.bars i,.bar-col,.bar-item,.bar-group");
  if(!b){tip.style.opacity=0;return}
  const txt=(b.querySelector(".bar-value,b")?.textContent||"")+" "+(b.querySelector(".bar-label,small,span")?.textContent||b.title||"");
  const val=b.style.height||b.querySelector(".bar")?.style.height;
  tip.textContent=(txt.trim()||val||"");tip.style.opacity=tip.textContent?1:0;tip.style.left=e.clientX+14+"px";tip.style.top=e.clientY+14+"px"});

 /* chart animation + KPI count-up */
 const io=new IntersectionObserver(es=>es.forEach(en=>{if(en.isIntersecting){en.target.classList.add("charts-in");io.unobserve(en.target)}}),{threshold:.2});
 const watch=()=>$$(".bar-chart,.bars,.histogram,.chart-shell,.inventory-bars,.panel,.card").forEach(c=>{if(!c._w&&c.querySelector(".bar,i")){c._w=1;io.observe(c)}});
 watch();
 const count=el=>{if(el._c||el.children.length)return;const m=el.textContent.match(/^(\D*?)([\d,]+(?:\.\d+)?)(.*)$/);if(!m)return;el._c=1;
  const end=parseFloat(m[2].replace(/,/g,"")),dec=(m[2].split(".")[1]||"").length,t0=performance.now();
  const step=t=>{const p=Math.min(1,(t-t0)/900),v=end*(1-Math.pow(1-p,3));el.textContent=m[1]+v.toLocaleString("en-US",{minimumFractionDigits:dec,maximumFractionDigits:dec})+m[3];if(p<1)requestAnimationFrame(step)};requestAnimationFrame(step)};
 if(!matchMedia("(prefers-reduced-motion:reduce)").matches)$$(".kpi h3,.kpi strong,.stats strong,.stat strong,.stat b").forEach(count);

 /* tables: sortable columns, CSV export */
 const enhanceTables=()=>$$("main table:not([data-ds])").forEach(t=>{t.dataset.ds=1;const hs=$$("thead th",t);if(!hs.length||!t.tBodies[0])return;
  hs.forEach((th,i)=>{th.classList.add("sortable");th.tabIndex=0;const go=()=>{const asc=!th.classList.contains("sort-asc");hs.forEach(x=>x.classList.remove("sort-asc","sort-desc"));th.classList.add(asc?"sort-asc":"sort-desc");
   const rows=[...t.tBodies[0].rows],val=r=>(r.cells[i]?.textContent||"").trim(),num=s=>parseFloat(s.replace(/[^\d.\-]/g,""));
   rows.sort((a,b)=>{const x=val(a),y=val(b),nx=num(x),ny=num(y);const c=(!isNaN(nx)&&!isNaN(ny)&&/\d/.test(x)&&/\d/.test(y))?nx-ny:x.localeCompare(y,undefined,{numeric:true});return asc?c:-c});
   rows.forEach(r=>t.tBodies[0].appendChild(r))};th.onclick=go;th.onkeydown=e=>{if(e.key==="Enter"){e.preventDefault();go()}}});
  if(t.rows.length>3&&!t.closest("[data-ds-tools]")){const w=t.closest(".table-wrap,.tablewrap")||t.parentNode;w.dataset.dsTools=1;
   const bar=document.createElement("div");bar.className="dsphere-tools";const b=document.createElement("button");b.type="button";b.className="secondary";b.textContent="Export CSV";
   b.onclick=()=>{const csv=[...t.rows].filter(r=>r.style.display!=="none").map(r=>[...r.cells].map(c=>'"'+c.textContent.trim().replace(/\s+/g," ").replace(/"/g,'""')+'"').join(",")).join("\n");
    const a=document.createElement("a");a.href=URL.createObjectURL(new Blob([csv],{type:"text/csv"}));a.download=(file.replace(".html","")||"table")+".csv";a.click();toast("Table exported as CSV.")};
   bar.appendChild(b);w.parentNode.insertBefore(bar,w)}});
 enhanceTables();
 const main=$("main,.main,#app");if(main)new MutationObserver(()=>{enhanceTables();watch()}).observe(main,{childList:true,subtree:true});

 /* command palette: Ctrl/Cmd+K or "/" */
 const links=$$(".sidebar a[href]").map(a=>({t:a.textContent.trim().replace(/\s+/g," "),h:a.getAttribute("href")}));
 const pal=document.createElement("div");pal.id="dsPal";pal.innerHTML='<div class="box"><input placeholder="Jump to a page…" aria-label="Jump to a page"><ul></ul><small>Enter to open · Esc to close</small></div>';body.appendChild(pal);
 const inp=$("input",pal),ul=$("ul",pal);let sel=0,shown=[];
 const draw=()=>{const q=inp.value.toLowerCase();shown=links.filter(l=>l.t.toLowerCase().includes(q));sel=0;ul.innerHTML=shown.map((l,i)=>`<li class="${i?"":"sel"}"><a href="${l.h}">${l.t}</a></li>`).join("")||"<li><a>No matching pages</a></li>"};
 const open=()=>{pal.classList.add("open");inp.value="";draw();inp.focus()},close=()=>pal.classList.remove("open");
 addEventListener("keydown",e=>{const typing=/INPUT|TEXTAREA|SELECT/.test(document.activeElement.tagName);
  if((e.ctrlKey||e.metaKey)&&e.key.toLowerCase()==="k"){e.preventDefault();open()}
  else if(e.key==="/"&&!typing){e.preventDefault();open()}
  else if(pal.classList.contains("open")){if(e.key==="Escape")close();
   if(e.key==="ArrowDown"||e.key==="ArrowUp"){e.preventDefault();sel=(sel+(e.key==="ArrowDown"?1:-1)+shown.length)%shown.length;$$("li",ul).forEach((li,i)=>li.classList.toggle("sel",i===sel))}
   if(e.key==="Enter"&&shown[sel])location.href=shown[sel].h}});
 inp.oninput=draw;pal.onclick=e=>{if(e.target===pal)close()};
 const si=$(".topbar input[type=search],.topbar input.search,.topbar .search input,.topbar input.global-search");
 if(si&&!si.placeholder.includes("⌘"))si.title="Press / or Ctrl+K to jump to any page";
});
})();

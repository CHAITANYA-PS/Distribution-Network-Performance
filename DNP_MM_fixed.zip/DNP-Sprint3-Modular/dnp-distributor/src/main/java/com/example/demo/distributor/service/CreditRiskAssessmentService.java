package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.CreditRiskAssessment;
import com.example.demo.distributor.repository.CreditRiskAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CreditRiskAssessmentService extends AbstractCrudService<CreditRiskAssessment, Long> {
    public CreditRiskAssessmentService(CreditRiskAssessmentRepository repository) {
        super(repository, CreditRiskAssessment.class);
    }
}

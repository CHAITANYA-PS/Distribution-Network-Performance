package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.CommitmentStatus;
import com.example.demo.distributor.repository.CommitmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentStatusService extends AbstractCrudService<CommitmentStatus, Long> {
    public CommitmentStatusService(CommitmentStatusRepository repository) {
        super(repository, CommitmentStatus.class);
    }
}

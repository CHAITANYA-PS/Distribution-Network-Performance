package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.Region;
import com.example.demo.distributor.repository.RegionRepository;
import org.springframework.stereotype.Service;

@Service
public class RegionService extends AbstractCrudService<Region, Long> {
    public RegionService(RegionRepository repository) {
        super(repository, Region.class);
    }
}

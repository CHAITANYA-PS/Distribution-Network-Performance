package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.Category;
import com.example.demo.distributor.repository.CategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CategoryService extends AbstractCrudService<Category, Long> {
    public CategoryService(CategoryRepository repository) {
        super(repository, Category.class);
    }
}

package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.CommitmentProgress;
import com.example.demo.distributor.repository.CommitmentProgressRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentProgressService extends AbstractCrudService<CommitmentProgress, Long> {
    public CommitmentProgressService(CommitmentProgressRepository repository) {
        super(repository, CommitmentProgress.class);
    }
}

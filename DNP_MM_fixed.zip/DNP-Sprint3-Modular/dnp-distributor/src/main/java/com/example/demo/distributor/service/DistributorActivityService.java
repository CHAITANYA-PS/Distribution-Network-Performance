package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.DistributorActivity;
import com.example.demo.distributor.repository.DistributorActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorActivityService extends AbstractCrudService<DistributorActivity, Long> {
    public DistributorActivityService(DistributorActivityRepository repository) {
        super(repository, DistributorActivity.class);
    }
}

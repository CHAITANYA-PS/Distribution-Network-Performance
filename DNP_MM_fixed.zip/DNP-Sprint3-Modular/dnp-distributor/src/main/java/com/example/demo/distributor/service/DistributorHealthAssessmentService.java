package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.DistributorHealthAssessment;
import com.example.demo.distributor.repository.DistributorHealthAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorHealthAssessmentService extends AbstractCrudService<DistributorHealthAssessment, Long> {
    public DistributorHealthAssessmentService(DistributorHealthAssessmentRepository repository) {
        super(repository, DistributorHealthAssessment.class);
    }
}

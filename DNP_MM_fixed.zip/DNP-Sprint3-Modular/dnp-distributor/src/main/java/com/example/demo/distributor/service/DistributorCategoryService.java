package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.DistributorCategory;
import com.example.demo.distributor.repository.DistributorCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorCategoryService extends AbstractCrudService<DistributorCategory, Long> {
    public DistributorCategoryService(DistributorCategoryRepository repository) {
        super(repository, DistributorCategory.class);
    }
}

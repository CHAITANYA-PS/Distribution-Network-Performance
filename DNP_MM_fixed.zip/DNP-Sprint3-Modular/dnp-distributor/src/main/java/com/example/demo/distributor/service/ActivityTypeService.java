package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.ActivityType;
import com.example.demo.distributor.repository.ActivityTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ActivityTypeService extends AbstractCrudService<ActivityType, Long> {
    public ActivityTypeService(ActivityTypeRepository repository) {
        super(repository, ActivityType.class);
    }
}

package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.ContinuityStatusType;
import com.example.demo.distributor.repository.ContinuityStatusTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityStatusTypeService extends AbstractCrudService<ContinuityStatusType, Long> {
    public ContinuityStatusTypeService(ContinuityStatusTypeRepository repository) {
        super(repository, ContinuityStatusType.class);
    }
}

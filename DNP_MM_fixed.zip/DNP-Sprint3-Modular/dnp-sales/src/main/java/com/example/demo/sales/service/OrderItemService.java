package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.OrderItem;
import com.example.demo.sales.repository.OrderItemRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService extends AbstractCrudService<OrderItem, Long> {
    public OrderItemService(OrderItemRepository repository) {
        super(repository, OrderItem.class);
    }
}

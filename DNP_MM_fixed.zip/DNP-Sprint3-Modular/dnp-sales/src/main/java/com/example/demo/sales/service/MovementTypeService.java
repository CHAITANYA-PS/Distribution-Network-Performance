package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.MovementType;
import com.example.demo.sales.repository.MovementTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class MovementTypeService extends AbstractCrudService<MovementType, Long> {
    public MovementTypeService(MovementTypeRepository repository) {
        super(repository, MovementType.class);
    }
}

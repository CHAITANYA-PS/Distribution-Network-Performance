package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.SalesRecord;
import com.example.demo.sales.repository.SalesRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesRecordService extends AbstractCrudService<SalesRecord, Long> {
    public SalesRecordService(SalesRecordRepository repository) {
        super(repository, SalesRecord.class);
    }
}

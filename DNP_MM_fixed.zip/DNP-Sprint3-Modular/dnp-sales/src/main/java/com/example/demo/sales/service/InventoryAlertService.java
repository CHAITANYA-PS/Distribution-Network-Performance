package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.InventoryAlert;
import com.example.demo.sales.repository.InventoryAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryAlertService extends AbstractCrudService<InventoryAlert, Long> {
    public InventoryAlertService(InventoryAlertRepository repository) {
        super(repository, InventoryAlert.class);
    }
}

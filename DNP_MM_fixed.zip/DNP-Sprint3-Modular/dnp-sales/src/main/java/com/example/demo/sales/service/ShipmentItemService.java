package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.ShipmentItem;
import com.example.demo.sales.repository.ShipmentItemRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentItemService extends AbstractCrudService<ShipmentItem, Long> {
    public ShipmentItemService(ShipmentItemRepository repository) {
        super(repository, ShipmentItem.class);
    }
}

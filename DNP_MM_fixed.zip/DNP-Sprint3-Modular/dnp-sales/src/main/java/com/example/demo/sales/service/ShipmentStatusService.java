package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.ShipmentStatus;
import com.example.demo.sales.repository.ShipmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentStatusService extends AbstractCrudService<ShipmentStatus, Long> {
    public ShipmentStatusService(ShipmentStatusRepository repository) {
        super(repository, ShipmentStatus.class);
    }
}

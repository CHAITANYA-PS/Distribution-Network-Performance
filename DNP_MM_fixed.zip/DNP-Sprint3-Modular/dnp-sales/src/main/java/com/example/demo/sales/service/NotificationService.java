package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.Notification;
import com.example.demo.sales.repository.NotificationRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationService extends AbstractCrudService<Notification, Long> {
    public NotificationService(NotificationRepository repository) {
        super(repository, Notification.class);
    }
}

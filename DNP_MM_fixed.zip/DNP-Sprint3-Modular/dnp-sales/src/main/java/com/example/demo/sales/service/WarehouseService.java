package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.Warehouse;
import com.example.demo.sales.repository.WarehouseRepository;
import org.springframework.stereotype.Service;

@Service
public class WarehouseService extends AbstractCrudService<Warehouse, Long> {
    public WarehouseService(WarehouseRepository repository) {
        super(repository, Warehouse.class);
    }
}

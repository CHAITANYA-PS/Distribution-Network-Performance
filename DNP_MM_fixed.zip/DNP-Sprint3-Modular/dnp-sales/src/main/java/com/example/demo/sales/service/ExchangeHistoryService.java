package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.ExchangeHistory;
import com.example.demo.sales.repository.ExchangeHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeHistoryService extends AbstractCrudService<ExchangeHistory, Long> {
    public ExchangeHistoryService(ExchangeHistoryRepository repository) {
        super(repository, ExchangeHistory.class);
    }
}

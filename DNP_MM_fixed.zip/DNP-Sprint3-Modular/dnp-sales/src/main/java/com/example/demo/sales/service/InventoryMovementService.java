package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.InventoryMovement;
import com.example.demo.sales.repository.InventoryMovementRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryMovementService extends AbstractCrudService<InventoryMovement, Long> {
    public InventoryMovementService(InventoryMovementRepository repository) {
        super(repository, InventoryMovement.class);
    }
}

package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.InventoryDocumentType;
import com.example.demo.sales.repository.InventoryDocumentTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentTypeService extends AbstractCrudService<InventoryDocumentType, Long> {
    public InventoryDocumentTypeService(InventoryDocumentTypeRepository repository) {
        super(repository, InventoryDocumentType.class);
    }
}

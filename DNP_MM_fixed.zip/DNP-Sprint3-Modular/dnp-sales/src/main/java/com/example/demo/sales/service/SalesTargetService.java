package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.SalesTarget;
import com.example.demo.sales.repository.SalesTargetRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesTargetService extends AbstractCrudService<SalesTarget, Long> {
    public SalesTargetService(SalesTargetRepository repository) {
        super(repository, SalesTarget.class);
    }
}

package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.SalesManager;
import com.example.demo.sales.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesManagerService extends AbstractCrudService<SalesManager, Long> {
    public SalesManagerService(SalesManagerRepository repository) {
        super(repository, SalesManager.class);
    }
}

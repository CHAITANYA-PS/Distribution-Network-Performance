package com.example.demo;

import org.springframework.boot.autoconfigure.SpringBootApplication;

/**
 * Test-only bootstrap for the dnp-recovery module. Library modules have no main class, so slice tests
 * (@WebMvcTest, @DataJpaTest) need this @SpringBootConfiguration to start. It sits in the base package so
 * the shared GlobalExceptionHandler (system-admin) is picked up exactly as in the assembled application.
 */
@SpringBootApplication
public class RecoveryModuleTestApplication {
}

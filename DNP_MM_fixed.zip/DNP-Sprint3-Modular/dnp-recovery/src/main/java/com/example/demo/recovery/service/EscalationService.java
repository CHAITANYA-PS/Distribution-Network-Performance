package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.Escalation;
import com.example.demo.recovery.repository.EscalationRepository;
import org.springframework.stereotype.Service;

@Service
public class EscalationService extends AbstractCrudService<Escalation, Long> {
    public EscalationService(EscalationRepository repository) {
        super(repository, Escalation.class);
    }
}

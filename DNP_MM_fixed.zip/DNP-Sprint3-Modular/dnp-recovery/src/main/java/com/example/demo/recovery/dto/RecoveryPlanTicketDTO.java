package com.example.demo.recovery.dto;

/** Communication DTO for RecoveryPlanTicket; contains scalar values only and no DAO behavior. */
public class RecoveryPlanTicketDTO {
    private Long recoveryPlanTicketId;
    private Long recoveryPlanId;
    private Long ticketId;

    public RecoveryPlanTicketDTO() {}

    public Long getRecoveryPlanTicketId() { return recoveryPlanTicketId; }
    public void setRecoveryPlanTicketId(Long recoveryPlanTicketId) { this.recoveryPlanTicketId = recoveryPlanTicketId; }

    public Long getRecoveryPlanId() { return recoveryPlanId; }
    public void setRecoveryPlanId(Long recoveryPlanId) { this.recoveryPlanId = recoveryPlanId; }

    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }

}
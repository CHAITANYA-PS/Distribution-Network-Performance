package com.example.demo.recovery.dto;

/** Communication DTO for TicketPriority; contains scalar values only and no DAO behavior. */
public class TicketPriorityDTO {
    private Long ticketPriorityId;
    private String priorityName;
    private Integer severityRank;

    public TicketPriorityDTO() {}

    public Long getTicketPriorityId() { return ticketPriorityId; }
    public void setTicketPriorityId(Long ticketPriorityId) { this.ticketPriorityId = ticketPriorityId; }

    public String getPriorityName() { return priorityName; }
    public void setPriorityName(String priorityName) { this.priorityName = priorityName; }

    public Integer getSeverityRank() { return severityRank; }
    public void setSeverityRank(Integer severityRank) { this.severityRank = severityRank; }

}
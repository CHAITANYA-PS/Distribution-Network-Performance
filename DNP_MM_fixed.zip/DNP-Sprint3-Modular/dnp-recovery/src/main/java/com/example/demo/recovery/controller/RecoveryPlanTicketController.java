package com.example.demo.recovery.controller;

import jakarta.validation.Valid;

import com.example.demo.recovery.entity.RecoveryPlanTicket;
import com.example.demo.recovery.service.RecoveryPlanTicketService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/recovery-plan-tickets")
public class RecoveryPlanTicketController {
    private final RecoveryPlanTicketService service;

    public RecoveryPlanTicketController(RecoveryPlanTicketService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RecoveryPlanTicket> create(@Valid @RequestBody RecoveryPlanTicket model) {
        RecoveryPlanTicket saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/recovery-plan-tickets/" + saved.getRecoveryPlanTicketId())).body(saved);
    }

    @GetMapping("/{id}")
    public RecoveryPlanTicket get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RecoveryPlanTicket> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public RecoveryPlanTicket update(@PathVariable Long id, @Valid @RequestBody RecoveryPlanTicket model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

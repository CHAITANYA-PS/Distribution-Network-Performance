package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.RecoveryManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryManagerRepository extends JpaRepository<RecoveryManager, Long> {
}

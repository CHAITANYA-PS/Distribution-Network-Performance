package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.Escalation;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EscalationRepository extends JpaRepository<Escalation, Long> {
}

package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.RecoveryPlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanStatusRepository extends JpaRepository<RecoveryPlanStatus, Long> {
}

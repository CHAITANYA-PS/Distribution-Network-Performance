package com.example.demo.recovery.dto;

import java.time.OffsetDateTime;

/** Communication DTO for Escalation; contains scalar values only and no DAO behavior. */
public class EscalationDTO {
    private Long escalationId;
    private Long ticketId;
    private Long escalatedTo;
    private Integer escalationLevel;
    private String reason;
    private OffsetDateTime createdAt;

    public EscalationDTO() {}

    public Long getEscalationId() { return escalationId; }
    public void setEscalationId(Long escalationId) { this.escalationId = escalationId; }

    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }

    public Long getEscalatedTo() { return escalatedTo; }
    public void setEscalatedTo(Long escalatedTo) { this.escalatedTo = escalatedTo; }

    public Integer getEscalationLevel() { return escalationLevel; }
    public void setEscalationLevel(Integer escalationLevel) { this.escalationLevel = escalationLevel; }

    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.TicketPriority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketPriorityRepository extends JpaRepository<TicketPriority, Long> {
}

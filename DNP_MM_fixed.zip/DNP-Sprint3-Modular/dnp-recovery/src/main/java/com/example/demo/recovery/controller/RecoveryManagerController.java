package com.example.demo.recovery.controller;

import jakarta.validation.Valid;

import com.example.demo.recovery.entity.RecoveryManager;
import com.example.demo.recovery.service.RecoveryManagerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/recovery-managers")
public class RecoveryManagerController {
    private final RecoveryManagerService service;

    public RecoveryManagerController(RecoveryManagerService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RecoveryManager> create(@Valid @RequestBody RecoveryManager model) {
        RecoveryManager saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/recovery-managers/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public RecoveryManager get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RecoveryManager> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public RecoveryManager update(@PathVariable Long id, @Valid @RequestBody RecoveryManager model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

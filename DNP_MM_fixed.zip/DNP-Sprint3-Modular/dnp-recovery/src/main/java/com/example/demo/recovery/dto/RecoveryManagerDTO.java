package com.example.demo.recovery.dto;

/** Communication DTO for RecoveryManager; contains scalar values only and no DAO behavior. */
public class RecoveryManagerDTO {
    private Long userId;
    private Long regionId;

    public RecoveryManagerDTO() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }

}
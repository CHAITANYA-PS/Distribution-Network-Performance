package com.example.demo.recovery.dto;

/** Communication DTO for RecoveryPlanStatus; contains scalar values only and no DAO behavior. */
public class RecoveryPlanStatusDTO {
    private Long recoveryStatusId;
    private String statusName;

    public RecoveryPlanStatusDTO() {}

    public Long getRecoveryStatusId() { return recoveryStatusId; }
    public void setRecoveryStatusId(Long recoveryStatusId) { this.recoveryStatusId = recoveryStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

}
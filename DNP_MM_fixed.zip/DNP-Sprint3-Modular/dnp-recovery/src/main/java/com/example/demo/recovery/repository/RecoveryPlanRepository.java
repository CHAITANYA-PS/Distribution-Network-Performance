package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.RecoveryPlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanRepository extends JpaRepository<RecoveryPlan, Long> {
}

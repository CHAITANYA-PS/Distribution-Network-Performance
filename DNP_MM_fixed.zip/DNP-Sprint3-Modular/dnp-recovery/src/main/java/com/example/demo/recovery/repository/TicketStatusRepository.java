package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketStatusRepository extends JpaRepository<TicketStatus, Long> {
}

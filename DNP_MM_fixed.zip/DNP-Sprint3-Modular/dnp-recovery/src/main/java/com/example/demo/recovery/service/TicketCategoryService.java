package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.TicketCategory;
import com.example.demo.recovery.repository.TicketCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCategoryService extends AbstractCrudService<TicketCategory, Long> {
    public TicketCategoryService(TicketCategoryRepository repository) {
        super(repository, TicketCategory.class);
    }
}

package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.Ticket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketRepository extends JpaRepository<Ticket, Long> {
}

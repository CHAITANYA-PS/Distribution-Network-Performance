package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.TicketComment;
import com.example.demo.recovery.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCommentService extends AbstractCrudService<TicketComment, Long> {
    public TicketCommentService(TicketCommentRepository repository) {
        super(repository, TicketComment.class);
    }
}

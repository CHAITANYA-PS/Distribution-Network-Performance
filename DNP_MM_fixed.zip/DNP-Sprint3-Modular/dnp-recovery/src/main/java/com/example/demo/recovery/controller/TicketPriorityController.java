package com.example.demo.recovery.controller;

import jakarta.validation.Valid;

import com.example.demo.recovery.entity.TicketPriority;
import com.example.demo.recovery.service.TicketPriorityService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/ticket-priorities")
public class TicketPriorityController {
    private final TicketPriorityService service;

    public TicketPriorityController(TicketPriorityService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<TicketPriority> create(@Valid @RequestBody TicketPriority model) {
        TicketPriority saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/ticket-priorities/" + saved.getTicketPriorityId())).body(saved);
    }

    @GetMapping("/{id}")
    public TicketPriority get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<TicketPriority> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public TicketPriority update(@PathVariable Long id, @Valid @RequestBody TicketPriority model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

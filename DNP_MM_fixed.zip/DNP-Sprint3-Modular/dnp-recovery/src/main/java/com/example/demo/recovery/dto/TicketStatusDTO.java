package com.example.demo.recovery.dto;

/** Communication DTO for TicketStatus; contains scalar values only and no DAO behavior. */
public class TicketStatusDTO {
    private Long ticketStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public TicketStatusDTO() {}

    public Long getTicketStatusId() { return ticketStatusId; }
    public void setTicketStatusId(Long ticketStatusId) { this.ticketStatusId = ticketStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }

    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

}
package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.RecoveryPlanStatus;
import com.example.demo.recovery.repository.RecoveryPlanStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanStatusService extends AbstractCrudService<RecoveryPlanStatus, Long> {
    public RecoveryPlanStatusService(RecoveryPlanStatusRepository repository) {
        super(repository, RecoveryPlanStatus.class);
    }
}

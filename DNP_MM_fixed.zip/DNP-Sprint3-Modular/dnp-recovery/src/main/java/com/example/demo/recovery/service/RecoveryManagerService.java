package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.RecoveryManager;
import com.example.demo.recovery.repository.RecoveryManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryManagerService extends AbstractCrudService<RecoveryManager, Long> {
    public RecoveryManagerService(RecoveryManagerRepository repository) {
        super(repository, RecoveryManager.class);
    }
}

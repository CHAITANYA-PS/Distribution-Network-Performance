package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.TicketPriority;
import com.example.demo.recovery.repository.TicketPriorityRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketPriorityService extends AbstractCrudService<TicketPriority, Long> {
    public TicketPriorityService(TicketPriorityRepository repository) {
        super(repository, TicketPriority.class);
    }
}

package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.RecoveryPlanTicket;
import com.example.demo.recovery.repository.RecoveryPlanTicketRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanTicketService extends AbstractCrudService<RecoveryPlanTicket, Long> {
    public RecoveryPlanTicketService(RecoveryPlanTicketRepository repository) {
        super(repository, RecoveryPlanTicket.class);
    }
}

package com.example.demo.recovery.dto;

import java.time.OffsetDateTime;

/** Communication DTO for TicketComment; contains scalar values only and no DAO behavior. */
public class TicketCommentDTO {
    private Long commentId;
    private Long ticketId;
    private Long userId;
    private String commentText;
    private OffsetDateTime createdAt;

    public TicketCommentDTO() {}

    public Long getCommentId() { return commentId; }
    public void setCommentId(Long commentId) { this.commentId = commentId; }

    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getCommentText() { return commentText; }
    public void setCommentText(String commentText) { this.commentText = commentText; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketService extends AbstractCrudService<Ticket, Long> {
    public TicketService(TicketRepository repository) {
        super(repository, Ticket.class);
    }
}

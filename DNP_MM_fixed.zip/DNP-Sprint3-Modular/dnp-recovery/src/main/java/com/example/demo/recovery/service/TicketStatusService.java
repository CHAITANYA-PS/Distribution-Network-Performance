package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.TicketStatus;
import com.example.demo.recovery.repository.TicketStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusService extends AbstractCrudService<TicketStatus, Long> {
    public TicketStatusService(TicketStatusRepository repository) {
        super(repository, TicketStatus.class);
    }
}

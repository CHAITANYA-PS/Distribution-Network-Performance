package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="ticket",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Ticket implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="ticket_category_id")
 private Long ticketCategoryId;
 @Column(name="ticket_status_id")
 private Long ticketStatusId;
 @Column(name="ticket_priority_id")
 private Long ticketPriorityId;
 @Column(name="subject")
 private String subject;
 @Column(name="description")
 private String description;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="closed_at")
 private OffsetDateTime closedAt;
}
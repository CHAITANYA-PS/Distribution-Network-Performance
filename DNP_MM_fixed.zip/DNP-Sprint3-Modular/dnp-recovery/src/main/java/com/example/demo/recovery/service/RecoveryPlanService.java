package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.recovery.entity.RecoveryPlan;
import com.example.demo.recovery.repository.RecoveryPlanRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanService extends AbstractCrudService<RecoveryPlan, Long> {
    public RecoveryPlanService(RecoveryPlanRepository repository) {
        super(repository, RecoveryPlan.class);
    }
}

package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.RecoveryPlanTicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanTicketRepository extends JpaRepository<RecoveryPlanTicket, Long> {
}

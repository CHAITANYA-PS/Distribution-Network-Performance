package com.example.demo.manufacturer.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.manufacturer.entity.ManufacturerUser;
import com.example.demo.manufacturer.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerUserService extends AbstractCrudService<ManufacturerUser, Long> {
    public ManufacturerUserService(ManufacturerUserRepository repository) {
        super(repository, ManufacturerUser.class);
    }
}

package com.example.demo.manufacturer.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.manufacturer.entity.Manufacturer;
import com.example.demo.manufacturer.repository.ManufacturerRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerService extends AbstractCrudService<Manufacturer, Long> {
    public ManufacturerService(ManufacturerRepository repository) {
        super(repository, Manufacturer.class);
    }
}

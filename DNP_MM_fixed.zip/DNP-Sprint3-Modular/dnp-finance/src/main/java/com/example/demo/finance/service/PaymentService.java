package com.example.demo.finance.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.finance.entity.Invoice;
import com.example.demo.finance.entity.Payment;
import com.example.demo.finance.repository.InvoiceRepository;
import com.example.demo.finance.repository.PaymentRepository;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

/**
 * Payments are checked against the invoice they settle. The invoice row is locked
 * (PESSIMISTIC_WRITE) for the rest of the transaction so two concurrent payments cannot
 * both pass the "not over-paid" check.
 */
@Service
public class PaymentService extends AbstractCrudService<Payment, Long> {
    private static final Long NO_PAYMENT = -1L;
    private final PaymentRepository payments;
    private final InvoiceRepository invoices;

    public PaymentService(PaymentRepository payments, InvoiceRepository invoices) {
        super(payments, Payment.class);
        this.payments = payments;
        this.invoices = invoices;
    }

    @Override
    protected Optional<Payment> findForUpdate(Long id) {
        return payments.findByIdForUpdate(id);
    }

    @Override
    protected void beforeCreate(Payment p) {
        applyRules(p, NO_PAYMENT);
        if (p.getPaymentDate() == null) {
            p.setPaymentDate(LocalDate.now());
        }
    }

    @Override
    protected void beforeUpdate(Long id, Payment p, Payment existing) {
        applyRules(p, id);
    }

    private void applyRules(Payment p, Long excludePaymentId) {
        if (p.getInvoiceId() == null) {
            throw new BusinessRuleException("Payment must reference an invoice");
        }
        if (p.getAmount() == null || p.getAmount().signum() <= 0) {
            throw new BusinessRuleException("Payment amount must be greater than zero");
        }
        Invoice invoice = invoices.findByIdForUpdate(p.getInvoiceId())
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found: " + p.getInvoiceId()));
        if (invoice.getInvoiceAmount() == null) {
            throw new BusinessRuleException("Invoice " + invoice.getInvoiceId() + " has no amount to pay against");
        }
        BigDecimal alreadyPaid = payments.sumPaidForInvoiceExcluding(p.getInvoiceId(), excludePaymentId);
        if (alreadyPaid.add(p.getAmount()).compareTo(invoice.getInvoiceAmount()) > 0) {
            throw new BusinessRuleException("Payment exceeds the outstanding balance of invoice "
                    + invoice.getInvoiceId() + " (invoice " + invoice.getInvoiceAmount() + ", already paid " + alreadyPaid + ")");
        }
    }
}

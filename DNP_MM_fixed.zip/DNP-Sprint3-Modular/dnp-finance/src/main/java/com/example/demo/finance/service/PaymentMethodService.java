package com.example.demo.finance.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.finance.entity.PaymentMethod;
import com.example.demo.finance.repository.PaymentMethodRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentMethodService extends AbstractCrudService<PaymentMethod, Long> {
    public PaymentMethodService(PaymentMethodRepository repository) {
        super(repository, PaymentMethod.class);
    }
}

package com.example.demo.finance.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.finance.entity.Invoice;
import com.example.demo.finance.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService extends AbstractCrudService<Invoice, Long> {
    public InvoiceService(InvoiceRepository repository) {
        super(repository, Invoice.class);
    }
}

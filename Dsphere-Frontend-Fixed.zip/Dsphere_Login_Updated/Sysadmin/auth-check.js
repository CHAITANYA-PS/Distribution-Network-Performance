/* Dsphere session guard - ensures only the matching stakeholder can open this workspace. */
(function () {
  "use strict";
  var ROLE = "system-administrator", LOGIN = "../Login/index.html", user = null;
  try { user = JSON.parse(sessionStorage.getItem("dsphereAuthenticatedUser") || "null"); } catch (e) { user = null; }
  if (!user || user.role !== ROLE) { window.location.replace(LOGIN); return; }
  document.addEventListener("DOMContentLoaded", function () {
    document.querySelectorAll("[data-user-name]").forEach(function (n) { n.textContent = user.name; });
    document.querySelectorAll("[data-avatar]").forEach(function (n) { n.textContent = user.name.charAt(0); });
    document.querySelectorAll(".logout-button, .logout, .logout-btn").forEach(function (a) {
      a.addEventListener("click", function (e) {
        e.preventDefault();
        try { sessionStorage.removeItem("dsphereAuthenticatedUser"); } catch (x) {}
        window.location.replace(LOGIN);
      });
    });
  });
})();

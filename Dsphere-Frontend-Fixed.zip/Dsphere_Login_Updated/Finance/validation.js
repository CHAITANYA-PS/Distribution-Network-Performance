"use strict";
/* Dsphere shared page helper: highlights the active navigation link and wires the notification bell. */
document.addEventListener("DOMContentLoaded", function () {
  var page = location.pathname.split("/").pop() || "index.html";
  document.querySelectorAll(".sidebar a[href]").forEach(function (a) {
    if (a.getAttribute("href") === page) { a.classList.add("active"); }
  });
  var bell = document.querySelector(".bell");
  if (bell && !bell.dataset.bound && page !== "notifications.html") {
    bell.dataset.bound = "1";
    bell.addEventListener("click", function () { location.href = "notifications.html"; });
  }
});

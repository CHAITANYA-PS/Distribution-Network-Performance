# Endpoint catalogue

All CRUD resources: `POST /`, `GET /`, `GET /{id}`, `PUT /{id}`, `DELETE /{id}` (201 / 200 / 200 / 200 / 204).

| Resource | Base path | Methods |
|---|---|---|
| ActivityType | `/api/v1/activity-types` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| AppUser | `/api/v1/app-users` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Category | `/api/v1/categories` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Commitment | `/api/v1/commitments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| CommitmentHistory | `/api/v1/commitment-histories` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| CommitmentProgress | `/api/v1/commitment-progresses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| CommitmentStatus | `/api/v1/commitment-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ContinuityAssessment | `/api/v1/continuity-assessments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ContinuityStatusType | `/api/v1/continuity-status-types` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| CreditRiskAssessment | `/api/v1/credit-risk-assessments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Department | `/api/v1/departments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Distributor | `/api/v1/distributors` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| DistributorActivity | `/api/v1/distributor-activities` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| DistributorCategory | `/api/v1/distributor-categories` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| DistributorCreditLimit | `/api/v1/distributor-credit-limits` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| DistributorHealthAssessment | `/api/v1/distributor-health-assessments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| DistributorOrder | `/api/v1/distributor-orders` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| DistributorUser | `/api/v1/distributor-users` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| EmissionFactor | `/api/v1/emission-factors` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Escalation | `/api/v1/escalations` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ExchangeHistory | `/api/v1/exchange-histories` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ExchangeRequest | `/api/v1/exchange-requests` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ExchangeStatus | `/api/v1/exchange-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| FinanceManager | `/api/v1/finance-managers` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| HealthAssessmentAlert | `/api/v1/health-assessment-alerts` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| HealthParameter | `/api/v1/health-parameters` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| HealthParameterWeight | `/api/v1/health-parameter-weights` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| InventoryAlert | `/api/v1/inventory-alerts` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| InventoryDocument | `/api/v1/inventory-documents` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| InventoryDocumentType | `/api/v1/inventory-document-types` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| InventoryMovement | `/api/v1/inventory-movements` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Invoice | `/api/v1/invoices` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| InvoiceStatus | `/api/v1/invoice-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Manufacturer | `/api/v1/manufacturers` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ManufacturerUser | `/api/v1/manufacturer-users` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| MeasurementUnit | `/api/v1/measurement-units` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| MovementType | `/api/v1/movement-types` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Notification | `/api/v1/notifications` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| NotificationType | `/api/v1/notification-types` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| OrderItem | `/api/v1/order-items` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| OrderStatus | `/api/v1/order-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| OrderStatusHistory | `/api/v1/order-status-histories` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| PasswordReset | `/api/v1/password-resets` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Payment | `/api/v1/payments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| PaymentMethod | `/api/v1/payment-methods` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| PaymentStatus | `/api/v1/payment-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Product | `/api/v1/products` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ProductBatch | `/api/v1/product-batches` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| RecoveryManager | `/api/v1/recovery-managers` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| RecoveryPlan | `/api/v1/recovery-plans` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| RecoveryPlanStatus | `/api/v1/recovery-plan-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| RecoveryPlanTicket | `/api/v1/recovery-plan-tickets` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Region | `/api/v1/regions` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Report | `/api/v1/reports` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ReportFilter | `/api/v1/report-filters` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ReportFilterValue | `/api/v1/report-filter-values` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ReportingPeriod | `/api/v1/reporting-periods` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| RiskBand | `/api/v1/risk-bands` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| RiskLevel | `/api/v1/risk-levels` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Role | `/api/v1/roles` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| SalesManager | `/api/v1/sales-managers` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| SalesRecord | `/api/v1/sales-records` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| SalesTarget | `/api/v1/sales-targets` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Shipment | `/api/v1/shipments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ShipmentItem | `/api/v1/shipment-items` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| ShipmentStatus | `/api/v1/shipment-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| SystemAdmin | `/api/v1/system-admins` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Ticket | `/api/v1/tickets` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| TicketCategory | `/api/v1/ticket-categories` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| TicketComment | `/api/v1/ticket-comments` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| TicketPriority | `/api/v1/ticket-priorities` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| TicketStatus | `/api/v1/ticket-statuses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| TransportationActivity | `/api/v1/transportation-activities` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| UserActivityLog | `/api/v1/user-activity-logs` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| UserRole | `/api/v1/user-roles` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| UserSession | `/api/v1/user-sessions` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| VehicleType | `/api/v1/vehicle-types` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| Warehouse | `/api/v1/warehouses` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |
| WarehouseStock | `/api/v1/warehouse-stocks` | POST, GET, GET/{id}, PUT/{id}, DELETE/{id} |

## Domain controllers (from Controller_Layer_For_FINAL)

- `InventoryController`: /api/v1/inventory/products, /stocks
- `OrderController`: /api/v1/orders
- `RiskManagementController`: /api/v1/risk-management/assessments, /credit-limits
- `SustainabilityController`: /api/v1/sustainability/commitments, /emission-factors
- `UserController`: /api/v1/users

## Read-only views

- `GET /api/v1/views/order-totals[/{id}]`
- `GET /api/v1/views/outstanding-payments[/{id}]`
- `GET /api/v1/views/transport-emissions[/{id}]`

## Batch

- `POST /api/v1/batch/distributors/import` (202)

# What was consolidated and what is left

## Inputs analysed
- `FINAL_spring.zip`: original Core Java / JDBC project (DAO, DTO, entity, services, JUnit4 stub tests). Its
  business rules (non-null body, positive id, not-found) are carried into `AbstractCrudService`. The JDBC DAOs,
  DTOs and `bin/` classes are replaced by Spring Data JPA, so they are not copied here.
- `DNP_T_L.zip`: existing Spring Boot project. **Kept** (models, repositories, controllers, batch, config,
  migration SQL, Postman, tests) and extended.
- `Controller_Layer_For_FINAL.zip`: plain-Java controller stubs. Distributor, Payment, RecoveryPlan and Ticket
  already existed as REST controllers and were kept. Inventory, Order, RiskManagement, Sustainability and User
  were created as REST controllers (`/api/v1/inventory|orders|risk-management|sustainability|users`).

## Done
- Layers: `controller`, `services`, `repository`, `model` (package `service` renamed to `services`).
- Controllers contain no logic; rules live in services. REST CRUD with correct status codes and `Location`.
- Endpoints standardised: plural fixed (`categorys` -> `categories`, `...statuss` -> `...statuses`, `historys`, `activitys`,
  `prioritys`, `batchs`, `progresss`). **Old paths changed**, update any client using them.
- Error model `ApiErrorResponse` + `GlobalExceptionHandler` (404, 400, 405, 415, 409, 422, 423, 500).
- Transactions in `services`: class-level `@Transactional` (reads read-only) and `TransactionalExecutor`
  (required, read-only, requires-new, optimistic retry).
- Locking in `model/locking`: `VersionedEntity`, `OptimisticLockGuard`, `EntityIdAccessor`, `LockTimeouts`;
  pessimistic lock queries in the repositories (Invoice, Payment, WarehouseStock, DistributorCreditLimit, ExchangeRequest).
- Bug fixed: the old `update` saved a body without a version, which Hibernate treats as a new row. Update now
  loads the row, checks the version and merges.
- Business rules: unique distributor code and defaults, payment cannot exceed invoice balance (invoice row locked),
  credit limit, reorder level and exchange quantity checks.
- Repositories use Spring Data JPA (`save`, `findById`, `findAll`, `deleteById`; update = `save` on an existing id).
- Views `order_total_view`, `outstanding_payment_view`, `transport_emission_view`: read-only entity, repository, service, GET API.
- Tests: Mockito service tests (`@ExtendWith(MockitoExtension.class)`, `@Mock`, `@InjectMocks`), MockMvc controller tests,
  `@DataJpaTest` repository tests, one end-to-end test on H2.
- Postman collection: 91 folders, 512 requests, with assertions and an end-to-end business flow.

## NOT verified
- **Nothing was compiled or run** (no JDK compiler / Maven / network in the generation environment). Only a static
  check was done (imports resolve, braces balanced). Expect to fix a few compile or test issues on first build.
- API test evidence has to be produced by `scripts/run-api-tests.sh`.

## Still to do
- `credit_utilization_view`, `current_stock_view`, `health_score_view`, `sales_performance_view`: the original entities
  were empty, so their columns are unknown; no API created.
- No concurrent-thread test of the pessimistic lock (only the 423 mapping is tested).
- Models are exposed directly as request/response bodies (no DTO layer, per the requested 4-folder structure).
- `PUT` replaces the whole row; omitted fields become null.
- No authentication/authorisation.
- Run `V3__add_optimistic_lock_versions.sql` on PostgreSQL before starting with `ddl-auto=validate`.

## Merge into the `demo` Spring Boot project (template structure)
- Base package `com.tcs.dnp` -> `com.example.demo`; Maven coordinates `com.example:demo:0.0.1-SNAPSHOT`.
- `model` -> `entity` (`model.locking` -> `entity.locking`), `services` -> `service`.
- `exception`: `ApiErrorResponse` -> `dto`; `GlobalExceptionHandler` -> `controller`;
  `BusinessRuleException`, `DuplicateResourceException`, `ResourceNotFoundException` -> `service`.
- `batch`: `DistributorBatchConfig` -> `config`; `DistributorCsvRow` -> `dto`.
- `EndToEndFlowTest` now sits in the base test package; other tests mirror their classes.
- Imports that used to be implicit (same package) were added where classes moved apart. No logic changed.
- `application*.yml` converted to `application*.properties`. The `spring.config.activate.on-profile`
  line was dropped from the `local` profile because Spring Boot 3 rejects it in a profile-specific file.
- pom.xml: added spring-boot-starter-actuator (health endpoint used by `scripts/run-api-tests.sh`) and explicit Mockito test dependencies.
- Demo Initializr stubs (`DemoApplication`, `DemoApplicationTests`) removed: the real application class
  and `EndToEndFlowTest` replace them (two `@SpringBootApplication` classes would break `@WebMvcTest`).

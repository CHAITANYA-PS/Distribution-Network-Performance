# API test evidence

**Status: not yet executed.** The environment this project was generated in had no Maven, no Maven Central
access and no database, so neither the unit tests nor the Postman run could be executed there.
Nothing below is a recorded result. Run the command, which fills `docs/evidence/` with real output:

```bash
./scripts/run-api-tests.sh
```

It starts the app on in-memory H2 (`h2` profile), runs `postman/DNP_API.postman_collection.json` with newman
(JSON + HTML report, console log) and then `mvn test`.

## What the evidence will cover

| Check | Where |
|---|---|
| CRUD for all 79 resources, 201/200/204/404 | Postman folders per resource |
| JSON error model on every failure (keys `timestamp,status,error,code,message,path[,fieldErrors]`) | Postman `ERR` tests, `GlobalExceptionHandlerTest` |
| 400 validation, 409 duplicate, 409 stale version (optimistic lock), 422 business rule, 404, 405, 415 | `00 End-to-end business flow` folder, `EndToEndFlowTest` |
| 423 pessimistic lock timeout mapping | `GlobalExceptionHandlerTest` (mapping only, see TODO) |
| Service logic with mocked repository | `src/test/.../services/*ServiceTest` |
| Controller layer with mocked service | `src/test/.../controller/*ControllerTest` |
| Repository against H2 | `src/test/.../repository/*` |
| Full flow, nothing mocked | `src/test/.../e2e/EndToEndFlowTest` |

Fill in after a run:

| Run date | newman requests | newman assertions failed | `mvn test` result |
|---|---|---|---|
| _pending_ | | | |

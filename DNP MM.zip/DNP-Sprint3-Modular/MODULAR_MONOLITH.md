# DNP Stakeholder Modular Monolith

Spring Boot 4.1.0 multi-module Maven build. Modules: distributor, manufacturer, finance, sales, recovery, system-admin, and application. No shared module is used. Common technical base classes are owned by system-admin; stakeholder modules depend on system-admin where required. The application module assembles all module JARs into one executable Spring Boot JAR.

Build: `mvnw.cmd clean install`
Run: `java -jar dnp-application/target/dnp-application-0.0.1-SNAPSHOT.jar`
Swagger: `http://localhost:8081/swagger-ui.html`

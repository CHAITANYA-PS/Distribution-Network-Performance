#!/usr/bin/env bash
# Starts the app on in-memory H2 (profile h2), runs the Postman collection with newman and stores evidence.
# Needs: JDK 17+, Maven, Node (npx). Usage: ./scripts/run-api-tests.sh
set -euo pipefail
cd "$(dirname "$0")/.."
mkdir -p docs/evidence
mvn -q -DskipTests package
java -jar target/demo-0.0.1-SNAPSHOT.jar --spring.profiles.active=h2 > docs/evidence/app.log 2>&1 &
APP=$!
trap 'kill $APP 2>/dev/null || true' EXIT
for i in $(seq 1 60); do curl -sf http://localhost:8080/actuator/health >/dev/null && break; sleep 2; done
npx --yes newman run postman/DNP_API.postman_collection.json \
  --reporters cli,json,htmlextra --reporter-json-export docs/evidence/newman-report.json \
  --reporter-htmlextra-export docs/evidence/newman-report.html | tee docs/evidence/newman-console.txt
mvn -q test | tee docs/evidence/mvn-test-console.txt
echo "Evidence written to docs/evidence/"

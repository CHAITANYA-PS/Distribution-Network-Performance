package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.Manufacturer;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerRepository extends JpaRepository<Manufacturer, Long> {
}

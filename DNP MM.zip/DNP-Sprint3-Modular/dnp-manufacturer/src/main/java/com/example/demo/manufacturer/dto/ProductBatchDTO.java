package com.example.demo.manufacturer.dto;

import java.time.LocalDate;

/** Communication DTO for ProductBatch; contains scalar values only and no DAO behavior. */
public class ProductBatchDTO {
    private Long productBatchId;
    private Long productId;
    private String batchNumber;
    private LocalDate manufacturingDate;
    private LocalDate expiryDate;
    private String operationalStatus;

    public ProductBatchDTO() {}

    public Long getProductBatchId() { return productBatchId; }
    public void setProductBatchId(Long productBatchId) { this.productBatchId = productBatchId; }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public String getBatchNumber() { return batchNumber; }
    public void setBatchNumber(String batchNumber) { this.batchNumber = batchNumber; }

    public LocalDate getManufacturingDate() { return manufacturingDate; }
    public void setManufacturingDate(LocalDate manufacturingDate) { this.manufacturingDate = manufacturingDate; }

    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }

    public String getOperationalStatus() { return operationalStatus; }
    public void setOperationalStatus(String operationalStatus) { this.operationalStatus = operationalStatus; }

}
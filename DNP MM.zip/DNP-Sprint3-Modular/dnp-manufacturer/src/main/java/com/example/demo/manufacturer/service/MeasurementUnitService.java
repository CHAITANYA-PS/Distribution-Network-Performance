package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.MeasurementUnit;
import com.example.demo.manufacturer.repository.MeasurementUnitRepository;
import org.springframework.stereotype.Service;

@Service
public class MeasurementUnitService extends AbstractCrudService<MeasurementUnit, Long> {
    public MeasurementUnitService(MeasurementUnitRepository repository) {
        super(repository, MeasurementUnit.class);
    }
}

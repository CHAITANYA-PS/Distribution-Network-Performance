package com.example.demo.manufacturer.controller;

import jakarta.validation.Valid;

import com.example.demo.manufacturer.entity.ManufacturerUser;
import com.example.demo.manufacturer.service.ManufacturerUserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/manufacturer-users")
public class ManufacturerUserController {
    private final ManufacturerUserService service;

    public ManufacturerUserController(ManufacturerUserService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ManufacturerUser> create(@Valid @RequestBody ManufacturerUser model) {
        ManufacturerUser saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/manufacturer-users/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public ManufacturerUser get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ManufacturerUser> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ManufacturerUser update(@PathVariable Long id, @Valid @RequestBody ManufacturerUser model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

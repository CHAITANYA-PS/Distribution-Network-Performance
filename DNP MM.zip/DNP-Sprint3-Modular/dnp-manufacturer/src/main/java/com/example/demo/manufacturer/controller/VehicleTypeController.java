package com.example.demo.manufacturer.controller;

import jakarta.validation.Valid;

import com.example.demo.manufacturer.entity.VehicleType;
import com.example.demo.manufacturer.service.VehicleTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/vehicle-types")
public class VehicleTypeController {
    private final VehicleTypeService service;

    public VehicleTypeController(VehicleTypeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<VehicleType> create(@Valid @RequestBody VehicleType model) {
        VehicleType saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/vehicle-types/" + saved.getVehicleTypeId())).body(saved);
    }

    @GetMapping("/{id}")
    public VehicleType get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<VehicleType> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public VehicleType update(@PathVariable Long id, @Valid @RequestBody VehicleType model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

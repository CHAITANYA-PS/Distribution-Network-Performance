package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.EmissionFactor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmissionFactorRepository extends JpaRepository<EmissionFactor, Long> {
}

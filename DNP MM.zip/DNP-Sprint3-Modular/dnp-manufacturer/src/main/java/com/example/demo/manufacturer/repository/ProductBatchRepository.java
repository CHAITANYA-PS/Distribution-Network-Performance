package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.ProductBatch;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductBatchRepository extends JpaRepository<ProductBatch, Long> {
}

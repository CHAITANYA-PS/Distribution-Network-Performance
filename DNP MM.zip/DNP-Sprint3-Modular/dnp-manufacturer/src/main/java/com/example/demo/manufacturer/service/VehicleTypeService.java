package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.VehicleType;
import com.example.demo.manufacturer.repository.VehicleTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class VehicleTypeService extends AbstractCrudService<VehicleType, Long> {
    public VehicleTypeService(VehicleTypeRepository repository) {
        super(repository, VehicleType.class);
    }
}

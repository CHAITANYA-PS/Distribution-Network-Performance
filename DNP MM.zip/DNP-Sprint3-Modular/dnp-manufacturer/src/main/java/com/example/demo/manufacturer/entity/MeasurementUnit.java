package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="measurement_unit",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class MeasurementUnit implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="measurement_unit_id")
 private Long measurementUnitId;
 @Column(name="unit_code")
 private String unitCode;
 @Column(name="unit_name")
 private String unitName;
}
package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.Product;
import com.example.demo.manufacturer.repository.ProductRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductService extends AbstractCrudService<Product, Long> {
    public ProductService(ProductRepository repository) {
        super(repository, Product.class);
    }
}

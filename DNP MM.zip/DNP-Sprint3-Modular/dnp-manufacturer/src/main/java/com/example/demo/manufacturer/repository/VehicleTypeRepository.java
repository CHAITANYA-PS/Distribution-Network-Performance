package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.VehicleType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface VehicleTypeRepository extends JpaRepository<VehicleType, Long> {
}

package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.MeasurementUnit;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MeasurementUnitRepository extends JpaRepository<MeasurementUnit, Long> {
}

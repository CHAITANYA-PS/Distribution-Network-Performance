package com.example.demo.manufacturer.dto;

/** Communication DTO for MeasurementUnit; contains scalar values only and no DAO behavior. */
public class MeasurementUnitDTO {
    private Long measurementUnitId;
    private String unitCode;
    private String unitName;

    public MeasurementUnitDTO() {}

    public Long getMeasurementUnitId() { return measurementUnitId; }
    public void setMeasurementUnitId(Long measurementUnitId) { this.measurementUnitId = measurementUnitId; }

    public String getUnitCode() { return unitCode; }
    public void setUnitCode(String unitCode) { this.unitCode = unitCode; }

    public String getUnitName() { return unitName; }
    public void setUnitName(String unitName) { this.unitName = unitName; }

}
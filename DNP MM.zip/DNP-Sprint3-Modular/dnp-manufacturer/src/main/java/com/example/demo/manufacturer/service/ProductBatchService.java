package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.ProductBatch;
import com.example.demo.manufacturer.repository.ProductBatchRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductBatchService extends AbstractCrudService<ProductBatch, Long> {
    public ProductBatchService(ProductBatchRepository repository) {
        super(repository, ProductBatch.class);
    }
}

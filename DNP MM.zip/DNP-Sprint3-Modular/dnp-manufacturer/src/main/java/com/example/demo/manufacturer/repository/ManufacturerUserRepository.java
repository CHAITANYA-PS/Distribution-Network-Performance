package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.ManufacturerUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerUserRepository extends JpaRepository<ManufacturerUser, Long> {
}

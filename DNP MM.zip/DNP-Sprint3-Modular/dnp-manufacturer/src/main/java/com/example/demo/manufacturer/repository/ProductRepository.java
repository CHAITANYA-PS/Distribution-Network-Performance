package com.example.demo.manufacturer.repository;

import com.example.demo.manufacturer.entity.Product;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ProductRepository extends JpaRepository<Product, Long> {
}

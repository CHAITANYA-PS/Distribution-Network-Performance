package com.example.demo.manufacturer.dto;

/** Communication DTO for ManufacturerUser; contains scalar values only and no DAO behavior. */
public class ManufacturerUserDTO {
    private Long userId;
    private Long manufacturerId;

    public ManufacturerUserDTO() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getManufacturerId() { return manufacturerId; }
    public void setManufacturerId(Long manufacturerId) { this.manufacturerId = manufacturerId; }

}
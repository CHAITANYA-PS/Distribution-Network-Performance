package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.EmissionFactor;
import com.example.demo.manufacturer.repository.EmissionFactorRepository;
import org.springframework.stereotype.Service;

@Service
public class EmissionFactorService extends AbstractCrudService<EmissionFactor, Long> {
    public EmissionFactorService(EmissionFactorRepository repository) {
        super(repository, EmissionFactor.class);
    }
}

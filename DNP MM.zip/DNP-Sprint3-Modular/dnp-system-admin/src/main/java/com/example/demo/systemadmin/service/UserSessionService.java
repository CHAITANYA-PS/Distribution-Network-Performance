package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.UserSession;
import com.example.demo.systemadmin.repository.UserSessionRepository;
import org.springframework.stereotype.Service;

@Service
public class UserSessionService extends AbstractCrudService<UserSession, Long> {
    public UserSessionService(UserSessionRepository repository) {
        super(repository, UserSession.class);
    }
}

package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.TransportEmissionView;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

/** Read-only repository: a view cannot be saved or deleted. */
public interface TransportEmissionViewRepository extends Repository<TransportEmissionView, Long> {
    List<TransportEmissionView> findAll();

    Optional<TransportEmissionView> findById(Long id);
}

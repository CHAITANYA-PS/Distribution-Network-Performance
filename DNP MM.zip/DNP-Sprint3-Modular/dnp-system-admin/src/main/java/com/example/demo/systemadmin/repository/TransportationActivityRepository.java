package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.TransportationActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransportationActivityRepository extends JpaRepository<TransportationActivity, Long> {
}

package com.example.demo.systemadmin.controller;

import jakarta.validation.Valid;

import com.example.demo.systemadmin.entity.Department;
import com.example.demo.systemadmin.service.DepartmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/departments")
public class DepartmentController {
    private final DepartmentService service;

    public DepartmentController(DepartmentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Department> create(@Valid @RequestBody Department model) {
        Department saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/departments/" + saved.getDepartmentId())).body(saved);
    }

    @GetMapping("/{id}")
    public Department get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Department> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Department update(@PathVariable Long id, @Valid @RequestBody Department model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

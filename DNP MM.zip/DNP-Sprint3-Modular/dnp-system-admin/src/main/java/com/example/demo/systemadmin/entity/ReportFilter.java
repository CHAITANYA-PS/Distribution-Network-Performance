package com.example.demo.systemadmin.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="report_filter",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ReportFilter implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="report_filter_id")
 private Long reportFilterId;
 @Column(name="report_id")
 private Long reportId;
 @Column(name="filter_name")
 private String filterName;
}
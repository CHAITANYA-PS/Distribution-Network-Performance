package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.AppUser;
import com.example.demo.systemadmin.repository.AppUserRepository;
import org.springframework.stereotype.Service;

@Service
public class AppUserService extends AbstractCrudService<AppUser, Long> {
    public AppUserService(AppUserRepository repository) {
        super(repository, AppUser.class);
    }
}

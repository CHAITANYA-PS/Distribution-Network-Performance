package com.example.demo.systemadmin.dto;

/** Communication DTO for Role; contains scalar values only and no DAO behavior. */
public class RoleDTO {
    private Long roleId;
    private String roleName;
    private String description;
    private String status;

    public RoleDTO() {}

    public Long getRoleId() { return roleId; }
    public void setRoleId(Long roleId) { this.roleId = roleId; }

    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

}
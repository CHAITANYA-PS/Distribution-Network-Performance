package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.TransportationActivity;
import com.example.demo.systemadmin.repository.TransportationActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class TransportationActivityService extends AbstractCrudService<TransportationActivity, Long> {
    public TransportationActivityService(TransportationActivityRepository repository) {
        super(repository, TransportationActivity.class);
    }
}

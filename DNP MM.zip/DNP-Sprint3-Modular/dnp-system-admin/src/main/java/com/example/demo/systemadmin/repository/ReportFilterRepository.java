package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.ReportFilter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportFilterRepository extends JpaRepository<ReportFilter, Long> {
}

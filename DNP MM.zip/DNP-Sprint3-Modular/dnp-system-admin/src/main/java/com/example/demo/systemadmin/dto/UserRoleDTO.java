package com.example.demo.systemadmin.dto;

import java.time.OffsetDateTime;

/** Communication DTO for UserRole; contains scalar values only and no DAO behavior. */
public class UserRoleDTO {
    private Long userRoleId;
    private Long userId;
    private Long roleId;
    private OffsetDateTime assignedAt;

    public UserRoleDTO() {}

    public Long getUserRoleId() { return userRoleId; }
    public void setUserRoleId(Long userRoleId) { this.userRoleId = userRoleId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getRoleId() { return roleId; }
    public void setRoleId(Long roleId) { this.roleId = roleId; }

    public OffsetDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(OffsetDateTime assignedAt) { this.assignedAt = assignedAt; }

}
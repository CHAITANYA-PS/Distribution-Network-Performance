package com.example.demo.systemadmin.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="password_reset",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class PasswordReset implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="reset_id")
 private Long resetId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="token")
 private String token;
 @Column(name="expires_at")
 private OffsetDateTime expiresAt;
 @Column(name="used_at")
 private OffsetDateTime usedAt;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
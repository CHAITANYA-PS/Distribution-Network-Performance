package com.example.demo.systemadmin.service;
public class ResourceNotFoundException extends RuntimeException { public ResourceNotFoundException(String message){super(message);} }

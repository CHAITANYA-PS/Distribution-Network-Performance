package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.AppUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface AppUserRepository extends JpaRepository<AppUser, Long> {
}

package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.UserSession;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserSessionRepository extends JpaRepository<UserSession, Long> {
}

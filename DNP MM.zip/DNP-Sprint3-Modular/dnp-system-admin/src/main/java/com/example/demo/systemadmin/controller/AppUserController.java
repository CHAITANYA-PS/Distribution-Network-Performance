package com.example.demo.systemadmin.controller;

import jakarta.validation.Valid;

import com.example.demo.systemadmin.entity.AppUser;
import com.example.demo.systemadmin.service.AppUserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/app-users")
public class AppUserController {
    private final AppUserService service;

    public AppUserController(AppUserService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<AppUser> create(@Valid @RequestBody AppUser model) {
        AppUser saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/app-users/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public AppUser get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<AppUser> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public AppUser update(@PathVariable Long id, @Valid @RequestBody AppUser model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

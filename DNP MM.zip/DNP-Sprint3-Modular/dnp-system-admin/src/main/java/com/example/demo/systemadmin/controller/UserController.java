package com.example.demo.systemadmin.controller;

import jakarta.validation.Valid;
import com.example.demo.systemadmin.entity.AppUser;
import com.example.demo.systemadmin.service.AppUserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

/** Application users. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/users")
public class UserController {
    private final AppUserService appUserService;

    public UserController(AppUserService appUserService) {
        this.appUserService = appUserService;
    }

    @PostMapping("")
    public ResponseEntity<AppUser> createAppUser(@Valid @RequestBody AppUser model) {
        AppUser saved = appUserService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/users/" + saved.getUserId())).body(saved);
    }

    @GetMapping("")
    public List<AppUser> getAllAppUser() {
        return appUserService.getAll();
    }

    @GetMapping("/{id}")
    public AppUser getAppUser(@PathVariable Long id) {
        return appUserService.get(id);
    }

    @PutMapping("/{id}")
    public AppUser updateAppUser(@PathVariable Long id, @Valid @RequestBody AppUser model) {
        return appUserService.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteAppUser(@PathVariable Long id) {
        appUserService.delete(id);
    }
}

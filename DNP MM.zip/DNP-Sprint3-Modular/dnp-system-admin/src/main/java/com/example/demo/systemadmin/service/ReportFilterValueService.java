package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.ReportFilterValue;
import com.example.demo.systemadmin.repository.ReportFilterValueRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterValueService extends AbstractCrudService<ReportFilterValue, Long> {
    public ReportFilterValueService(ReportFilterValueRepository repository) {
        super(repository, ReportFilterValue.class);
    }
}

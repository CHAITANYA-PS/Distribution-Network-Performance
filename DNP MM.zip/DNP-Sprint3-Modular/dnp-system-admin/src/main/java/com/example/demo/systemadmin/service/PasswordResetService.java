package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.PasswordReset;
import com.example.demo.systemadmin.repository.PasswordResetRepository;
import org.springframework.stereotype.Service;

@Service
public class PasswordResetService extends AbstractCrudService<PasswordReset, Long> {
    public PasswordResetService(PasswordResetRepository repository) {
        super(repository, PasswordReset.class);
    }
}

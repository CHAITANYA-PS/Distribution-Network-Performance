package com.example.demo.systemadmin.controller;

import jakarta.validation.Valid;

import com.example.demo.systemadmin.entity.Role;
import com.example.demo.systemadmin.service.RoleService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/roles")
public class RoleController {
    private final RoleService service;

    public RoleController(RoleService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Role> create(@Valid @RequestBody Role model) {
        Role saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/roles/" + saved.getRoleId())).body(saved);
    }

    @GetMapping("/{id}")
    public Role get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Role> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Role update(@PathVariable Long id, @Valid @RequestBody Role model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

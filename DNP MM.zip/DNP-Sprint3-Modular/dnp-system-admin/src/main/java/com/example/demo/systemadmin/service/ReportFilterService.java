package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.ReportFilter;
import com.example.demo.systemadmin.repository.ReportFilterRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterService extends AbstractCrudService<ReportFilter, Long> {
    public ReportFilterService(ReportFilterRepository repository) {
        super(repository, ReportFilter.class);
    }
}

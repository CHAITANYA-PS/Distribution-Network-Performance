package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.SystemAdmin;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SystemAdminRepository extends JpaRepository<SystemAdmin, Long> {
}

package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.ReportFilterValue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportFilterValueRepository extends JpaRepository<ReportFilterValue, Long> {
}

package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

/** Base for services over database views: reads only, there is no create/update/delete. */
@Transactional(readOnly = true)
public abstract class ReadOnlyViewService<T, ID> {
    private final String name;

    protected ReadOnlyViewService(String name) {
        this.name = name;
    }

    protected abstract List<T> findAllRows();

    protected abstract Optional<T> findRow(ID id);

    public List<T> getAll() {
        return findAllRows();
    }

    public T get(ID id) {
        return findRow(id).orElseThrow(() -> new ResourceNotFoundException(name + " not found: " + id));
    }
}

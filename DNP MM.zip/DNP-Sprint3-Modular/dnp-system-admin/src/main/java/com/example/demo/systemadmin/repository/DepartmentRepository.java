package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.Department;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DepartmentRepository extends JpaRepository<Department, Long> {
}

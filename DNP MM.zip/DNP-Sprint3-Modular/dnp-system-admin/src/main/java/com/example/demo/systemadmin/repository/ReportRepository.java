package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
}

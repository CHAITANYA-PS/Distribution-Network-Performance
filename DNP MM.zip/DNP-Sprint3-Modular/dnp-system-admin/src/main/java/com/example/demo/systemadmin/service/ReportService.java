package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.Report;
import com.example.demo.systemadmin.repository.ReportRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportService extends AbstractCrudService<Report, Long> {
    public ReportService(ReportRepository repository) {
        super(repository, Report.class);
    }
}

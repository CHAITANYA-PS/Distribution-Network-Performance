package com.example.demo.systemadmin.entity.locking;

/** Central place for pessimistic-lock settings so every repository uses the same value. */
public final class LockTimeouts {
    /** Milliseconds a transaction waits for a row lock before failing (String: used in annotations). */
    public static final String PESSIMISTIC_TIMEOUT_MS = "5000";
    /** Hint name understood by Hibernate/JPA. */
    public static final String HINT_LOCK_TIMEOUT = "jakarta.persistence.lock.timeout";

    private LockTimeouts() {
    }
}

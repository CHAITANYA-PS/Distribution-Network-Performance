package com.example.demo.systemadmin.dto;

/** Communication DTO for ReportFilterValue; contains scalar values only and no DAO behavior. */
public class ReportFilterValueDTO {
    private Long reportFilterValueId;
    private Long reportFilterId;
    private String filterValue;

    public ReportFilterValueDTO() {}

    public Long getReportFilterValueId() { return reportFilterValueId; }
    public void setReportFilterValueId(Long reportFilterValueId) { this.reportFilterValueId = reportFilterValueId; }

    public Long getReportFilterId() { return reportFilterId; }
    public void setReportFilterId(Long reportFilterId) { this.reportFilterId = reportFilterId; }

    public String getFilterValue() { return filterValue; }
    public void setFilterValue(String filterValue) { this.filterValue = filterValue; }

}
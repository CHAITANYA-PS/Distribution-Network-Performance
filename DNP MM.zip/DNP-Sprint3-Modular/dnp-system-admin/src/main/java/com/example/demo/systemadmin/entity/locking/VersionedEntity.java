package com.example.demo.systemadmin.entity.locking;

/**
 * Contract implemented by every JPA model that carries an optimistic-lock {@code @Version} column.
 * Lombok generates the accessors on each model, which satisfy this interface.
 */
public interface VersionedEntity {
    Long getVersion();

    void setVersion(Long version);
}

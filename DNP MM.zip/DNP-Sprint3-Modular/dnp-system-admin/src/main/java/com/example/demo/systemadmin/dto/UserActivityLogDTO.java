package com.example.demo.systemadmin.dto;

import java.time.OffsetDateTime;

/** Communication DTO for UserActivityLog; contains scalar values only and no DAO behavior. */
public class UserActivityLogDTO {
    private Long logId;
    private Long userId;
    private String action;
    private String details;
    private String ipAddress;
    private OffsetDateTime createdAt;

    public UserActivityLogDTO() {}

    public Long getLogId() { return logId; }
    public void setLogId(Long logId) { this.logId = logId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }

    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
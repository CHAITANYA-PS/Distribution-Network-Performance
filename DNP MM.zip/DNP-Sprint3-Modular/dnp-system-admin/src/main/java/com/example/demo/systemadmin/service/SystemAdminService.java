package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.SystemAdmin;
import com.example.demo.systemadmin.repository.SystemAdminRepository;
import org.springframework.stereotype.Service;

@Service
public class SystemAdminService extends AbstractCrudService<SystemAdmin, Long> {
    public SystemAdminService(SystemAdminRepository repository) {
        super(repository, SystemAdmin.class);
    }
}

package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.Role;
import com.example.demo.systemadmin.repository.RoleRepository;
import org.springframework.stereotype.Service;

@Service
public class RoleService extends AbstractCrudService<Role, Long> {
    public RoleService(RoleRepository repository) {
        super(repository, Role.class);
    }
}

package com.example.demo.systemadmin.controller;

import jakarta.validation.Valid;

import com.example.demo.systemadmin.entity.PasswordReset;
import com.example.demo.systemadmin.service.PasswordResetService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/password-resets")
public class PasswordResetController {
    private final PasswordResetService service;

    public PasswordResetController(PasswordResetService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<PasswordReset> create(@Valid @RequestBody PasswordReset model) {
        PasswordReset saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/password-resets/" + saved.getResetId())).body(saved);
    }

    @GetMapping("/{id}")
    public PasswordReset get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<PasswordReset> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public PasswordReset update(@PathVariable Long id, @Valid @RequestBody PasswordReset model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

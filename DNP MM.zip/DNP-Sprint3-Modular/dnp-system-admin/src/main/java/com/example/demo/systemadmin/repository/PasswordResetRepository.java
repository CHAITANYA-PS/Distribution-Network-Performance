package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.PasswordReset;
import org.springframework.data.jpa.repository.JpaRepository;

public interface PasswordResetRepository extends JpaRepository<PasswordReset, Long> {
}

package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.ReportingPeriod;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportingPeriodRepository extends JpaRepository<ReportingPeriod, Long> {
}

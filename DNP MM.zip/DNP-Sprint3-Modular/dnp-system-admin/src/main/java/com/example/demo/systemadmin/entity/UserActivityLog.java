package com.example.demo.systemadmin.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="user_activity_log",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class UserActivityLog implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="log_id")
 private Long logId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="action")
 private String action;
 @Column(name="details")
 private String details;
 @Column(name="ip_address")
 private String ipAddress;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
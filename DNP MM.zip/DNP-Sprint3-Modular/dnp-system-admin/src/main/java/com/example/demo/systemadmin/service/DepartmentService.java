package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.Department;
import com.example.demo.systemadmin.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService extends AbstractCrudService<Department, Long> {
    public DepartmentService(DepartmentRepository repository) {
        super(repository, Department.class);
    }
}

package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.UserActivityLog;
import com.example.demo.systemadmin.repository.UserActivityLogRepository;
import org.springframework.stereotype.Service;

@Service
public class UserActivityLogService extends AbstractCrudService<UserActivityLog, Long> {
    public UserActivityLogService(UserActivityLogRepository repository) {
        super(repository, UserActivityLog.class);
    }
}

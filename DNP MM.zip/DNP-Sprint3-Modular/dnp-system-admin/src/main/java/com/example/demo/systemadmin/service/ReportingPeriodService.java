package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.ReportingPeriod;
import com.example.demo.systemadmin.repository.ReportingPeriodRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportingPeriodService extends AbstractCrudService<ReportingPeriod, Long> {
    public ReportingPeriodService(ReportingPeriodRepository repository) {
        super(repository, ReportingPeriod.class);
    }
}

package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.UserRole;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserRoleRepository extends JpaRepository<UserRole, Long> {
}

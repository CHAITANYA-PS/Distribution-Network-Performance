package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.Role;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RoleRepository extends JpaRepository<Role, Long> {
}

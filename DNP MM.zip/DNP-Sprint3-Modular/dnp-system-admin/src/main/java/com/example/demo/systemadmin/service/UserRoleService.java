package com.example.demo.systemadmin.service;

import com.example.demo.systemadmin.entity.UserRole;
import com.example.demo.systemadmin.repository.UserRoleRepository;
import org.springframework.stereotype.Service;

@Service
public class UserRoleService extends AbstractCrudService<UserRole, Long> {
    public UserRoleService(UserRoleRepository repository) {
        super(repository, UserRole.class);
    }
}

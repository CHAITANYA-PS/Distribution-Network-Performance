package com.example.demo.systemadmin.dto;

import java.time.LocalDate;

/** Communication DTO for ReportingPeriod; contains scalar values only and no DAO behavior. */
public class ReportingPeriodDTO {
    private Long reportingPeriodId;
    private String periodName;
    private String periodType;
    private LocalDate startDate;
    private LocalDate endDate;

    public ReportingPeriodDTO() {}

    public Long getReportingPeriodId() { return reportingPeriodId; }
    public void setReportingPeriodId(Long reportingPeriodId) { this.reportingPeriodId = reportingPeriodId; }

    public String getPeriodName() { return periodName; }
    public void setPeriodName(String periodName) { this.periodName = periodName; }

    public String getPeriodType() { return periodType; }
    public void setPeriodType(String periodType) { this.periodType = periodType; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

}
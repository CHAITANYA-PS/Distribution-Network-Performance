package com.example.demo.systemadmin.controller;

import jakarta.validation.Valid;

import com.example.demo.systemadmin.entity.TransportationActivity;
import com.example.demo.systemadmin.service.TransportationActivityService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/transportation-activities")
public class TransportationActivityController {
    private final TransportationActivityService service;

    public TransportationActivityController(TransportationActivityService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<TransportationActivity> create(@Valid @RequestBody TransportationActivity model) {
        TransportationActivity saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/transportation-activities/" + saved.getTransportationActivityId())).body(saved);
    }

    @GetMapping("/{id}")
    public TransportationActivity get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<TransportationActivity> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public TransportationActivity update(@PathVariable Long id, @Valid @RequestBody TransportationActivity model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

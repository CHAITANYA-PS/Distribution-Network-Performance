package com.example.demo.systemadmin.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for TransportationActivity; contains scalar values only and no DAO behavior. */
public class TransportationActivityDTO {
    private Long transportationActivityId;
    private Long shipmentId;
    private Long emissionFactorId;
    private String origin;
    private String destination;
    private BigDecimal distanceKm;
    private LocalDate activityDate;

    public TransportationActivityDTO() {}

    public Long getTransportationActivityId() { return transportationActivityId; }
    public void setTransportationActivityId(Long transportationActivityId) { this.transportationActivityId = transportationActivityId; }

    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }

    public Long getEmissionFactorId() { return emissionFactorId; }
    public void setEmissionFactorId(Long emissionFactorId) { this.emissionFactorId = emissionFactorId; }

    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }

    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }

    public BigDecimal getDistanceKm() { return distanceKm; }
    public void setDistanceKm(BigDecimal distanceKm) { this.distanceKm = distanceKm; }

    public LocalDate getActivityDate() { return activityDate; }
    public void setActivityDate(LocalDate activityDate) { this.activityDate = activityDate; }

}
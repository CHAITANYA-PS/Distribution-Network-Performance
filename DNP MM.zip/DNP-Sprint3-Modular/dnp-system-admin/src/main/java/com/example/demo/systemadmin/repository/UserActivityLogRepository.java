package com.example.demo.systemadmin.repository;

import com.example.demo.systemadmin.entity.UserActivityLog;
import org.springframework.data.jpa.repository.JpaRepository;

public interface UserActivityLogRepository extends JpaRepository<UserActivityLog, Long> {
}

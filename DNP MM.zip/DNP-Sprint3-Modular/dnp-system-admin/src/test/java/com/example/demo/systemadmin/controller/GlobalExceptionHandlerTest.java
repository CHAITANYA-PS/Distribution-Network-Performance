package com.example.demo.systemadmin.controller;

import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.DuplicateResourceException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;

import com.example.demo.distributor.controller.DistributorController;
import com.example.demo.distributor.service.DistributorService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.WebMvcTest;
import org.springframework.test.context.bean.override.mockito.MockitoBean;
import org.springframework.dao.CannotAcquireLockException;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.MediaType;
import org.springframework.orm.ObjectOptimisticLockingFailureException;
import org.springframework.test.web.servlet.MockMvc;

import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/** Every failure must come back as the ApiErrorResponse JSON model. */
@WebMvcTest(DistributorController.class)
class GlobalExceptionHandlerTest {
    @Autowired MockMvc mvc;
    @MockitoBean DistributorService service;

    private void expect(org.springframework.test.web.servlet.ResultActions r, int status, String code) throws Exception {
        r.andExpect(status().is(status))
                .andExpect(content().contentTypeCompatibleWith(MediaType.APPLICATION_JSON))
                .andExpect(jsonPath("$.status").value(status))
                .andExpect(jsonPath("$.code").value(code))
                .andExpect(jsonPath("$.timestamp").exists())
                .andExpect(jsonPath("$.error").exists())
                .andExpect(jsonPath("$.message").exists())
                .andExpect(jsonPath("$.path").exists());
    }

    @Test void notFound404() throws Exception {
        when(service.get(1L)).thenThrow(new ResourceNotFoundException("x"));
        expect(mvc.perform(get("/api/v1/distributors/1")), 404, "RESOURCE_NOT_FOUND");
    }
    @Test void optimisticConflict409() throws Exception {
        when(service.get(1L)).thenThrow(new ObjectOptimisticLockingFailureException("Distributor", 1L));
        expect(mvc.perform(get("/api/v1/distributors/1")), 409, "OPTIMISTIC_LOCK_CONFLICT");
    }
    @Test void duplicate409() throws Exception {
        when(service.get(1L)).thenThrow(new DuplicateResourceException("dup"));
        expect(mvc.perform(get("/api/v1/distributors/1")), 409, "DUPLICATE_RESOURCE");
    }
    @Test void businessRule422() throws Exception {
        when(service.get(1L)).thenThrow(new BusinessRuleException("rule"));
        expect(mvc.perform(get("/api/v1/distributors/1")), 422, "BUSINESS_RULE_VIOLATION");
    }
    @Test void pessimisticLock423() throws Exception {
        when(service.get(1L)).thenThrow(new CannotAcquireLockException("locked"));
        expect(mvc.perform(get("/api/v1/distributors/1")), 423, "RECORD_LOCKED");
    }
    @Test void integrity409() throws Exception {
        when(service.get(1L)).thenThrow(new DataIntegrityViolationException("fk"));
        expect(mvc.perform(get("/api/v1/distributors/1")), 409, "DATA_INTEGRITY_VIOLATION");
    }
    @Test void unexpected500HidesDetails() throws Exception {
        when(service.get(1L)).thenThrow(new IllegalStateException("secret"));
        expect(mvc.perform(get("/api/v1/distributors/1")), 500, "INTERNAL_ERROR");
        mvc.perform(get("/api/v1/distributors/1")).andExpect(jsonPath("$.message").value("Unexpected server error"));
    }
    @Test void badIdType400() throws Exception {
        expect(mvc.perform(get("/api/v1/distributors/abc")), 400, "INVALID_PARAMETER");
    }
    @Test void validation400HasFieldErrors() throws Exception {
        expect(mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content("{}")), 400, "VALIDATION_FAILED");
        mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(jsonPath("$.fieldErrors.distributorCode").exists());
    }
    @Test void method405() throws Exception {
        expect(mvc.perform(patch("/api/v1/distributors/1")), 405, "METHOD_NOT_ALLOWED");
    }
    @Test void mediaType415() throws Exception {
        expect(mvc.perform(post("/api/v1/distributors").contentType(MediaType.TEXT_PLAIN).content("x")), 415, "UNSUPPORTED_MEDIA_TYPE");
    }
    @Test void unknownRoute404() throws Exception {
        expect(mvc.perform(get("/api/v1/nothing-here")), 404, "ENDPOINT_NOT_FOUND");
    }
}

package com.example.demo.distributor.dto;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Communication DTO for Distributor; contains scalar values only and no DAO behavior. */
public class DistributorDTO {
    private Long distributorId;
    private String distributorCode;
    private String distributorName;
    private Long regionId;
    private String contactPerson;
    private String email;
    private String phone;
    private String address;
    private String status;
    private LocalDate onboardingDate;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public DistributorDTO() {}

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public String getDistributorCode() { return distributorCode; }
    public void setDistributorCode(String distributorCode) { this.distributorCode = distributorCode; }

    public String getDistributorName() { return distributorName; }
    public void setDistributorName(String distributorName) { this.distributorName = distributorName; }

    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }

    public String getContactPerson() { return contactPerson; }
    public void setContactPerson(String contactPerson) { this.contactPerson = contactPerson; }

    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }

    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }

    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public LocalDate getOnboardingDate() { return onboardingDate; }
    public void setOnboardingDate(LocalDate onboardingDate) { this.onboardingDate = onboardingDate; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

}
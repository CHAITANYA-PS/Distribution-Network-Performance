package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.RiskLevel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskLevelRepository extends JpaRepository<RiskLevel, Long> {
}

package com.example.demo.distributor.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="commitment_progress",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class CommitmentProgress implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="progress_id")
 private Long progressId;
 @Column(name="commitment_id")
 private Long commitmentId;
 @Column(name="progress_value")
 private BigDecimal progressValue;
 @Column(name="recorded_by")
 private Long recordedBy;
 @Column(name="recorded_at")
 private OffsetDateTime recordedAt;
 @Column(name="remarks")
 private String remarks;
}
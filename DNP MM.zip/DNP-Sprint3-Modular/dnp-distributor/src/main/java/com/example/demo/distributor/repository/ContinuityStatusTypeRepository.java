package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.ContinuityStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityStatusTypeRepository extends JpaRepository<ContinuityStatusType, Long> {
}

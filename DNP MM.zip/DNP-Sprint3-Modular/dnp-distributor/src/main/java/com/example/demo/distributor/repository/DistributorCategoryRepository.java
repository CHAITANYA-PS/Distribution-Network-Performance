package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorCategoryRepository extends JpaRepository<DistributorCategory, Long> {
}

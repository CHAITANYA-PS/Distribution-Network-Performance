package com.example.demo.distributor.controller;

import jakarta.validation.Valid;

import com.example.demo.distributor.entity.DistributorHealthAssessment;
import com.example.demo.distributor.service.DistributorHealthAssessmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor-health-assessments")
public class DistributorHealthAssessmentController {
    private final DistributorHealthAssessmentService service;

    public DistributorHealthAssessmentController(DistributorHealthAssessmentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DistributorHealthAssessment> create(@Valid @RequestBody DistributorHealthAssessment model) {
        DistributorHealthAssessment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributor-health-assessments/" + saved.getAssessmentId())).body(saved);
    }

    @GetMapping("/{id}")
    public DistributorHealthAssessment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<DistributorHealthAssessment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public DistributorHealthAssessment update(@PathVariable Long id, @Valid @RequestBody DistributorHealthAssessment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

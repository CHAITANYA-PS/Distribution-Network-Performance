package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.CommitmentProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentProgressRepository extends JpaRepository<CommitmentProgress, Long> {
}

package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.RiskLevel;
import com.example.demo.distributor.repository.RiskLevelRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskLevelService extends AbstractCrudService<RiskLevel, Long> {
    public RiskLevelService(RiskLevelRepository repository) {
        super(repository, RiskLevel.class);
    }
}

package com.example.demo.distributor.controller;

import jakarta.validation.Valid;

import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.service.DistributorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributors")
public class DistributorController {
    private final DistributorService service;

    public DistributorController(DistributorService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Distributor> create(@Valid @RequestBody Distributor model) {
        Distributor saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributors/" + saved.getDistributorId())).body(saved);
    }

    @GetMapping("/{id}")
    public Distributor get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Distributor> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Distributor update(@PathVariable Long id, @Valid @RequestBody Distributor model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

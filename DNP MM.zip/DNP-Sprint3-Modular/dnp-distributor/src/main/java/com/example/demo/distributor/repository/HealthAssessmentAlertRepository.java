package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.HealthAssessmentAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthAssessmentAlertRepository extends JpaRepository<HealthAssessmentAlert, Long> {
}

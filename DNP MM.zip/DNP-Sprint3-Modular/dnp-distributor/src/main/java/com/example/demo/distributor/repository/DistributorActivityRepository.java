package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorActivityRepository extends JpaRepository<DistributorActivity, Long> {
}

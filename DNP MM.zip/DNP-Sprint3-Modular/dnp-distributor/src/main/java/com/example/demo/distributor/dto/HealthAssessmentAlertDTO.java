package com.example.demo.distributor.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for HealthAssessmentAlert; contains scalar values only and no DAO behavior. */
public class HealthAssessmentAlertDTO {
    private Long alertId;
    private Long assessmentId;
    private BigDecimal thresholdValue;
    private String message;
    private Boolean readStatus;
    private OffsetDateTime createdAt;

    public HealthAssessmentAlertDTO() {}

    public Long getAlertId() { return alertId; }
    public void setAlertId(Long alertId) { this.alertId = alertId; }

    public Long getAssessmentId() { return assessmentId; }
    public void setAssessmentId(Long assessmentId) { this.assessmentId = assessmentId; }

    public BigDecimal getThresholdValue() { return thresholdValue; }
    public void setThresholdValue(BigDecimal thresholdValue) { this.thresholdValue = thresholdValue; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Boolean getReadStatus() { return readStatus; }
    public void setReadStatus(Boolean readStatus) { this.readStatus = readStatus; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.HealthParameterWeight;
import com.example.demo.distributor.repository.HealthParameterWeightRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterWeightService extends AbstractCrudService<HealthParameterWeight, Long> {
    public HealthParameterWeightService(HealthParameterWeightRepository repository) {
        super(repository, HealthParameterWeight.class);
    }
}

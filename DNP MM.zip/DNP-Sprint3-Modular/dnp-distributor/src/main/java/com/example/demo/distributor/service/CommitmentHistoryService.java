package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.CommitmentHistory;
import com.example.demo.distributor.repository.CommitmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentHistoryService extends AbstractCrudService<CommitmentHistory, Long> {
    public CommitmentHistoryService(CommitmentHistoryRepository repository) {
        super(repository, CommitmentHistory.class);
    }
}

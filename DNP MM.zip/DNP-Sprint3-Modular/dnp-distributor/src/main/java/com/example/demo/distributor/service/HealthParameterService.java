package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.HealthParameter;
import com.example.demo.distributor.repository.HealthParameterRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterService extends AbstractCrudService<HealthParameter, Long> {
    public HealthParameterService(HealthParameterRepository repository) {
        super(repository, HealthParameter.class);
    }
}

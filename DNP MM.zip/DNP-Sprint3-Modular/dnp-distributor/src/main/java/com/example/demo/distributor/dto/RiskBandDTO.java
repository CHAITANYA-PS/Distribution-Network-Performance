package com.example.demo.distributor.dto;

import java.math.BigDecimal;

/** Communication DTO for RiskBand; contains scalar values only and no DAO behavior. */
public class RiskBandDTO {
    private Long riskBandId;
    private String riskCategory;
    private BigDecimal minimumScore;
    private BigDecimal maximumScore;

    public RiskBandDTO() {}

    public Long getRiskBandId() { return riskBandId; }
    public void setRiskBandId(Long riskBandId) { this.riskBandId = riskBandId; }

    public String getRiskCategory() { return riskCategory; }
    public void setRiskCategory(String riskCategory) { this.riskCategory = riskCategory; }

    public BigDecimal getMinimumScore() { return minimumScore; }
    public void setMinimumScore(BigDecimal minimumScore) { this.minimumScore = minimumScore; }

    public BigDecimal getMaximumScore() { return maximumScore; }
    public void setMaximumScore(BigDecimal maximumScore) { this.maximumScore = maximumScore; }

}
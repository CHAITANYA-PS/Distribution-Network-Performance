package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.CreditRiskAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditRiskAssessmentRepository extends JpaRepository<CreditRiskAssessment, Long> {
}

package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorHealthAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorHealthAssessmentRepository extends JpaRepository<DistributorHealthAssessment, Long> {
}

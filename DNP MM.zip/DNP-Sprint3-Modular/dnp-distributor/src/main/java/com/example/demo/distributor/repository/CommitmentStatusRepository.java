package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.CommitmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentStatusRepository extends JpaRepository<CommitmentStatus, Long> {
}

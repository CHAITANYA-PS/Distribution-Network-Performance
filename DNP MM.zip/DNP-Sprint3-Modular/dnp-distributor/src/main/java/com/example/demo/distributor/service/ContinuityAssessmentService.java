package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.ContinuityAssessment;
import com.example.demo.distributor.repository.ContinuityAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityAssessmentService extends AbstractCrudService<ContinuityAssessment, Long> {
    public ContinuityAssessmentService(ContinuityAssessmentRepository repository) {
        super(repository, ContinuityAssessment.class);
    }
}

package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Commitment;
import com.example.demo.distributor.repository.CommitmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentService extends AbstractCrudService<Commitment, Long> {
    public CommitmentService(CommitmentRepository repository) {
        super(repository, Commitment.class);
    }
}

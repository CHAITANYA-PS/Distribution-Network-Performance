package com.example.demo.distributor.controller;

import jakarta.validation.Valid;

import com.example.demo.distributor.entity.Category;
import com.example.demo.distributor.service.CategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/categories")
public class CategoryController {
    private final CategoryService service;

    public CategoryController(CategoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Category> create(@Valid @RequestBody Category model) {
        Category saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/categories/" + saved.getCategoryId())).body(saved);
    }

    @GetMapping("/{id}")
    public Category get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Category> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Category update(@PathVariable Long id, @Valid @RequestBody Category model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.HealthAssessmentAlert;
import com.example.demo.distributor.repository.HealthAssessmentAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthAssessmentAlertService extends AbstractCrudService<HealthAssessmentAlert, Long> {
    public HealthAssessmentAlertService(HealthAssessmentAlertRepository repository) {
        super(repository, HealthAssessmentAlert.class);
    }
}

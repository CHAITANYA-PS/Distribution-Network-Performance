package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorOrderRepository extends JpaRepository<DistributorOrder, Long> {
}

package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.CommitmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, Long> {
}

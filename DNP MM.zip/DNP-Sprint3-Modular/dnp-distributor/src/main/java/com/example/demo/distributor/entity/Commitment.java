package com.example.demo.distributor.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="commitment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Commitment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="commitment_id")
 private Long commitmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="measurement_unit_id")
 private Long measurementUnitId;
 @Column(name="commitment_status_id")
 private Long commitmentStatusId;
 @Column(name="target_name")
 private String targetName;
 @Column(name="target_value")
 private BigDecimal targetValue;
 @Column(name="due_date")
 private LocalDate dueDate;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;
}
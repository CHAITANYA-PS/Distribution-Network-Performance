package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.HealthParameter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterRepository extends JpaRepository<HealthParameter, Long> {
}

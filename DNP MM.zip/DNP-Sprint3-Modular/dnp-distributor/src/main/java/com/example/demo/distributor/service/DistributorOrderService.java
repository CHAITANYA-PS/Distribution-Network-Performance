package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.repository.DistributorOrderRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorOrderService extends AbstractCrudService<DistributorOrder, Long> {
    public DistributorOrderService(DistributorOrderRepository repository) {
        super(repository, DistributorOrder.class);
    }
}

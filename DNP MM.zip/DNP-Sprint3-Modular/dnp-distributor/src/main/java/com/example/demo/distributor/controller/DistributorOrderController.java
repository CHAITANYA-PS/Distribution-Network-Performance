package com.example.demo.distributor.controller;

import jakarta.validation.Valid;

import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.service.DistributorOrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor-orders")
public class DistributorOrderController {
    private final DistributorOrderService service;

    public DistributorOrderController(DistributorOrderService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DistributorOrder> create(@Valid @RequestBody DistributorOrder model) {
        DistributorOrder saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributor-orders/" + saved.getOrderId())).body(saved);
    }

    @GetMapping("/{id}")
    public DistributorOrder get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<DistributorOrder> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public DistributorOrder update(@PathVariable Long id, @Valid @RequestBody DistributorOrder model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

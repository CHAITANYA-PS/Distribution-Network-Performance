package com.example.demo.distributor.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="health_assessment_alert",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthAssessmentAlert implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="alert_id")
 private Long alertId;
 @Column(name="assessment_id")
 private Long assessmentId;
 @Column(name="threshold_value")
 private BigDecimal thresholdValue;
 @Column(name="message")
 private String message;
 @Column(name="read_status")
 private Boolean readStatus;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.Commitment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentRepository extends JpaRepository<Commitment, Long> {
}

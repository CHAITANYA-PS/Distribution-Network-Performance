package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.RiskBand;
import com.example.demo.distributor.repository.RiskBandRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskBandService extends AbstractCrudService<RiskBand, Long> {
    public RiskBandService(RiskBandRepository repository) {
        super(repository, RiskBand.class);
    }
}

package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.HealthParameterWeight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterWeightRepository extends JpaRepository<HealthParameterWeight, Long> {
}

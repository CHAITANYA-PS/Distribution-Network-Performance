package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorUserRepository extends JpaRepository<DistributorUser, Long> {
}

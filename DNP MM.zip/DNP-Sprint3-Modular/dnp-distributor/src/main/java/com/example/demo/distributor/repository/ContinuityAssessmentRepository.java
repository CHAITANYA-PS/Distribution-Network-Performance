package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.ContinuityAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityAssessmentRepository extends JpaRepository<ContinuityAssessment, Long> {
}

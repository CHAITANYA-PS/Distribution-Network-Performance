package com.example.demo.distributor.controller;

import jakarta.validation.Valid;

import com.example.demo.distributor.entity.DistributorCreditLimit;
import com.example.demo.distributor.service.DistributorCreditLimitService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor-credit-limits")
public class DistributorCreditLimitController {
    private final DistributorCreditLimitService service;

    public DistributorCreditLimitController(DistributorCreditLimitService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DistributorCreditLimit> create(@Valid @RequestBody DistributorCreditLimit model) {
        DistributorCreditLimit saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributor-credit-limits/" + saved.getCreditLimitId())).body(saved);
    }

    @GetMapping("/{id}")
    public DistributorCreditLimit get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<DistributorCreditLimit> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public DistributorCreditLimit update(@PathVariable Long id, @Valid @RequestBody DistributorCreditLimit model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

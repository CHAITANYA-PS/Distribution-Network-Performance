package com.example.demo.distributor.dto;

import java.time.OffsetDateTime;

/** Communication DTO for ContinuityAssessment; contains scalar values only and no DAO behavior. */
public class ContinuityAssessmentDTO {
    private Long continuityAssessmentId;
    private Long distributorId;
    private Long continuityStatusId;
    private Long riskLevelId;
    private Long assessedBy;
    private OffsetDateTime assessmentDate;
    private String remarks;

    public ContinuityAssessmentDTO() {}

    public Long getContinuityAssessmentId() { return continuityAssessmentId; }
    public void setContinuityAssessmentId(Long continuityAssessmentId) { this.continuityAssessmentId = continuityAssessmentId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getContinuityStatusId() { return continuityStatusId; }
    public void setContinuityStatusId(Long continuityStatusId) { this.continuityStatusId = continuityStatusId; }

    public Long getRiskLevelId() { return riskLevelId; }
    public void setRiskLevelId(Long riskLevelId) { this.riskLevelId = riskLevelId; }

    public Long getAssessedBy() { return assessedBy; }
    public void setAssessedBy(Long assessedBy) { this.assessedBy = assessedBy; }

    public OffsetDateTime getAssessmentDate() { return assessmentDate; }
    public void setAssessmentDate(OffsetDateTime assessmentDate) { this.assessmentDate = assessmentDate; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

}
package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.RiskBand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskBandRepository extends JpaRepository<RiskBand, Long> {
}

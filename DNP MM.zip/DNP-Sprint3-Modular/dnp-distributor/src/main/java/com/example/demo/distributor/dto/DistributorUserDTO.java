package com.example.demo.distributor.dto;

/** Communication DTO for DistributorUser; contains scalar values only and no DAO behavior. */
public class DistributorUserDTO {
    private Long userId;
    private Long distributorId;

    public DistributorUserDTO() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

}
package com.example.demo.distributor.controller;

import jakarta.validation.Valid;

import com.example.demo.distributor.entity.RiskLevel;
import com.example.demo.distributor.service.RiskLevelService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/risk-levels")
public class RiskLevelController {
    private final RiskLevelService service;

    public RiskLevelController(RiskLevelService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RiskLevel> create(@Valid @RequestBody RiskLevel model) {
        RiskLevel saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/risk-levels/" + saved.getRiskLevelId())).body(saved);
    }

    @GetMapping("/{id}")
    public RiskLevel get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RiskLevel> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public RiskLevel update(@PathVariable Long id, @Valid @RequestBody RiskLevel model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

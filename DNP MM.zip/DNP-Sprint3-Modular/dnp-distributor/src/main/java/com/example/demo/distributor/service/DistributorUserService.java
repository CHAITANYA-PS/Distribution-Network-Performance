package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.DistributorUser;
import com.example.demo.distributor.repository.DistributorUserRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorUserService extends AbstractCrudService<DistributorUser, Long> {
    public DistributorUserService(DistributorUserRepository repository) {
        super(repository, DistributorUser.class);
    }
}

package com.example.demo.finance.repository;

import com.example.demo.finance.entity.OutstandingPaymentView;
import org.springframework.data.repository.Repository;

import java.util.List;
import java.util.Optional;

/** Read-only repository: a view cannot be saved or deleted. */
public interface OutstandingPaymentViewRepository extends Repository<OutstandingPaymentView, Long> {
    List<OutstandingPaymentView> findAll();

    Optional<OutstandingPaymentView> findById(Long id);
}

package com.example.demo.finance.service;

import com.example.demo.finance.entity.PaymentStatus;
import com.example.demo.finance.repository.PaymentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentStatusService extends AbstractCrudService<PaymentStatus, Long> {
    public PaymentStatusService(PaymentStatusRepository repository) {
        super(repository, PaymentStatus.class);
    }
}

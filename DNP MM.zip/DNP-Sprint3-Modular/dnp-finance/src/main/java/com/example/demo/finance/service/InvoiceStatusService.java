package com.example.demo.finance.service;

import com.example.demo.finance.entity.InvoiceStatus;
import com.example.demo.finance.repository.InvoiceStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceStatusService extends AbstractCrudService<InvoiceStatus, Long> {
    public InvoiceStatusService(InvoiceStatusRepository repository) {
        super(repository, InvoiceStatus.class);
    }
}

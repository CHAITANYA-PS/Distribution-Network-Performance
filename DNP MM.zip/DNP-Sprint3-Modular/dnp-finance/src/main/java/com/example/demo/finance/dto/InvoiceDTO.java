package com.example.demo.finance.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for Invoice; contains scalar values only and no DAO behavior. */
public class InvoiceDTO {
    private Long invoiceId;
    private String invoiceNumber;
    private Long orderId;
    private Long invoiceStatusId;
    private LocalDate invoiceDate;
    private LocalDate dueDate;
    private BigDecimal invoiceAmount;

    public InvoiceDTO() {}

    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }

    public String getInvoiceNumber() { return invoiceNumber; }
    public void setInvoiceNumber(String invoiceNumber) { this.invoiceNumber = invoiceNumber; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public Long getInvoiceStatusId() { return invoiceStatusId; }
    public void setInvoiceStatusId(Long invoiceStatusId) { this.invoiceStatusId = invoiceStatusId; }

    public LocalDate getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(LocalDate invoiceDate) { this.invoiceDate = invoiceDate; }

    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }

    public BigDecimal getInvoiceAmount() { return invoiceAmount; }
    public void setInvoiceAmount(BigDecimal invoiceAmount) { this.invoiceAmount = invoiceAmount; }

}
package com.example.demo.finance.dto;

/** Communication DTO for InvoiceStatus; contains scalar values only and no DAO behavior. */
public class InvoiceStatusDTO {
    private Long invoiceStatusId;
    private String statusName;

    public InvoiceStatusDTO() {}

    public Long getInvoiceStatusId() { return invoiceStatusId; }
    public void setInvoiceStatusId(Long invoiceStatusId) { this.invoiceStatusId = invoiceStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

}
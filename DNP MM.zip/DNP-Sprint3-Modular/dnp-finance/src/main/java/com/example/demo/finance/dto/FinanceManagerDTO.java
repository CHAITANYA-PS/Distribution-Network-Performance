package com.example.demo.finance.dto;

/** Communication DTO for FinanceManager; contains scalar values only and no DAO behavior. */
public class FinanceManagerDTO {
    private Long userId;
    private Long departmentId;

    public FinanceManagerDTO() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

}
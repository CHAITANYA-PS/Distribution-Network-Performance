package com.example.demo.finance.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="invoice",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Invoice implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="invoice_id")
 private Long invoiceId;
 @Column(name="invoice_number")
 private String invoiceNumber;
 @Column(name="order_id")
 private Long orderId;
 @Column(name="invoice_status_id")
 private Long invoiceStatusId;
 @Column(name="invoice_date")
 private LocalDate invoiceDate;
 @Column(name="due_date")
 private LocalDate dueDate;
 @Column(name="invoice_amount")
 private BigDecimal invoiceAmount;
}
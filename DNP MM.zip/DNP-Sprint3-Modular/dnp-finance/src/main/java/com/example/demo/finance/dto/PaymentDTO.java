package com.example.demo.finance.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for Payment; contains scalar values only and no DAO behavior. */
public class PaymentDTO {
    private Long paymentId;
    private Long invoiceId;
    private Long paymentMethodId;
    private Long paymentStatusId;
    private String transactionReference;
    private LocalDate paymentDate;
    private BigDecimal amount;

    public PaymentDTO() {}

    public Long getPaymentId() { return paymentId; }
    public void setPaymentId(Long paymentId) { this.paymentId = paymentId; }

    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }

    public Long getPaymentMethodId() { return paymentMethodId; }
    public void setPaymentMethodId(Long paymentMethodId) { this.paymentMethodId = paymentMethodId; }

    public Long getPaymentStatusId() { return paymentStatusId; }
    public void setPaymentStatusId(Long paymentStatusId) { this.paymentStatusId = paymentStatusId; }

    public String getTransactionReference() { return transactionReference; }
    public void setTransactionReference(String transactionReference) { this.transactionReference = transactionReference; }

    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }

    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

}
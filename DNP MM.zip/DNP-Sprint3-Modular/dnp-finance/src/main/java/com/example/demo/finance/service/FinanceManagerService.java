package com.example.demo.finance.service;

import com.example.demo.finance.entity.FinanceManager;
import com.example.demo.finance.repository.FinanceManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class FinanceManagerService extends AbstractCrudService<FinanceManager, Long> {
    public FinanceManagerService(FinanceManagerRepository repository) {
        super(repository, FinanceManager.class);
    }
}

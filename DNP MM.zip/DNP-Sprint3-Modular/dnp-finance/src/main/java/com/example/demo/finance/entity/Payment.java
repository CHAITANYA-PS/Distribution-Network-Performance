package com.example.demo.finance.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="payment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Payment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="payment_id")
 private Long paymentId;
 @NotNull(message="Invoice id is required")
 @Column(name="invoice_id")
 private Long invoiceId;
 @Column(name="payment_method_id")
 private Long paymentMethodId;
 @Column(name="payment_status_id")
 private Long paymentStatusId;
 @Column(name="transaction_reference")
 private String transactionReference;
 @Column(name="payment_date")
 private LocalDate paymentDate;
 @NotNull(message="Amount is required")
 @DecimalMin(value="0.01", message="Amount must be at least 0.01")
 @Column(name="amount")
 private BigDecimal amount;
}
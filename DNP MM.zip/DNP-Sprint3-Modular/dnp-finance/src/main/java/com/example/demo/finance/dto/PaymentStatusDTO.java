package com.example.demo.finance.dto;

/** Communication DTO for PaymentStatus; contains scalar values only and no DAO behavior. */
public class PaymentStatusDTO {
    private Long paymentStatusId;
    private String statusName;

    public PaymentStatusDTO() {}

    public Long getPaymentStatusId() { return paymentStatusId; }
    public void setPaymentStatusId(Long paymentStatusId) { this.paymentStatusId = paymentStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

}
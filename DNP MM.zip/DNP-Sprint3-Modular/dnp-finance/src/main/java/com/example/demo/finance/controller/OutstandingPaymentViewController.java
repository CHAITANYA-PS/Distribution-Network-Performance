package com.example.demo.finance.controller;

import com.example.demo.finance.entity.OutstandingPaymentView;
import com.example.demo.finance.service.OutstandingPaymentViewService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Read-only endpoints over the OutstandingPaymentView database view. */
@RestController
@RequestMapping("/api/v1/views/outstanding-payments")
public class OutstandingPaymentViewController {
    private final OutstandingPaymentViewService service;

    public OutstandingPaymentViewController(OutstandingPaymentViewService service) {
        this.service = service;
    }

    @GetMapping
    public List<OutstandingPaymentView> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public OutstandingPaymentView get(@PathVariable Long id) {
        return service.get(id);
    }
}

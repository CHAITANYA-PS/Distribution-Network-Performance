package com.example.demo.finance.repository;

import com.example.demo.finance.entity.FinanceManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinanceManagerRepository extends JpaRepository<FinanceManager, Long> {
}

package com.example.demo.finance.repository;

import com.example.demo.finance.entity.Invoice;
import com.example.demo.finance.entity.Payment;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.jdbc.test.autoconfigure.AutoConfigureTestDatabase;
import org.springframework.boot.data.jpa.test.autoconfigure.DataJpaTest;
import org.springframework.test.context.ActiveProfiles;

import java.math.BigDecimal;

import static org.junit.jupiter.api.Assertions.*;

@DataJpaTest
@AutoConfigureTestDatabase(replace = AutoConfigureTestDatabase.Replace.NONE)
@ActiveProfiles("test")
class PaymentRepositoryTest {
    @Autowired PaymentRepository payments;
    @Autowired InvoiceRepository invoices;

    @Test void sumExcludingOnePayment() {
        Invoice inv = invoices.saveAndFlush(Invoice.builder().invoiceNumber("I-1").invoiceAmount(new BigDecimal("1000")).build());
        Payment a = payments.saveAndFlush(Payment.builder().invoiceId(inv.getInvoiceId()).amount(new BigDecimal("100")).build());
        payments.saveAndFlush(Payment.builder().invoiceId(inv.getInvoiceId()).amount(new BigDecimal("50")).build());
        assertEquals(0, new BigDecimal("150").compareTo(payments.sumPaidForInvoiceExcluding(inv.getInvoiceId(), -1L)));
        assertEquals(0, new BigDecimal("50").compareTo(payments.sumPaidForInvoiceExcluding(inv.getInvoiceId(), a.getPaymentId())));
        assertEquals(0, BigDecimal.ZERO.compareTo(payments.sumPaidForInvoiceExcluding(999L, -1L)));
    }

    @Test void lockedFinderReturnsRow() {
        Invoice inv = invoices.saveAndFlush(Invoice.builder().invoiceNumber("I-2").invoiceAmount(BigDecimal.TEN).build());
        assertTrue(invoices.findByIdForUpdate(inv.getInvoiceId()).isPresent());
        assertTrue(invoices.findByIdForUpdate(-5L).isEmpty());
    }
}

package com.example.demo.sales.service;

import com.example.demo.sales.entity.ExchangeStatus;
import com.example.demo.sales.repository.ExchangeStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeStatusService extends AbstractCrudService<ExchangeStatus, Long> {
    public ExchangeStatusService(ExchangeStatusRepository repository) {
        super(repository, ExchangeStatus.class);
    }
}

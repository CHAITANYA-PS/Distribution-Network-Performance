package com.example.demo.sales.dto;

/** Communication DTO for NotificationType; contains scalar values only and no DAO behavior. */
public class NotificationTypeDTO {
    private Long notificationTypeId;
    private String typeName;

    public NotificationTypeDTO() {}

    public Long getNotificationTypeId() { return notificationTypeId; }
    public void setNotificationTypeId(Long notificationTypeId) { this.notificationTypeId = notificationTypeId; }

    public String getTypeName() { return typeName; }
    public void setTypeName(String typeName) { this.typeName = typeName; }

}
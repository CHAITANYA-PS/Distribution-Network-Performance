package com.example.demo.sales.service;

import com.example.demo.sales.entity.InventoryDocument;
import com.example.demo.sales.repository.InventoryDocumentRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentService extends AbstractCrudService<InventoryDocument, Long> {
    public InventoryDocumentService(InventoryDocumentRepository repository) {
        super(repository, InventoryDocument.class);
    }
}

package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="shipment_item",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ShipmentItem implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="shipment_item_id")
 private Long shipmentItemId;
 @Column(name="shipment_id")
 private Long shipmentId;
 @Column(name="order_item_id")
 private Long orderItemId;
 @Column(name="quantity")
 private BigDecimal quantity;
}
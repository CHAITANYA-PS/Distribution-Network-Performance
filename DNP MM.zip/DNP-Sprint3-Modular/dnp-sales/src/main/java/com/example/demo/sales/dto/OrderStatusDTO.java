package com.example.demo.sales.dto;

/** Communication DTO for OrderStatus; contains scalar values only and no DAO behavior. */
public class OrderStatusDTO {
    private Long orderStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public OrderStatusDTO() {}

    public Long getOrderStatusId() { return orderStatusId; }
    public void setOrderStatusId(Long orderStatusId) { this.orderStatusId = orderStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }

    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

}
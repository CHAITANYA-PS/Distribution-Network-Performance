package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="exchange_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ExchangeHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="exchange_history_id")
 private Long exchangeHistoryId;
 @Column(name="exchange_id")
 private Long exchangeId;
 @Column(name="exchange_status_id")
 private Long exchangeStatusId;
 @Column(name="changed_by")
 private Long changedBy;
 @Column(name="remarks")
 private String remarks;
 @Column(name="changed_at")
 private OffsetDateTime changedAt;
}
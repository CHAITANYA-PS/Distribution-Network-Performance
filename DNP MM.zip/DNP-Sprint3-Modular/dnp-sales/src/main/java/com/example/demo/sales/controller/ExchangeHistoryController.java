package com.example.demo.sales.controller;

import jakarta.validation.Valid;

import com.example.demo.sales.entity.ExchangeHistory;
import com.example.demo.sales.service.ExchangeHistoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/exchange-histories")
public class ExchangeHistoryController {
    private final ExchangeHistoryService service;

    public ExchangeHistoryController(ExchangeHistoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ExchangeHistory> create(@Valid @RequestBody ExchangeHistory model) {
        ExchangeHistory saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/exchange-histories/" + saved.getExchangeHistoryId())).body(saved);
    }

    @GetMapping("/{id}")
    public ExchangeHistory get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ExchangeHistory> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ExchangeHistory update(@PathVariable Long id, @Valid @RequestBody ExchangeHistory model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

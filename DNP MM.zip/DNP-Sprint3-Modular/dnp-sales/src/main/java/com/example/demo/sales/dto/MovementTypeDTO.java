package com.example.demo.sales.dto;

/** Communication DTO for MovementType; contains scalar values only and no DAO behavior. */
public class MovementTypeDTO {
    private Long movementTypeId;
    private String movementTypeName;
    private String movementDirection;

    public MovementTypeDTO() {}

    public Long getMovementTypeId() { return movementTypeId; }
    public void setMovementTypeId(Long movementTypeId) { this.movementTypeId = movementTypeId; }

    public String getMovementTypeName() { return movementTypeName; }
    public void setMovementTypeName(String movementTypeName) { this.movementTypeName = movementTypeName; }

    public String getMovementDirection() { return movementDirection; }
    public void setMovementDirection(String movementDirection) { this.movementDirection = movementDirection; }

}
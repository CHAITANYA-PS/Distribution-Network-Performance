package com.example.demo.sales.dto;

/** Communication DTO for InventoryDocumentType; contains scalar values only and no DAO behavior. */
public class InventoryDocumentTypeDTO {
    private Long inventoryDocumentTypeId;
    private String documentTypeName;

    public InventoryDocumentTypeDTO() {}

    public Long getInventoryDocumentTypeId() { return inventoryDocumentTypeId; }
    public void setInventoryDocumentTypeId(Long inventoryDocumentTypeId) { this.inventoryDocumentTypeId = inventoryDocumentTypeId; }

    public String getDocumentTypeName() { return documentTypeName; }
    public void setDocumentTypeName(String documentTypeName) { this.documentTypeName = documentTypeName; }

}
package com.example.demo.sales.dto;

import java.math.BigDecimal;

/** Communication DTO for ShipmentItem; contains scalar values only and no DAO behavior. */
public class ShipmentItemDTO {
    private Long shipmentItemId;
    private Long shipmentId;
    private Long orderItemId;
    private BigDecimal quantity;

    public ShipmentItemDTO() {}

    public Long getShipmentItemId() { return shipmentItemId; }
    public void setShipmentItemId(Long shipmentItemId) { this.shipmentItemId = shipmentItemId; }

    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }

    public Long getOrderItemId() { return orderItemId; }
    public void setOrderItemId(Long orderItemId) { this.orderItemId = orderItemId; }

    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

}
package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="sales_record",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class SalesRecord implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="sales_record_id")
 private Long salesRecordId;
 @Column(name="order_id")
 private Long orderId;
 @Column(name="sale_date")
 private LocalDate saleDate;
 @Column(name="recognized_amount")
 private BigDecimal recognizedAmount;
}
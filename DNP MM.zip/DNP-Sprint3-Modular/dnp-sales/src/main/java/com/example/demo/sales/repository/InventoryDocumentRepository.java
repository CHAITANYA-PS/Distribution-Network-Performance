package com.example.demo.sales.repository;

import com.example.demo.sales.entity.InventoryDocument;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentRepository extends JpaRepository<InventoryDocument, Long> {
}

package com.example.demo.sales.repository;

import com.example.demo.sales.entity.InventoryAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryAlertRepository extends JpaRepository<InventoryAlert, Long> {
}

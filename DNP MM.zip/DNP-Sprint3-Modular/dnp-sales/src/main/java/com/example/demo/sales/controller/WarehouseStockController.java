package com.example.demo.sales.controller;

import jakarta.validation.Valid;

import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.service.WarehouseStockService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/warehouse-stocks")
public class WarehouseStockController {
    private final WarehouseStockService service;

    public WarehouseStockController(WarehouseStockService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<WarehouseStock> create(@Valid @RequestBody WarehouseStock model) {
        WarehouseStock saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/warehouse-stocks/" + saved.getWarehouseStockId())).body(saved);
    }

    @GetMapping("/{id}")
    public WarehouseStock get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<WarehouseStock> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public WarehouseStock update(@PathVariable Long id, @Valid @RequestBody WarehouseStock model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

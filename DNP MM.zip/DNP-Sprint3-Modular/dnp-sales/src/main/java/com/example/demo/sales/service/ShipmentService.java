package com.example.demo.sales.service;

import com.example.demo.sales.entity.Shipment;
import com.example.demo.sales.repository.ShipmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentService extends AbstractCrudService<Shipment, Long> {
    public ShipmentService(ShipmentRepository repository) {
        super(repository, Shipment.class);
    }
}

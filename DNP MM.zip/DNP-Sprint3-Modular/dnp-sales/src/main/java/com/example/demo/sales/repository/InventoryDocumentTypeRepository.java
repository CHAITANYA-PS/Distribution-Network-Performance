package com.example.demo.sales.repository;

import com.example.demo.sales.entity.InventoryDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentTypeRepository extends JpaRepository<InventoryDocumentType, Long> {
}

package com.example.demo.sales.repository;

import com.example.demo.sales.entity.SalesManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesManagerRepository extends JpaRepository<SalesManager, Long> {
}

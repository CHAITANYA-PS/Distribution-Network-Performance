package com.example.demo.sales.repository;

import com.example.demo.sales.entity.MovementType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovementTypeRepository extends JpaRepository<MovementType, Long> {
}

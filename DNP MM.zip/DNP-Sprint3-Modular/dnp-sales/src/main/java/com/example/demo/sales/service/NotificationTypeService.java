package com.example.demo.sales.service;

import com.example.demo.sales.entity.NotificationType;
import com.example.demo.sales.repository.NotificationTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationTypeService extends AbstractCrudService<NotificationType, Long> {
    public NotificationTypeService(NotificationTypeRepository repository) {
        super(repository, NotificationType.class);
    }
}

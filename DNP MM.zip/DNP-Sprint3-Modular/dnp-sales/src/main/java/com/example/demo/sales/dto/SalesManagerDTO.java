package com.example.demo.sales.dto;

/** Communication DTO for SalesManager; contains scalar values only and no DAO behavior. */
public class SalesManagerDTO {
    private Long userId;
    private Long regionId;

    public SalesManagerDTO() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }

}
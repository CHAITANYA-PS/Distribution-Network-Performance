package com.example.demo.sales.service;

import com.example.demo.sales.entity.OrderStatusHistory;
import com.example.demo.sales.repository.OrderStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusHistoryService extends AbstractCrudService<OrderStatusHistory, Long> {
    public OrderStatusHistoryService(OrderStatusHistoryRepository repository) {
        super(repository, OrderStatusHistory.class);
    }
}

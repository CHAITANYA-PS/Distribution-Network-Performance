package com.example.demo.sales.dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for SalesRecord; contains scalar values only and no DAO behavior. */
public class SalesRecordDTO {
    private Long salesRecordId;
    private Long orderId;
    private LocalDate saleDate;
    private BigDecimal recognizedAmount;

    public SalesRecordDTO() {}

    public Long getSalesRecordId() { return salesRecordId; }
    public void setSalesRecordId(Long salesRecordId) { this.salesRecordId = salesRecordId; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public LocalDate getSaleDate() { return saleDate; }
    public void setSaleDate(LocalDate saleDate) { this.saleDate = saleDate; }

    public BigDecimal getRecognizedAmount() { return recognizedAmount; }
    public void setRecognizedAmount(BigDecimal recognizedAmount) { this.recognizedAmount = recognizedAmount; }

}
package com.example.demo.sales.controller;

import jakarta.validation.Valid;

import com.example.demo.sales.entity.ExchangeStatus;
import com.example.demo.sales.service.ExchangeStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/exchange-statuses")
public class ExchangeStatusController {
    private final ExchangeStatusService service;

    public ExchangeStatusController(ExchangeStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ExchangeStatus> create(@Valid @RequestBody ExchangeStatus model) {
        ExchangeStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/exchange-statuses/" + saved.getExchangeStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public ExchangeStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ExchangeStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ExchangeStatus update(@PathVariable Long id, @Valid @RequestBody ExchangeStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

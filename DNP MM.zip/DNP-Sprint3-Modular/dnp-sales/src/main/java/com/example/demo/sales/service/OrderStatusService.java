package com.example.demo.sales.service;

import com.example.demo.sales.entity.OrderStatus;
import com.example.demo.sales.repository.OrderStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusService extends AbstractCrudService<OrderStatus, Long> {
    public OrderStatusService(OrderStatusRepository repository) {
        super(repository, OrderStatus.class);
    }
}

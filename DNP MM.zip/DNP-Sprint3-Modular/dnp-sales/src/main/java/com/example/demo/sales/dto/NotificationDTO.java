package com.example.demo.sales.dto;

import java.time.OffsetDateTime;

/** Communication DTO for Notification; contains scalar values only and no DAO behavior. */
public class NotificationDTO {
    private Long notificationId;
    private Long userId;
    private Long notificationTypeId;
    private String message;
    private Boolean readStatus;
    private OffsetDateTime createdAt;

    public NotificationDTO() {}

    public Long getNotificationId() { return notificationId; }
    public void setNotificationId(Long notificationId) { this.notificationId = notificationId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public Long getNotificationTypeId() { return notificationTypeId; }
    public void setNotificationTypeId(Long notificationTypeId) { this.notificationTypeId = notificationTypeId; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public Boolean getReadStatus() { return readStatus; }
    public void setReadStatus(Boolean readStatus) { this.readStatus = readStatus; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
package com.example.demo.sales.repository;

import com.example.demo.sales.entity.SalesTarget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesTargetRepository extends JpaRepository<SalesTarget, Long> {
}

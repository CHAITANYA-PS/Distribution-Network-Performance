package com.example.demo.sales.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for ExchangeRequest; contains scalar values only and no DAO behavior. */
public class ExchangeRequestDTO {
    private Long exchangeId;
    private Long distributorId;
    private Long productId;
    private BigDecimal requestedQuantity;
    private String sourceLocation;
    private Long exchangeStatusId;
    private Long requestedBy;
    private OffsetDateTime requestedAt;

    public ExchangeRequestDTO() {}

    public Long getExchangeId() { return exchangeId; }
    public void setExchangeId(Long exchangeId) { this.exchangeId = exchangeId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public BigDecimal getRequestedQuantity() { return requestedQuantity; }
    public void setRequestedQuantity(BigDecimal requestedQuantity) { this.requestedQuantity = requestedQuantity; }

    public String getSourceLocation() { return sourceLocation; }
    public void setSourceLocation(String sourceLocation) { this.sourceLocation = sourceLocation; }

    public Long getExchangeStatusId() { return exchangeStatusId; }
    public void setExchangeStatusId(Long exchangeStatusId) { this.exchangeStatusId = exchangeStatusId; }

    public Long getRequestedBy() { return requestedBy; }
    public void setRequestedBy(Long requestedBy) { this.requestedBy = requestedBy; }

    public OffsetDateTime getRequestedAt() { return requestedAt; }
    public void setRequestedAt(OffsetDateTime requestedAt) { this.requestedAt = requestedAt; }

}
package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="shipment_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ShipmentStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="shipment_status_id")
 private Long shipmentStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="sequence_number")
 private Integer sequenceNumber;
 @Column(name="is_terminal")
 private Boolean isTerminal;
}
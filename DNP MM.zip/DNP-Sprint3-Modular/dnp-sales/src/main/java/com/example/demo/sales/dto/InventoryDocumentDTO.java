package com.example.demo.sales.dto;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Communication DTO for InventoryDocument; contains scalar values only and no DAO behavior. */
public class InventoryDocumentDTO {
    private Long inventoryDocumentId;
    private Long inventoryDocumentTypeId;
    private String documentNumber;
    private LocalDate documentDate;
    private Long createdBy;
    private OffsetDateTime createdAt;

    public InventoryDocumentDTO() {}

    public Long getInventoryDocumentId() { return inventoryDocumentId; }
    public void setInventoryDocumentId(Long inventoryDocumentId) { this.inventoryDocumentId = inventoryDocumentId; }

    public Long getInventoryDocumentTypeId() { return inventoryDocumentTypeId; }
    public void setInventoryDocumentTypeId(Long inventoryDocumentTypeId) { this.inventoryDocumentTypeId = inventoryDocumentTypeId; }

    public String getDocumentNumber() { return documentNumber; }
    public void setDocumentNumber(String documentNumber) { this.documentNumber = documentNumber; }

    public LocalDate getDocumentDate() { return documentDate; }
    public void setDocumentDate(LocalDate documentDate) { this.documentDate = documentDate; }

    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
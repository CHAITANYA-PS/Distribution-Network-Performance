package com.example.demo.sales.controller;

import jakarta.validation.Valid;
import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.service.DistributorOrderService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

/** Distributor orders. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {
    private final DistributorOrderService distributorOrderService;

    public OrderController(DistributorOrderService distributorOrderService) {
        this.distributorOrderService = distributorOrderService;
    }

    @PostMapping("")
    public ResponseEntity<DistributorOrder> createDistributorOrder(@Valid @RequestBody DistributorOrder model) {
        DistributorOrder saved = distributorOrderService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/orders/" + saved.getOrderId())).body(saved);
    }

    @GetMapping("")
    public List<DistributorOrder> getAllDistributorOrder() {
        return distributorOrderService.getAll();
    }

    @GetMapping("/{id}")
    public DistributorOrder getDistributorOrder(@PathVariable Long id) {
        return distributorOrderService.get(id);
    }

    @PutMapping("/{id}")
    public DistributorOrder updateDistributorOrder(@PathVariable Long id, @Valid @RequestBody DistributorOrder model) {
        return distributorOrderService.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteDistributorOrder(@PathVariable Long id) {
        distributorOrderService.delete(id);
    }
}

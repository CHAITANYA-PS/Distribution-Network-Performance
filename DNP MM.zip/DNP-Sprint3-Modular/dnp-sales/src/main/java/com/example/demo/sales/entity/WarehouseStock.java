package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="warehouse_stock",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class WarehouseStock implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @Column(name="warehouse_id")
 private Long warehouseId;
 @Column(name="product_batch_id")
 private Long productBatchId;
 @Column(name="owner_distributor_id")
 private Long ownerDistributorId;
 @Column(name="reorder_level")
 private BigDecimal reorderLevel;
}
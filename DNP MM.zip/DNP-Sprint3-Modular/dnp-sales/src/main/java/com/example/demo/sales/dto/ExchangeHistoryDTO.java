package com.example.demo.sales.dto;

import java.time.OffsetDateTime;

/** Communication DTO for ExchangeHistory; contains scalar values only and no DAO behavior. */
public class ExchangeHistoryDTO {
    private Long exchangeHistoryId;
    private Long exchangeId;
    private Long exchangeStatusId;
    private Long changedBy;
    private String remarks;
    private OffsetDateTime changedAt;

    public ExchangeHistoryDTO() {}

    public Long getExchangeHistoryId() { return exchangeHistoryId; }
    public void setExchangeHistoryId(Long exchangeHistoryId) { this.exchangeHistoryId = exchangeHistoryId; }

    public Long getExchangeId() { return exchangeId; }
    public void setExchangeId(Long exchangeId) { this.exchangeId = exchangeId; }

    public Long getExchangeStatusId() { return exchangeStatusId; }
    public void setExchangeStatusId(Long exchangeStatusId) { this.exchangeStatusId = exchangeStatusId; }

    public Long getChangedBy() { return changedBy; }
    public void setChangedBy(Long changedBy) { this.changedBy = changedBy; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public OffsetDateTime getChangedAt() { return changedAt; }
    public void setChangedAt(OffsetDateTime changedAt) { this.changedAt = changedAt; }

}
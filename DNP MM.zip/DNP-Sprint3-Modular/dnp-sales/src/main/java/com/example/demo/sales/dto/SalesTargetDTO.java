package com.example.demo.sales.dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for SalesTarget; contains scalar values only and no DAO behavior. */
public class SalesTargetDTO {
    private Long targetId;
    private Long distributorId;
    private Long reportingPeriodId;
    private BigDecimal targetValue;
    private OffsetDateTime createdAt;

    public SalesTargetDTO() {}

    public Long getTargetId() { return targetId; }
    public void setTargetId(Long targetId) { this.targetId = targetId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getReportingPeriodId() { return reportingPeriodId; }
    public void setReportingPeriodId(Long reportingPeriodId) { this.reportingPeriodId = reportingPeriodId; }

    public BigDecimal getTargetValue() { return targetValue; }
    public void setTargetValue(BigDecimal targetValue) { this.targetValue = targetValue; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
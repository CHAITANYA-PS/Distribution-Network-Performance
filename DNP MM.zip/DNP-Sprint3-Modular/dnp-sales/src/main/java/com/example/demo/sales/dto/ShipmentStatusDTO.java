package com.example.demo.sales.dto;

/** Communication DTO for ShipmentStatus; contains scalar values only and no DAO behavior. */
public class ShipmentStatusDTO {
    private Long shipmentStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public ShipmentStatusDTO() {}

    public Long getShipmentStatusId() { return shipmentStatusId; }
    public void setShipmentStatusId(Long shipmentStatusId) { this.shipmentStatusId = shipmentStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }

    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

}
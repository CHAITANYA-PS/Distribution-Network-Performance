package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="inventory_document",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InventoryDocument implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="inventory_document_id")
 private Long inventoryDocumentId;
 @Column(name="inventory_document_type_id")
 private Long inventoryDocumentTypeId;
 @Column(name="document_number")
 private String documentNumber;
 @Column(name="document_date")
 private LocalDate documentDate;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
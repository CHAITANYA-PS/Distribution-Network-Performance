package com.example.demo.sales.repository;

import com.example.demo.sales.entity.ExchangeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExchangeStatusRepository extends JpaRepository<ExchangeStatus, Long> {
}

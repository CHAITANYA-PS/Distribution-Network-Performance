package services;
import dto.SalesRecordDTO;
public interface SalesRecordService extends GenericService<SalesRecordDTO> {}

package services;
import dto.ShipmentStatusDTO;
public interface ShipmentStatusService extends GenericService<ShipmentStatusDTO> {}

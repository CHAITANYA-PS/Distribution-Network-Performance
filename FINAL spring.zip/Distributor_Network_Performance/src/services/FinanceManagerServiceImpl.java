package services;
import dao.FinanceManagerDao;
import dao.FinanceManagerDaoImpl;
import dto.FinanceManagerDTO;
import entity.FinanceManager;
import jdbc.ConnectionFactory;
public class FinanceManagerServiceImpl extends AbstractService<FinanceManager,FinanceManagerDTO> implements FinanceManagerService { public FinanceManagerServiceImpl(FinanceManagerDao dao){super(dao,FinanceManager.class,FinanceManagerDTO.class);} public FinanceManagerServiceImpl(ConnectionFactory cf){this(new FinanceManagerDaoImpl(cf));} }

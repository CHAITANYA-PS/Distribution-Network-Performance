package services;
import dto.RecoveryPlanTicketDTO;
public interface RecoveryPlanTicketService extends GenericService<RecoveryPlanTicketDTO> {}

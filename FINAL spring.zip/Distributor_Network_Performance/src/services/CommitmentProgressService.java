package services;
import dto.CommitmentProgressDTO;
public interface CommitmentProgressService extends GenericService<CommitmentProgressDTO> {}

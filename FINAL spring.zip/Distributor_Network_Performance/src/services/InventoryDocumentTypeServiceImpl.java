package services;
import dao.InventoryDocumentTypeDao;
import dao.InventoryDocumentTypeDaoImpl;
import dto.InventoryDocumentTypeDTO;
import entity.InventoryDocumentType;
import jdbc.ConnectionFactory;
public class InventoryDocumentTypeServiceImpl extends AbstractService<InventoryDocumentType,InventoryDocumentTypeDTO> implements InventoryDocumentTypeService { public InventoryDocumentTypeServiceImpl(InventoryDocumentTypeDao dao){super(dao,InventoryDocumentType.class,InventoryDocumentTypeDTO.class);} public InventoryDocumentTypeServiceImpl(ConnectionFactory cf){this(new InventoryDocumentTypeDaoImpl(cf));} }

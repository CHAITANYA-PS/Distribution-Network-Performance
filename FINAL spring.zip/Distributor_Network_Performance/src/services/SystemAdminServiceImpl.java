package services;
import dao.SystemAdminDao;
import dao.SystemAdminDaoImpl;
import dto.SystemAdminDTO;
import entity.SystemAdmin;
import jdbc.ConnectionFactory;
public class SystemAdminServiceImpl extends AbstractService<SystemAdmin,SystemAdminDTO> implements SystemAdminService { public SystemAdminServiceImpl(SystemAdminDao dao){super(dao,SystemAdmin.class,SystemAdminDTO.class);} public SystemAdminServiceImpl(ConnectionFactory cf){this(new SystemAdminDaoImpl(cf));} }

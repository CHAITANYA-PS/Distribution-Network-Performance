package services;
import dao.ProductBatchDao;
import dao.ProductBatchDaoImpl;
import dto.ProductBatchDTO;
import entity.ProductBatch;
import jdbc.ConnectionFactory;
public class ProductBatchServiceImpl extends AbstractService<ProductBatch,ProductBatchDTO> implements ProductBatchService { public ProductBatchServiceImpl(ProductBatchDao dao){super(dao,ProductBatch.class,ProductBatchDTO.class);} public ProductBatchServiceImpl(ConnectionFactory cf){this(new ProductBatchDaoImpl(cf));} }

package services;
import dto.ExchangeRequestDTO;
public interface ExchangeRequestService extends GenericService<ExchangeRequestDTO> {}

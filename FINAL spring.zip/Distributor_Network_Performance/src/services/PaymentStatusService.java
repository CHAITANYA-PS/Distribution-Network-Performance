package services;
import dto.PaymentStatusDTO;
public interface PaymentStatusService extends GenericService<PaymentStatusDTO> {}

package services;
import dto.PaymentDTO;
public interface PaymentService extends GenericService<PaymentDTO> {}

package services;
import dao.CommitmentStatusDao;
import dao.CommitmentStatusDaoImpl;
import dto.CommitmentStatusDTO;
import entity.CommitmentStatus;
import jdbc.ConnectionFactory;
public class CommitmentStatusServiceImpl extends AbstractService<CommitmentStatus,CommitmentStatusDTO> implements CommitmentStatusService { public CommitmentStatusServiceImpl(CommitmentStatusDao dao){super(dao,CommitmentStatus.class,CommitmentStatusDTO.class);} public CommitmentStatusServiceImpl(ConnectionFactory cf){this(new CommitmentStatusDaoImpl(cf));} }

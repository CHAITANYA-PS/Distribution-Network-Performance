package services;
import dao.HealthAssessmentAlertDao;
import dao.HealthAssessmentAlertDaoImpl;
import dto.HealthAssessmentAlertDTO;
import entity.HealthAssessmentAlert;
import jdbc.ConnectionFactory;
public class HealthAssessmentAlertServiceImpl extends AbstractService<HealthAssessmentAlert,HealthAssessmentAlertDTO> implements HealthAssessmentAlertService { public HealthAssessmentAlertServiceImpl(HealthAssessmentAlertDao dao){super(dao,HealthAssessmentAlert.class,HealthAssessmentAlertDTO.class);} public HealthAssessmentAlertServiceImpl(ConnectionFactory cf){this(new HealthAssessmentAlertDaoImpl(cf));} }

package services;
import dao.RecoveryPlanDao;
import dao.RecoveryPlanDaoImpl;
import dto.RecoveryPlanDTO;
import entity.RecoveryPlan;
import jdbc.ConnectionFactory;
public class RecoveryPlanServiceImpl extends AbstractService<RecoveryPlan,RecoveryPlanDTO> implements RecoveryPlanService { public RecoveryPlanServiceImpl(RecoveryPlanDao dao){super(dao,RecoveryPlan.class,RecoveryPlanDTO.class);} public RecoveryPlanServiceImpl(ConnectionFactory cf){this(new RecoveryPlanDaoImpl(cf));} }

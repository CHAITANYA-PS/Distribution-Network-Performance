package services;
import dao.InvoiceStatusDao;
import dao.InvoiceStatusDaoImpl;
import dto.InvoiceStatusDTO;
import entity.InvoiceStatus;
import jdbc.ConnectionFactory;
public class InvoiceStatusServiceImpl extends AbstractService<InvoiceStatus,InvoiceStatusDTO> implements InvoiceStatusService { public InvoiceStatusServiceImpl(InvoiceStatusDao dao){super(dao,InvoiceStatus.class,InvoiceStatusDTO.class);} public InvoiceStatusServiceImpl(ConnectionFactory cf){this(new InvoiceStatusDaoImpl(cf));} }

package services;

import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.util.LinkedHashMap;
import java.util.Map;

public final class EntityDtoMapper {
	private EntityDtoMapper() {
	}

	public static <S, T> T map(S source, Class<T> target) {
		if (source == null)
			return null;
		try {
			@SuppressWarnings("deprecation")
			T t = target.newInstance();
			Map<String, Field> tf = fields(target);
			for (Field sf : fields(source.getClass()).values()) {
				Field d = tf.get(sf.getName());
				if (d != null && d.getType().isAssignableFrom(sf.getType())) {
					sf.setAccessible(true);
					d.setAccessible(true);
					d.set(t, sf.get(source));
				}
			}
			return t;
		} catch (Exception e) {
			throw new BusinessException(
					"Mapping failed from " + source.getClass().getSimpleName() + " to " + target.getSimpleName(), e);
		}
	}

	private static Map<String, Field> fields(Class<?> c) {
		Map<String, Field> m = new LinkedHashMap<>();
		for (Class<?> x = c; x != null && x != Object.class; x = x.getSuperclass())
			for (Field f : x.getDeclaredFields())
				if (!Modifier.isStatic(f.getModifiers()))
					m.put(f.getName(), f);
		return m;
	}
}

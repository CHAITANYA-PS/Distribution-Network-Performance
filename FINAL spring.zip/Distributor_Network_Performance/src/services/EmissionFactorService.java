package services;
import dto.EmissionFactorDTO;
public interface EmissionFactorService extends GenericService<EmissionFactorDTO> {}

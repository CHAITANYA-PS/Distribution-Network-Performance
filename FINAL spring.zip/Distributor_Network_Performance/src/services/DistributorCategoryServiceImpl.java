package services;
import dao.DistributorCategoryDao;
import dao.DistributorCategoryDaoImpl;
import dto.DistributorCategoryDTO;
import entity.DistributorCategory;
import jdbc.ConnectionFactory;
public class DistributorCategoryServiceImpl extends AbstractService<DistributorCategory,DistributorCategoryDTO> implements DistributorCategoryService { public DistributorCategoryServiceImpl(DistributorCategoryDao dao){super(dao,DistributorCategory.class,DistributorCategoryDTO.class);} public DistributorCategoryServiceImpl(ConnectionFactory cf){this(new DistributorCategoryDaoImpl(cf));} }

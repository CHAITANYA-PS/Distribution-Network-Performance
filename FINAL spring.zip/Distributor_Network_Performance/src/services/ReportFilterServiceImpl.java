package services;
import dao.ReportFilterDao;
import dao.ReportFilterDaoImpl;
import dto.ReportFilterDTO;
import entity.ReportFilter;
import jdbc.ConnectionFactory;
public class ReportFilterServiceImpl extends AbstractService<ReportFilter,ReportFilterDTO> implements ReportFilterService { public ReportFilterServiceImpl(ReportFilterDao dao){super(dao,ReportFilter.class,ReportFilterDTO.class);} public ReportFilterServiceImpl(ConnectionFactory cf){this(new ReportFilterDaoImpl(cf));} }

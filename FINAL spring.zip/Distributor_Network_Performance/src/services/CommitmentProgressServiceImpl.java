package services;
import dao.CommitmentProgressDao;
import dao.CommitmentProgressDaoImpl;
import dto.CommitmentProgressDTO;
import entity.CommitmentProgress;
import jdbc.ConnectionFactory;
public class CommitmentProgressServiceImpl extends AbstractService<CommitmentProgress,CommitmentProgressDTO> implements CommitmentProgressService { public CommitmentProgressServiceImpl(CommitmentProgressDao dao){super(dao,CommitmentProgress.class,CommitmentProgressDTO.class);} public CommitmentProgressServiceImpl(ConnectionFactory cf){this(new CommitmentProgressDaoImpl(cf));} }

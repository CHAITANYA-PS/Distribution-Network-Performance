package services;
import dao.SalesRecordDao;
import dao.SalesRecordDaoImpl;
import dto.SalesRecordDTO;
import entity.SalesRecord;
import jdbc.ConnectionFactory;
public class SalesRecordServiceImpl extends AbstractService<SalesRecord,SalesRecordDTO> implements SalesRecordService { public SalesRecordServiceImpl(SalesRecordDao dao){super(dao,SalesRecord.class,SalesRecordDTO.class);} public SalesRecordServiceImpl(ConnectionFactory cf){this(new SalesRecordDaoImpl(cf));} }

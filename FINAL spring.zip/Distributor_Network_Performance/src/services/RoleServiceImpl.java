package services;
import dao.RoleDao;
import dao.RoleDaoImpl;
import dto.RoleDTO;
import entity.Role;
import jdbc.ConnectionFactory;
public class RoleServiceImpl extends AbstractService<Role,RoleDTO> implements RoleService { public RoleServiceImpl(RoleDao dao){super(dao,Role.class,RoleDTO.class);} public RoleServiceImpl(ConnectionFactory cf){this(new RoleDaoImpl(cf));} }

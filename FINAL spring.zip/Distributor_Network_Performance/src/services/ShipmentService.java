package services;
import dto.ShipmentDTO;
public interface ShipmentService extends GenericService<ShipmentDTO> {}

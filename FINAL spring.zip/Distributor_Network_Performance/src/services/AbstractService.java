package services;
import java.util.List;
import java.util.stream.Collectors;

import dao.GenericDao;
public abstract class AbstractService<E,D> implements GenericService<D>{ protected final GenericDao<E,Long> dao;private final Class<E> ec;private final Class<D> dc;private final String name;
 protected AbstractService(GenericDao<E,Long> dao,Class<E> ec,Class<D> dc){this.dao=BusinessValidator.notNull(dao,"dao");this.ec=ec;this.dc=dc;this.name=ec.getSimpleName();}
 protected void validateForCreate(D dto){BusinessValidator.notNull(dto,name+"DTO");}
 protected void validateForUpdate(D dto){validateForCreate(dto);}
 @Override
public D create(D dto){validateForCreate(dto);try{return toDto(dao.save(toEntity(dto)));}catch(RuntimeException e){throw translate("create",e);}}
 @Override
public D update(Long id,D dto){BusinessValidator.positiveId(id);validateForUpdate(dto);try{E e=toEntity(dto);setId(e,id);return toDto(dao.update(e));}catch(RuntimeException e){throw translate("update",e);}}
 @Override
public D getById(Long id){BusinessValidator.positiveId(id);try{return dao.findById(id).map(this::toDto).orElseThrow(()->new BusinessNotFoundException(name+" not found: "+id));}catch(BusinessException e){throw e;}catch(RuntimeException e){throw translate("read",e);}}
 @Override
public List<D> getAll(){try{return dao.findAll().stream().map(this::toDto).collect(Collectors.toList());}catch(RuntimeException e){throw translate("list",e);}}
 @Override
public boolean delete(Long id){BusinessValidator.positiveId(id);try{return dao.deleteById(id);}catch(RuntimeException e){throw translate("delete",e);}} @Override
public long count(){return dao.count();}
 protected E toEntity(D d){return EntityDtoMapper.map(d,ec);} protected D toDto(E e){return EntityDtoMapper.map(e,dc);}
 private void setId(E e,Long id){try{for(java.lang.reflect.Field f:ec.getDeclaredFields())if(f.getType()==Long.class&&f.getName().toLowerCase().endsWith("id")){f.setAccessible(true);f.set(e,id);return;}throw new BusinessException("No ID field for "+name);}catch(IllegalAccessException x){throw new BusinessException("Cannot set ID for "+name,x);}}
 private BusinessException translate(String op,RuntimeException e){return e instanceof BusinessException?(BusinessException)e:new BusinessException("Unable to "+op+" "+name,e);}
}

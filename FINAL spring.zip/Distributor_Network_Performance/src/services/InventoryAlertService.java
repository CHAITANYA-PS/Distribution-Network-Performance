package services;
import dto.InventoryAlertDTO;
public interface InventoryAlertService extends GenericService<InventoryAlertDTO> {}

package services;
import dto.DepartmentDTO;
public interface DepartmentService extends GenericService<DepartmentDTO> {}

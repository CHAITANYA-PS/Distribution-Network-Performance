package services;
import dto.DistributorDTO;
public interface DistributorService extends GenericService<DistributorDTO> {}

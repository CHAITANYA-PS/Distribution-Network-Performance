package services;
import dto.HealthAssessmentAlertDTO;
public interface HealthAssessmentAlertService extends GenericService<HealthAssessmentAlertDTO> {}

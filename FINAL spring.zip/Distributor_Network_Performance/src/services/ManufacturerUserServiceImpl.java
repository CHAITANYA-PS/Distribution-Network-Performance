package services;
import dao.ManufacturerUserDao;
import dao.ManufacturerUserDaoImpl;
import dto.ManufacturerUserDTO;
import entity.ManufacturerUser;
import jdbc.ConnectionFactory;
public class ManufacturerUserServiceImpl extends AbstractService<ManufacturerUser,ManufacturerUserDTO> implements ManufacturerUserService { public ManufacturerUserServiceImpl(ManufacturerUserDao dao){super(dao,ManufacturerUser.class,ManufacturerUserDTO.class);} public ManufacturerUserServiceImpl(ConnectionFactory cf){this(new ManufacturerUserDaoImpl(cf));} }

package services;
import dto.ReportingPeriodDTO;
public interface ReportingPeriodService extends GenericService<ReportingPeriodDTO> {}

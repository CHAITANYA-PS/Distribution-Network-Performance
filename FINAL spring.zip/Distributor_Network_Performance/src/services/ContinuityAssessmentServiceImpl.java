package services;
import dao.ContinuityAssessmentDao;
import dao.ContinuityAssessmentDaoImpl;
import dto.ContinuityAssessmentDTO;
import entity.ContinuityAssessment;
import jdbc.ConnectionFactory;
public class ContinuityAssessmentServiceImpl extends AbstractService<ContinuityAssessment,ContinuityAssessmentDTO> implements ContinuityAssessmentService { public ContinuityAssessmentServiceImpl(ContinuityAssessmentDao dao){super(dao,ContinuityAssessment.class,ContinuityAssessmentDTO.class);} public ContinuityAssessmentServiceImpl(ConnectionFactory cf){this(new ContinuityAssessmentDaoImpl(cf));} }

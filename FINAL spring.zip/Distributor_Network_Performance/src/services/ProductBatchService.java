package services;
import dto.ProductBatchDTO;
public interface ProductBatchService extends GenericService<ProductBatchDTO> {}

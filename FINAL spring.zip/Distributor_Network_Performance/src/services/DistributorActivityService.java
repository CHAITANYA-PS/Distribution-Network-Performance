package services;
import dto.DistributorActivityDTO;
public interface DistributorActivityService extends GenericService<DistributorActivityDTO> {}

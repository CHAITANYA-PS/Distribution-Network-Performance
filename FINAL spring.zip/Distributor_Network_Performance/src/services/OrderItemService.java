package services;
import dto.OrderItemDTO;
public interface OrderItemService extends GenericService<OrderItemDTO> {}

package services;
import dao.PasswordResetDao;
import dao.PasswordResetDaoImpl;
import dto.PasswordResetDTO;
import entity.PasswordReset;
import jdbc.ConnectionFactory;
public class PasswordResetServiceImpl extends AbstractService<PasswordReset,PasswordResetDTO> implements PasswordResetService { public PasswordResetServiceImpl(PasswordResetDao dao){super(dao,PasswordReset.class,PasswordResetDTO.class);} public PasswordResetServiceImpl(ConnectionFactory cf){this(new PasswordResetDaoImpl(cf));} }

package services;
import dto.InvoiceStatusDTO;
public interface InvoiceStatusService extends GenericService<InvoiceStatusDTO> {}

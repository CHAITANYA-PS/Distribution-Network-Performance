package services;
import dao.SalesManagerDao;
import dao.SalesManagerDaoImpl;
import dto.SalesManagerDTO;
import entity.SalesManager;
import jdbc.ConnectionFactory;
public class SalesManagerServiceImpl extends AbstractService<SalesManager,SalesManagerDTO> implements SalesManagerService { public SalesManagerServiceImpl(SalesManagerDao dao){super(dao,SalesManager.class,SalesManagerDTO.class);} public SalesManagerServiceImpl(ConnectionFactory cf){this(new SalesManagerDaoImpl(cf));} }

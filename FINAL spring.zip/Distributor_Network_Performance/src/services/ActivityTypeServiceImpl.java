package services;
import dao.ActivityTypeDao;
import dao.ActivityTypeDaoImpl;
import dto.ActivityTypeDTO;
import entity.ActivityType;
import jdbc.ConnectionFactory;
public class ActivityTypeServiceImpl extends AbstractService<ActivityType,ActivityTypeDTO> implements ActivityTypeService { public ActivityTypeServiceImpl(ActivityTypeDao dao){super(dao,ActivityType.class,ActivityTypeDTO.class);} public ActivityTypeServiceImpl(ConnectionFactory cf){this(new ActivityTypeDaoImpl(cf));} }

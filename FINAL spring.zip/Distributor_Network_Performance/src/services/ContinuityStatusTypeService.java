package services;
import dto.ContinuityStatusTypeDTO;
public interface ContinuityStatusTypeService extends GenericService<ContinuityStatusTypeDTO> {}

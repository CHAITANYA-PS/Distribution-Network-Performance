package services;
import dto.ActivityTypeDTO;
public interface ActivityTypeService extends GenericService<ActivityTypeDTO> {}

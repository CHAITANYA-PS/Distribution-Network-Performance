package services;
import dao.NotificationDao;
import dao.NotificationDaoImpl;
import dto.NotificationDTO;
import entity.Notification;
import jdbc.ConnectionFactory;
public class NotificationServiceImpl extends AbstractService<Notification,NotificationDTO> implements NotificationService { public NotificationServiceImpl(NotificationDao dao){super(dao,Notification.class,NotificationDTO.class);} public NotificationServiceImpl(ConnectionFactory cf){this(new NotificationDaoImpl(cf));} }

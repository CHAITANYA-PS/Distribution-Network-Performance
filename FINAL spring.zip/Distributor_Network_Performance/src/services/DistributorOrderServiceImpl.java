package services;
import dao.DistributorOrderDao;
import dao.DistributorOrderDaoImpl;
import dto.DistributorOrderDTO;
import entity.DistributorOrder;
import jdbc.ConnectionFactory;
public class DistributorOrderServiceImpl extends AbstractService<DistributorOrder,DistributorOrderDTO> implements DistributorOrderService { public DistributorOrderServiceImpl(DistributorOrderDao dao){super(dao,DistributorOrder.class,DistributorOrderDTO.class);} public DistributorOrderServiceImpl(ConnectionFactory cf){this(new DistributorOrderDaoImpl(cf));} }

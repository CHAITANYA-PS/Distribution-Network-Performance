package services;
import dto.ManufacturerUserDTO;
public interface ManufacturerUserService extends GenericService<ManufacturerUserDTO> {}

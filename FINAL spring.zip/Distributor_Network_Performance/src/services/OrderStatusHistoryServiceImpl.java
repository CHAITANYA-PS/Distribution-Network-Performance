package services;
import dao.OrderStatusHistoryDao;
import dao.OrderStatusHistoryDaoImpl;
import dto.OrderStatusHistoryDTO;
import entity.OrderStatusHistory;
import jdbc.ConnectionFactory;
public class OrderStatusHistoryServiceImpl extends AbstractService<OrderStatusHistory,OrderStatusHistoryDTO> implements OrderStatusHistoryService { public OrderStatusHistoryServiceImpl(OrderStatusHistoryDao dao){super(dao,OrderStatusHistory.class,OrderStatusHistoryDTO.class);} public OrderStatusHistoryServiceImpl(ConnectionFactory cf){this(new OrderStatusHistoryDaoImpl(cf));} }

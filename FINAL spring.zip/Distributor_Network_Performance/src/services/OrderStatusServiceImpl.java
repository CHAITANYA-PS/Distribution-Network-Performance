package services;
import dao.OrderStatusDao;
import dao.OrderStatusDaoImpl;
import dto.OrderStatusDTO;
import entity.OrderStatus;
import jdbc.ConnectionFactory;
public class OrderStatusServiceImpl extends AbstractService<OrderStatus,OrderStatusDTO> implements OrderStatusService { public OrderStatusServiceImpl(OrderStatusDao dao){super(dao,OrderStatus.class,OrderStatusDTO.class);} public OrderStatusServiceImpl(ConnectionFactory cf){this(new OrderStatusDaoImpl(cf));} }

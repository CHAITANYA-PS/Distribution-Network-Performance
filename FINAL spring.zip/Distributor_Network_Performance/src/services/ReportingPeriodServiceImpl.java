package services;
import dao.ReportingPeriodDao;
import dao.ReportingPeriodDaoImpl;
import dto.ReportingPeriodDTO;
import entity.ReportingPeriod;
import jdbc.ConnectionFactory;
public class ReportingPeriodServiceImpl extends AbstractService<ReportingPeriod,ReportingPeriodDTO> implements ReportingPeriodService { public ReportingPeriodServiceImpl(ReportingPeriodDao dao){super(dao,ReportingPeriod.class,ReportingPeriodDTO.class);} public ReportingPeriodServiceImpl(ConnectionFactory cf){this(new ReportingPeriodDaoImpl(cf));} }

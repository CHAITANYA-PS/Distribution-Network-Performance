package services;
import dao.ContinuityStatusTypeDao;
import dao.ContinuityStatusTypeDaoImpl;
import dto.ContinuityStatusTypeDTO;
import entity.ContinuityStatusType;
import jdbc.ConnectionFactory;
public class ContinuityStatusTypeServiceImpl extends AbstractService<ContinuityStatusType,ContinuityStatusTypeDTO> implements ContinuityStatusTypeService { public ContinuityStatusTypeServiceImpl(ContinuityStatusTypeDao dao){super(dao,ContinuityStatusType.class,ContinuityStatusTypeDTO.class);} public ContinuityStatusTypeServiceImpl(ConnectionFactory cf){this(new ContinuityStatusTypeDaoImpl(cf));} }

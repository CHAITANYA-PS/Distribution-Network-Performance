package services;
import dto.ReportFilterValueDTO;
public interface ReportFilterValueService extends GenericService<ReportFilterValueDTO> {}

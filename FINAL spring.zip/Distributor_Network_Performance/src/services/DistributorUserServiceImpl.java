package services;
import dao.DistributorUserDao;
import dao.DistributorUserDaoImpl;
import dto.DistributorUserDTO;
import entity.DistributorUser;
import jdbc.ConnectionFactory;
public class DistributorUserServiceImpl extends AbstractService<DistributorUser,DistributorUserDTO> implements DistributorUserService { public DistributorUserServiceImpl(DistributorUserDao dao){super(dao,DistributorUser.class,DistributorUserDTO.class);} public DistributorUserServiceImpl(ConnectionFactory cf){this(new DistributorUserDaoImpl(cf));} }

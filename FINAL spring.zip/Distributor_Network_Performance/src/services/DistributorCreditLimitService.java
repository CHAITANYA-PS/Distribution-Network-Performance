package services;
import dto.DistributorCreditLimitDTO;
public interface DistributorCreditLimitService extends GenericService<DistributorCreditLimitDTO> {}

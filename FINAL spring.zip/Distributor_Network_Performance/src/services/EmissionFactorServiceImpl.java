package services;
import dao.EmissionFactorDao;
import dao.EmissionFactorDaoImpl;
import dto.EmissionFactorDTO;
import entity.EmissionFactor;
import jdbc.ConnectionFactory;
public class EmissionFactorServiceImpl extends AbstractService<EmissionFactor,EmissionFactorDTO> implements EmissionFactorService { public EmissionFactorServiceImpl(EmissionFactorDao dao){super(dao,EmissionFactor.class,EmissionFactorDTO.class);} public EmissionFactorServiceImpl(ConnectionFactory cf){this(new EmissionFactorDaoImpl(cf));} }

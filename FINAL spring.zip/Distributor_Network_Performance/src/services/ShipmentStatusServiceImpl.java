package services;
import dao.ShipmentStatusDao;
import dao.ShipmentStatusDaoImpl;
import dto.ShipmentStatusDTO;
import entity.ShipmentStatus;
import jdbc.ConnectionFactory;
public class ShipmentStatusServiceImpl extends AbstractService<ShipmentStatus,ShipmentStatusDTO> implements ShipmentStatusService { public ShipmentStatusServiceImpl(ShipmentStatusDao dao){super(dao,ShipmentStatus.class,ShipmentStatusDTO.class);} public ShipmentStatusServiceImpl(ConnectionFactory cf){this(new ShipmentStatusDaoImpl(cf));} }

package services;

public final class BusinessValidator { private BusinessValidator(){} public static <T>T notNull(T v,String n){if(v==null)throw new BusinessException(n+" must not be null");return v;} public static Long positiveId(Long id){if(id==null||id<=0)throw new BusinessException("ID must be positive");return id;} }

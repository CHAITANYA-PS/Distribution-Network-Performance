package services;
import dto.ReportFilterDTO;
public interface ReportFilterService extends GenericService<ReportFilterDTO> {}

package services;
import dao.SalesTargetDao;
import dao.SalesTargetDaoImpl;
import dto.SalesTargetDTO;
import entity.SalesTarget;
import jdbc.ConnectionFactory;
public class SalesTargetServiceImpl extends AbstractService<SalesTarget,SalesTargetDTO> implements SalesTargetService { public SalesTargetServiceImpl(SalesTargetDao dao){super(dao,SalesTarget.class,SalesTargetDTO.class);} public SalesTargetServiceImpl(ConnectionFactory cf){this(new SalesTargetDaoImpl(cf));} }

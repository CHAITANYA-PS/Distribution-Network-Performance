package services;
import dao.RecoveryManagerDao;
import dao.RecoveryManagerDaoImpl;
import dto.RecoveryManagerDTO;
import entity.RecoveryManager;
import jdbc.ConnectionFactory;
public class RecoveryManagerServiceImpl extends AbstractService<RecoveryManager,RecoveryManagerDTO> implements RecoveryManagerService { public RecoveryManagerServiceImpl(RecoveryManagerDao dao){super(dao,RecoveryManager.class,RecoveryManagerDTO.class);} public RecoveryManagerServiceImpl(ConnectionFactory cf){this(new RecoveryManagerDaoImpl(cf));} }

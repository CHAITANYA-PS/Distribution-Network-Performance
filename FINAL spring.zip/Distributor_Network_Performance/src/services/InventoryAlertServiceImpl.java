package services;
import dao.InventoryAlertDao;
import dao.InventoryAlertDaoImpl;
import dto.InventoryAlertDTO;
import entity.InventoryAlert;
import jdbc.ConnectionFactory;
public class InventoryAlertServiceImpl extends AbstractService<InventoryAlert,InventoryAlertDTO> implements InventoryAlertService { public InventoryAlertServiceImpl(InventoryAlertDao dao){super(dao,InventoryAlert.class,InventoryAlertDTO.class);} public InventoryAlertServiceImpl(ConnectionFactory cf){this(new InventoryAlertDaoImpl(cf));} }

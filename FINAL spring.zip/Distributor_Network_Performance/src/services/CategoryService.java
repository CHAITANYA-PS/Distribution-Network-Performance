package services;
import dto.CategoryDTO;
public interface CategoryService extends GenericService<CategoryDTO> {}

package services;
import dto.RiskBandDTO;
public interface RiskBandService extends GenericService<RiskBandDTO> {}

package services;
import dto.PaymentMethodDTO;
public interface PaymentMethodService extends GenericService<PaymentMethodDTO> {}

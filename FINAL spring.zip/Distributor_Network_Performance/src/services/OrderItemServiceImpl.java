package services;
import dao.OrderItemDao;
import dao.OrderItemDaoImpl;
import dto.OrderItemDTO;
import entity.OrderItem;
import jdbc.ConnectionFactory;
public class OrderItemServiceImpl extends AbstractService<OrderItem,OrderItemDTO> implements OrderItemService { public OrderItemServiceImpl(OrderItemDao dao){super(dao,OrderItem.class,OrderItemDTO.class);} public OrderItemServiceImpl(ConnectionFactory cf){this(new OrderItemDaoImpl(cf));} }

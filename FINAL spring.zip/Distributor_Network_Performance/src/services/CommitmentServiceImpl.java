package services;
import dao.CommitmentDao;
import dao.CommitmentDaoImpl;
import dto.CommitmentDTO;
import entity.Commitment;
import jdbc.ConnectionFactory;
public class CommitmentServiceImpl extends AbstractService<Commitment,CommitmentDTO> implements CommitmentService { public CommitmentServiceImpl(CommitmentDao dao){super(dao,Commitment.class,CommitmentDTO.class);} public CommitmentServiceImpl(ConnectionFactory cf){this(new CommitmentDaoImpl(cf));} }

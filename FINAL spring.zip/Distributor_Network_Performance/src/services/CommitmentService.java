package services;
import dto.CommitmentDTO;
public interface CommitmentService extends GenericService<CommitmentDTO> {}

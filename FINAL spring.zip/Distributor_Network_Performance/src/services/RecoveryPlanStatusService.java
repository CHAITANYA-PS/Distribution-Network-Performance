package services;
import dto.RecoveryPlanStatusDTO;
public interface RecoveryPlanStatusService extends GenericService<RecoveryPlanStatusDTO> {}

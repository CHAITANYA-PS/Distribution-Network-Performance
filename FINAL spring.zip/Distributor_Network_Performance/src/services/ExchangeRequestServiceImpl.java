package services;
import dao.ExchangeRequestDao;
import dao.ExchangeRequestDaoImpl;
import dto.ExchangeRequestDTO;
import entity.ExchangeRequest;
import jdbc.ConnectionFactory;
public class ExchangeRequestServiceImpl extends AbstractService<ExchangeRequest,ExchangeRequestDTO> implements ExchangeRequestService { public ExchangeRequestServiceImpl(ExchangeRequestDao dao){super(dao,ExchangeRequest.class,ExchangeRequestDTO.class);} public ExchangeRequestServiceImpl(ConnectionFactory cf){this(new ExchangeRequestDaoImpl(cf));} }

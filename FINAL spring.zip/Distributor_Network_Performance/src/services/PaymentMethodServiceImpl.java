package services;
import dao.PaymentMethodDao;
import dao.PaymentMethodDaoImpl;
import dto.PaymentMethodDTO;
import entity.PaymentMethod;
import jdbc.ConnectionFactory;
public class PaymentMethodServiceImpl extends AbstractService<PaymentMethod,PaymentMethodDTO> implements PaymentMethodService { public PaymentMethodServiceImpl(PaymentMethodDao dao){super(dao,PaymentMethod.class,PaymentMethodDTO.class);} public PaymentMethodServiceImpl(ConnectionFactory cf){this(new PaymentMethodDaoImpl(cf));} }

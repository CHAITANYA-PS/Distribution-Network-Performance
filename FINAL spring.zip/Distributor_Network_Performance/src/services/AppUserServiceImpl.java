package services;
import dao.AppUserDao;
import dao.AppUserDaoImpl;
import dto.AppUserDTO;
import entity.AppUser;
import jdbc.ConnectionFactory;
public class AppUserServiceImpl extends AbstractService<AppUser,AppUserDTO> implements AppUserService { public AppUserServiceImpl(AppUserDao dao){super(dao,AppUser.class,AppUserDTO.class);} public AppUserServiceImpl(ConnectionFactory cf){this(new AppUserDaoImpl(cf));} }

package services;
import dao.RiskLevelDao;
import dao.RiskLevelDaoImpl;
import dto.RiskLevelDTO;
import entity.RiskLevel;
import jdbc.ConnectionFactory;
public class RiskLevelServiceImpl extends AbstractService<RiskLevel,RiskLevelDTO> implements RiskLevelService { public RiskLevelServiceImpl(RiskLevelDao dao){super(dao,RiskLevel.class,RiskLevelDTO.class);} public RiskLevelServiceImpl(ConnectionFactory cf){this(new RiskLevelDaoImpl(cf));} }

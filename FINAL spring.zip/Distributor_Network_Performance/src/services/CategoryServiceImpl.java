package services;
import dao.CategoryDao;
import dao.CategoryDaoImpl;
import dto.CategoryDTO;
import entity.Category;
import jdbc.ConnectionFactory;
public class CategoryServiceImpl extends AbstractService<Category,CategoryDTO> implements CategoryService { public CategoryServiceImpl(CategoryDao dao){super(dao,Category.class,CategoryDTO.class);} public CategoryServiceImpl(ConnectionFactory cf){this(new CategoryDaoImpl(cf));} }

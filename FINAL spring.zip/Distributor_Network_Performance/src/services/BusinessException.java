package services;
public class BusinessException extends RuntimeException { private static final long serialVersionUID=1L; public BusinessException(String m){super(m);} public BusinessException(String m,Throwable c){super(m,c);} }

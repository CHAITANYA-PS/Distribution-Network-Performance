package services;
import dto.NotificationTypeDTO;
public interface NotificationTypeService extends GenericService<NotificationTypeDTO> {}

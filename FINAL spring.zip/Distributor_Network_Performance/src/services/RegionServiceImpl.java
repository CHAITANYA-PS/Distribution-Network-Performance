package services;
import dao.RegionDao;
import dao.RegionDaoImpl;
import dto.RegionDTO;
import entity.Region;
import jdbc.ConnectionFactory;
public class RegionServiceImpl extends AbstractService<Region,RegionDTO> implements RegionService { public RegionServiceImpl(RegionDao dao){super(dao,Region.class,RegionDTO.class);} public RegionServiceImpl(ConnectionFactory cf){this(new RegionDaoImpl(cf));} }

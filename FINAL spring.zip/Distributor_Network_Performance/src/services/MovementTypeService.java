package services;
import dto.MovementTypeDTO;
public interface MovementTypeService extends GenericService<MovementTypeDTO> {}

package services;
import dto.RegionDTO;
public interface RegionService extends GenericService<RegionDTO> {}

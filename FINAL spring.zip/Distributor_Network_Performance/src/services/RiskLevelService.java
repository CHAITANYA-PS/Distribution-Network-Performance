package services;
import dto.RiskLevelDTO;
public interface RiskLevelService extends GenericService<RiskLevelDTO> {}

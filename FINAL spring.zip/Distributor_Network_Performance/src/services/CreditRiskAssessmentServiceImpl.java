package services;
import dao.CreditRiskAssessmentDao;
import dao.CreditRiskAssessmentDaoImpl;
import dto.CreditRiskAssessmentDTO;
import entity.CreditRiskAssessment;
import jdbc.ConnectionFactory;
public class CreditRiskAssessmentServiceImpl extends AbstractService<CreditRiskAssessment,CreditRiskAssessmentDTO> implements CreditRiskAssessmentService { public CreditRiskAssessmentServiceImpl(CreditRiskAssessmentDao dao){super(dao,CreditRiskAssessment.class,CreditRiskAssessmentDTO.class);} public CreditRiskAssessmentServiceImpl(ConnectionFactory cf){this(new CreditRiskAssessmentDaoImpl(cf));} }

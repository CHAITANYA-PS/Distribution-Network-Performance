package services;
import java.util.List;
public interface GenericService<D>{ D create(D dto); D update(Long id,D dto); D getById(Long id); List<D> getAll(); boolean delete(Long id); long count(); }

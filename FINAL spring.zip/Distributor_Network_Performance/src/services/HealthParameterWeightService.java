package services;
import dto.HealthParameterWeightDTO;
public interface HealthParameterWeightService extends GenericService<HealthParameterWeightDTO> {}

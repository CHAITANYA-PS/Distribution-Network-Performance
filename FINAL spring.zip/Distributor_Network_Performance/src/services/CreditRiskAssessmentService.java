package services;
import dto.CreditRiskAssessmentDTO;
public interface CreditRiskAssessmentService extends GenericService<CreditRiskAssessmentDTO> {}

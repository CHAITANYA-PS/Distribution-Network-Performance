package services;
import dao.EscalationDao;
import dao.EscalationDaoImpl;
import dto.EscalationDTO;
import entity.Escalation;
import jdbc.ConnectionFactory;
public class EscalationServiceImpl extends AbstractService<Escalation,EscalationDTO> implements EscalationService { public EscalationServiceImpl(EscalationDao dao){super(dao,Escalation.class,EscalationDTO.class);} public EscalationServiceImpl(ConnectionFactory cf){this(new EscalationDaoImpl(cf));} }

package services;
import dto.AppUserDTO;
public interface AppUserService extends GenericService<AppUserDTO> {}

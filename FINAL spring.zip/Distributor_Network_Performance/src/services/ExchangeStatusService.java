package services;
import dto.ExchangeStatusDTO;
public interface ExchangeStatusService extends GenericService<ExchangeStatusDTO> {}

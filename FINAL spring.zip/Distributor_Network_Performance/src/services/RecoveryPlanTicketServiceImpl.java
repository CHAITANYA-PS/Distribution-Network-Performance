package services;
import dao.RecoveryPlanTicketDao;
import dao.RecoveryPlanTicketDaoImpl;
import dto.RecoveryPlanTicketDTO;
import entity.RecoveryPlanTicket;
import jdbc.ConnectionFactory;
public class RecoveryPlanTicketServiceImpl extends AbstractService<RecoveryPlanTicket,RecoveryPlanTicketDTO> implements RecoveryPlanTicketService { public RecoveryPlanTicketServiceImpl(RecoveryPlanTicketDao dao){super(dao,RecoveryPlanTicket.class,RecoveryPlanTicketDTO.class);} public RecoveryPlanTicketServiceImpl(ConnectionFactory cf){this(new RecoveryPlanTicketDaoImpl(cf));} }

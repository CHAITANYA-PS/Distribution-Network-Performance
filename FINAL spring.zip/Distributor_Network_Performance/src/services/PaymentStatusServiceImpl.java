package services;
import dao.PaymentStatusDao;
import dao.PaymentStatusDaoImpl;
import dto.PaymentStatusDTO;
import entity.PaymentStatus;
import jdbc.ConnectionFactory;
public class PaymentStatusServiceImpl extends AbstractService<PaymentStatus,PaymentStatusDTO> implements PaymentStatusService { public PaymentStatusServiceImpl(PaymentStatusDao dao){super(dao,PaymentStatus.class,PaymentStatusDTO.class);} public PaymentStatusServiceImpl(ConnectionFactory cf){this(new PaymentStatusDaoImpl(cf));} }

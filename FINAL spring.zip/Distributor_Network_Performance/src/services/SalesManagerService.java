package services;
import dto.SalesManagerDTO;
public interface SalesManagerService extends GenericService<SalesManagerDTO> {}

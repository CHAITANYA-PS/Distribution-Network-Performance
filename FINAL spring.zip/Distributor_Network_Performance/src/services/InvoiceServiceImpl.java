package services;
import dao.InvoiceDao;
import dao.InvoiceDaoImpl;
import dto.InvoiceDTO;
import entity.Invoice;
import jdbc.ConnectionFactory;
public class InvoiceServiceImpl extends AbstractService<Invoice,InvoiceDTO> implements InvoiceService { public InvoiceServiceImpl(InvoiceDao dao){super(dao,Invoice.class,InvoiceDTO.class);} public InvoiceServiceImpl(ConnectionFactory cf){this(new InvoiceDaoImpl(cf));} }

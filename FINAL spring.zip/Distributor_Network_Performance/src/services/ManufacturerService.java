package services;
import dto.ManufacturerDTO;
public interface ManufacturerService extends GenericService<ManufacturerDTO> {}

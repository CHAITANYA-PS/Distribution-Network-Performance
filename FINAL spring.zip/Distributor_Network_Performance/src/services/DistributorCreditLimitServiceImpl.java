package services;
import dao.DistributorCreditLimitDao;
import dao.DistributorCreditLimitDaoImpl;
import dto.DistributorCreditLimitDTO;
import entity.DistributorCreditLimit;
import jdbc.ConnectionFactory;
public class DistributorCreditLimitServiceImpl extends AbstractService<DistributorCreditLimit,DistributorCreditLimitDTO> implements DistributorCreditLimitService { public DistributorCreditLimitServiceImpl(DistributorCreditLimitDao dao){super(dao,DistributorCreditLimit.class,DistributorCreditLimitDTO.class);} public DistributorCreditLimitServiceImpl(ConnectionFactory cf){this(new DistributorCreditLimitDaoImpl(cf));} }

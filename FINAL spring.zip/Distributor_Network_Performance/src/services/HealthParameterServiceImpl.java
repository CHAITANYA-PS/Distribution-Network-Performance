package services;
import dao.HealthParameterDao;
import dao.HealthParameterDaoImpl;
import dto.HealthParameterDTO;
import entity.HealthParameter;
import jdbc.ConnectionFactory;
public class HealthParameterServiceImpl extends AbstractService<HealthParameter,HealthParameterDTO> implements HealthParameterService { public HealthParameterServiceImpl(HealthParameterDao dao){super(dao,HealthParameter.class,HealthParameterDTO.class);} public HealthParameterServiceImpl(ConnectionFactory cf){this(new HealthParameterDaoImpl(cf));} }

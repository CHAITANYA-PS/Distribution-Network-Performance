package services;
import dto.InventoryMovementDTO;
public interface InventoryMovementService extends GenericService<InventoryMovementDTO> {}

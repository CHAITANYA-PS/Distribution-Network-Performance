package services;
import dao.ReportFilterValueDao;
import dao.ReportFilterValueDaoImpl;
import dto.ReportFilterValueDTO;
import entity.ReportFilterValue;
import jdbc.ConnectionFactory;
public class ReportFilterValueServiceImpl extends AbstractService<ReportFilterValue,ReportFilterValueDTO> implements ReportFilterValueService { public ReportFilterValueServiceImpl(ReportFilterValueDao dao){super(dao,ReportFilterValue.class,ReportFilterValueDTO.class);} public ReportFilterValueServiceImpl(ConnectionFactory cf){this(new ReportFilterValueDaoImpl(cf));} }

package services;
import dto.TicketCategoryDTO;
public interface TicketCategoryService extends GenericService<TicketCategoryDTO> {}

package services;
import dto.ExchangeHistoryDTO;
public interface ExchangeHistoryService extends GenericService<ExchangeHistoryDTO> {}

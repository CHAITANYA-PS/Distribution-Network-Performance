package services;
import dto.ShipmentItemDTO;
public interface ShipmentItemService extends GenericService<ShipmentItemDTO> {}

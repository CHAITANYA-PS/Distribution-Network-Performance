package services;
import dao.PaymentDao;
import dao.PaymentDaoImpl;
import dto.PaymentDTO;
import entity.Payment;
import jdbc.ConnectionFactory;
public class PaymentServiceImpl extends AbstractService<Payment,PaymentDTO> implements PaymentService { public PaymentServiceImpl(PaymentDao dao){super(dao,Payment.class,PaymentDTO.class);} public PaymentServiceImpl(ConnectionFactory cf){this(new PaymentDaoImpl(cf));} }

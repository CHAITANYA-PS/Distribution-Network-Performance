package services;
import dto.CommitmentHistoryDTO;
public interface CommitmentHistoryService extends GenericService<CommitmentHistoryDTO> {}

package services;
import dao.RiskBandDao;
import dao.RiskBandDaoImpl;
import dto.RiskBandDTO;
import entity.RiskBand;
import jdbc.ConnectionFactory;
public class RiskBandServiceImpl extends AbstractService<RiskBand,RiskBandDTO> implements RiskBandService { public RiskBandServiceImpl(RiskBandDao dao){super(dao,RiskBand.class,RiskBandDTO.class);} public RiskBandServiceImpl(ConnectionFactory cf){this(new RiskBandDaoImpl(cf));} }

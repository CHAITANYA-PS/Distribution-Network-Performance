package services;
import dto.ContinuityAssessmentDTO;
public interface ContinuityAssessmentService extends GenericService<ContinuityAssessmentDTO> {}

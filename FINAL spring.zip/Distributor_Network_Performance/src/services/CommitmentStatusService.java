package services;
import dto.CommitmentStatusDTO;
public interface CommitmentStatusService extends GenericService<CommitmentStatusDTO> {}

package services;
import dto.DistributorUserDTO;
public interface DistributorUserService extends GenericService<DistributorUserDTO> {}

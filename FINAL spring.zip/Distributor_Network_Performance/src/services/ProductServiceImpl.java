package services;
import dao.ProductDao;
import dao.ProductDaoImpl;
import dto.ProductDTO;
import entity.Product;
import jdbc.ConnectionFactory;
public class ProductServiceImpl extends AbstractService<Product,ProductDTO> implements ProductService { public ProductServiceImpl(ProductDao dao){super(dao,Product.class,ProductDTO.class);} public ProductServiceImpl(ConnectionFactory cf){this(new ProductDaoImpl(cf));} }

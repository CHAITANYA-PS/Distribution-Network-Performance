package services;
import dto.SalesTargetDTO;
public interface SalesTargetService extends GenericService<SalesTargetDTO> {}

package services;
import dto.DistributorCategoryDTO;
public interface DistributorCategoryService extends GenericService<DistributorCategoryDTO> {}

package services;
import dao.RecoveryPlanStatusDao;
import dao.RecoveryPlanStatusDaoImpl;
import dto.RecoveryPlanStatusDTO;
import entity.RecoveryPlanStatus;
import jdbc.ConnectionFactory;
public class RecoveryPlanStatusServiceImpl extends AbstractService<RecoveryPlanStatus,RecoveryPlanStatusDTO> implements RecoveryPlanStatusService { public RecoveryPlanStatusServiceImpl(RecoveryPlanStatusDao dao){super(dao,RecoveryPlanStatus.class,RecoveryPlanStatusDTO.class);} public RecoveryPlanStatusServiceImpl(ConnectionFactory cf){this(new RecoveryPlanStatusDaoImpl(cf));} }

package services;
import dao.ShipmentDao;
import dao.ShipmentDaoImpl;
import dto.ShipmentDTO;
import entity.Shipment;
import jdbc.ConnectionFactory;
public class ShipmentServiceImpl extends AbstractService<Shipment,ShipmentDTO> implements ShipmentService { public ShipmentServiceImpl(ShipmentDao dao){super(dao,Shipment.class,ShipmentDTO.class);} public ShipmentServiceImpl(ConnectionFactory cf){this(new ShipmentDaoImpl(cf));} }

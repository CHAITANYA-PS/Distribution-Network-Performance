package services;
import dto.InventoryDocumentTypeDTO;
public interface InventoryDocumentTypeService extends GenericService<InventoryDocumentTypeDTO> {}

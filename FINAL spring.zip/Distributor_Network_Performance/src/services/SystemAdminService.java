package services;
import dto.SystemAdminDTO;
public interface SystemAdminService extends GenericService<SystemAdminDTO> {}

package services;
import dto.PasswordResetDTO;
public interface PasswordResetService extends GenericService<PasswordResetDTO> {}

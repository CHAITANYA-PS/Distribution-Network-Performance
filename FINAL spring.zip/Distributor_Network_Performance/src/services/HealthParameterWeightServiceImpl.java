package services;
import dao.HealthParameterWeightDao;
import dao.HealthParameterWeightDaoImpl;
import dto.HealthParameterWeightDTO;
import entity.HealthParameterWeight;
import jdbc.ConnectionFactory;
public class HealthParameterWeightServiceImpl extends AbstractService<HealthParameterWeight,HealthParameterWeightDTO> implements HealthParameterWeightService { public HealthParameterWeightServiceImpl(HealthParameterWeightDao dao){super(dao,HealthParameterWeight.class,HealthParameterWeightDTO.class);} public HealthParameterWeightServiceImpl(ConnectionFactory cf){this(new HealthParameterWeightDaoImpl(cf));} }

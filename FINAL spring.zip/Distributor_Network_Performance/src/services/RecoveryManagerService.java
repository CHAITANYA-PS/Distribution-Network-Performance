package services;
import dto.RecoveryManagerDTO;
public interface RecoveryManagerService extends GenericService<RecoveryManagerDTO> {}

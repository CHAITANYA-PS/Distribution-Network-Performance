package services;
public class BusinessNotFoundException extends BusinessException { private static final long serialVersionUID=1L; public BusinessNotFoundException(String m){super(m);} }

package services;
import dto.EscalationDTO;
public interface EscalationService extends GenericService<EscalationDTO> {}

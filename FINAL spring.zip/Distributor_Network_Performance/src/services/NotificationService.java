package services;
import dto.NotificationDTO;
public interface NotificationService extends GenericService<NotificationDTO> {}

package services;
import dto.FinanceManagerDTO;
public interface FinanceManagerService extends GenericService<FinanceManagerDTO> {}

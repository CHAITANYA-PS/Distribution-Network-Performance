package services;
import dao.MeasurementUnitDao;
import dao.MeasurementUnitDaoImpl;
import dto.MeasurementUnitDTO;
import entity.MeasurementUnit;
import jdbc.ConnectionFactory;
public class MeasurementUnitServiceImpl extends AbstractService<MeasurementUnit,MeasurementUnitDTO> implements MeasurementUnitService { public MeasurementUnitServiceImpl(MeasurementUnitDao dao){super(dao,MeasurementUnit.class,MeasurementUnitDTO.class);} public MeasurementUnitServiceImpl(ConnectionFactory cf){this(new MeasurementUnitDaoImpl(cf));} }

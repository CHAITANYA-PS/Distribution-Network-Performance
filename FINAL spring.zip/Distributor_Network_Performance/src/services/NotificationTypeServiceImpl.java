package services;
import dao.NotificationTypeDao;
import dao.NotificationTypeDaoImpl;
import dto.NotificationTypeDTO;
import entity.NotificationType;
import jdbc.ConnectionFactory;
public class NotificationTypeServiceImpl extends AbstractService<NotificationType,NotificationTypeDTO> implements NotificationTypeService { public NotificationTypeServiceImpl(NotificationTypeDao dao){super(dao,NotificationType.class,NotificationTypeDTO.class);} public NotificationTypeServiceImpl(ConnectionFactory cf){this(new NotificationTypeDaoImpl(cf));} }

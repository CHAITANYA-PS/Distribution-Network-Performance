package services;
import dao.ManufacturerDao;
import dao.ManufacturerDaoImpl;
import dto.ManufacturerDTO;
import entity.Manufacturer;
import jdbc.ConnectionFactory;
public class ManufacturerServiceImpl extends AbstractService<Manufacturer,ManufacturerDTO> implements ManufacturerService { public ManufacturerServiceImpl(ManufacturerDao dao){super(dao,Manufacturer.class,ManufacturerDTO.class);} public ManufacturerServiceImpl(ConnectionFactory cf){this(new ManufacturerDaoImpl(cf));} }

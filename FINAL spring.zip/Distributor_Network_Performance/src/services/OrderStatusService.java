package services;
import dto.OrderStatusDTO;
public interface OrderStatusService extends GenericService<OrderStatusDTO> {}

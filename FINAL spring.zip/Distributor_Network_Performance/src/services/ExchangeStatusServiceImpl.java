package services;
import dao.ExchangeStatusDao;
import dao.ExchangeStatusDaoImpl;
import dto.ExchangeStatusDTO;
import entity.ExchangeStatus;
import jdbc.ConnectionFactory;
public class ExchangeStatusServiceImpl extends AbstractService<ExchangeStatus,ExchangeStatusDTO> implements ExchangeStatusService { public ExchangeStatusServiceImpl(ExchangeStatusDao dao){super(dao,ExchangeStatus.class,ExchangeStatusDTO.class);} public ExchangeStatusServiceImpl(ConnectionFactory cf){this(new ExchangeStatusDaoImpl(cf));} }

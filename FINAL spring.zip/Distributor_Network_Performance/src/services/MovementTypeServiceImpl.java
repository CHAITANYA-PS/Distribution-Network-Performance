package services;
import dao.MovementTypeDao;
import dao.MovementTypeDaoImpl;
import dto.MovementTypeDTO;
import entity.MovementType;
import jdbc.ConnectionFactory;
public class MovementTypeServiceImpl extends AbstractService<MovementType,MovementTypeDTO> implements MovementTypeService { public MovementTypeServiceImpl(MovementTypeDao dao){super(dao,MovementType.class,MovementTypeDTO.class);} public MovementTypeServiceImpl(ConnectionFactory cf){this(new MovementTypeDaoImpl(cf));} }

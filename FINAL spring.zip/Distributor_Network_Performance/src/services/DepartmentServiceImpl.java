package services;
import dao.DepartmentDao;
import dao.DepartmentDaoImpl;
import dto.DepartmentDTO;
import entity.Department;
import jdbc.ConnectionFactory;
public class DepartmentServiceImpl extends AbstractService<Department,DepartmentDTO> implements DepartmentService { public DepartmentServiceImpl(DepartmentDao dao){super(dao,Department.class,DepartmentDTO.class);} public DepartmentServiceImpl(ConnectionFactory cf){this(new DepartmentDaoImpl(cf));} }

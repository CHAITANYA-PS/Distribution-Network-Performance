package services;
import dto.RoleDTO;
public interface RoleService extends GenericService<RoleDTO> {}

package services;
import dao.DistributorDao;
import dao.DistributorDaoImpl;
import dto.DistributorDTO;
import entity.Distributor;
import jdbc.ConnectionFactory;
public class DistributorServiceImpl extends AbstractService<Distributor,DistributorDTO> implements DistributorService { public DistributorServiceImpl(DistributorDao dao){super(dao,Distributor.class,DistributorDTO.class);} public DistributorServiceImpl(ConnectionFactory cf){this(new DistributorDaoImpl(cf));} }

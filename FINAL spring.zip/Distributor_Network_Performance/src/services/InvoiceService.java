package services;
import dto.InvoiceDTO;
public interface InvoiceService extends GenericService<InvoiceDTO> {}

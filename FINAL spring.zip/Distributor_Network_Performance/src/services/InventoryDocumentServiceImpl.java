package services;
import dao.InventoryDocumentDao;
import dao.InventoryDocumentDaoImpl;
import dto.InventoryDocumentDTO;
import entity.InventoryDocument;
import jdbc.ConnectionFactory;
public class InventoryDocumentServiceImpl extends AbstractService<InventoryDocument,InventoryDocumentDTO> implements InventoryDocumentService { public InventoryDocumentServiceImpl(InventoryDocumentDao dao){super(dao,InventoryDocument.class,InventoryDocumentDTO.class);} public InventoryDocumentServiceImpl(ConnectionFactory cf){this(new InventoryDocumentDaoImpl(cf));} }

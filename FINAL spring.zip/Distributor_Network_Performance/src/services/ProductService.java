package services;
import dto.ProductDTO;
public interface ProductService extends GenericService<ProductDTO> {}

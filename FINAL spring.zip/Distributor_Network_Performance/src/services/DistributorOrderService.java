package services;
import dto.DistributorOrderDTO;
public interface DistributorOrderService extends GenericService<DistributorOrderDTO> {}

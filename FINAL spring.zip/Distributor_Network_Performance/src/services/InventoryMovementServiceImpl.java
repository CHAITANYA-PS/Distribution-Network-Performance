package services;
import dao.InventoryMovementDao;
import dao.InventoryMovementDaoImpl;
import dto.InventoryMovementDTO;
import entity.InventoryMovement;
import jdbc.ConnectionFactory;
public class InventoryMovementServiceImpl extends AbstractService<InventoryMovement,InventoryMovementDTO> implements InventoryMovementService { public InventoryMovementServiceImpl(InventoryMovementDao dao){super(dao,InventoryMovement.class,InventoryMovementDTO.class);} public InventoryMovementServiceImpl(ConnectionFactory cf){this(new InventoryMovementDaoImpl(cf));} }

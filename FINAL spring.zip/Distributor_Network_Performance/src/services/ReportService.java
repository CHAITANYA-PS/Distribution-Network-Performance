package services;
import dto.ReportDTO;
public interface ReportService extends GenericService<ReportDTO> {}

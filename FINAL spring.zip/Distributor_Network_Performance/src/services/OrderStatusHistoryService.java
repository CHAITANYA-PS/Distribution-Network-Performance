package services;
import dto.OrderStatusHistoryDTO;
public interface OrderStatusHistoryService extends GenericService<OrderStatusHistoryDTO> {}

package services;
import dao.DistributorActivityDao;
import dao.DistributorActivityDaoImpl;
import dto.DistributorActivityDTO;
import entity.DistributorActivity;
import jdbc.ConnectionFactory;
public class DistributorActivityServiceImpl extends AbstractService<DistributorActivity,DistributorActivityDTO> implements DistributorActivityService { public DistributorActivityServiceImpl(DistributorActivityDao dao){super(dao,DistributorActivity.class,DistributorActivityDTO.class);} public DistributorActivityServiceImpl(ConnectionFactory cf){this(new DistributorActivityDaoImpl(cf));} }

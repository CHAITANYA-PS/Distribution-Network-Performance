package services;
import dao.CommitmentHistoryDao;
import dao.CommitmentHistoryDaoImpl;
import dto.CommitmentHistoryDTO;
import entity.CommitmentHistory;
import jdbc.ConnectionFactory;
public class CommitmentHistoryServiceImpl extends AbstractService<CommitmentHistory,CommitmentHistoryDTO> implements CommitmentHistoryService { public CommitmentHistoryServiceImpl(CommitmentHistoryDao dao){super(dao,CommitmentHistory.class,CommitmentHistoryDTO.class);} public CommitmentHistoryServiceImpl(ConnectionFactory cf){this(new CommitmentHistoryDaoImpl(cf));} }

package services;
import dto.RecoveryPlanDTO;
public interface RecoveryPlanService extends GenericService<RecoveryPlanDTO> {}

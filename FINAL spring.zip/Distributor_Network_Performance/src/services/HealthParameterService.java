package services;
import dto.HealthParameterDTO;
public interface HealthParameterService extends GenericService<HealthParameterDTO> {}

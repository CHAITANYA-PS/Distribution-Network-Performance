package services;
import dto.MeasurementUnitDTO;
public interface MeasurementUnitService extends GenericService<MeasurementUnitDTO> {}

package services;
import dao.ReportDao;
import dao.ReportDaoImpl;
import dto.ReportDTO;
import entity.Report;
import jdbc.ConnectionFactory;
public class ReportServiceImpl extends AbstractService<Report,ReportDTO> implements ReportService { public ReportServiceImpl(ReportDao dao){super(dao,Report.class,ReportDTO.class);} public ReportServiceImpl(ConnectionFactory cf){this(new ReportDaoImpl(cf));} }

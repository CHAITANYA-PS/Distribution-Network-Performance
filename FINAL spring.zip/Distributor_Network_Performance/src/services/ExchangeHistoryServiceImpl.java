package services;
import dao.ExchangeHistoryDao;
import dao.ExchangeHistoryDaoImpl;
import dto.ExchangeHistoryDTO;
import entity.ExchangeHistory;
import jdbc.ConnectionFactory;
public class ExchangeHistoryServiceImpl extends AbstractService<ExchangeHistory,ExchangeHistoryDTO> implements ExchangeHistoryService { public ExchangeHistoryServiceImpl(ExchangeHistoryDao dao){super(dao,ExchangeHistory.class,ExchangeHistoryDTO.class);} public ExchangeHistoryServiceImpl(ConnectionFactory cf){this(new ExchangeHistoryDaoImpl(cf));} }

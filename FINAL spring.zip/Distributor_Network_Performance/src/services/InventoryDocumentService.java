package services;
import dto.InventoryDocumentDTO;
public interface InventoryDocumentService extends GenericService<InventoryDocumentDTO> {}

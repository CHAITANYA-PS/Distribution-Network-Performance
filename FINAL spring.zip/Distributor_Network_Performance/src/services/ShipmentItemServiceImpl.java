package services;
import dao.ShipmentItemDao;
import dao.ShipmentItemDaoImpl;
import dto.ShipmentItemDTO;
import entity.ShipmentItem;
import jdbc.ConnectionFactory;
public class ShipmentItemServiceImpl extends AbstractService<ShipmentItem,ShipmentItemDTO> implements ShipmentItemService { public ShipmentItemServiceImpl(ShipmentItemDao dao){super(dao,ShipmentItem.class,ShipmentItemDTO.class);} public ShipmentItemServiceImpl(ConnectionFactory cf){this(new ShipmentItemDaoImpl(cf));} }

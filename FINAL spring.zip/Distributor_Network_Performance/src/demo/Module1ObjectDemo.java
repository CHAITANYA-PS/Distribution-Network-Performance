package demo;

import java.util.ArrayList;
import java.util.List;

import entity.ActivityType;
import entity.CreditRiskAssessment;
import entity.EmissionFactor;
import entity.InventoryAlert;
import entity.MovementType;
import entity.PaymentStatus;
import entity.ReportFilter;
import entity.Shipment;
import entity.TransportationActivity;

/** Creates default entity objects assigned to logical demo module 1. */
public final class Module1ObjectDemo {
    private Module1ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            ActivityType.class,
            CreditRiskAssessment.class,
            EmissionFactor.class,
            InventoryAlert.class,
            MovementType.class,
            PaymentStatus.class,
            ReportFilter.class,
            Shipment.class,
            TransportationActivity.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 1 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

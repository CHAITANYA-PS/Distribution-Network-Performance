package demo;

import java.util.ArrayList;
import java.util.List;

import entity.CommitmentHistory;
import entity.DistributorCategory;
import entity.ExchangeStatus;
import entity.Invoice;
import entity.OrderStatus;
import entity.RecoveryPlan;
import entity.RiskLevel;
import entity.Ticket;
import entity.VehicleType;

/** Creates default entity objects assigned to logical demo module 5. */
public final class Module5ObjectDemo {
    private Module5ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            CommitmentHistory.class,
            DistributorCategory.class,
            ExchangeStatus.class,
            Invoice.class,
            OrderStatus.class,
            RecoveryPlan.class,
            RiskLevel.class,
            Ticket.class,
            VehicleType.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 5 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

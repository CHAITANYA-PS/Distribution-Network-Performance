package demo;

import java.util.ArrayList;
import java.util.List;

import entity.CommitmentProgress;
import entity.DistributorCreditLimit;
import entity.FinanceManager;
import entity.InvoiceStatus;
import entity.OrderStatusHistory;
import entity.RecoveryPlanStatus;
import entity.Role;
import entity.TicketCategory;
import entity.Warehouse;

/** Creates default entity objects assigned to logical demo module 6. */
public final class Module6ObjectDemo {
    private Module6ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            CommitmentProgress.class,
            DistributorCreditLimit.class,
            FinanceManager.class,
            InvoiceStatus.class,
            OrderStatusHistory.class,
            RecoveryPlanStatus.class,
            Role.class,
            TicketCategory.class,
            Warehouse.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 6 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

package demo;

import java.util.ArrayList;
import java.util.List;

/** Runs all nine model-object demonstrations from one entry point. */
public final class AllModelsObjectDemo {
    private AllModelsObjectDemo() { }

    public static List<Object> createAllObjects() {
        List<Object> allObjects = new ArrayList<>();
        allObjects.addAll(Module1ObjectDemo.createObjects());
        allObjects.addAll(Module2ObjectDemo.createObjects());
        allObjects.addAll(Module3ObjectDemo.createObjects());
        allObjects.addAll(Module4ObjectDemo.createObjects());
        allObjects.addAll(Module5ObjectDemo.createObjects());
        allObjects.addAll(Module6ObjectDemo.createObjects());
        allObjects.addAll(Module7ObjectDemo.createObjects());
        allObjects.addAll(Module8ObjectDemo.createObjects());
        allObjects.addAll(Module9ObjectDemo.createObjects());
        return allObjects;
    }

    public static void main(String[] args) {
        Module1ObjectDemo.runDemo();
        Module2ObjectDemo.runDemo();
        Module3ObjectDemo.runDemo();
        Module4ObjectDemo.runDemo();
        Module5ObjectDemo.runDemo();
        Module6ObjectDemo.runDemo();
        Module7ObjectDemo.runDemo();
        Module8ObjectDemo.runDemo();
        Module9ObjectDemo.runDemo();
        System.out.println("All model objects created: " + createAllObjects().size());
    }
}

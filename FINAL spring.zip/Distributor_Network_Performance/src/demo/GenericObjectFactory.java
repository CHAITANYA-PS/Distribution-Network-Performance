package demo;

import java.lang.reflect.Constructor;

/** Creates model objects through their no-argument constructors for demos. */
public final class GenericObjectFactory {
    private GenericObjectFactory() { }

    public static <T> T createDefaultObject(Class<T> objectType) {
        if (objectType == null) {
            throw new IllegalArgumentException("Object type cannot be null");
        }
        try {
            Constructor<T> constructor = objectType.getDeclaredConstructor();
            constructor.setAccessible(true);
            return constructor.newInstance();
        } catch (ReflectiveOperationException exception) {
            throw new IllegalStateException(
                    "Unable to create default object for " + objectType.getName(),
                    exception);
        }
    }
}

package demo;

import java.util.ArrayList;
import java.util.List;

import entity.Commitment;
import entity.DistributorActivity;
import entity.ExchangeRequest;
import entity.InventoryMovement;
import entity.OrderItem;
import entity.RecoveryManager;
import entity.RiskBand;
import entity.SystemAdmin;
import entity.UserSession;

/** Creates default entity objects assigned to logical demo module 4. */
public final class Module4ObjectDemo {
    private Module4ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            Commitment.class,
            DistributorActivity.class,
            ExchangeRequest.class,
            InventoryMovement.class,
            OrderItem.class,
            RecoveryManager.class,
            RiskBand.class,
            SystemAdmin.class,
            UserSession.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 4 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

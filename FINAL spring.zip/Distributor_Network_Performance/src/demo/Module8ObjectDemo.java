package demo;

import java.util.ArrayList;
import java.util.List;

import entity.ContinuityAssessment;
import entity.DistributorOrder;
import entity.HealthParameter;
import entity.ManufacturerUser;
import entity.Payment;
import entity.Region;
import entity.SalesRecord;
import entity.TicketPriority;

/** Creates default entity objects assigned to logical demo module 8. */
public final class Module8ObjectDemo {
    private Module8ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            ContinuityAssessment.class,
            DistributorOrder.class,
            HealthParameter.class,
            ManufacturerUser.class,
            Payment.class,
            Region.class,
            SalesRecord.class,
            TicketPriority.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 8 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

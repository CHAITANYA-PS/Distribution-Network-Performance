package demo;

import java.util.ArrayList;
import java.util.List;

import entity.ContinuityStatusType;
import entity.DistributorUser;
import entity.HealthParameterWeight;
import entity.MeasurementUnit;
import entity.PaymentMethod;
import entity.Report;
import entity.SalesTarget;
import entity.TicketStatus;

/** Creates default entity objects assigned to logical demo module 9. */
public final class Module9ObjectDemo {
    private Module9ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            ContinuityStatusType.class,
            DistributorUser.class,
            HealthParameterWeight.class,
            MeasurementUnit.class,
            PaymentMethod.class,
            Report.class,
            SalesTarget.class,
            TicketStatus.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 9 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

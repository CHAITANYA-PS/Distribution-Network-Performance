package demo;

import java.util.ArrayList;
import java.util.List;

import entity.CommitmentStatus;
import entity.DistributorHealthAssessment;
import entity.HealthAssessmentAlert;
import entity.Manufacturer;
import entity.PasswordReset;
import entity.RecoveryPlanTicket;
import entity.SalesManager;
import entity.TicketComment;
import entity.WarehouseStock;

/** Creates default entity objects assigned to logical demo module 7. */
public final class Module7ObjectDemo {
    private Module7ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            CommitmentStatus.class,
            DistributorHealthAssessment.class,
            HealthAssessmentAlert.class,
            Manufacturer.class,
            PasswordReset.class,
            RecoveryPlanTicket.class,
            SalesManager.class,
            TicketComment.class,
            WarehouseStock.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 7 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

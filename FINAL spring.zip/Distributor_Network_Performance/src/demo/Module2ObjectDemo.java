package demo;

import java.util.ArrayList;
import java.util.List;

import entity.AppUser;
import entity.Department;
import entity.Escalation;
import entity.InventoryDocument;
import entity.Notification;
import entity.Product;
import entity.ReportFilterValue;
import entity.ShipmentItem;
import entity.UserActivityLog;

/** Creates default entity objects assigned to logical demo module 2. */
public final class Module2ObjectDemo {
    private Module2ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            AppUser.class,
            Department.class,
            Escalation.class,
            InventoryDocument.class,
            Notification.class,
            Product.class,
            ReportFilterValue.class,
            ShipmentItem.class,
            UserActivityLog.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 2 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

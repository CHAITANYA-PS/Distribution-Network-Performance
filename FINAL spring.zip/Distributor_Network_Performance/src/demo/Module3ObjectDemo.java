package demo;

import java.util.ArrayList;
import java.util.List;

import entity.Category;
import entity.Distributor;
import entity.ExchangeHistory;
import entity.InventoryDocumentType;
import entity.NotificationType;
import entity.ProductBatch;
import entity.ReportingPeriod;
import entity.ShipmentStatus;
import entity.UserRole;

/** Creates default entity objects assigned to logical demo module 3. */
public final class Module3ObjectDemo {
    private Module3ObjectDemo() { }

    public static List<Object> createObjects() {
        List<Object> moduleObjects = new ArrayList<>();
        Class<?>[] entityTypes = {
            Category.class,
            Distributor.class,
            ExchangeHistory.class,
            InventoryDocumentType.class,
            NotificationType.class,
            ProductBatch.class,
            ReportingPeriod.class,
            ShipmentStatus.class,
            UserRole.class
        };
        for (Class<?> entityType : entityTypes) {
            moduleObjects.add(GenericObjectFactory.createDefaultObject(entityType));
        }
        return moduleObjects;
    }

    public static void runDemo() {
        List<Object> objects = createObjects();
        System.out.println("Module 3 objects created: " + objects.size());
    }

    public static void main(String[] args) {
        runDemo();
    }
}

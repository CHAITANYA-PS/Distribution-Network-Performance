package dao;import entity.DistributorUser;
import jdbc.ConnectionFactory;public class DistributorUserDaoImpl extends JdbcGenericDao<DistributorUser> implements DistributorUserDao{public DistributorUserDaoImpl(ConnectionFactory cf){super(cf,DistributorUser.class,"dsphere","distributor_user","user_id");}}

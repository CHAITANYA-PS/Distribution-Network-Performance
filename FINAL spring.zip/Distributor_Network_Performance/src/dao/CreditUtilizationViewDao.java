package dao;import entity.CreditUtilizationView;public interface CreditUtilizationViewDao extends ReadOnlyDao<CreditUtilizationView>{}

package dao;import entity.FinanceManager;
import jdbc.ConnectionFactory;public class FinanceManagerDaoImpl extends JdbcGenericDao<FinanceManager> implements FinanceManagerDao{public FinanceManagerDaoImpl(ConnectionFactory cf){super(cf,FinanceManager.class,"dsphere","finance_manager","user_id");}}

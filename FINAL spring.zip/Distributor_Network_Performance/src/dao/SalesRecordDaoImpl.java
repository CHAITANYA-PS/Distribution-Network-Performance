package dao;import entity.SalesRecord;
import jdbc.ConnectionFactory;public class SalesRecordDaoImpl extends JdbcGenericDao<SalesRecord> implements SalesRecordDao{public SalesRecordDaoImpl(ConnectionFactory cf){super(cf,SalesRecord.class,"dsphere","sales_record","sales_record_id");}}

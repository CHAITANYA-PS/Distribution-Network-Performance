package dao;import entity.DistributorOrder;
import jdbc.ConnectionFactory;public class DistributorOrderDaoImpl extends JdbcGenericDao<DistributorOrder> implements DistributorOrderDao{public DistributorOrderDaoImpl(ConnectionFactory cf){super(cf,DistributorOrder.class,"dsphere","distributor_order","order_id");}}

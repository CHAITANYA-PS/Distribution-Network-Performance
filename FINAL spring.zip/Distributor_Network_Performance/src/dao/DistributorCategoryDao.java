package dao;import entity.DistributorCategory;public interface DistributorCategoryDao extends GenericDao<DistributorCategory,Long>{}

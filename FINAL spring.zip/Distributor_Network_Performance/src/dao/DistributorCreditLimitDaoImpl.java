package dao;import entity.DistributorCreditLimit;
import jdbc.ConnectionFactory;public class DistributorCreditLimitDaoImpl extends JdbcGenericDao<DistributorCreditLimit> implements DistributorCreditLimitDao{public DistributorCreditLimitDaoImpl(ConnectionFactory cf){super(cf,DistributorCreditLimit.class,"dsphere","distributor_credit_limit","credit_limit_id");}}

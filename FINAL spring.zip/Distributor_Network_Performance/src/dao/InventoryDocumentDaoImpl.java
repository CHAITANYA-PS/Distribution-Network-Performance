package dao;import entity.InventoryDocument;
import jdbc.ConnectionFactory;public class InventoryDocumentDaoImpl extends JdbcGenericDao<InventoryDocument> implements InventoryDocumentDao{public InventoryDocumentDaoImpl(ConnectionFactory cf){super(cf,InventoryDocument.class,"dsphere","inventory_document","inventory_document_id");}}

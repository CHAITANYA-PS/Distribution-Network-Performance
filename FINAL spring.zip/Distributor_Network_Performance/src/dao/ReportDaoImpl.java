package dao;import entity.Report;
import jdbc.ConnectionFactory;public class ReportDaoImpl extends JdbcGenericDao<Report> implements ReportDao{public ReportDaoImpl(ConnectionFactory cf){super(cf,Report.class,"dsphere","report","report_id");}}

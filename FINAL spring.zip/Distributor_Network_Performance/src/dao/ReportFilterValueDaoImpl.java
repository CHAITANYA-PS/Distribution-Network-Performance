package dao;import entity.ReportFilterValue;
import jdbc.ConnectionFactory;public class ReportFilterValueDaoImpl extends JdbcGenericDao<ReportFilterValue> implements ReportFilterValueDao{public ReportFilterValueDaoImpl(ConnectionFactory cf){super(cf,ReportFilterValue.class,"dsphere","report_filter_value","report_filter_value_id");}}

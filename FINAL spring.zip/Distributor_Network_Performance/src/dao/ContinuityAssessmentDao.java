package dao;import entity.ContinuityAssessment;public interface ContinuityAssessmentDao extends GenericDao<ContinuityAssessment,Long>{}

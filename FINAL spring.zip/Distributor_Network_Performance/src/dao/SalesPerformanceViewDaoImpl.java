package dao;import entity.SalesPerformanceView;
import jdbc.ConnectionFactory;public class SalesPerformanceViewDaoImpl extends JdbcReadOnlyDao<SalesPerformanceView> implements SalesPerformanceViewDao{public SalesPerformanceViewDaoImpl(ConnectionFactory cf){super(cf,SalesPerformanceView.class,"dsphere","sales_performance_view");}}

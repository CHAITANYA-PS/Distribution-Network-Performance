package dao;import entity.DistributorCategory;
import jdbc.ConnectionFactory;public class DistributorCategoryDaoImpl extends JdbcGenericDao<DistributorCategory> implements DistributorCategoryDao{public DistributorCategoryDaoImpl(ConnectionFactory cf){super(cf,DistributorCategory.class,"dsphere","distributor_category","distributor_category_id");}}

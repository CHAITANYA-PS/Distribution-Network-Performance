package dao;import entity.ShipmentItem;public interface ShipmentItemDao extends GenericDao<ShipmentItem,Long>{}

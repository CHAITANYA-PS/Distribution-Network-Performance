package dao;import entity.WarehouseStock;
import jdbc.ConnectionFactory;public class WarehouseStockDaoImpl extends JdbcGenericDao<WarehouseStock> implements WarehouseStockDao{public WarehouseStockDaoImpl(ConnectionFactory cf){super(cf,WarehouseStock.class,"dsphere","warehouse_stock","warehouse_stock_id");}}

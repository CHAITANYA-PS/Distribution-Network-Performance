package dao;import entity.TransportationActivity;public interface TransportationActivityDao extends GenericDao<TransportationActivity,Long>{}

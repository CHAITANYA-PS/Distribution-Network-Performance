package dao;import entity.RecoveryPlanStatus;public interface RecoveryPlanStatusDao extends GenericDao<RecoveryPlanStatus,Long>{}

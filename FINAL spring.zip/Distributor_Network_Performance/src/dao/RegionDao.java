package dao;import entity.Region;public interface RegionDao extends GenericDao<Region,Long>{}

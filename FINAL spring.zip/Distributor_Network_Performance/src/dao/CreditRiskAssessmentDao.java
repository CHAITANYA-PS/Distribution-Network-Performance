package dao;import entity.CreditRiskAssessment;public interface CreditRiskAssessmentDao extends GenericDao<CreditRiskAssessment,Long>{}

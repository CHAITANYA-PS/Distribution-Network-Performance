package dao;import entity.HealthScoreView;
import jdbc.ConnectionFactory;public class HealthScoreViewDaoImpl extends JdbcReadOnlyDao<HealthScoreView> implements HealthScoreViewDao{public HealthScoreViewDaoImpl(ConnectionFactory cf){super(cf,HealthScoreView.class,"dsphere","health_score_view");}}

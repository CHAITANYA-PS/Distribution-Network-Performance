package dao;import entity.InventoryAlert;
import jdbc.ConnectionFactory;public class InventoryAlertDaoImpl extends JdbcGenericDao<InventoryAlert> implements InventoryAlertDao{public InventoryAlertDaoImpl(ConnectionFactory cf){super(cf,InventoryAlert.class,"dsphere","inventory_alert","alert_id");}}

package dao;import entity.EmissionFactor;
import jdbc.ConnectionFactory;public class EmissionFactorDaoImpl extends JdbcGenericDao<EmissionFactor> implements EmissionFactorDao{public EmissionFactorDaoImpl(ConnectionFactory cf){super(cf,EmissionFactor.class,"dsphere","emission_factor","emission_factor_id");}}

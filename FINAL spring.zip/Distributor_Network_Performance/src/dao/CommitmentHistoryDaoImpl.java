package dao;import entity.CommitmentHistory;
import jdbc.ConnectionFactory;public class CommitmentHistoryDaoImpl extends JdbcGenericDao<CommitmentHistory> implements CommitmentHistoryDao{public CommitmentHistoryDaoImpl(ConnectionFactory cf){super(cf,CommitmentHistory.class,"dsphere","commitment_history","history_id");}}

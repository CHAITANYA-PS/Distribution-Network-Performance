package dao;import entity.Shipment;
import jdbc.ConnectionFactory;public class ShipmentDaoImpl extends JdbcGenericDao<Shipment> implements ShipmentDao{public ShipmentDaoImpl(ConnectionFactory cf){super(cf,Shipment.class,"dsphere","shipment","shipment_id");}}

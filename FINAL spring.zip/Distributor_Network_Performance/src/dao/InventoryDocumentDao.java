package dao;import entity.InventoryDocument;public interface InventoryDocumentDao extends GenericDao<InventoryDocument,Long>{}

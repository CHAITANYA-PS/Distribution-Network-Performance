package dao;import entity.RecoveryManager;
import jdbc.ConnectionFactory;public class RecoveryManagerDaoImpl extends JdbcGenericDao<RecoveryManager> implements RecoveryManagerDao{public RecoveryManagerDaoImpl(ConnectionFactory cf){super(cf,RecoveryManager.class,"dsphere","recovery_manager","user_id");}}

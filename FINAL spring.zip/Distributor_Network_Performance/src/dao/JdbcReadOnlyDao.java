package dao;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import dao.exception.DaoException;
import jdbc.ConnectionFactory;
public class JdbcReadOnlyDao<T> implements ReadOnlyDao<T>{private final ConnectionFactory cf;private final Class<T> type;private final String full;private final Map<String,Field> fields;
 public JdbcReadOnlyDao(ConnectionFactory cf,Class<T> type,String schema,String view){this.cf=cf;this.type=type;this.full=schema+"."+view;this.fields=ReflectionMapper.byColumn(type);}
 @Override
public List<T> findAll(){try(Connection c=cf.getConnection();PreparedStatement ps=c.prepareStatement("SELECT * FROM "+full);ResultSet rs=ps.executeQuery()){List<T> r=new ArrayList<>();while(rs.next())r.add(ReflectionMapper.map(rs,type,fields));return r;}catch(SQLException e){throw new DaoException("Failed to read "+type.getSimpleName(),e);}}
 @Override
public List<T> filter(Predicate<T> p){if(p==null)throw new DaoException("Predicate cannot be null");return findAll().stream().filter(p).collect(Collectors.toList());}}

package dao;import entity.SalesManager;public interface SalesManagerDao extends GenericDao<SalesManager,Long>{}

package dao;import entity.CreditRiskAssessment;
import jdbc.ConnectionFactory;public class CreditRiskAssessmentDaoImpl extends JdbcGenericDao<CreditRiskAssessment> implements CreditRiskAssessmentDao{public CreditRiskAssessmentDaoImpl(ConnectionFactory cf){super(cf,CreditRiskAssessment.class,"dsphere","credit_risk_assessment","risk_assessment_id");}}

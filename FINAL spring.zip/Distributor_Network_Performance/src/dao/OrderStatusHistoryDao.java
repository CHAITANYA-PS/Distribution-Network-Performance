package dao;import entity.OrderStatusHistory;public interface OrderStatusHistoryDao extends GenericDao<OrderStatusHistory,Long>{}

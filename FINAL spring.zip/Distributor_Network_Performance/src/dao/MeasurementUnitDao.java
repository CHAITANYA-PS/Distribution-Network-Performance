package dao;import entity.MeasurementUnit;public interface MeasurementUnitDao extends GenericDao<MeasurementUnit,Long>{}

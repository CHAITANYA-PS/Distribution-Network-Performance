package dao;import entity.PaymentStatus;
import jdbc.ConnectionFactory;public class PaymentStatusDaoImpl extends JdbcGenericDao<PaymentStatus> implements PaymentStatusDao{public PaymentStatusDaoImpl(ConnectionFactory cf){super(cf,PaymentStatus.class,"dsphere","payment_status","payment_status_id");}}

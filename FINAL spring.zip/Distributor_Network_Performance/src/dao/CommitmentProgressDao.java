package dao;import entity.CommitmentProgress;public interface CommitmentProgressDao extends GenericDao<CommitmentProgress,Long>{}

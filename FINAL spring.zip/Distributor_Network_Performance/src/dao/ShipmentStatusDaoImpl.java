package dao;import entity.ShipmentStatus;
import jdbc.ConnectionFactory;public class ShipmentStatusDaoImpl extends JdbcGenericDao<ShipmentStatus> implements ShipmentStatusDao{public ShipmentStatusDaoImpl(ConnectionFactory cf){super(cf,ShipmentStatus.class,"dsphere","shipment_status","shipment_status_id");}}

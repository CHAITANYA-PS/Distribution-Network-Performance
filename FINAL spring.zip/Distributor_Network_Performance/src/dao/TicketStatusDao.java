package dao;import entity.TicketStatus;public interface TicketStatusDao extends GenericDao<TicketStatus,Long>{}

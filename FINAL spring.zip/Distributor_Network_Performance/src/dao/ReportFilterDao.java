package dao;import entity.ReportFilter;public interface ReportFilterDao extends GenericDao<ReportFilter,Long>{}

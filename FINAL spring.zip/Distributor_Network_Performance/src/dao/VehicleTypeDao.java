package dao;import entity.VehicleType;public interface VehicleTypeDao extends GenericDao<VehicleType,Long>{}

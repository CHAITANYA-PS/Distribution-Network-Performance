package dao;import entity.RecoveryPlan;
import jdbc.ConnectionFactory;public class RecoveryPlanDaoImpl extends JdbcGenericDao<RecoveryPlan> implements RecoveryPlanDao{public RecoveryPlanDaoImpl(ConnectionFactory cf){super(cf,RecoveryPlan.class,"dsphere","recovery_plan","recovery_plan_id");}}

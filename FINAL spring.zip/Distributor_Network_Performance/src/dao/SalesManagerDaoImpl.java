package dao;import entity.SalesManager;
import jdbc.ConnectionFactory;public class SalesManagerDaoImpl extends JdbcGenericDao<SalesManager> implements SalesManagerDao{public SalesManagerDaoImpl(ConnectionFactory cf){super(cf,SalesManager.class,"dsphere","sales_manager","user_id");}}

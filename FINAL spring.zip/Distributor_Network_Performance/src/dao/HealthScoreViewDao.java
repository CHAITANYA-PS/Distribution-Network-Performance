package dao;import entity.HealthScoreView;public interface HealthScoreViewDao extends ReadOnlyDao<HealthScoreView>{}

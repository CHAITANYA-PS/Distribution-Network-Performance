package dao;import entity.Product;
import jdbc.ConnectionFactory;public class ProductDaoImpl extends JdbcGenericDao<Product> implements ProductDao{public ProductDaoImpl(ConnectionFactory cf){super(cf,Product.class,"dsphere","product","product_id");}}

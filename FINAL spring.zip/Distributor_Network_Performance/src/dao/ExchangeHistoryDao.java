package dao;import entity.ExchangeHistory;public interface ExchangeHistoryDao extends GenericDao<ExchangeHistory,Long>{}

package dao;import entity.Distributor;public interface DistributorDao extends GenericDao<Distributor,Long>{}

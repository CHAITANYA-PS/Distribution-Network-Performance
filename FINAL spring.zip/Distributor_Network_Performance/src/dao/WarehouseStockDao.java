package dao;import entity.WarehouseStock;public interface WarehouseStockDao extends GenericDao<WarehouseStock,Long>{}

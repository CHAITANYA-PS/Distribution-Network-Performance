package dao;import entity.Report;public interface ReportDao extends GenericDao<Report,Long>{}

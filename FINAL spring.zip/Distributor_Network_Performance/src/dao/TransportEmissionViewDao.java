package dao;

import entity.TransportEmissionView;

public interface TransportEmissionViewDao extends ReadOnlyDao<TransportEmissionView> {
}

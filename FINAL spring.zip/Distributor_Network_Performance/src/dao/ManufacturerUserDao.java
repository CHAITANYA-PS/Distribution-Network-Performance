package dao;import entity.ManufacturerUser;public interface ManufacturerUserDao extends GenericDao<ManufacturerUser,Long>{}

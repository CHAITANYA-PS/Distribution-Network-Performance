package dao;import entity.ContinuityAssessment;
import jdbc.ConnectionFactory;public class ContinuityAssessmentDaoImpl extends JdbcGenericDao<ContinuityAssessment> implements ContinuityAssessmentDao{public ContinuityAssessmentDaoImpl(ConnectionFactory cf){super(cf,ContinuityAssessment.class,"dsphere","continuity_assessment","continuity_assessment_id");}}

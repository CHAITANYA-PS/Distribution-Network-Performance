package dao;import entity.ExchangeStatus;public interface ExchangeStatusDao extends GenericDao<ExchangeStatus,Long>{}

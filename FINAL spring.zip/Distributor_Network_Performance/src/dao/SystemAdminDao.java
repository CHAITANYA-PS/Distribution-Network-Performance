package dao;import entity.SystemAdmin;public interface SystemAdminDao extends GenericDao<SystemAdmin,Long>{}

package dao;import entity.PasswordReset;
import jdbc.ConnectionFactory;public class PasswordResetDaoImpl extends JdbcGenericDao<PasswordReset> implements PasswordResetDao{public PasswordResetDaoImpl(ConnectionFactory cf){super(cf,PasswordReset.class,"dsphere","password_reset","reset_id");}}

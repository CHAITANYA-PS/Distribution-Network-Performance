package dao;import entity.ReportingPeriod;
import jdbc.ConnectionFactory;public class ReportingPeriodDaoImpl extends JdbcGenericDao<ReportingPeriod> implements ReportingPeriodDao{public ReportingPeriodDaoImpl(ConnectionFactory cf){super(cf,ReportingPeriod.class,"dsphere","reporting_period","reporting_period_id");}}

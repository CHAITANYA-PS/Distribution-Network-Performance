package dao;import entity.DistributorUser;public interface DistributorUserDao extends GenericDao<DistributorUser,Long>{}

package dao;import entity.UserActivityLog;public interface UserActivityLogDao extends GenericDao<UserActivityLog,Long>{}

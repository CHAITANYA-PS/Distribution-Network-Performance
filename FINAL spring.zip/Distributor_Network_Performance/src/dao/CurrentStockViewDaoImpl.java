package dao;import entity.CurrentStockView;
import jdbc.ConnectionFactory;public class CurrentStockViewDaoImpl extends JdbcReadOnlyDao<CurrentStockView> implements CurrentStockViewDao{public CurrentStockViewDaoImpl(ConnectionFactory cf){super(cf,CurrentStockView.class,"dsphere","current_stock_view");}}

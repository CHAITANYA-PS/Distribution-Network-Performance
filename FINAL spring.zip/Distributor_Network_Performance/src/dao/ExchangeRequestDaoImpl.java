package dao;import entity.ExchangeRequest;
import jdbc.ConnectionFactory;public class ExchangeRequestDaoImpl extends JdbcGenericDao<ExchangeRequest> implements ExchangeRequestDao{public ExchangeRequestDaoImpl(ConnectionFactory cf){super(cf,ExchangeRequest.class,"dsphere","exchange_request","exchange_id");}}

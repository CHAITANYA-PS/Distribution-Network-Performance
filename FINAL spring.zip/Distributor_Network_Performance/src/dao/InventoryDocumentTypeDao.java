package dao;import entity.InventoryDocumentType;public interface InventoryDocumentTypeDao extends GenericDao<InventoryDocumentType,Long>{}

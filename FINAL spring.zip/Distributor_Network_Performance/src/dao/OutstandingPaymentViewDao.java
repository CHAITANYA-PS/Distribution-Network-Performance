package dao;import entity.OutstandingPaymentView;public interface OutstandingPaymentViewDao extends ReadOnlyDao<OutstandingPaymentView>{}

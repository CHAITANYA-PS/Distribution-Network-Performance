package dao;import entity.RecoveryPlanTicket;
import jdbc.ConnectionFactory;public class RecoveryPlanTicketDaoImpl extends JdbcGenericDao<RecoveryPlanTicket> implements RecoveryPlanTicketDao{public RecoveryPlanTicketDaoImpl(ConnectionFactory cf){super(cf,RecoveryPlanTicket.class,"dsphere","recovery_plan_ticket","recovery_plan_ticket_id");}}

package dao;import entity.TicketComment;
import jdbc.ConnectionFactory;public class TicketCommentDaoImpl extends JdbcGenericDao<TicketComment> implements TicketCommentDao{public TicketCommentDaoImpl(ConnectionFactory cf){super(cf,TicketComment.class,"dsphere","ticket_comment","comment_id");}}

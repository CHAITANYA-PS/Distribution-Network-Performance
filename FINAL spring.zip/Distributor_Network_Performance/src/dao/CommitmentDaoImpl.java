package dao;import entity.Commitment;
import jdbc.ConnectionFactory;public class CommitmentDaoImpl extends JdbcGenericDao<Commitment> implements CommitmentDao{public CommitmentDaoImpl(ConnectionFactory cf){super(cf,Commitment.class,"dsphere","commitment","commitment_id");}}

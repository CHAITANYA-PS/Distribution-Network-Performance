package dao;import entity.HealthParameter;public interface HealthParameterDao extends GenericDao<HealthParameter,Long>{}

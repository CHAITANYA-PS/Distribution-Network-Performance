package dao;import entity.CommitmentStatus;public interface CommitmentStatusDao extends GenericDao<CommitmentStatus,Long>{}

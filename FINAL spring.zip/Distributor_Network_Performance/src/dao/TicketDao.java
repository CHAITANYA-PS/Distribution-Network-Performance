package dao;import entity.Ticket;public interface TicketDao extends GenericDao<Ticket,Long>{}

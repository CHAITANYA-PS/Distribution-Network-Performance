package dao;import entity.Invoice;
import jdbc.ConnectionFactory;public class InvoiceDaoImpl extends JdbcGenericDao<Invoice> implements InvoiceDao{public InvoiceDaoImpl(ConnectionFactory cf){super(cf,Invoice.class,"dsphere","invoice","invoice_id");}}

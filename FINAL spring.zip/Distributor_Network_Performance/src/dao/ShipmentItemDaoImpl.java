package dao;import entity.ShipmentItem;
import jdbc.ConnectionFactory;public class ShipmentItemDaoImpl extends JdbcGenericDao<ShipmentItem> implements ShipmentItemDao{public ShipmentItemDaoImpl(ConnectionFactory cf){super(cf,ShipmentItem.class,"dsphere","shipment_item","shipment_item_id");}}

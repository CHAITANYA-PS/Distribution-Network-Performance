package dao;import entity.RecoveryManager;public interface RecoveryManagerDao extends GenericDao<RecoveryManager,Long>{}

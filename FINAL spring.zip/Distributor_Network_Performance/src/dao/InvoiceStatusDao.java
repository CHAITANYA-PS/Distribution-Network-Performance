package dao;import entity.InvoiceStatus;public interface InvoiceStatusDao extends GenericDao<InvoiceStatus,Long>{}

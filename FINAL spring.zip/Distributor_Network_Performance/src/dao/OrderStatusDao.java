package dao;import entity.OrderStatus;public interface OrderStatusDao extends GenericDao<OrderStatus,Long>{}

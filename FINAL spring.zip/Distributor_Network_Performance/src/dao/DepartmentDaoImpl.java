package dao;import entity.Department;
import jdbc.ConnectionFactory;public class DepartmentDaoImpl extends JdbcGenericDao<Department> implements DepartmentDao{public DepartmentDaoImpl(ConnectionFactory cf){super(cf,Department.class,"dsphere","department","department_id");}}

package dao;import entity.TransportationActivity;
import jdbc.ConnectionFactory;public class TransportationActivityDaoImpl extends JdbcGenericDao<TransportationActivity> implements TransportationActivityDao{public TransportationActivityDaoImpl(ConnectionFactory cf){super(cf,TransportationActivity.class,"dsphere","transportation_activity","transportation_activity_id");}}

package dao;import entity.OrderItem;
import jdbc.ConnectionFactory;public class OrderItemDaoImpl extends JdbcGenericDao<OrderItem> implements OrderItemDao{public OrderItemDaoImpl(ConnectionFactory cf){super(cf,OrderItem.class,"dsphere","order_item","order_item_id");}}

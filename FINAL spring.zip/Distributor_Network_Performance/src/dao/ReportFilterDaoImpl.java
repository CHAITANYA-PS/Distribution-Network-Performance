package dao;import entity.ReportFilter;
import jdbc.ConnectionFactory;public class ReportFilterDaoImpl extends JdbcGenericDao<ReportFilter> implements ReportFilterDao{public ReportFilterDaoImpl(ConnectionFactory cf){super(cf,ReportFilter.class,"dsphere","report_filter","report_filter_id");}}

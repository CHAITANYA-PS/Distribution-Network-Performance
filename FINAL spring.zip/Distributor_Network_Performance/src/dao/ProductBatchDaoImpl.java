package dao;import entity.ProductBatch;
import jdbc.ConnectionFactory;public class ProductBatchDaoImpl extends JdbcGenericDao<ProductBatch> implements ProductBatchDao{public ProductBatchDaoImpl(ConnectionFactory cf){super(cf,ProductBatch.class,"dsphere","product_batch","product_batch_id");}}

package dao;import entity.PaymentMethod;public interface PaymentMethodDao extends GenericDao<PaymentMethod,Long>{}

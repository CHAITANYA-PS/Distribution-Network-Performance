package dao;import entity.UserRole;
import jdbc.ConnectionFactory;public class UserRoleDaoImpl extends JdbcGenericDao<UserRole> implements UserRoleDao{public UserRoleDaoImpl(ConnectionFactory cf){super(cf,UserRole.class,"dsphere","user_role","user_role_id");}}

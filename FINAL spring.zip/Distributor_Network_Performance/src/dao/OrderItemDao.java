package dao;import entity.OrderItem;public interface OrderItemDao extends GenericDao<OrderItem,Long>{}

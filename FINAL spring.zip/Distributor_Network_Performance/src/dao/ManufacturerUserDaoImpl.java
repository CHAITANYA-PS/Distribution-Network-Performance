package dao;import entity.ManufacturerUser;
import jdbc.ConnectionFactory;public class ManufacturerUserDaoImpl extends JdbcGenericDao<ManufacturerUser> implements ManufacturerUserDao{public ManufacturerUserDaoImpl(ConnectionFactory cf){super(cf,ManufacturerUser.class,"dsphere","manufacturer_user","user_id");}}

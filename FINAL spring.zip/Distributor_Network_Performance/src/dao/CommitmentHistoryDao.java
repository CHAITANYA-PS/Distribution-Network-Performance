package dao;import entity.CommitmentHistory;public interface CommitmentHistoryDao extends GenericDao<CommitmentHistory,Long>{}

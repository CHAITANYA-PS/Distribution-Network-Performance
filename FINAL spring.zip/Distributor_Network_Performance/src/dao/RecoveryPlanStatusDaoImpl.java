package dao;import entity.RecoveryPlanStatus;
import jdbc.ConnectionFactory;public class RecoveryPlanStatusDaoImpl extends JdbcGenericDao<RecoveryPlanStatus> implements RecoveryPlanStatusDao{public RecoveryPlanStatusDaoImpl(ConnectionFactory cf){super(cf,RecoveryPlanStatus.class,"dsphere","recovery_plan_status","recovery_status_id");}}

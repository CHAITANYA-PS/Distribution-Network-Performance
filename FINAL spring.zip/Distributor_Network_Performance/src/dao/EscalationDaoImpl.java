package dao;import entity.Escalation;
import jdbc.ConnectionFactory;public class EscalationDaoImpl extends JdbcGenericDao<Escalation> implements EscalationDao{public EscalationDaoImpl(ConnectionFactory cf){super(cf,Escalation.class,"dsphere","escalation","escalation_id");}}

package dao;import entity.ReportingPeriod;public interface ReportingPeriodDao extends GenericDao<ReportingPeriod,Long>{}

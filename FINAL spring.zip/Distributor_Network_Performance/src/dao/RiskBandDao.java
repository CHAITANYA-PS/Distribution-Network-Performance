package dao;import entity.RiskBand;public interface RiskBandDao extends GenericDao<RiskBand,Long>{}

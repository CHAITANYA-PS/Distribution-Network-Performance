package dao;

import entity.TransportEmissionView;
import jdbc.ConnectionFactory;

public class TransportEmissionViewDaoImpl extends JdbcReadOnlyDao<TransportEmissionView>
		implements TransportEmissionViewDao {
	public TransportEmissionViewDaoImpl(ConnectionFactory cf) {
		super(cf, TransportEmissionView.class, "dsphere", "transport_emission_view");
	}
}

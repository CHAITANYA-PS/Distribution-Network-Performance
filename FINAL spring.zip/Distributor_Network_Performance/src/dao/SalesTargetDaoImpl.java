package dao;import entity.SalesTarget;
import jdbc.ConnectionFactory;public class SalesTargetDaoImpl extends JdbcGenericDao<SalesTarget> implements SalesTargetDao{public SalesTargetDaoImpl(ConnectionFactory cf){super(cf,SalesTarget.class,"dsphere","sales_target","target_id");}}

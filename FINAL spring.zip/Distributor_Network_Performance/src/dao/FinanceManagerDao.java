package dao;import entity.FinanceManager;public interface FinanceManagerDao extends GenericDao<FinanceManager,Long>{}

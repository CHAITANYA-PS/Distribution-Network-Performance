package dao;import entity.InventoryMovement;public interface InventoryMovementDao extends GenericDao<InventoryMovement,Long>{}

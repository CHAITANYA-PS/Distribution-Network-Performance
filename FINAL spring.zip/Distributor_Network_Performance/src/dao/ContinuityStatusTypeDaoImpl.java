package dao;import entity.ContinuityStatusType;
import jdbc.ConnectionFactory;public class ContinuityStatusTypeDaoImpl extends JdbcGenericDao<ContinuityStatusType> implements ContinuityStatusTypeDao{public ContinuityStatusTypeDaoImpl(ConnectionFactory cf){super(cf,ContinuityStatusType.class,"dsphere","continuity_status_type","continuity_status_id");}}

package dao;import entity.Warehouse;public interface WarehouseDao extends GenericDao<Warehouse,Long>{}

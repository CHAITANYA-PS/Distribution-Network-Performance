package dao;
import java.lang.reflect.Field;
import java.lang.reflect.Modifier;
import java.sql.ResultSet;
import java.sql.Timestamp;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.ZoneOffset;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

import dao.exception.DaoException;
public final class ReflectionMapper{
 private ReflectionMapper(){}
 public static String snake(String s){return s.replaceAll("([a-z0-9])([A-Z])","$1_$2").toLowerCase(Locale.ROOT);}
 public static List<Field> fields(Class<?> type){List<Field> r=new ArrayList<>();for(Class<?> c=type;c!=null&&c!=Object.class;c=c.getSuperclass())r.addAll(Arrays.asList(c.getDeclaredFields()));return r.stream().filter(f->!Modifier.isStatic(f.getModifiers())).collect(Collectors.toList());}
 public static Object get(Field f,Object o){try{f.setAccessible(true);return f.get(o);}catch(Exception e){throw new DaoException("Cannot read "+f.getName(),e);}}
 public static void set(Field f,Object o,Object v){try{f.setAccessible(true);if(v!=null){Class<?> t=f.getType();if(t==Long.class||t==long.class)v=((Number)v).longValue();else if(t==Integer.class||t==int.class)v=((Number)v).intValue();else if(t==LocalDate.class&&v instanceof java.sql.Date)v=((java.sql.Date)v).toLocalDate();else if(t==OffsetDateTime.class&&v instanceof Timestamp)v=((Timestamp)v).toInstant().atOffset(ZoneOffset.UTC);}f.set(o,v);}catch(Exception e){throw new DaoException("Cannot set "+f.getName(),e);}}
 public static <T>T map(ResultSet rs,Class<T> type,Map<String,Field> byColumn){try{T x=type.newInstance();for(Map.Entry<String,Field> e:byColumn.entrySet())set(e.getValue(),x,rs.getObject(e.getKey()));return x;}catch(Exception e){throw new DaoException("Cannot map "+type.getSimpleName(),e);}}
 public static Map<String,Field> byColumn(Class<?> t){return fields(t).stream().collect(Collectors.toMap(f->snake(f.getName()),Function.identity(),(a,b)->a,LinkedHashMap::new));}
}

package dao;import entity.EmissionFactor;public interface EmissionFactorDao extends GenericDao<EmissionFactor,Long>{}

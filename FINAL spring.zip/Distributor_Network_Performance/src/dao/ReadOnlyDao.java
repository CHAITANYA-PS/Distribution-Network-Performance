package dao;
import java.util.List;
import java.util.function.Predicate;
public interface ReadOnlyDao<T>{List<T> findAll();List<T> filter(Predicate<T> p);}

package dao;import entity.Department;public interface DepartmentDao extends GenericDao<Department,Long>{}

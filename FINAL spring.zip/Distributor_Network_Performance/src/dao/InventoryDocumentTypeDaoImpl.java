package dao;import entity.InventoryDocumentType;
import jdbc.ConnectionFactory;public class InventoryDocumentTypeDaoImpl extends JdbcGenericDao<InventoryDocumentType> implements InventoryDocumentTypeDao{public InventoryDocumentTypeDaoImpl(ConnectionFactory cf){super(cf,InventoryDocumentType.class,"dsphere","inventory_document_type","inventory_document_type_id");}}

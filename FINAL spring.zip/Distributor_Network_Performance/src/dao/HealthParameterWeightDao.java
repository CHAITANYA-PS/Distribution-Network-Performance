package dao;import entity.HealthParameterWeight;public interface HealthParameterWeightDao extends GenericDao<HealthParameterWeight,Long>{}

package dao;import entity.VehicleType;
import jdbc.ConnectionFactory;public class VehicleTypeDaoImpl extends JdbcGenericDao<VehicleType> implements VehicleTypeDao{public VehicleTypeDaoImpl(ConnectionFactory cf){super(cf,VehicleType.class,"dsphere","vehicle_type","vehicle_type_id");}}

package dao;import entity.ActivityType;public interface ActivityTypeDao extends GenericDao<ActivityType,Long>{}

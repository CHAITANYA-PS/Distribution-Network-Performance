package dao;import entity.TicketPriority;
import jdbc.ConnectionFactory;public class TicketPriorityDaoImpl extends JdbcGenericDao<TicketPriority> implements TicketPriorityDao{public TicketPriorityDaoImpl(ConnectionFactory cf){super(cf,TicketPriority.class,"dsphere","ticket_priority","ticket_priority_id");}}

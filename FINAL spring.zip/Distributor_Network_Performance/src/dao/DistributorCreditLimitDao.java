package dao;import entity.DistributorCreditLimit;public interface DistributorCreditLimitDao extends GenericDao<DistributorCreditLimit,Long>{}

package dao;import entity.CurrentStockView;public interface CurrentStockViewDao extends ReadOnlyDao<CurrentStockView>{}

package dao;import entity.HealthAssessmentAlert;public interface HealthAssessmentAlertDao extends GenericDao<HealthAssessmentAlert,Long>{}

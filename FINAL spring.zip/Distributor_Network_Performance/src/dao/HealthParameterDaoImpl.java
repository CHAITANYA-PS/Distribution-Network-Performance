package dao;import entity.HealthParameter;
import jdbc.ConnectionFactory;public class HealthParameterDaoImpl extends JdbcGenericDao<HealthParameter> implements HealthParameterDao{public HealthParameterDaoImpl(ConnectionFactory cf){super(cf,HealthParameter.class,"dsphere","health_parameter","parameter_id");}}

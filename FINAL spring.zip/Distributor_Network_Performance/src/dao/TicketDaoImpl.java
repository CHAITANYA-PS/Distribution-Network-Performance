package dao;import entity.Ticket;
import jdbc.ConnectionFactory;public class TicketDaoImpl extends JdbcGenericDao<Ticket> implements TicketDao{public TicketDaoImpl(ConnectionFactory cf){super(cf,Ticket.class,"dsphere","ticket","ticket_id");}}

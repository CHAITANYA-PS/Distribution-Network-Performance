package dao;import entity.Region;
import jdbc.ConnectionFactory;public class RegionDaoImpl extends JdbcGenericDao<Region> implements RegionDao{public RegionDaoImpl(ConnectionFactory cf){super(cf,Region.class,"dsphere","region","region_id");}}

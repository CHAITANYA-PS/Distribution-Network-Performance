package dao;

import entity.OutstandingPaymentView;
import jdbc.ConnectionFactory;

public class OutstandingPaymentViewDaoImpl extends JdbcReadOnlyDao<OutstandingPaymentView>
		implements OutstandingPaymentViewDao {
	public OutstandingPaymentViewDaoImpl(ConnectionFactory cf) {
		super(cf, OutstandingPaymentView.class, "dsphere", "outstanding_payment_view");
	}
}

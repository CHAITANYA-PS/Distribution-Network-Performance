package dao;import entity.Warehouse;
import jdbc.ConnectionFactory;public class WarehouseDaoImpl extends JdbcGenericDao<Warehouse> implements WarehouseDao{public WarehouseDaoImpl(ConnectionFactory cf){super(cf,Warehouse.class,"dsphere","warehouse","warehouse_id");}}

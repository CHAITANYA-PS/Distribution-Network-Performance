package dao;import entity.Payment;
import jdbc.ConnectionFactory;public class PaymentDaoImpl extends JdbcGenericDao<Payment> implements PaymentDao{public PaymentDaoImpl(ConnectionFactory cf){super(cf,Payment.class,"dsphere","payment","payment_id");}}

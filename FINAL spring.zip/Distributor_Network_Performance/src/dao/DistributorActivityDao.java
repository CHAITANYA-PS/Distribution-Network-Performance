package dao;import entity.DistributorActivity;public interface DistributorActivityDao extends GenericDao<DistributorActivity,Long>{}

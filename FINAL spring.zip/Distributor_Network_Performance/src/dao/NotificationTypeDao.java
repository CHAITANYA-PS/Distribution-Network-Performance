package dao;import entity.NotificationType;public interface NotificationTypeDao extends GenericDao<NotificationType,Long>{}

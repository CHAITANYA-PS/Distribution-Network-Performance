package dao;import entity.Commitment;public interface CommitmentDao extends GenericDao<Commitment,Long>{}

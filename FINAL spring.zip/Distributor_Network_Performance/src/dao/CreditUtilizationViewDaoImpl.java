package dao;import entity.CreditUtilizationView;
import jdbc.ConnectionFactory;public class CreditUtilizationViewDaoImpl extends JdbcReadOnlyDao<CreditUtilizationView> implements CreditUtilizationViewDao{public CreditUtilizationViewDaoImpl(ConnectionFactory cf){super(cf,CreditUtilizationView.class,"dsphere","credit_utilization_view");}}

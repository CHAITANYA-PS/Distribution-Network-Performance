package dao;import entity.Category;
import jdbc.ConnectionFactory;public class CategoryDaoImpl extends JdbcGenericDao<Category> implements CategoryDao{public CategoryDaoImpl(ConnectionFactory cf){super(cf,Category.class,"dsphere","category","category_id");}}

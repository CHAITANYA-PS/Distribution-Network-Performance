package dao;import entity.DistributorActivity;
import jdbc.ConnectionFactory;public class DistributorActivityDaoImpl extends JdbcGenericDao<DistributorActivity> implements DistributorActivityDao{public DistributorActivityDaoImpl(ConnectionFactory cf){super(cf,DistributorActivity.class,"dsphere","distributor_activity","activity_id");}}

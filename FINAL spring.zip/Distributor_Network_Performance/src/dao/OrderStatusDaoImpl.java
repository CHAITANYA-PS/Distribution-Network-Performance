package dao;import entity.OrderStatus;
import jdbc.ConnectionFactory;public class OrderStatusDaoImpl extends JdbcGenericDao<OrderStatus> implements OrderStatusDao{public OrderStatusDaoImpl(ConnectionFactory cf){super(cf,OrderStatus.class,"dsphere","order_status","order_status_id");}}

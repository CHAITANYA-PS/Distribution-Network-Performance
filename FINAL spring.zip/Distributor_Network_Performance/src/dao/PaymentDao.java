package dao;import entity.Payment;public interface PaymentDao extends GenericDao<Payment,Long>{}

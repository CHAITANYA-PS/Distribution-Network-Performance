package dao;import entity.HealthParameterWeight;
import jdbc.ConnectionFactory;public class HealthParameterWeightDaoImpl extends JdbcGenericDao<HealthParameterWeight> implements HealthParameterWeightDao{public HealthParameterWeightDaoImpl(ConnectionFactory cf){super(cf,HealthParameterWeight.class,"dsphere","health_parameter_weight","parameter_weight_id");}}

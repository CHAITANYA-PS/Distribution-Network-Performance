package dao;import entity.InventoryMovement;
import jdbc.ConnectionFactory;public class InventoryMovementDaoImpl extends JdbcGenericDao<InventoryMovement> implements InventoryMovementDao{public InventoryMovementDaoImpl(ConnectionFactory cf){super(cf,InventoryMovement.class,"dsphere","inventory_movement","movement_id");}}

package dao;import entity.DistributorHealthAssessment;
import jdbc.ConnectionFactory;public class DistributorHealthAssessmentDaoImpl extends JdbcGenericDao<DistributorHealthAssessment> implements DistributorHealthAssessmentDao{public DistributorHealthAssessmentDaoImpl(ConnectionFactory cf){super(cf,DistributorHealthAssessment.class,"dsphere","distributor_health_assessment","assessment_id");}}

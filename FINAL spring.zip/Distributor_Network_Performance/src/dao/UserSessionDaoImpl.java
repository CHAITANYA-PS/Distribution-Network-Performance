package dao;import entity.UserSession;
import jdbc.ConnectionFactory;public class UserSessionDaoImpl extends JdbcGenericDao<UserSession> implements UserSessionDao{public UserSessionDaoImpl(ConnectionFactory cf){super(cf,UserSession.class,"dsphere","user_session","session_id");}}

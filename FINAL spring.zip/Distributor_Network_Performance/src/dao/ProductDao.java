package dao;import entity.Product;public interface ProductDao extends GenericDao<Product,Long>{}

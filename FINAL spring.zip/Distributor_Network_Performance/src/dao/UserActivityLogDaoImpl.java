package dao;import entity.UserActivityLog;
import jdbc.ConnectionFactory;public class UserActivityLogDaoImpl extends JdbcGenericDao<UserActivityLog> implements UserActivityLogDao{public UserActivityLogDaoImpl(ConnectionFactory cf){super(cf,UserActivityLog.class,"dsphere","user_activity_log","log_id");}}

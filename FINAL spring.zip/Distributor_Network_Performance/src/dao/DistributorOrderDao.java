package dao;import entity.DistributorOrder;public interface DistributorOrderDao extends GenericDao<DistributorOrder,Long>{}

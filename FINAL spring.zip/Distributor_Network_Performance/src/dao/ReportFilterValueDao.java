package dao;import entity.ReportFilterValue;public interface ReportFilterValueDao extends GenericDao<ReportFilterValue,Long>{}

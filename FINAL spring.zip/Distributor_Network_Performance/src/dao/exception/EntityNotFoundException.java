package dao.exception;
public class EntityNotFoundException extends DaoException{private static final long serialVersionUID=1L;public EntityNotFoundException(String m){super(m);}}

package dao;import entity.InventoryAlert;public interface InventoryAlertDao extends GenericDao<InventoryAlert,Long>{}

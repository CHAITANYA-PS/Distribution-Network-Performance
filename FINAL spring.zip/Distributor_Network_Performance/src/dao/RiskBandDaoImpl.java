package dao;import entity.RiskBand;
import jdbc.ConnectionFactory;public class RiskBandDaoImpl extends JdbcGenericDao<RiskBand> implements RiskBandDao{public RiskBandDaoImpl(ConnectionFactory cf){super(cf,RiskBand.class,"dsphere","risk_band","risk_band_id");}}

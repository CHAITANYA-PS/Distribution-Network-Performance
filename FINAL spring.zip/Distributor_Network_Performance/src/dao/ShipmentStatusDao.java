package dao;import entity.ShipmentStatus;public interface ShipmentStatusDao extends GenericDao<ShipmentStatus,Long>{}

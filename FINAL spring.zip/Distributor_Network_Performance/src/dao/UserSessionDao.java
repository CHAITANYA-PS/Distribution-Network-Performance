package dao;import entity.UserSession;public interface UserSessionDao extends GenericDao<UserSession,Long>{}

package dao;import entity.MovementType;
import jdbc.ConnectionFactory;public class MovementTypeDaoImpl extends JdbcGenericDao<MovementType> implements MovementTypeDao{public MovementTypeDaoImpl(ConnectionFactory cf){super(cf,MovementType.class,"dsphere","movement_type","movement_type_id");}}

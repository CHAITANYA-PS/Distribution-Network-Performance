package dao;import entity.Notification;public interface NotificationDao extends GenericDao<Notification,Long>{}

package dao;

import entity.ActivityType;
import jdbc.ConnectionFactory;

public class ActivityTypeDaoImpl extends JdbcGenericDao<ActivityType> implements ActivityTypeDao {
	public ActivityTypeDaoImpl(ConnectionFactory cf) {
		super(cf, ActivityType.class, "dsphere", "activity_type", "activity_type_id");
	}
}

package dao;import entity.SystemAdmin;
import jdbc.ConnectionFactory;public class SystemAdminDaoImpl extends JdbcGenericDao<SystemAdmin> implements SystemAdminDao{public SystemAdminDaoImpl(ConnectionFactory cf){super(cf,SystemAdmin.class,"dsphere","system_admin","user_id");}}

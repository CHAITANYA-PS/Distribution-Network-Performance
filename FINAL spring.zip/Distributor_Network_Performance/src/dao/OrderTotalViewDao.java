package dao;

import entity.OrderTotalView;

public interface OrderTotalViewDao extends ReadOnlyDao<OrderTotalView> {
}

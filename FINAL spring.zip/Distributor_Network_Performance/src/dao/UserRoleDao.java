package dao;import entity.UserRole;public interface UserRoleDao extends GenericDao<UserRole,Long>{}

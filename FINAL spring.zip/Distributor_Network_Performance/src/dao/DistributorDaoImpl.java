package dao;import entity.Distributor;
import jdbc.ConnectionFactory;public class DistributorDaoImpl extends JdbcGenericDao<Distributor> implements DistributorDao{public DistributorDaoImpl(ConnectionFactory cf){super(cf,Distributor.class,"dsphere","distributor","distributor_id");}}

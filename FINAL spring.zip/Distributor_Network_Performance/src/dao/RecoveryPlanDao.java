package dao;import entity.RecoveryPlan;public interface RecoveryPlanDao extends GenericDao<RecoveryPlan,Long>{}

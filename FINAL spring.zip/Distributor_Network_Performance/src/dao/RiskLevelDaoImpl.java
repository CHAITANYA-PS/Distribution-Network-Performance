package dao;import entity.RiskLevel;
import jdbc.ConnectionFactory;public class RiskLevelDaoImpl extends JdbcGenericDao<RiskLevel> implements RiskLevelDao{public RiskLevelDaoImpl(ConnectionFactory cf){super(cf,RiskLevel.class,"dsphere","risk_level","risk_level_id");}}

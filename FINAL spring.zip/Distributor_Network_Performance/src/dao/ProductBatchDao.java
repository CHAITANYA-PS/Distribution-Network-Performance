package dao;import entity.ProductBatch;public interface ProductBatchDao extends GenericDao<ProductBatch,Long>{}

package dao;import entity.Shipment;public interface ShipmentDao extends GenericDao<Shipment,Long>{}

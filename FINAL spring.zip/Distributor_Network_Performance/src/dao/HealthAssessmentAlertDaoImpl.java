package dao;import entity.HealthAssessmentAlert;
import jdbc.ConnectionFactory;public class HealthAssessmentAlertDaoImpl extends JdbcGenericDao<HealthAssessmentAlert> implements HealthAssessmentAlertDao{public HealthAssessmentAlertDaoImpl(ConnectionFactory cf){super(cf,HealthAssessmentAlert.class,"dsphere","health_assessment_alert","alert_id");}}

package dao;
import java.lang.reflect.Field;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.ResultSetMetaData;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.Optional;
import java.util.function.Predicate;
import java.util.stream.Collectors;

import dao.exception.DaoException;
import dao.exception.DuplicateEntityException;
import dao.exception.EntityNotFoundException;
import jdbc.ConnectionFactory;
public class JdbcGenericDao<T> implements GenericDao<T,Long>{
 protected final ConnectionFactory cf;private final Class<T> type;private final String schema,table,idColumn;private final Map<String,Field> fields;
 public JdbcGenericDao(ConnectionFactory cf,Class<T> type,String schema,String table,String idColumn){this.cf=cf;this.type=type;this.schema=schema;this.table=table;this.idColumn=idColumn;this.fields=ReflectionMapper.byColumn(type);}
 @Override
public T save(T e){require(e);try(Connection c=cf.getConnection()){List<String> cols=columns(c);Field idf=fields.get(idColumn);Object id=idf==null?null:ReflectionMapper.get(idf,e);List<String> use=cols.stream().filter(fields::containsKey).filter(x->!x.equals(idColumn)||id!=null).collect(Collectors.toList());String q=use.stream().map(x->"?").collect(Collectors.joining(","));String sql="INSERT INTO "+full()+" ("+String.join(",",use)+") VALUES ("+q+") RETURNING "+idColumn;try(PreparedStatement ps=c.prepareStatement(sql)){bind(ps,use,e);try(ResultSet rs=ps.executeQuery()){if(rs.next()&&idf!=null)ReflectionMapper.set(idf,e,rs.getObject(1));return e;}}}catch(SQLException x){throw translate("save",x);} }
 @Override
public T update(T e){require(e);Field idf=fields.get(idColumn);Long id=(Long)ReflectionMapper.get(idf,e);requireId(id);try(Connection c=cf.getConnection()){List<String> use=columns(c).stream().filter(fields::containsKey).filter(x->!x.equals(idColumn)).collect(Collectors.toList());String set=use.stream().map(x->x+"=?").collect(Collectors.joining(","));try(PreparedStatement ps=c.prepareStatement("UPDATE "+full()+" SET "+set+" WHERE "+idColumn+"=?")){bind(ps,use,e);ps.setLong(use.size()+1,id);if(ps.executeUpdate()==0)throw new EntityNotFoundException(type.getSimpleName()+" not found: "+id);return e;}}catch(SQLException x){throw translate("update",x);} }
 @Override
public Optional<T> findById(Long id){requireId(id);try(Connection c=cf.getConnection();PreparedStatement ps=c.prepareStatement("SELECT * FROM "+full()+" WHERE "+idColumn+"=?")){ps.setLong(1,id);try(ResultSet rs=ps.executeQuery()){return rs.next()?Optional.of(ReflectionMapper.map(rs,type,fields)):Optional.empty();}}catch(SQLException x){throw translate("find",x);} }
 @Override
public List<T> findAll(){try(Connection c=cf.getConnection();PreparedStatement ps=c.prepareStatement("SELECT * FROM "+full());ResultSet rs=ps.executeQuery()){List<T> r=new ArrayList<>();while(rs.next())r.add(ReflectionMapper.map(rs,type,fields));return r;}catch(SQLException x){throw translate("find all",x);} }
 @Override
public List<T> filter(Predicate<T> p){if(p==null)throw new DaoException("Predicate cannot be null");return findAll().stream().filter(p).collect(Collectors.toList());}
 @Override
public boolean existsById(Long id){return findById(id).isPresent();}
 @Override
public boolean deleteById(Long id){requireId(id);try(Connection c=cf.getConnection();PreparedStatement ps=c.prepareStatement("DELETE FROM "+full()+" WHERE "+idColumn+"=?")){ps.setLong(1,id);return ps.executeUpdate()>0;}catch(SQLException x){throw translate("delete",x);} }
 @Override
public long count(){try(Connection c=cf.getConnection();PreparedStatement ps=c.prepareStatement("SELECT COUNT(*) FROM "+full());ResultSet rs=ps.executeQuery()){rs.next();return rs.getLong(1);}catch(SQLException x){throw translate("count",x);} }
 private List<String> columns(Connection c)throws SQLException{try(PreparedStatement ps=c.prepareStatement("SELECT * FROM "+full()+" WHERE 1=0");ResultSet rs=ps.executeQuery()){ResultSetMetaData m=rs.getMetaData();List<String> r=new ArrayList<>();for(int i=1;i<=m.getColumnCount();i++)r.add(m.getColumnLabel(i));return r;}}
 private void bind(PreparedStatement ps,List<String> cols,T e)throws SQLException{for(int i=0;i<cols.size();i++)ps.setObject(i+1,ReflectionMapper.get(fields.get(cols.get(i)),e));}
 private String full(){return schema+"."+table;}private void require(T e){if(e==null)throw new DaoException(type.getSimpleName()+" cannot be null");}private void requireId(Long id){if(id==null||id<=0)throw new DaoException("ID must be positive");}
 private DaoException translate(String op,SQLException e){return "23505".equals(e.getSQLState())?new DuplicateEntityException("Duplicate "+type.getSimpleName(),e):new DaoException("Failed to "+op+" "+type.getSimpleName()+" [SQLState="+e.getSQLState()+"]",e);}
}

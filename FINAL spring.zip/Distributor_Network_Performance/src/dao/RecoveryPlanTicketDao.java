package dao;import entity.RecoveryPlanTicket;public interface RecoveryPlanTicketDao extends GenericDao<RecoveryPlanTicket,Long>{}

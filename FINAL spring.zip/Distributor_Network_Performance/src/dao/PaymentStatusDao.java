package dao;import entity.PaymentStatus;public interface PaymentStatusDao extends GenericDao<PaymentStatus,Long>{}

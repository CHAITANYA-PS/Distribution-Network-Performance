package dao;import entity.AppUser;public interface AppUserDao extends GenericDao<AppUser,Long>{}

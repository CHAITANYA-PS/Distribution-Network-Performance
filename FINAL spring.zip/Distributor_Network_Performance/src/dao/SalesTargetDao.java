package dao;import entity.SalesTarget;public interface SalesTargetDao extends GenericDao<SalesTarget,Long>{}

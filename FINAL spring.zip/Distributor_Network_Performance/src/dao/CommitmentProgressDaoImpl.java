package dao;import entity.CommitmentProgress;
import jdbc.ConnectionFactory;public class CommitmentProgressDaoImpl extends JdbcGenericDao<CommitmentProgress> implements CommitmentProgressDao{public CommitmentProgressDaoImpl(ConnectionFactory cf){super(cf,CommitmentProgress.class,"dsphere","commitment_progress","progress_id");}}

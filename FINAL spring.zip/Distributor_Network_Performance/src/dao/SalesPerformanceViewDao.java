package dao;

import entity.SalesPerformanceView;

public interface SalesPerformanceViewDao extends ReadOnlyDao<SalesPerformanceView> {
}

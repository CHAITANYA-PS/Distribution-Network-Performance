package dao;import entity.MovementType;public interface MovementTypeDao extends GenericDao<MovementType,Long>{}

package dao;import entity.TicketStatus;
import jdbc.ConnectionFactory;public class TicketStatusDaoImpl extends JdbcGenericDao<TicketStatus> implements TicketStatusDao{public TicketStatusDaoImpl(ConnectionFactory cf){super(cf,TicketStatus.class,"dsphere","ticket_status","ticket_status_id");}}

package dao;import entity.TicketCategory;
import jdbc.ConnectionFactory;public class TicketCategoryDaoImpl extends JdbcGenericDao<TicketCategory> implements TicketCategoryDao{public TicketCategoryDaoImpl(ConnectionFactory cf){super(cf,TicketCategory.class,"dsphere","ticket_category","ticket_category_id");}}

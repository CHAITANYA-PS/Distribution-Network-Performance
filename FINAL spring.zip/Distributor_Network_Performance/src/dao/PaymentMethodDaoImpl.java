package dao;import entity.PaymentMethod;
import jdbc.ConnectionFactory;public class PaymentMethodDaoImpl extends JdbcGenericDao<PaymentMethod> implements PaymentMethodDao{public PaymentMethodDaoImpl(ConnectionFactory cf){super(cf,PaymentMethod.class,"dsphere","payment_method","payment_method_id");}}

package dao;import entity.SalesRecord;public interface SalesRecordDao extends GenericDao<SalesRecord,Long>{}

package dao;import entity.PasswordReset;public interface PasswordResetDao extends GenericDao<PasswordReset,Long>{}

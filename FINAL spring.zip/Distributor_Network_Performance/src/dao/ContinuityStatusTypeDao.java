package dao;import entity.ContinuityStatusType;public interface ContinuityStatusTypeDao extends GenericDao<ContinuityStatusType,Long>{}

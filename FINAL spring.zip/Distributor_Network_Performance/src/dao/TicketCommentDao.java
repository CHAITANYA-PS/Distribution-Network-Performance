package dao;import entity.TicketComment;public interface TicketCommentDao extends GenericDao<TicketComment,Long>{}

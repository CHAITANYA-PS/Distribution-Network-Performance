package dao;import entity.ExchangeHistory;
import jdbc.ConnectionFactory;public class ExchangeHistoryDaoImpl extends JdbcGenericDao<ExchangeHistory> implements ExchangeHistoryDao{public ExchangeHistoryDaoImpl(ConnectionFactory cf){super(cf,ExchangeHistory.class,"dsphere","exchange_history","exchange_history_id");}}

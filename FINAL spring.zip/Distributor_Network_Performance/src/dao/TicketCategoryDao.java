package dao;import entity.TicketCategory;public interface TicketCategoryDao extends GenericDao<TicketCategory,Long>{}

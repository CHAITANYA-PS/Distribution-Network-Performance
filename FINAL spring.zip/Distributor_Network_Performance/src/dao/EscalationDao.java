package dao;import entity.Escalation;public interface EscalationDao extends GenericDao<Escalation,Long>{}

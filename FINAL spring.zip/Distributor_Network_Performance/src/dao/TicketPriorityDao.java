package dao;import entity.TicketPriority;public interface TicketPriorityDao extends GenericDao<TicketPriority,Long>{}

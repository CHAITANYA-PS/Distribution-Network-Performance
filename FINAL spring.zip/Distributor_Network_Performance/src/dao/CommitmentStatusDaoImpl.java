package dao;import entity.CommitmentStatus;
import jdbc.ConnectionFactory;public class CommitmentStatusDaoImpl extends JdbcGenericDao<CommitmentStatus> implements CommitmentStatusDao{public CommitmentStatusDaoImpl(ConnectionFactory cf){super(cf,CommitmentStatus.class,"dsphere","commitment_status","commitment_status_id");}}

package dao;import entity.InvoiceStatus;
import jdbc.ConnectionFactory;public class InvoiceStatusDaoImpl extends JdbcGenericDao<InvoiceStatus> implements InvoiceStatusDao{public InvoiceStatusDaoImpl(ConnectionFactory cf){super(cf,InvoiceStatus.class,"dsphere","invoice_status","invoice_status_id");}}

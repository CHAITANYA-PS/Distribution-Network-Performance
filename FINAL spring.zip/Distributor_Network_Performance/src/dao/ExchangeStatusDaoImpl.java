package dao;import entity.ExchangeStatus;
import jdbc.ConnectionFactory;public class ExchangeStatusDaoImpl extends JdbcGenericDao<ExchangeStatus> implements ExchangeStatusDao{public ExchangeStatusDaoImpl(ConnectionFactory cf){super(cf,ExchangeStatus.class,"dsphere","exchange_status","exchange_status_id");}}

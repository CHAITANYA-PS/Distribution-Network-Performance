package dao;import entity.AppUser;
import jdbc.ConnectionFactory;public class AppUserDaoImpl extends JdbcGenericDao<AppUser> implements AppUserDao{public AppUserDaoImpl(ConnectionFactory cf){super(cf,AppUser.class,"dsphere","app_user","user_id");}}

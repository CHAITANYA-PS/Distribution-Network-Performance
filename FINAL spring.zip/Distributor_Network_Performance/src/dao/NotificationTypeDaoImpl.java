package dao;import entity.NotificationType;
import jdbc.ConnectionFactory;public class NotificationTypeDaoImpl extends JdbcGenericDao<NotificationType> implements NotificationTypeDao{public NotificationTypeDaoImpl(ConnectionFactory cf){super(cf,NotificationType.class,"dsphere","notification_type","notification_type_id");}}

package dao;import entity.Manufacturer;public interface ManufacturerDao extends GenericDao<Manufacturer,Long>{}

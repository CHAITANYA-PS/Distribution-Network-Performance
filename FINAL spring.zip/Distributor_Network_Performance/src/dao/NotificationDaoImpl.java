package dao;import entity.Notification;
import jdbc.ConnectionFactory;public class NotificationDaoImpl extends JdbcGenericDao<Notification> implements NotificationDao{public NotificationDaoImpl(ConnectionFactory cf){super(cf,Notification.class,"dsphere","notification","notification_id");}}

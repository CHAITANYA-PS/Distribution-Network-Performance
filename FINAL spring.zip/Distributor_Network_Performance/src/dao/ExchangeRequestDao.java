package dao;import entity.ExchangeRequest;public interface ExchangeRequestDao extends GenericDao<ExchangeRequest,Long>{}

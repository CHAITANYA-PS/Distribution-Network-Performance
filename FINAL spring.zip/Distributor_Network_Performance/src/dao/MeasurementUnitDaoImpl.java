package dao;import entity.MeasurementUnit;
import jdbc.ConnectionFactory;public class MeasurementUnitDaoImpl extends JdbcGenericDao<MeasurementUnit> implements MeasurementUnitDao{public MeasurementUnitDaoImpl(ConnectionFactory cf){super(cf,MeasurementUnit.class,"dsphere","measurement_unit","measurement_unit_id");}}

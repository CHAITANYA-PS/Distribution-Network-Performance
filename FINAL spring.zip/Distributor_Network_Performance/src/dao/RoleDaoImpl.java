package dao;import entity.Role;
import jdbc.ConnectionFactory;public class RoleDaoImpl extends JdbcGenericDao<Role> implements RoleDao{public RoleDaoImpl(ConnectionFactory cf){super(cf,Role.class,"dsphere","role","role_id");}}

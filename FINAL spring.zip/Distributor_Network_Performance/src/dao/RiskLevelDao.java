package dao;import entity.RiskLevel;public interface RiskLevelDao extends GenericDao<RiskLevel,Long>{}

package dao;import entity.OrderStatusHistory;
import jdbc.ConnectionFactory;public class OrderStatusHistoryDaoImpl extends JdbcGenericDao<OrderStatusHistory> implements OrderStatusHistoryDao{public OrderStatusHistoryDaoImpl(ConnectionFactory cf){super(cf,OrderStatusHistory.class,"dsphere","order_status_history","order_status_history_id");}}

package dao;import entity.Manufacturer;
import jdbc.ConnectionFactory;public class ManufacturerDaoImpl extends JdbcGenericDao<Manufacturer> implements ManufacturerDao{public ManufacturerDaoImpl(ConnectionFactory cf){super(cf,Manufacturer.class,"dsphere","manufacturer","manufacturer_id");}}

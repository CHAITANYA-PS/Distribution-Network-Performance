package dao;

import entity.OrderTotalView;
import jdbc.ConnectionFactory;

public class OrderTotalViewDaoImpl extends JdbcReadOnlyDao<OrderTotalView> implements OrderTotalViewDao {
	public OrderTotalViewDaoImpl(ConnectionFactory cf) {
		super(cf, OrderTotalView.class, "dsphere", "order_total_view");
	}
}

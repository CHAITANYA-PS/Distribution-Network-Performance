package dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Communication DTO for RecoveryPlan; contains scalar values only and no DAO behavior. */
public class RecoveryPlanDTO {
    private Long recoveryPlanId;
    private Long distributorId;
    private Long recoveryStatusId;
    private BigDecimal targetAmount;
    private LocalDate startDate;
    private LocalDate endDate;
    private Long createdBy;
    private OffsetDateTime createdAt;

    public RecoveryPlanDTO() {}

    public Long getRecoveryPlanId() { return recoveryPlanId; }
    public void setRecoveryPlanId(Long recoveryPlanId) { this.recoveryPlanId = recoveryPlanId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getRecoveryStatusId() { return recoveryStatusId; }
    public void setRecoveryStatusId(Long recoveryStatusId) { this.recoveryStatusId = recoveryStatusId; }

    public BigDecimal getTargetAmount() { return targetAmount; }
    public void setTargetAmount(BigDecimal targetAmount) { this.targetAmount = targetAmount; }

    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }

    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
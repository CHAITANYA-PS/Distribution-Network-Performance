package dto;

import java.time.OffsetDateTime;

/** Communication DTO for Report; contains scalar values only and no DAO behavior. */
public class ReportDTO {
    private Long reportId;
    private String reportName;
    private String module;
    private String format;
    private Long generatedBy;
    private OffsetDateTime generatedAt;
    private String filePath;

    public ReportDTO() {}

    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }

    public String getReportName() { return reportName; }
    public void setReportName(String reportName) { this.reportName = reportName; }

    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }

    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }

    public Long getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(Long generatedBy) { this.generatedBy = generatedBy; }

    public OffsetDateTime getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(OffsetDateTime generatedAt) { this.generatedAt = generatedAt; }

    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

}
package dto;

/** Communication DTO for PaymentMethod; contains scalar values only and no DAO behavior. */
public class PaymentMethodDTO {
    private Long paymentMethodId;
    private String methodName;

    public PaymentMethodDTO() {}

    public Long getPaymentMethodId() { return paymentMethodId; }
    public void setPaymentMethodId(Long paymentMethodId) { this.paymentMethodId = paymentMethodId; }

    public String getMethodName() { return methodName; }
    public void setMethodName(String methodName) { this.methodName = methodName; }

}
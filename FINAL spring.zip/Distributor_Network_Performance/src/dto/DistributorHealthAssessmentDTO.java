package dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for DistributorHealthAssessment; contains scalar values only and no DAO behavior. */
public class DistributorHealthAssessmentDTO {
    private Long assessmentId;
    private Long distributorId;
    private Long parameterWeightId;
    private Long reportingPeriodId;
    private BigDecimal score;
    private Long assessedBy;
    private OffsetDateTime assessedAt;
    private String remarks;

    public DistributorHealthAssessmentDTO() {}

    public Long getAssessmentId() { return assessmentId; }
    public void setAssessmentId(Long assessmentId) { this.assessmentId = assessmentId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getParameterWeightId() { return parameterWeightId; }
    public void setParameterWeightId(Long parameterWeightId) { this.parameterWeightId = parameterWeightId; }

    public Long getReportingPeriodId() { return reportingPeriodId; }
    public void setReportingPeriodId(Long reportingPeriodId) { this.reportingPeriodId = reportingPeriodId; }

    public BigDecimal getScore() { return score; }
    public void setScore(BigDecimal score) { this.score = score; }

    public Long getAssessedBy() { return assessedBy; }
    public void setAssessedBy(Long assessedBy) { this.assessedBy = assessedBy; }

    public OffsetDateTime getAssessedAt() { return assessedAt; }
    public void setAssessedAt(OffsetDateTime assessedAt) { this.assessedAt = assessedAt; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

}
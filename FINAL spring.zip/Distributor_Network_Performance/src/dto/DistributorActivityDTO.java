package dto;

import java.time.OffsetDateTime;

/** Communication DTO for DistributorActivity; contains scalar values only and no DAO behavior. */
public class DistributorActivityDTO {
    private Long activityId;
    private Long distributorId;
    private Long activityTypeId;
    private OffsetDateTime activityDate;
    private Long recordedBy;
    private String remarks;

    public DistributorActivityDTO() {}

    public Long getActivityId() { return activityId; }
    public void setActivityId(Long activityId) { this.activityId = activityId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getActivityTypeId() { return activityTypeId; }
    public void setActivityTypeId(Long activityTypeId) { this.activityTypeId = activityTypeId; }

    public OffsetDateTime getActivityDate() { return activityDate; }
    public void setActivityDate(OffsetDateTime activityDate) { this.activityDate = activityDate; }

    public Long getRecordedBy() { return recordedBy; }
    public void setRecordedBy(Long recordedBy) { this.recordedBy = recordedBy; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

}
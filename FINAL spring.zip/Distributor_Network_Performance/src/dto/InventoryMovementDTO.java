package dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for InventoryMovement; contains scalar values only and no DAO behavior. */
public class InventoryMovementDTO {
    private Long movementId;
    private Long inventoryDocumentId;
    private Long warehouseStockId;
    private Long movementTypeId;
    private BigDecimal quantity;
    private OffsetDateTime movementDate;

    public InventoryMovementDTO() {}

    public Long getMovementId() { return movementId; }
    public void setMovementId(Long movementId) { this.movementId = movementId; }

    public Long getInventoryDocumentId() { return inventoryDocumentId; }
    public void setInventoryDocumentId(Long inventoryDocumentId) { this.inventoryDocumentId = inventoryDocumentId; }

    public Long getWarehouseStockId() { return warehouseStockId; }
    public void setWarehouseStockId(Long warehouseStockId) { this.warehouseStockId = warehouseStockId; }

    public Long getMovementTypeId() { return movementTypeId; }
    public void setMovementTypeId(Long movementTypeId) { this.movementTypeId = movementTypeId; }

    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

    public OffsetDateTime getMovementDate() { return movementDate; }
    public void setMovementDate(OffsetDateTime movementDate) { this.movementDate = movementDate; }

}
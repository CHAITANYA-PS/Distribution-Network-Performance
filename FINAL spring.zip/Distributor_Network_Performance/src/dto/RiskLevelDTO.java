package dto;

/** Communication DTO for RiskLevel; contains scalar values only and no DAO behavior. */
public class RiskLevelDTO {
    private Long riskLevelId;
    private String riskLevelName;
    private Integer severityRank;

    public RiskLevelDTO() {}

    public Long getRiskLevelId() { return riskLevelId; }
    public void setRiskLevelId(Long riskLevelId) { this.riskLevelId = riskLevelId; }

    public String getRiskLevelName() { return riskLevelName; }
    public void setRiskLevelName(String riskLevelName) { this.riskLevelName = riskLevelName; }

    public Integer getSeverityRank() { return severityRank; }
    public void setSeverityRank(Integer severityRank) { this.severityRank = severityRank; }

}
package dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Communication DTO for Commitment; contains scalar values only and no DAO behavior. */
public class CommitmentDTO {
    private Long commitmentId;
    private Long distributorId;
    private Long measurementUnitId;
    private Long commitmentStatusId;
    private String targetName;
    private BigDecimal targetValue;
    private LocalDate dueDate;
    private Long createdBy;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public CommitmentDTO() {}

    public Long getCommitmentId() { return commitmentId; }
    public void setCommitmentId(Long commitmentId) { this.commitmentId = commitmentId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getMeasurementUnitId() { return measurementUnitId; }
    public void setMeasurementUnitId(Long measurementUnitId) { this.measurementUnitId = measurementUnitId; }

    public Long getCommitmentStatusId() { return commitmentStatusId; }
    public void setCommitmentStatusId(Long commitmentStatusId) { this.commitmentStatusId = commitmentStatusId; }

    public String getTargetName() { return targetName; }
    public void setTargetName(String targetName) { this.targetName = targetName; }

    public BigDecimal getTargetValue() { return targetValue; }
    public void setTargetValue(BigDecimal targetValue) { this.targetValue = targetValue; }

    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }

    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

}
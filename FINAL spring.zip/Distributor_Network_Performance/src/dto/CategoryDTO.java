package dto;

/** Communication DTO for Category; contains scalar values only and no DAO behavior. */
public class CategoryDTO {
    private Long categoryId;
    private String categoryName;
    private String description;

    public CategoryDTO() {}

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

}
package dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for DistributorCreditLimit; contains scalar values only and no DAO behavior. */
public class DistributorCreditLimitDTO {
    private Long creditLimitId;
    private Long distributorId;
    private BigDecimal creditLimit;
    private LocalDate validFrom;
    private LocalDate validTo;
    private Long approvedBy;

    public DistributorCreditLimitDTO() {}

    public Long getCreditLimitId() { return creditLimitId; }
    public void setCreditLimitId(Long creditLimitId) { this.creditLimitId = creditLimitId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public BigDecimal getCreditLimit() { return creditLimit; }
    public void setCreditLimit(BigDecimal creditLimit) { this.creditLimit = creditLimit; }

    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }

    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate validTo) { this.validTo = validTo; }

    public Long getApprovedBy() { return approvedBy; }
    public void setApprovedBy(Long approvedBy) { this.approvedBy = approvedBy; }

}
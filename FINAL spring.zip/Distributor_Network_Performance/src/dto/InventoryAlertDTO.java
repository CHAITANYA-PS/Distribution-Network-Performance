package dto;

import java.time.OffsetDateTime;

/** Communication DTO for InventoryAlert; contains scalar values only and no DAO behavior. */
public class InventoryAlertDTO {
    private Long alertId;
    private Long warehouseStockId;
    private String alertType;
    private String message;
    private String status;
    private OffsetDateTime createdAt;

    public InventoryAlertDTO() {}

    public Long getAlertId() { return alertId; }
    public void setAlertId(Long alertId) { this.alertId = alertId; }

    public Long getWarehouseStockId() { return warehouseStockId; }
    public void setWarehouseStockId(Long warehouseStockId) { this.warehouseStockId = warehouseStockId; }

    public String getAlertType() { return alertType; }
    public void setAlertType(String alertType) { this.alertType = alertType; }

    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
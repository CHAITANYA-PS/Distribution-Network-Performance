package dto;

/** Communication DTO for TicketCategory; contains scalar values only and no DAO behavior. */
public class TicketCategoryDTO {
    private Long ticketCategoryId;
    private String categoryName;

    public TicketCategoryDTO() {}

    public Long getTicketCategoryId() { return ticketCategoryId; }
    public void setTicketCategoryId(Long ticketCategoryId) { this.ticketCategoryId = ticketCategoryId; }

    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

}
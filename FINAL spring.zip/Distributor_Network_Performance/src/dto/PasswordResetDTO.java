package dto;

import java.time.OffsetDateTime;

/** Communication DTO for PasswordReset; contains scalar values only and no DAO behavior. */
public class PasswordResetDTO {
    private Long resetId;
    private Long userId;
    private String token;
    private OffsetDateTime expiresAt;
    private OffsetDateTime usedAt;
    private OffsetDateTime createdAt;

    public PasswordResetDTO() {}

    public Long getResetId() { return resetId; }
    public void setResetId(Long resetId) { this.resetId = resetId; }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }

    public OffsetDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(OffsetDateTime expiresAt) { this.expiresAt = expiresAt; }

    public OffsetDateTime getUsedAt() { return usedAt; }
    public void setUsedAt(OffsetDateTime usedAt) { this.usedAt = usedAt; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

}
package dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for CommitmentProgress; contains scalar values only and no DAO behavior. */
public class CommitmentProgressDTO {
    private Long progressId;
    private Long commitmentId;
    private BigDecimal progressValue;
    private Long recordedBy;
    private OffsetDateTime recordedAt;
    private String remarks;

    public CommitmentProgressDTO() {}

    public Long getProgressId() { return progressId; }
    public void setProgressId(Long progressId) { this.progressId = progressId; }

    public Long getCommitmentId() { return commitmentId; }
    public void setCommitmentId(Long commitmentId) { this.commitmentId = commitmentId; }

    public BigDecimal getProgressValue() { return progressValue; }
    public void setProgressValue(BigDecimal progressValue) { this.progressValue = progressValue; }

    public Long getRecordedBy() { return recordedBy; }
    public void setRecordedBy(Long recordedBy) { this.recordedBy = recordedBy; }

    public OffsetDateTime getRecordedAt() { return recordedAt; }
    public void setRecordedAt(OffsetDateTime recordedAt) { this.recordedAt = recordedAt; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

}
package dto;

/** Communication DTO for HealthParameter; contains scalar values only and no DAO behavior. */
public class HealthParameterDTO {
    private Long parameterId;
    private String parameterName;
    private String description;
    private Boolean isActive;

    public HealthParameterDTO() {}

    public Long getParameterId() { return parameterId; }
    public void setParameterId(Long parameterId) { this.parameterId = parameterId; }

    public String getParameterName() { return parameterName; }
    public void setParameterName(String parameterName) { this.parameterName = parameterName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

}
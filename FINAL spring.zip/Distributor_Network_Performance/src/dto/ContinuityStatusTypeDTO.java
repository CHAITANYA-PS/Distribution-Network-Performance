package dto;

/** Communication DTO for ContinuityStatusType; contains scalar values only and no DAO behavior. */
public class ContinuityStatusTypeDTO {
    private Long continuityStatusId;
    private String statusName;
    private String description;

    public ContinuityStatusTypeDTO() {}

    public Long getContinuityStatusId() { return continuityStatusId; }
    public void setContinuityStatusId(Long continuityStatusId) { this.continuityStatusId = continuityStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

}
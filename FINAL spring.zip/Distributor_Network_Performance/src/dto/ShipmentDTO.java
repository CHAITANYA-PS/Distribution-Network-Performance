package dto;

import java.time.LocalDate;

/** Communication DTO for Shipment; contains scalar values only and no DAO behavior. */
public class ShipmentDTO {
    private Long shipmentId;
    private String trackingNumber;
    private Long warehouseId;
    private Long shipmentStatusId;
    private LocalDate dispatchDate;
    private LocalDate deliveryDate;

    public ShipmentDTO() {}

    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }

    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) { this.trackingNumber = trackingNumber; }

    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }

    public Long getShipmentStatusId() { return shipmentStatusId; }
    public void setShipmentStatusId(Long shipmentStatusId) { this.shipmentStatusId = shipmentStatusId; }

    public LocalDate getDispatchDate() { return dispatchDate; }
    public void setDispatchDate(LocalDate dispatchDate) { this.dispatchDate = dispatchDate; }

    public LocalDate getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(LocalDate deliveryDate) { this.deliveryDate = deliveryDate; }

}
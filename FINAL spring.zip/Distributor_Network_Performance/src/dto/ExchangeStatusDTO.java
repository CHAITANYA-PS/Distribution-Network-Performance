package dto;

/** Communication DTO for ExchangeStatus; contains scalar values only and no DAO behavior. */
public class ExchangeStatusDTO {
    private Long exchangeStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public ExchangeStatusDTO() {}

    public Long getExchangeStatusId() { return exchangeStatusId; }
    public void setExchangeStatusId(Long exchangeStatusId) { this.exchangeStatusId = exchangeStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }

    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

}
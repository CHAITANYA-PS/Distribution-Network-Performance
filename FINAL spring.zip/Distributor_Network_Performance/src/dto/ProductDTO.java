package dto;

/** Communication DTO for Product; contains scalar values only and no DAO behavior. */
public class ProductDTO {
    private Long productId;
    private String sku;
    private String productName;
    private Long categoryId;
    private String unit;
    private Integer shelfLifeDays;
    private String status;

    public ProductDTO() {}

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }

    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }

    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public Integer getShelfLifeDays() { return shelfLifeDays; }
    public void setShelfLifeDays(Integer shelfLifeDays) { this.shelfLifeDays = shelfLifeDays; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

}
package dto;

/** Communication DTO for Region; contains scalar values only and no DAO behavior. */
public class RegionDTO {
    private Long regionId;
    private String regionName;
    private String description;

    public RegionDTO() {}

    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }

    public String getRegionName() { return regionName; }
    public void setRegionName(String regionName) { this.regionName = regionName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

}
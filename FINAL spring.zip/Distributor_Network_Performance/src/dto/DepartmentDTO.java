package dto;

/** Communication DTO for Department; contains scalar values only and no DAO behavior. */
public class DepartmentDTO {
    private Long departmentId;
    private String departmentName;

    public DepartmentDTO() {}

    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

    public String getDepartmentName() { return departmentName; }
    public void setDepartmentName(String departmentName) { this.departmentName = departmentName; }

}
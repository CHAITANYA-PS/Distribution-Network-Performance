package dto;

/** Communication DTO for VehicleType; contains scalar values only and no DAO behavior. */
public class VehicleTypeDTO {
    private Long vehicleTypeId;
    private String vehicleName;
    private String fuelType;

    public VehicleTypeDTO() {}

    public Long getVehicleTypeId() { return vehicleTypeId; }
    public void setVehicleTypeId(Long vehicleTypeId) { this.vehicleTypeId = vehicleTypeId; }

    public String getVehicleName() { return vehicleName; }
    public void setVehicleName(String vehicleName) { this.vehicleName = vehicleName; }

    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

}
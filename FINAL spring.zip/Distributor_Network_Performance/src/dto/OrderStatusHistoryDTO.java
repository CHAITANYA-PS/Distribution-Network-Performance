package dto;

import java.time.OffsetDateTime;

/** Communication DTO for OrderStatusHistory; contains scalar values only and no DAO behavior. */
public class OrderStatusHistoryDTO {
    private Long orderStatusHistoryId;
    private Long orderId;
    private Long orderStatusId;
    private Long changedBy;
    private String remarks;
    private OffsetDateTime changedAt;

    public OrderStatusHistoryDTO() {}

    public Long getOrderStatusHistoryId() { return orderStatusHistoryId; }
    public void setOrderStatusHistoryId(Long orderStatusHistoryId) { this.orderStatusHistoryId = orderStatusHistoryId; }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }

    public Long getOrderStatusId() { return orderStatusId; }
    public void setOrderStatusId(Long orderStatusId) { this.orderStatusId = orderStatusId; }

    public Long getChangedBy() { return changedBy; }
    public void setChangedBy(Long changedBy) { this.changedBy = changedBy; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public OffsetDateTime getChangedAt() { return changedAt; }
    public void setChangedAt(OffsetDateTime changedAt) { this.changedAt = changedAt; }

}
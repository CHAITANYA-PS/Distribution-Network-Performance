package dto;

/** Communication DTO for SystemAdmin; contains scalar values only and no DAO behavior. */
public class SystemAdminDTO {
    private Long userId;
    private String adminLevel;

    public SystemAdminDTO() {}

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }

    public String getAdminLevel() { return adminLevel; }
    public void setAdminLevel(String adminLevel) { this.adminLevel = adminLevel; }

}
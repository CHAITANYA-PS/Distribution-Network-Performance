package dto;

/** Communication DTO for ReportFilter; contains scalar values only and no DAO behavior. */
public class ReportFilterDTO {
    private Long reportFilterId;
    private Long reportId;
    private String filterName;

    public ReportFilterDTO() {}

    public Long getReportFilterId() { return reportFilterId; }
    public void setReportFilterId(Long reportFilterId) { this.reportFilterId = reportFilterId; }

    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }

    public String getFilterName() { return filterName; }
    public void setFilterName(String filterName) { this.filterName = filterName; }

}
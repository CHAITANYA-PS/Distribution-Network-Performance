package dto;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Communication DTO for CreditRiskAssessment; contains scalar values only and no DAO behavior. */
public class CreditRiskAssessmentDTO {
    private Long riskAssessmentId;
    private Long distributorId;
    private Long creditLimitId;
    private BigDecimal riskScore;
    private Long assessedBy;
    private OffsetDateTime assessedAt;

    public CreditRiskAssessmentDTO() {}

    public Long getRiskAssessmentId() { return riskAssessmentId; }
    public void setRiskAssessmentId(Long riskAssessmentId) { this.riskAssessmentId = riskAssessmentId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getCreditLimitId() { return creditLimitId; }
    public void setCreditLimitId(Long creditLimitId) { this.creditLimitId = creditLimitId; }

    public BigDecimal getRiskScore() { return riskScore; }
    public void setRiskScore(BigDecimal riskScore) { this.riskScore = riskScore; }

    public Long getAssessedBy() { return assessedBy; }
    public void setAssessedBy(Long assessedBy) { this.assessedBy = assessedBy; }

    public OffsetDateTime getAssessedAt() { return assessedAt; }
    public void setAssessedAt(OffsetDateTime assessedAt) { this.assessedAt = assessedAt; }

}
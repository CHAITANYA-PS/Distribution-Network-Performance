package dto;

/** Communication DTO for ActivityType; contains scalar values only and no DAO behavior. */
public class ActivityTypeDTO {
    private Long activityTypeId;
    private String activityTypeName;
    private String description;

    public ActivityTypeDTO() {}

    public Long getActivityTypeId() { return activityTypeId; }
    public void setActivityTypeId(Long activityTypeId) { this.activityTypeId = activityTypeId; }

    public String getActivityTypeName() { return activityTypeName; }
    public void setActivityTypeName(String activityTypeName) { this.activityTypeName = activityTypeName; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

}
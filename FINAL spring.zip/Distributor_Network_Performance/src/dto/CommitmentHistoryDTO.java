package dto;

import java.time.OffsetDateTime;

/** Communication DTO for CommitmentHistory; contains scalar values only and no DAO behavior. */
public class CommitmentHistoryDTO {
    private Long historyId;
    private Long commitmentId;
    private String action;
    private Long actionBy;
    private String remarks;
    private OffsetDateTime actionAt;

    public CommitmentHistoryDTO() {}

    public Long getHistoryId() { return historyId; }
    public void setHistoryId(Long historyId) { this.historyId = historyId; }

    public Long getCommitmentId() { return commitmentId; }
    public void setCommitmentId(Long commitmentId) { this.commitmentId = commitmentId; }

    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }

    public Long getActionBy() { return actionBy; }
    public void setActionBy(Long actionBy) { this.actionBy = actionBy; }

    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public OffsetDateTime getActionAt() { return actionAt; }
    public void setActionAt(OffsetDateTime actionAt) { this.actionAt = actionAt; }

}
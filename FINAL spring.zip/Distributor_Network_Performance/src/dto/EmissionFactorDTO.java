package dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for EmissionFactor; contains scalar values only and no DAO behavior. */
public class EmissionFactorDTO {
    private Long emissionFactorId;
    private Long vehicleTypeId;
    private BigDecimal factorValue;
    private String unit;
    private LocalDate validFrom;
    private LocalDate validTo;

    public EmissionFactorDTO() {}

    public Long getEmissionFactorId() { return emissionFactorId; }
    public void setEmissionFactorId(Long emissionFactorId) { this.emissionFactorId = emissionFactorId; }

    public Long getVehicleTypeId() { return vehicleTypeId; }
    public void setVehicleTypeId(Long vehicleTypeId) { this.vehicleTypeId = vehicleTypeId; }

    public BigDecimal getFactorValue() { return factorValue; }
    public void setFactorValue(BigDecimal factorValue) { this.factorValue = factorValue; }

    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }

    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }

    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate validTo) { this.validTo = validTo; }

}
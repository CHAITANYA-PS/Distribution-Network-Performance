package dto;

import java.time.OffsetDateTime;

/** Communication DTO for Ticket; contains scalar values only and no DAO behavior. */
public class TicketDTO {
    private Long ticketId;
    private Long distributorId;
    private Long ticketCategoryId;
    private Long ticketStatusId;
    private Long ticketPriorityId;
    private String subject;
    private String description;
    private Long createdBy;
    private OffsetDateTime createdAt;
    private OffsetDateTime closedAt;

    public TicketDTO() {}

    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getTicketCategoryId() { return ticketCategoryId; }
    public void setTicketCategoryId(Long ticketCategoryId) { this.ticketCategoryId = ticketCategoryId; }

    public Long getTicketStatusId() { return ticketStatusId; }
    public void setTicketStatusId(Long ticketStatusId) { this.ticketStatusId = ticketStatusId; }

    public Long getTicketPriorityId() { return ticketPriorityId; }
    public void setTicketPriorityId(Long ticketPriorityId) { this.ticketPriorityId = ticketPriorityId; }

    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }

    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }

    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public OffsetDateTime getClosedAt() { return closedAt; }
    public void setClosedAt(OffsetDateTime closedAt) { this.closedAt = closedAt; }

}
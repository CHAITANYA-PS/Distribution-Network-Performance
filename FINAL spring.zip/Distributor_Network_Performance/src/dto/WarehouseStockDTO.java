package dto;

import java.math.BigDecimal;

/** Communication DTO for WarehouseStock; contains scalar values only and no DAO behavior. */
public class WarehouseStockDTO {
    private Long warehouseStockId;
    private Long warehouseId;
    private Long productBatchId;
    private Long ownerDistributorId;
    private BigDecimal reorderLevel;

    public WarehouseStockDTO() {}

    public Long getWarehouseStockId() { return warehouseStockId; }
    public void setWarehouseStockId(Long warehouseStockId) { this.warehouseStockId = warehouseStockId; }

    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }

    public Long getProductBatchId() { return productBatchId; }
    public void setProductBatchId(Long productBatchId) { this.productBatchId = productBatchId; }

    public Long getOwnerDistributorId() { return ownerDistributorId; }
    public void setOwnerDistributorId(Long ownerDistributorId) { this.ownerDistributorId = ownerDistributorId; }

    public BigDecimal getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(BigDecimal reorderLevel) { this.reorderLevel = reorderLevel; }

}
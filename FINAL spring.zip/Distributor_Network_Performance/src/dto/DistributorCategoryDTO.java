package dto;

import java.time.OffsetDateTime;

/** Communication DTO for DistributorCategory; contains scalar values only and no DAO behavior. */
public class DistributorCategoryDTO {
    private Long distributorCategoryId;
    private Long distributorId;
    private Long categoryId;
    private OffsetDateTime assignedAt;
    private String status;

    public DistributorCategoryDTO() {}

    public Long getDistributorCategoryId() { return distributorCategoryId; }
    public void setDistributorCategoryId(Long distributorCategoryId) { this.distributorCategoryId = distributorCategoryId; }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }

    public OffsetDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(OffsetDateTime assignedAt) { this.assignedAt = assignedAt; }

    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

}
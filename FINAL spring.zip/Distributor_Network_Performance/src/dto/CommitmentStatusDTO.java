package dto;

/** Communication DTO for CommitmentStatus; contains scalar values only and no DAO behavior. */
public class CommitmentStatusDTO {
    private Long commitmentStatusId;
    private String statusName;
    private Boolean isTerminal;

    public CommitmentStatusDTO() {}

    public Long getCommitmentStatusId() { return commitmentStatusId; }
    public void setCommitmentStatusId(Long commitmentStatusId) { this.commitmentStatusId = commitmentStatusId; }

    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

}
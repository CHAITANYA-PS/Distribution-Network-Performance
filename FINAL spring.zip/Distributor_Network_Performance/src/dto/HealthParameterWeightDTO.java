package dto;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Communication DTO for HealthParameterWeight; contains scalar values only and no DAO behavior. */
public class HealthParameterWeightDTO {
    private Long parameterWeightId;
    private Long parameterId;
    private BigDecimal weight;
    private LocalDate validFrom;
    private LocalDate validTo;

    public HealthParameterWeightDTO() {}

    public Long getParameterWeightId() { return parameterWeightId; }
    public void setParameterWeightId(Long parameterWeightId) { this.parameterWeightId = parameterWeightId; }

    public Long getParameterId() { return parameterId; }
    public void setParameterId(Long parameterId) { this.parameterId = parameterId; }

    public BigDecimal getWeight() { return weight; }
    public void setWeight(BigDecimal weight) { this.weight = weight; }

    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }

    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate validTo) { this.validTo = validTo; }

}
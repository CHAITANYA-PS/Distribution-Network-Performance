package entity;

/** Maps to dsphere.payment_method. */
public class PaymentMethod {
    private Long paymentMethodId;
    private String methodName;

    public PaymentMethod() {}
    public PaymentMethod(Long paymentMethodId, String methodName) {
        this.paymentMethodId = paymentMethodId;
        this.methodName = methodName;
    }

    public Long getPaymentMethodId() { return paymentMethodId; }
    public void setPaymentMethodId(Long paymentMethodId) { this.paymentMethodId = paymentMethodId; }
    public String getMethodName() { return methodName; }
    public void setMethodName(String methodName) { this.methodName = methodName; }

    @Override
    public String toString() {
        return "PaymentMethod{" + "paymentMethodId=" + paymentMethodId + ", " + "methodName=" + methodName + "}";
    }
}
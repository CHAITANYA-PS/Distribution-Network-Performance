package entity;

/** Maps to dsphere.product. */
public class Product {
    private Long productId;
    private String sku;
    private String productName;
    private Long categoryId;
    private String unit;
    private Integer shelfLifeDays;
    private String status;

    /** Object relationship for FK categoryId; the scalar FK remains the persistence source of truth. */
    private Category category;
    public Product() {}
    public Product(Long productId, String sku, String productName, Long categoryId, String unit, Integer shelfLifeDays, String status) {
        this.productId = productId;
        this.sku = sku;
        this.productName = productName;
        this.categoryId = categoryId;
        this.unit = unit;
        this.shelfLifeDays = shelfLifeDays;
        this.status = status;
    }

    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public String getSku() { return sku; }
    public void setSku(String sku) { this.sku = sku; }
    public String getProductName() { return productName; }
    public void setProductName(String productName) { this.productName = productName; }
    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    public Integer getShelfLifeDays() { return shelfLifeDays; }
    public void setShelfLifeDays(Integer shelfLifeDays) { this.shelfLifeDays = shelfLifeDays; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Category getCategory() { return category; }
    public void setCategory(Category category) {
        this.category = category;
        this.categoryId = category == null ? null : category.getCategoryId();
    }
    @Override
    public String toString() {
        return "Product{" + "productId=" + productId + ", " + "sku=" + sku + ", " + "productName=" + productName + ", " + "categoryId=" + categoryId + ", " + "unit=" + unit + ", " + "shelfLifeDays=" + shelfLifeDays + ", " + "status=" + status + "}";
    }
}
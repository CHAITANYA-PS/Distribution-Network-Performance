package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.sales_record. */
public class SalesRecord {
    private Long salesRecordId;
    private Long orderId;
    private LocalDate saleDate;
    private BigDecimal recognizedAmount;

    /** Object relationship for FK orderId; the scalar FK remains the persistence source of truth. */
    private DistributorOrder order;
    public SalesRecord() {}
    public SalesRecord(Long salesRecordId, Long orderId, LocalDate saleDate, BigDecimal recognizedAmount) {
        this.salesRecordId = salesRecordId;
        this.orderId = orderId;
        this.saleDate = saleDate;
        this.recognizedAmount = recognizedAmount;
    }

    public Long getSalesRecordId() { return salesRecordId; }
    public void setSalesRecordId(Long salesRecordId) { this.salesRecordId = salesRecordId; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public LocalDate getSaleDate() { return saleDate; }
    public void setSaleDate(LocalDate saleDate) { this.saleDate = saleDate; }
    public BigDecimal getRecognizedAmount() { return recognizedAmount; }
    public void setRecognizedAmount(BigDecimal recognizedAmount) { this.recognizedAmount = recognizedAmount; }

    public DistributorOrder getOrder() { return order; }
    public void setOrder(DistributorOrder order) {
        this.order = order;
        this.orderId = order == null ? null : order.getOrderId();
    }
    @Override
    public String toString() {
        return "SalesRecord{" + "salesRecordId=" + salesRecordId + ", " + "orderId=" + orderId + ", " + "saleDate=" + saleDate + ", " + "recognizedAmount=" + recognizedAmount + "}";
    }
}
package entity;

import java.io.Serializable;
import java.math.BigDecimal;

public class OrderTotalView implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long orderId;
    private String customerName;
    private Integer totalItems;
    private BigDecimal totalAmount;
    private String orderStatus;

    public OrderTotalView() {
    }

    public Long getOrderId() {
        return orderId;
    }

    public void setOrderId(Long orderId) {
        this.orderId = orderId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Integer getTotalItems() {
        return totalItems;
    }

    public void setTotalItems(Integer totalItems) {
        this.totalItems = totalItems;
    }

    public BigDecimal getTotalAmount() {
        return totalAmount;
    }

    public void setTotalAmount(BigDecimal totalAmount) {
        this.totalAmount = totalAmount;
    }

    public String getOrderStatus() {
        return orderStatus;
    }

    public void setOrderStatus(String orderStatus) {
        this.orderStatus = orderStatus;
    }

    @Override
    public String toString() {
        return "OrderTotalView [orderId=" + orderId
                + ", customerName=" + customerName
                + ", totalItems=" + totalItems
                + ", totalAmount=" + totalAmount
                + ", orderStatus=" + orderStatus + "]";
    }
}
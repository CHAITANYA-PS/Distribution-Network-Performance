package entity;

/** Maps to dsphere.distributor_user. */
public class DistributorUser {
    private Long userId;
    private Long distributorId;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    public DistributorUser() {}
    public DistributorUser(Long userId, Long distributorId) {
        this.userId = userId;
        this.distributorId = distributorId;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    @Override
    public String toString() {
        return "DistributorUser{" + "userId=" + userId + ", " + "distributorId=" + distributorId + "}";
    }
}
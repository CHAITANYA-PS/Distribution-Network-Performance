package entity;

/** Maps to dsphere.exchange_status. */
public class ExchangeStatus {
    private Long exchangeStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public ExchangeStatus() {}
    public ExchangeStatus(Long exchangeStatusId, String statusName, Integer sequenceNumber, Boolean isTerminal) {
        this.exchangeStatusId = exchangeStatusId;
        this.statusName = statusName;
        this.sequenceNumber = sequenceNumber;
        this.isTerminal = isTerminal;
    }

    public Long getExchangeStatusId() { return exchangeStatusId; }
    public void setExchangeStatusId(Long exchangeStatusId) { this.exchangeStatusId = exchangeStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }
    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }
    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

    @Override
    public String toString() {
        return "ExchangeStatus{" + "exchangeStatusId=" + exchangeStatusId + ", " + "statusName=" + statusName + ", " + "sequenceNumber=" + sequenceNumber + ", " + "isTerminal=" + isTerminal + "}";
    }
}
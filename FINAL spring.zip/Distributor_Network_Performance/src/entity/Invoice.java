package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.invoice. */
public class Invoice {
    private Long invoiceId;
    private String invoiceNumber;
    private Long orderId;
    private Long invoiceStatusId;
    private LocalDate invoiceDate;
    private LocalDate dueDate;
    private BigDecimal invoiceAmount;

    /** Object relationship for FK orderId; the scalar FK remains the persistence source of truth. */
    private DistributorOrder order;
    /** Object relationship for FK invoiceStatusId; the scalar FK remains the persistence source of truth. */
    private InvoiceStatus invoiceStatus;
    public Invoice() {}
    public Invoice(Long invoiceId, String invoiceNumber, Long orderId, Long invoiceStatusId, LocalDate invoiceDate, LocalDate dueDate, BigDecimal invoiceAmount) {
        this.invoiceId = invoiceId;
        this.invoiceNumber = invoiceNumber;
        this.orderId = orderId;
        this.invoiceStatusId = invoiceStatusId;
        this.invoiceDate = invoiceDate;
        this.dueDate = dueDate;
        this.invoiceAmount = invoiceAmount;
    }

    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }
    public String getInvoiceNumber() { return invoiceNumber; }
    public void setInvoiceNumber(String invoiceNumber) { this.invoiceNumber = invoiceNumber; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Long getInvoiceStatusId() { return invoiceStatusId; }
    public void setInvoiceStatusId(Long invoiceStatusId) { this.invoiceStatusId = invoiceStatusId; }
    public LocalDate getInvoiceDate() { return invoiceDate; }
    public void setInvoiceDate(LocalDate invoiceDate) { this.invoiceDate = invoiceDate; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public BigDecimal getInvoiceAmount() { return invoiceAmount; }
    public void setInvoiceAmount(BigDecimal invoiceAmount) { this.invoiceAmount = invoiceAmount; }

    public DistributorOrder getOrder() { return order; }
    public void setOrder(DistributorOrder order) {
        this.order = order;
        this.orderId = order == null ? null : order.getOrderId();
    }
    public InvoiceStatus getInvoiceStatus() { return invoiceStatus; }
    public void setInvoiceStatus(InvoiceStatus invoiceStatus) {
        this.invoiceStatus = invoiceStatus;
        this.invoiceStatusId = invoiceStatus == null ? null : invoiceStatus.getInvoiceStatusId();
    }
    @Override
    public String toString() {
        return "Invoice{" + "invoiceId=" + invoiceId + ", " + "invoiceNumber=" + invoiceNumber + ", " + "orderId=" + orderId + ", " + "invoiceStatusId=" + invoiceStatusId + ", " + "invoiceDate=" + invoiceDate + ", " + "dueDate=" + dueDate + ", " + "invoiceAmount=" + invoiceAmount + "}";
    }
}
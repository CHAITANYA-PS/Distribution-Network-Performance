package entity;

/** Maps to dsphere.movement_type. */
public class MovementType {
    private Long movementTypeId;
    private String movementTypeName;
    private String movementDirection;

    public MovementType() {}
    public MovementType(Long movementTypeId, String movementTypeName, String movementDirection) {
        this.movementTypeId = movementTypeId;
        this.movementTypeName = movementTypeName;
        this.movementDirection = movementDirection;
    }

    public Long getMovementTypeId() { return movementTypeId; }
    public void setMovementTypeId(Long movementTypeId) { this.movementTypeId = movementTypeId; }
    public String getMovementTypeName() { return movementTypeName; }
    public void setMovementTypeName(String movementTypeName) { this.movementTypeName = movementTypeName; }
    public String getMovementDirection() { return movementDirection; }
    public void setMovementDirection(String movementDirection) { this.movementDirection = movementDirection; }

    @Override
    public String toString() {
        return "MovementType{" + "movementTypeId=" + movementTypeId + ", " + "movementTypeName=" + movementTypeName + ", " + "movementDirection=" + movementDirection + "}";
    }
}
package entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Maps to dsphere.commitment. */
public class Commitment {
    private Long commitmentId;
    private Long distributorId;
    private Long measurementUnitId;
    private Long commitmentStatusId;
    private String targetName;
    private BigDecimal targetValue;
    private LocalDate dueDate;
    private Long createdBy;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK measurementUnitId; the scalar FK remains the persistence source of truth. */
    private MeasurementUnit measurementUnit;
    /** Object relationship for FK commitmentStatusId; the scalar FK remains the persistence source of truth. */
    private CommitmentStatus commitmentStatus;
    /** Object relationship for FK createdBy; the scalar FK remains the persistence source of truth. */
    private AppUser creator;
    public Commitment() {}
    public Commitment(Long commitmentId, Long distributorId, Long measurementUnitId, Long commitmentStatusId, String targetName, BigDecimal targetValue, LocalDate dueDate, Long createdBy, OffsetDateTime createdAt, OffsetDateTime updatedAt) {
        this.commitmentId = commitmentId;
        this.distributorId = distributorId;
        this.measurementUnitId = measurementUnitId;
        this.commitmentStatusId = commitmentStatusId;
        this.targetName = targetName;
        this.targetValue = targetValue;
        this.dueDate = dueDate;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getCommitmentId() { return commitmentId; }
    public void setCommitmentId(Long commitmentId) { this.commitmentId = commitmentId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getMeasurementUnitId() { return measurementUnitId; }
    public void setMeasurementUnitId(Long measurementUnitId) { this.measurementUnitId = measurementUnitId; }
    public Long getCommitmentStatusId() { return commitmentStatusId; }
    public void setCommitmentStatusId(Long commitmentStatusId) { this.commitmentStatusId = commitmentStatusId; }
    public String getTargetName() { return targetName; }
    public void setTargetName(String targetName) { this.targetName = targetName; }
    public BigDecimal getTargetValue() { return targetValue; }
    public void setTargetValue(BigDecimal targetValue) { this.targetValue = targetValue; }
    public LocalDate getDueDate() { return dueDate; }
    public void setDueDate(LocalDate dueDate) { this.dueDate = dueDate; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public MeasurementUnit getMeasurementUnit() { return measurementUnit; }
    public void setMeasurementUnit(MeasurementUnit measurementUnit) {
        this.measurementUnit = measurementUnit;
        this.measurementUnitId = measurementUnit == null ? null : measurementUnit.getMeasurementUnitId();
    }
    public CommitmentStatus getCommitmentStatus() { return commitmentStatus; }
    public void setCommitmentStatus(CommitmentStatus commitmentStatus) {
        this.commitmentStatus = commitmentStatus;
        this.commitmentStatusId = commitmentStatus == null ? null : commitmentStatus.getCommitmentStatusId();
    }
    public AppUser getCreator() { return creator; }
    public void setCreator(AppUser creator) {
        this.creator = creator;
        this.createdBy = creator == null ? null : creator.getUserId();
    }
    @Override
    public String toString() {
        return "Commitment{" + "commitmentId=" + commitmentId + ", " + "distributorId=" + distributorId + ", " + "measurementUnitId=" + measurementUnitId + ", " + "commitmentStatusId=" + commitmentStatusId + ", " + "targetName=" + targetName + ", " + "targetValue=" + targetValue + ", " + "dueDate=" + dueDate + ", " + "createdBy=" + createdBy + ", " + "createdAt=" + createdAt + ", " + "updatedAt=" + updatedAt + "}";
    }
}
package entity;

/** Maps to dsphere.finance_manager. */
public class FinanceManager {
    private Long userId;
    private Long departmentId;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    /** Object relationship for FK departmentId; the scalar FK remains the persistence source of truth. */
    private Department department;
    public FinanceManager() {}
    public FinanceManager(Long userId, Long departmentId) {
        this.userId = userId;
        this.departmentId = departmentId;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getDepartmentId() { return departmentId; }
    public void setDepartmentId(Long departmentId) { this.departmentId = departmentId; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    public Department getDepartment() { return department; }
    public void setDepartment(Department department) {
        this.department = department;
        this.departmentId = department == null ? null : department.getDepartmentId();
    }
    @Override
    public String toString() {
        return "FinanceManager{" + "userId=" + userId + ", " + "departmentId=" + departmentId + "}";
    }
}
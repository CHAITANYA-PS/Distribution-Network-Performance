package entity;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Maps to dsphere.inventory_document. */
public class InventoryDocument {
    private Long inventoryDocumentId;
    private Long inventoryDocumentTypeId;
    private String documentNumber;
    private LocalDate documentDate;
    private Long createdBy;
    private OffsetDateTime createdAt;

    /** Object relationship for FK inventoryDocumentTypeId; the scalar FK remains the persistence source of truth. */
    private InventoryDocumentType inventoryDocumentType;
    /** Object relationship for FK createdBy; the scalar FK remains the persistence source of truth. */
    private AppUser creator;
    public InventoryDocument() {}
    public InventoryDocument(Long inventoryDocumentId, Long inventoryDocumentTypeId, String documentNumber, LocalDate documentDate, Long createdBy, OffsetDateTime createdAt) {
        this.inventoryDocumentId = inventoryDocumentId;
        this.inventoryDocumentTypeId = inventoryDocumentTypeId;
        this.documentNumber = documentNumber;
        this.documentDate = documentDate;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public Long getInventoryDocumentId() { return inventoryDocumentId; }
    public void setInventoryDocumentId(Long inventoryDocumentId) { this.inventoryDocumentId = inventoryDocumentId; }
    public Long getInventoryDocumentTypeId() { return inventoryDocumentTypeId; }
    public void setInventoryDocumentTypeId(Long inventoryDocumentTypeId) { this.inventoryDocumentTypeId = inventoryDocumentTypeId; }
    public String getDocumentNumber() { return documentNumber; }
    public void setDocumentNumber(String documentNumber) { this.documentNumber = documentNumber; }
    public LocalDate getDocumentDate() { return documentDate; }
    public void setDocumentDate(LocalDate documentDate) { this.documentDate = documentDate; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public InventoryDocumentType getInventoryDocumentType() { return inventoryDocumentType; }
    public void setInventoryDocumentType(InventoryDocumentType inventoryDocumentType) {
        this.inventoryDocumentType = inventoryDocumentType;
        this.inventoryDocumentTypeId = inventoryDocumentType == null ? null : inventoryDocumentType.getInventoryDocumentTypeId();
    }
    public AppUser getCreator() { return creator; }
    public void setCreator(AppUser creator) {
        this.creator = creator;
        this.createdBy = creator == null ? null : creator.getUserId();
    }
    @Override
    public String toString() {
        return "InventoryDocument{" + "inventoryDocumentId=" + inventoryDocumentId + ", " + "inventoryDocumentTypeId=" + inventoryDocumentTypeId + ", " + "documentNumber=" + documentNumber + ", " + "documentDate=" + documentDate + ", " + "createdBy=" + createdBy + ", " + "createdAt=" + createdAt + "}";
    }
}
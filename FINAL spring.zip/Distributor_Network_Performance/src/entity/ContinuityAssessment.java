package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.continuity_assessment. */
public class ContinuityAssessment {
    private Long continuityAssessmentId;
    private Long distributorId;
    private Long continuityStatusId;
    private Long riskLevelId;
    private Long assessedBy;
    private OffsetDateTime assessmentDate;
    private String remarks;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK continuityStatusId; the scalar FK remains the persistence source of truth. */
    private ContinuityStatusType continuityStatus;
    /** Object relationship for FK riskLevelId; the scalar FK remains the persistence source of truth. */
    private RiskLevel riskLevel;
    /** Object relationship for FK assessedBy; the scalar FK remains the persistence source of truth. */
    private AppUser assessor;
    public ContinuityAssessment() {}
    public ContinuityAssessment(Long continuityAssessmentId, Long distributorId, Long continuityStatusId, Long riskLevelId, Long assessedBy, OffsetDateTime assessmentDate, String remarks) {
        this.continuityAssessmentId = continuityAssessmentId;
        this.distributorId = distributorId;
        this.continuityStatusId = continuityStatusId;
        this.riskLevelId = riskLevelId;
        this.assessedBy = assessedBy;
        this.assessmentDate = assessmentDate;
        this.remarks = remarks;
    }

    public Long getContinuityAssessmentId() { return continuityAssessmentId; }
    public void setContinuityAssessmentId(Long continuityAssessmentId) { this.continuityAssessmentId = continuityAssessmentId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getContinuityStatusId() { return continuityStatusId; }
    public void setContinuityStatusId(Long continuityStatusId) { this.continuityStatusId = continuityStatusId; }
    public Long getRiskLevelId() { return riskLevelId; }
    public void setRiskLevelId(Long riskLevelId) { this.riskLevelId = riskLevelId; }
    public Long getAssessedBy() { return assessedBy; }
    public void setAssessedBy(Long assessedBy) { this.assessedBy = assessedBy; }
    public OffsetDateTime getAssessmentDate() { return assessmentDate; }
    public void setAssessmentDate(OffsetDateTime assessmentDate) { this.assessmentDate = assessmentDate; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public ContinuityStatusType getContinuityStatus() { return continuityStatus; }
    public void setContinuityStatus(ContinuityStatusType continuityStatus) {
        this.continuityStatus = continuityStatus;
        this.continuityStatusId = continuityStatus == null ? null : continuityStatus.getContinuityStatusId();
    }
    public RiskLevel getRiskLevel() { return riskLevel; }
    public void setRiskLevel(RiskLevel riskLevel) {
        this.riskLevel = riskLevel;
        this.riskLevelId = riskLevel == null ? null : riskLevel.getRiskLevelId();
    }
    public AppUser getAssessor() { return assessor; }
    public void setAssessor(AppUser assessor) {
        this.assessor = assessor;
        this.assessedBy = assessor == null ? null : assessor.getUserId();
    }
    @Override
    public String toString() {
        return "ContinuityAssessment{" + "continuityAssessmentId=" + continuityAssessmentId + ", " + "distributorId=" + distributorId + ", " + "continuityStatusId=" + continuityStatusId + ", " + "riskLevelId=" + riskLevelId + ", " + "assessedBy=" + assessedBy + ", " + "assessmentDate=" + assessmentDate + ", " + "remarks=" + remarks + "}";
    }
}
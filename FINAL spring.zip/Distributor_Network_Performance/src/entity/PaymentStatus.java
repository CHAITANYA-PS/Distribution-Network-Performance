package entity;

/** Maps to dsphere.payment_status. */
public class PaymentStatus {
    private Long paymentStatusId;
    private String statusName;

    public PaymentStatus() {}
    public PaymentStatus(Long paymentStatusId, String statusName) {
        this.paymentStatusId = paymentStatusId;
        this.statusName = statusName;
    }

    public Long getPaymentStatusId() { return paymentStatusId; }
    public void setPaymentStatusId(Long paymentStatusId) { this.paymentStatusId = paymentStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    @Override
    public String toString() {
        return "PaymentStatus{" + "paymentStatusId=" + paymentStatusId + ", " + "statusName=" + statusName + "}";
    }
}
package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.app_user. */
public class AppUser {
    private Long userId;
    private String email;
    private String userName;
    private String passwordHash;
    private String phone;
    private Boolean mfaEnabled;
    private String status;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    public AppUser() {}
    public AppUser(Long userId, String email, String userName, String passwordHash, String phone, Boolean mfaEnabled, String status, OffsetDateTime createdAt, OffsetDateTime updatedAt) {
        this.userId = userId;
        this.email = email;
        this.userName = userName;
        this.passwordHash = passwordHash;
        this.phone = phone;
        this.mfaEnabled = mfaEnabled;
        this.status = status;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getUserName() { return userName; }
    public void setUserName(String userName) { this.userName = userName; }
    public String getPasswordHash() { return passwordHash; }
    public void setPasswordHash(String passwordHash) { this.passwordHash = passwordHash; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public Boolean getMfaEnabled() { return mfaEnabled; }
    public void setMfaEnabled(Boolean mfaEnabled) { this.mfaEnabled = mfaEnabled; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    @Override
    public String toString() {
        return "AppUser{" + "userId=" + userId + ", " + "email=" + email + ", " + "userName=" + userName + ", " + "passwordHash=" + passwordHash + ", " + "phone=" + phone + ", " + "mfaEnabled=" + mfaEnabled + ", " + "status=" + status + ", " + "createdAt=" + createdAt + ", " + "updatedAt=" + updatedAt + "}";
    }
}
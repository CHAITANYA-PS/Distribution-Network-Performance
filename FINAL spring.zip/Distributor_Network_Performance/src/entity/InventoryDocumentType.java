package entity;

/** Maps to dsphere.inventory_document_type. */
public class InventoryDocumentType {
    private Long inventoryDocumentTypeId;
    private String documentTypeName;

    public InventoryDocumentType() {}
    public InventoryDocumentType(Long inventoryDocumentTypeId, String documentTypeName) {
        this.inventoryDocumentTypeId = inventoryDocumentTypeId;
        this.documentTypeName = documentTypeName;
    }

    public Long getInventoryDocumentTypeId() { return inventoryDocumentTypeId; }
    public void setInventoryDocumentTypeId(Long inventoryDocumentTypeId) { this.inventoryDocumentTypeId = inventoryDocumentTypeId; }
    public String getDocumentTypeName() { return documentTypeName; }
    public void setDocumentTypeName(String documentTypeName) { this.documentTypeName = documentTypeName; }

    @Override
    public String toString() {
        return "InventoryDocumentType{" + "inventoryDocumentTypeId=" + inventoryDocumentTypeId + ", " + "documentTypeName=" + documentTypeName + "}";
    }
}
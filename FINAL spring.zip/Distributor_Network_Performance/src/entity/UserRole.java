package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.user_role. */
public class UserRole {
    private Long userRoleId;
    private Long userId;
    private Long roleId;
    private OffsetDateTime assignedAt;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    /** Object relationship for FK roleId; the scalar FK remains the persistence source of truth. */
    private Role role;
    public UserRole() {}
    public UserRole(Long userRoleId, Long userId, Long roleId, OffsetDateTime assignedAt) {
        this.userRoleId = userRoleId;
        this.userId = userId;
        this.roleId = roleId;
        this.assignedAt = assignedAt;
    }

    public Long getUserRoleId() { return userRoleId; }
    public void setUserRoleId(Long userRoleId) { this.userRoleId = userRoleId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getRoleId() { return roleId; }
    public void setRoleId(Long roleId) { this.roleId = roleId; }
    public OffsetDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(OffsetDateTime assignedAt) { this.assignedAt = assignedAt; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    public Role getRole() { return role; }
    public void setRole(Role role) {
        this.role = role;
        this.roleId = role == null ? null : role.getRoleId();
    }
    @Override
    public String toString() {
        return "UserRole{" + "userRoleId=" + userRoleId + ", " + "userId=" + userId + ", " + "roleId=" + roleId + ", " + "assignedAt=" + assignedAt + "}";
    }
}
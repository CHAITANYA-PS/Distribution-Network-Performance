package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.inventory_alert. */
public class InventoryAlert {
    private Long alertId;
    private Long warehouseStockId;
    private String alertType;
    private String message;
    private String status;
    private OffsetDateTime createdAt;

    /** Object relationship for FK warehouseStockId; the scalar FK remains the persistence source of truth. */
    private WarehouseStock warehouseStock;
    public InventoryAlert() {}
    public InventoryAlert(Long alertId, Long warehouseStockId, String alertType, String message, String status, OffsetDateTime createdAt) {
        this.alertId = alertId;
        this.warehouseStockId = warehouseStockId;
        this.alertType = alertType;
        this.message = message;
        this.status = status;
        this.createdAt = createdAt;
    }

    public Long getAlertId() { return alertId; }
    public void setAlertId(Long alertId) { this.alertId = alertId; }
    public Long getWarehouseStockId() { return warehouseStockId; }
    public void setWarehouseStockId(Long warehouseStockId) { this.warehouseStockId = warehouseStockId; }
    public String getAlertType() { return alertType; }
    public void setAlertType(String alertType) { this.alertType = alertType; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public WarehouseStock getWarehouseStock() { return warehouseStock; }
    public void setWarehouseStock(WarehouseStock warehouseStock) {
        this.warehouseStock = warehouseStock;
        this.warehouseStockId = warehouseStock == null ? null : warehouseStock.getWarehouseStockId();
    }
    @Override
    public String toString() {
        return "InventoryAlert{" + "alertId=" + alertId + ", " + "warehouseStockId=" + warehouseStockId + ", " + "alertType=" + alertType + ", " + "message=" + message + ", " + "status=" + status + ", " + "createdAt=" + createdAt + "}";
    }
}
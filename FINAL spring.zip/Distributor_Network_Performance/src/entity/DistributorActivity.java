package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.distributor_activity. */
public class DistributorActivity {
    private Long activityId;
    private Long distributorId;
    private Long activityTypeId;
    private OffsetDateTime activityDate;
    private Long recordedBy;
    private String remarks;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK activityTypeId; the scalar FK remains the persistence source of truth. */
    private ActivityType activityType;
    /** Object relationship for FK recordedBy; the scalar FK remains the persistence source of truth. */
    private AppUser recorder;
    public DistributorActivity() {}
    public DistributorActivity(Long activityId, Long distributorId, Long activityTypeId, OffsetDateTime activityDate, Long recordedBy, String remarks) {
        this.activityId = activityId;
        this.distributorId = distributorId;
        this.activityTypeId = activityTypeId;
        this.activityDate = activityDate;
        this.recordedBy = recordedBy;
        this.remarks = remarks;
    }

    public Long getActivityId() { return activityId; }
    public void setActivityId(Long activityId) { this.activityId = activityId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getActivityTypeId() { return activityTypeId; }
    public void setActivityTypeId(Long activityTypeId) { this.activityTypeId = activityTypeId; }
    public OffsetDateTime getActivityDate() { return activityDate; }
    public void setActivityDate(OffsetDateTime activityDate) { this.activityDate = activityDate; }
    public Long getRecordedBy() { return recordedBy; }
    public void setRecordedBy(Long recordedBy) { this.recordedBy = recordedBy; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public ActivityType getActivityType() { return activityType; }
    public void setActivityType(ActivityType activityType) {
        this.activityType = activityType;
        this.activityTypeId = activityType == null ? null : activityType.getActivityTypeId();
    }
    public AppUser getRecorder() { return recorder; }
    public void setRecorder(AppUser recorder) {
        this.recorder = recorder;
        this.recordedBy = recorder == null ? null : recorder.getUserId();
    }
    @Override
    public String toString() {
        return "DistributorActivity{" + "activityId=" + activityId + ", " + "distributorId=" + distributorId + ", " + "activityTypeId=" + activityTypeId + ", " + "activityDate=" + activityDate + ", " + "recordedBy=" + recordedBy + ", " + "remarks=" + remarks + "}";
    }
}
package entity;

/** Maps to dsphere.report_filter_value. */
public class ReportFilterValue {
    private Long reportFilterValueId;
    private Long reportFilterId;
    private String filterValue;

    /** Object relationship for FK reportFilterId; the scalar FK remains the persistence source of truth. */
    private ReportFilter reportFilter;
    public ReportFilterValue() {}
    public ReportFilterValue(Long reportFilterValueId, Long reportFilterId, String filterValue) {
        this.reportFilterValueId = reportFilterValueId;
        this.reportFilterId = reportFilterId;
        this.filterValue = filterValue;
    }

    public Long getReportFilterValueId() { return reportFilterValueId; }
    public void setReportFilterValueId(Long reportFilterValueId) { this.reportFilterValueId = reportFilterValueId; }
    public Long getReportFilterId() { return reportFilterId; }
    public void setReportFilterId(Long reportFilterId) { this.reportFilterId = reportFilterId; }
    public String getFilterValue() { return filterValue; }
    public void setFilterValue(String filterValue) { this.filterValue = filterValue; }

    public ReportFilter getReportFilter() { return reportFilter; }
    public void setReportFilter(ReportFilter reportFilter) {
        this.reportFilter = reportFilter;
        this.reportFilterId = reportFilter == null ? null : reportFilter.getReportFilterId();
    }
    @Override
    public String toString() {
        return "ReportFilterValue{" + "reportFilterValueId=" + reportFilterValueId + ", " + "reportFilterId=" + reportFilterId + ", " + "filterValue=" + filterValue + "}";
    }
}
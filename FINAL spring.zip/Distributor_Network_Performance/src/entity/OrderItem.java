package entity;

import java.math.BigDecimal;

/** Maps to dsphere.order_item. */
public class OrderItem {
    private Long orderItemId;
    private Long orderId;
    private Long productId;
    private BigDecimal quantity;
    private BigDecimal unitPrice;

    /** Object relationship for FK orderId; the scalar FK remains the persistence source of truth. */
    private DistributorOrder order;
    /** Object relationship for FK productId; the scalar FK remains the persistence source of truth. */
    private Product product;
    public OrderItem() {}
    public OrderItem(Long orderItemId, Long orderId, Long productId, BigDecimal quantity, BigDecimal unitPrice) {
        this.orderItemId = orderItemId;
        this.orderId = orderId;
        this.productId = productId;
        this.quantity = quantity;
        this.unitPrice = unitPrice;
    }

    public Long getOrderItemId() { return orderItemId; }
    public void setOrderItemId(Long orderItemId) { this.orderItemId = orderItemId; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }
    public BigDecimal getUnitPrice() { return unitPrice; }
    public void setUnitPrice(BigDecimal unitPrice) { this.unitPrice = unitPrice; }

    public DistributorOrder getOrder() { return order; }
    public void setOrder(DistributorOrder order) {
        this.order = order;
        this.orderId = order == null ? null : order.getOrderId();
    }
    public Product getProduct() { return product; }
    public void setProduct(Product product) {
        this.product = product;
        this.productId = product == null ? null : product.getProductId();
    }
    @Override
    public String toString() {
        return "OrderItem{" + "orderItemId=" + orderItemId + ", " + "orderId=" + orderId + ", " + "productId=" + productId + ", " + "quantity=" + quantity + ", " + "unitPrice=" + unitPrice + "}";
    }
}
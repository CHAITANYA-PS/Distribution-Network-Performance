package entity;

public class SalesPerformanceView {

}

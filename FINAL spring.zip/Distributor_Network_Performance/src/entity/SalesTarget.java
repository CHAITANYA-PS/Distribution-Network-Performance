package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.sales_target. */
public class SalesTarget {
    private Long targetId;
    private Long distributorId;
    private Long reportingPeriodId;
    private BigDecimal targetValue;
    private OffsetDateTime createdAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK reportingPeriodId; the scalar FK remains the persistence source of truth. */
    private ReportingPeriod reportingPeriod;
    public SalesTarget() {}
    public SalesTarget(Long targetId, Long distributorId, Long reportingPeriodId, BigDecimal targetValue, OffsetDateTime createdAt) {
        this.targetId = targetId;
        this.distributorId = distributorId;
        this.reportingPeriodId = reportingPeriodId;
        this.targetValue = targetValue;
        this.createdAt = createdAt;
    }

    public Long getTargetId() { return targetId; }
    public void setTargetId(Long targetId) { this.targetId = targetId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getReportingPeriodId() { return reportingPeriodId; }
    public void setReportingPeriodId(Long reportingPeriodId) { this.reportingPeriodId = reportingPeriodId; }
    public BigDecimal getTargetValue() { return targetValue; }
    public void setTargetValue(BigDecimal targetValue) { this.targetValue = targetValue; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public ReportingPeriod getReportingPeriod() { return reportingPeriod; }
    public void setReportingPeriod(ReportingPeriod reportingPeriod) {
        this.reportingPeriod = reportingPeriod;
        this.reportingPeriodId = reportingPeriod == null ? null : reportingPeriod.getReportingPeriodId();
    }
    @Override
    public String toString() {
        return "SalesTarget{" + "targetId=" + targetId + ", " + "distributorId=" + distributorId + ", " + "reportingPeriodId=" + reportingPeriodId + ", " + "targetValue=" + targetValue + ", " + "createdAt=" + createdAt + "}";
    }
}
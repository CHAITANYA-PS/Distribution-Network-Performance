package entity;

/** Maps to dsphere.vehicle_type. */
public class VehicleType {
    private Long vehicleTypeId;
    private String vehicleName;
    private String fuelType;

    public VehicleType() {}
    public VehicleType(Long vehicleTypeId, String vehicleName, String fuelType) {
        this.vehicleTypeId = vehicleTypeId;
        this.vehicleName = vehicleName;
        this.fuelType = fuelType;
    }

    public Long getVehicleTypeId() { return vehicleTypeId; }
    public void setVehicleTypeId(Long vehicleTypeId) { this.vehicleTypeId = vehicleTypeId; }
    public String getVehicleName() { return vehicleName; }
    public void setVehicleName(String vehicleName) { this.vehicleName = vehicleName; }
    public String getFuelType() { return fuelType; }
    public void setFuelType(String fuelType) { this.fuelType = fuelType; }

    @Override
    public String toString() {
        return "VehicleType{" + "vehicleTypeId=" + vehicleTypeId + ", " + "vehicleName=" + vehicleName + ", " + "fuelType=" + fuelType + "}";
    }
}
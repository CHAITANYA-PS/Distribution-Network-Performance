package entity;

/** Maps to dsphere.report_filter. */
public class ReportFilter {
    private Long reportFilterId;
    private Long reportId;
    private String filterName;

    /** Object relationship for FK reportId; the scalar FK remains the persistence source of truth. */
    private Report report;
    public ReportFilter() {}
    public ReportFilter(Long reportFilterId, Long reportId, String filterName) {
        this.reportFilterId = reportFilterId;
        this.reportId = reportId;
        this.filterName = filterName;
    }

    public Long getReportFilterId() { return reportFilterId; }
    public void setReportFilterId(Long reportFilterId) { this.reportFilterId = reportFilterId; }
    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }
    public String getFilterName() { return filterName; }
    public void setFilterName(String filterName) { this.filterName = filterName; }

    public Report getReport() { return report; }
    public void setReport(Report report) {
        this.report = report;
        this.reportId = report == null ? null : report.getReportId();
    }
    @Override
    public String toString() {
        return "ReportFilter{" + "reportFilterId=" + reportFilterId + ", " + "reportId=" + reportId + ", " + "filterName=" + filterName + "}";
    }
}
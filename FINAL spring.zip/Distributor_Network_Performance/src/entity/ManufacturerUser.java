package entity;

/** Maps to dsphere.manufacturer_user. */
public class ManufacturerUser {
    private Long userId;
    private Long manufacturerId;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    /** Object relationship for FK manufacturerId; the scalar FK remains the persistence source of truth. */
    private Manufacturer manufacturer;
    public ManufacturerUser() {}
    public ManufacturerUser(Long userId, Long manufacturerId) {
        this.userId = userId;
        this.manufacturerId = manufacturerId;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getManufacturerId() { return manufacturerId; }
    public void setManufacturerId(Long manufacturerId) { this.manufacturerId = manufacturerId; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    public Manufacturer getManufacturer() { return manufacturer; }
    public void setManufacturer(Manufacturer manufacturer) {
        this.manufacturer = manufacturer;
        this.manufacturerId = manufacturer == null ? null : manufacturer.getManufacturerId();
    }
    @Override
    public String toString() {
        return "ManufacturerUser{" + "userId=" + userId + ", " + "manufacturerId=" + manufacturerId + "}";
    }
}
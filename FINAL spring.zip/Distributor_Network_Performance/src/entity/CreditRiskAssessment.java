package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.credit_risk_assessment. */
public class CreditRiskAssessment {
    private Long riskAssessmentId;
    private Long distributorId;
    private Long creditLimitId;
    private BigDecimal riskScore;
    private Long assessedBy;
    private OffsetDateTime assessedAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK creditLimitId; the scalar FK remains the persistence source of truth. */
    private DistributorCreditLimit creditLimit;
    /** Object relationship for FK assessedBy; the scalar FK remains the persistence source of truth. */
    private AppUser assessor;
    public CreditRiskAssessment() {}
    public CreditRiskAssessment(Long riskAssessmentId, Long distributorId, Long creditLimitId, BigDecimal riskScore, Long assessedBy, OffsetDateTime assessedAt) {
        this.riskAssessmentId = riskAssessmentId;
        this.distributorId = distributorId;
        this.creditLimitId = creditLimitId;
        this.riskScore = riskScore;
        this.assessedBy = assessedBy;
        this.assessedAt = assessedAt;
    }

    public Long getRiskAssessmentId() { return riskAssessmentId; }
    public void setRiskAssessmentId(Long riskAssessmentId) { this.riskAssessmentId = riskAssessmentId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getCreditLimitId() { return creditLimitId; }
    public void setCreditLimitId(Long creditLimitId) { this.creditLimitId = creditLimitId; }
    public BigDecimal getRiskScore() { return riskScore; }
    public void setRiskScore(BigDecimal riskScore) { this.riskScore = riskScore; }
    public Long getAssessedBy() { return assessedBy; }
    public void setAssessedBy(Long assessedBy) { this.assessedBy = assessedBy; }
    public OffsetDateTime getAssessedAt() { return assessedAt; }
    public void setAssessedAt(OffsetDateTime assessedAt) { this.assessedAt = assessedAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public DistributorCreditLimit getCreditLimit() { return creditLimit; }
    public void setCreditLimit(DistributorCreditLimit creditLimit) {
        this.creditLimit = creditLimit;
        this.creditLimitId = creditLimit == null ? null : creditLimit.getCreditLimitId();
    }
    public AppUser getAssessor() { return assessor; }
    public void setAssessor(AppUser assessor) {
        this.assessor = assessor;
        this.assessedBy = assessor == null ? null : assessor.getUserId();
    }
    @Override
    public String toString() {
        return "CreditRiskAssessment{" + "riskAssessmentId=" + riskAssessmentId + ", " + "distributorId=" + distributorId + ", " + "creditLimitId=" + creditLimitId + ", " + "riskScore=" + riskScore + ", " + "assessedBy=" + assessedBy + ", " + "assessedAt=" + assessedAt + "}";
    }
}
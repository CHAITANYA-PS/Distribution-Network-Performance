package entity;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Maps to dsphere.recovery_plan. */
public class RecoveryPlan {
    private Long recoveryPlanId;
    private Long distributorId;
    private Long recoveryStatusId;
    private BigDecimal targetAmount;
    private LocalDate startDate;
    private LocalDate endDate;
    private Long createdBy;
    private OffsetDateTime createdAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK recoveryStatusId; the scalar FK remains the persistence source of truth. */
    private RecoveryPlanStatus recoveryStatus;
    /** Object relationship for FK createdBy; the scalar FK remains the persistence source of truth. */
    private AppUser creator;
    public RecoveryPlan() {}
    public RecoveryPlan(Long recoveryPlanId, Long distributorId, Long recoveryStatusId, BigDecimal targetAmount, LocalDate startDate, LocalDate endDate, Long createdBy, OffsetDateTime createdAt) {
        this.recoveryPlanId = recoveryPlanId;
        this.distributorId = distributorId;
        this.recoveryStatusId = recoveryStatusId;
        this.targetAmount = targetAmount;
        this.startDate = startDate;
        this.endDate = endDate;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
    }

    public Long getRecoveryPlanId() { return recoveryPlanId; }
    public void setRecoveryPlanId(Long recoveryPlanId) { this.recoveryPlanId = recoveryPlanId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getRecoveryStatusId() { return recoveryStatusId; }
    public void setRecoveryStatusId(Long recoveryStatusId) { this.recoveryStatusId = recoveryStatusId; }
    public BigDecimal getTargetAmount() { return targetAmount; }
    public void setTargetAmount(BigDecimal targetAmount) { this.targetAmount = targetAmount; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public RecoveryPlanStatus getRecoveryStatus() { return recoveryStatus; }
    public void setRecoveryStatus(RecoveryPlanStatus recoveryStatus) {
        this.recoveryStatus = recoveryStatus;
        this.recoveryStatusId = recoveryStatus == null ? null : recoveryStatus.getRecoveryStatusId();
    }
    public AppUser getCreator() { return creator; }
    public void setCreator(AppUser creator) {
        this.creator = creator;
        this.createdBy = creator == null ? null : creator.getUserId();
    }
    @Override
    public String toString() {
        return "RecoveryPlan{" + "recoveryPlanId=" + recoveryPlanId + ", " + "distributorId=" + distributorId + ", " + "recoveryStatusId=" + recoveryStatusId + ", " + "targetAmount=" + targetAmount + ", " + "startDate=" + startDate + ", " + "endDate=" + endDate + ", " + "createdBy=" + createdBy + ", " + "createdAt=" + createdAt + "}";
    }
}
package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.emission_factor. */
public class EmissionFactor {
    private Long emissionFactorId;
    private Long vehicleTypeId;
    private BigDecimal factorValue;
    private String unit;
    private LocalDate validFrom;
    private LocalDate validTo;

    /** Object relationship for FK vehicleTypeId; the scalar FK remains the persistence source of truth. */
    private VehicleType vehicleType;
    public EmissionFactor() {}
    public EmissionFactor(Long emissionFactorId, Long vehicleTypeId, BigDecimal factorValue, String unit, LocalDate validFrom, LocalDate validTo) {
        this.emissionFactorId = emissionFactorId;
        this.vehicleTypeId = vehicleTypeId;
        this.factorValue = factorValue;
        this.unit = unit;
        this.validFrom = validFrom;
        this.validTo = validTo;
    }

    public Long getEmissionFactorId() { return emissionFactorId; }
    public void setEmissionFactorId(Long emissionFactorId) { this.emissionFactorId = emissionFactorId; }
    public Long getVehicleTypeId() { return vehicleTypeId; }
    public void setVehicleTypeId(Long vehicleTypeId) { this.vehicleTypeId = vehicleTypeId; }
    public BigDecimal getFactorValue() { return factorValue; }
    public void setFactorValue(BigDecimal factorValue) { this.factorValue = factorValue; }
    public String getUnit() { return unit; }
    public void setUnit(String unit) { this.unit = unit; }
    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }
    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate validTo) { this.validTo = validTo; }

    public VehicleType getVehicleType() { return vehicleType; }
    public void setVehicleType(VehicleType vehicleType) {
        this.vehicleType = vehicleType;
        this.vehicleTypeId = vehicleType == null ? null : vehicleType.getVehicleTypeId();
    }
    @Override
    public String toString() {
        return "EmissionFactor{" + "emissionFactorId=" + emissionFactorId + ", " + "vehicleTypeId=" + vehicleTypeId + ", " + "factorValue=" + factorValue + ", " + "unit=" + unit + ", " + "validFrom=" + validFrom + ", " + "validTo=" + validTo + "}";
    }
}
package entity;

/** Maps to dsphere.recovery_plan_ticket. */
public class RecoveryPlanTicket {
    private Long recoveryPlanTicketId;
    private Long recoveryPlanId;
    private Long ticketId;

    /** Object relationship for FK recoveryPlanId; the scalar FK remains the persistence source of truth. */
    private RecoveryPlan recoveryPlan;
    /** Object relationship for FK ticketId; the scalar FK remains the persistence source of truth. */
    private Ticket ticket;
    public RecoveryPlanTicket() {}
    public RecoveryPlanTicket(Long recoveryPlanTicketId, Long recoveryPlanId, Long ticketId) {
        this.recoveryPlanTicketId = recoveryPlanTicketId;
        this.recoveryPlanId = recoveryPlanId;
        this.ticketId = ticketId;
    }

    public Long getRecoveryPlanTicketId() { return recoveryPlanTicketId; }
    public void setRecoveryPlanTicketId(Long recoveryPlanTicketId) { this.recoveryPlanTicketId = recoveryPlanTicketId; }
    public Long getRecoveryPlanId() { return recoveryPlanId; }
    public void setRecoveryPlanId(Long recoveryPlanId) { this.recoveryPlanId = recoveryPlanId; }
    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }

    public RecoveryPlan getRecoveryPlan() { return recoveryPlan; }
    public void setRecoveryPlan(RecoveryPlan recoveryPlan) {
        this.recoveryPlan = recoveryPlan;
        this.recoveryPlanId = recoveryPlan == null ? null : recoveryPlan.getRecoveryPlanId();
    }
    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
        this.ticketId = ticket == null ? null : ticket.getTicketId();
    }
    @Override
    public String toString() {
        return "RecoveryPlanTicket{" + "recoveryPlanTicketId=" + recoveryPlanTicketId + ", " + "recoveryPlanId=" + recoveryPlanId + ", " + "ticketId=" + ticketId + "}";
    }
}
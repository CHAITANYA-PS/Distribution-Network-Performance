package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.distributor_category. */
public class DistributorCategory {
    private Long distributorCategoryId;
    private Long distributorId;
    private Long categoryId;
    private OffsetDateTime assignedAt;
    private String status;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK categoryId; the scalar FK remains the persistence source of truth. */
    private Category category;
    public DistributorCategory() {}
    public DistributorCategory(Long distributorCategoryId, Long distributorId, Long categoryId, OffsetDateTime assignedAt, String status) {
        this.distributorCategoryId = distributorCategoryId;
        this.distributorId = distributorId;
        this.categoryId = categoryId;
        this.assignedAt = assignedAt;
        this.status = status;
    }

    public Long getDistributorCategoryId() { return distributorCategoryId; }
    public void setDistributorCategoryId(Long distributorCategoryId) { this.distributorCategoryId = distributorCategoryId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getCategoryId() { return categoryId; }
    public void setCategoryId(Long categoryId) { this.categoryId = categoryId; }
    public OffsetDateTime getAssignedAt() { return assignedAt; }
    public void setAssignedAt(OffsetDateTime assignedAt) { this.assignedAt = assignedAt; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public Category getCategory() { return category; }
    public void setCategory(Category category) {
        this.category = category;
        this.categoryId = category == null ? null : category.getCategoryId();
    }
    @Override
    public String toString() {
        return "DistributorCategory{" + "distributorCategoryId=" + distributorCategoryId + ", " + "distributorId=" + distributorId + ", " + "categoryId=" + categoryId + ", " + "assignedAt=" + assignedAt + ", " + "status=" + status + "}";
    }
}
package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.distributor_health_assessment. */
public class DistributorHealthAssessment {
    private Long assessmentId;
    private Long distributorId;
    private Long parameterWeightId;
    private Long reportingPeriodId;
    private BigDecimal score;
    private Long assessedBy;
    private OffsetDateTime assessedAt;
    private String remarks;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK parameterWeightId; the scalar FK remains the persistence source of truth. */
    private HealthParameterWeight parameterWeight;
    /** Object relationship for FK reportingPeriodId; the scalar FK remains the persistence source of truth. */
    private ReportingPeriod reportingPeriod;
    /** Object relationship for FK assessedBy; the scalar FK remains the persistence source of truth. */
    private AppUser assessor;
    public DistributorHealthAssessment() {}
    public DistributorHealthAssessment(Long assessmentId, Long distributorId, Long parameterWeightId, Long reportingPeriodId, BigDecimal score, Long assessedBy, OffsetDateTime assessedAt, String remarks) {
        this.assessmentId = assessmentId;
        this.distributorId = distributorId;
        this.parameterWeightId = parameterWeightId;
        this.reportingPeriodId = reportingPeriodId;
        this.score = score;
        this.assessedBy = assessedBy;
        this.assessedAt = assessedAt;
        this.remarks = remarks;
    }

    public Long getAssessmentId() { return assessmentId; }
    public void setAssessmentId(Long assessmentId) { this.assessmentId = assessmentId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getParameterWeightId() { return parameterWeightId; }
    public void setParameterWeightId(Long parameterWeightId) { this.parameterWeightId = parameterWeightId; }
    public Long getReportingPeriodId() { return reportingPeriodId; }
    public void setReportingPeriodId(Long reportingPeriodId) { this.reportingPeriodId = reportingPeriodId; }
    public BigDecimal getScore() { return score; }
    public void setScore(BigDecimal score) { this.score = score; }
    public Long getAssessedBy() { return assessedBy; }
    public void setAssessedBy(Long assessedBy) { this.assessedBy = assessedBy; }
    public OffsetDateTime getAssessedAt() { return assessedAt; }
    public void setAssessedAt(OffsetDateTime assessedAt) { this.assessedAt = assessedAt; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public HealthParameterWeight getParameterWeight() { return parameterWeight; }
    public void setParameterWeight(HealthParameterWeight parameterWeight) {
        this.parameterWeight = parameterWeight;
        this.parameterWeightId = parameterWeight == null ? null : parameterWeight.getParameterWeightId();
    }
    public ReportingPeriod getReportingPeriod() { return reportingPeriod; }
    public void setReportingPeriod(ReportingPeriod reportingPeriod) {
        this.reportingPeriod = reportingPeriod;
        this.reportingPeriodId = reportingPeriod == null ? null : reportingPeriod.getReportingPeriodId();
    }
    public AppUser getAssessor() { return assessor; }
    public void setAssessor(AppUser assessor) {
        this.assessor = assessor;
        this.assessedBy = assessor == null ? null : assessor.getUserId();
    }
    @Override
    public String toString() {
        return "DistributorHealthAssessment{" + "assessmentId=" + assessmentId + ", " + "distributorId=" + distributorId + ", " + "parameterWeightId=" + parameterWeightId + ", " + "reportingPeriodId=" + reportingPeriodId + ", " + "score=" + score + ", " + "assessedBy=" + assessedBy + ", " + "assessedAt=" + assessedAt + ", " + "remarks=" + remarks + "}";
    }
}
package entity;

/** Maps to dsphere.notification_type. */
public class NotificationType {
    private Long notificationTypeId;
    private String typeName;

    public NotificationType() {}
    public NotificationType(Long notificationTypeId, String typeName) {
        this.notificationTypeId = notificationTypeId;
        this.typeName = typeName;
    }

    public Long getNotificationTypeId() { return notificationTypeId; }
    public void setNotificationTypeId(Long notificationTypeId) { this.notificationTypeId = notificationTypeId; }
    public String getTypeName() { return typeName; }
    public void setTypeName(String typeName) { this.typeName = typeName; }

    @Override
    public String toString() {
        return "NotificationType{" + "notificationTypeId=" + notificationTypeId + ", " + "typeName=" + typeName + "}";
    }
}
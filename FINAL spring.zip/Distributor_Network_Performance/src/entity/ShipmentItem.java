package entity;

import java.math.BigDecimal;

/** Maps to dsphere.shipment_item. */
public class ShipmentItem {
    private Long shipmentItemId;
    private Long shipmentId;
    private Long orderItemId;
    private BigDecimal quantity;

    /** Object relationship for FK shipmentId; the scalar FK remains the persistence source of truth. */
    private Shipment shipment;
    /** Object relationship for FK orderItemId; the scalar FK remains the persistence source of truth. */
    private OrderItem orderItem;
    public ShipmentItem() {}
    public ShipmentItem(Long shipmentItemId, Long shipmentId, Long orderItemId, BigDecimal quantity) {
        this.shipmentItemId = shipmentItemId;
        this.shipmentId = shipmentId;
        this.orderItemId = orderItemId;
        this.quantity = quantity;
    }

    public Long getShipmentItemId() { return shipmentItemId; }
    public void setShipmentItemId(Long shipmentItemId) { this.shipmentItemId = shipmentItemId; }
    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }
    public Long getOrderItemId() { return orderItemId; }
    public void setOrderItemId(Long orderItemId) { this.orderItemId = orderItemId; }
    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }

    public Shipment getShipment() { return shipment; }
    public void setShipment(Shipment shipment) {
        this.shipment = shipment;
        this.shipmentId = shipment == null ? null : shipment.getShipmentId();
    }
    public OrderItem getOrderItem() { return orderItem; }
    public void setOrderItem(OrderItem orderItem) {
        this.orderItem = orderItem;
        this.orderItemId = orderItem == null ? null : orderItem.getOrderItemId();
    }
    @Override
    public String toString() {
        return "ShipmentItem{" + "shipmentItemId=" + shipmentItemId + ", " + "shipmentId=" + shipmentId + ", " + "orderItemId=" + orderItemId + ", " + "quantity=" + quantity + "}";
    }
}
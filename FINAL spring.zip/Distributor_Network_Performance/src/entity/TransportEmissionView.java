package entity;

import java.io.Serializable;

public class TransportEmissionView implements Serializable {

    private static final long serialVersionUID = 1L;

    private Long transportId;
    private String vehicleType;
    private String fuelType;
    private Double distanceTravelled;
    private Double fuelConsumed;
    private Double emissionValue;
    private String emissionUnit;

    public TransportEmissionView() {
    }

    public Long getTransportId() {
        return transportId;
    }

    public void setTransportId(Long transportId) {
        this.transportId = transportId;
    }

    public String getVehicleType() {
        return vehicleType;
    }

    public void setVehicleType(String vehicleType) {
        this.vehicleType = vehicleType;
    }

    public String getFuelType() {
        return fuelType;
    }

    public void setFuelType(String fuelType) {
        this.fuelType = fuelType;
    }

    public Double getDistanceTravelled() {
        return distanceTravelled;
    }

    public void setDistanceTravelled(Double distanceTravelled) {
        this.distanceTravelled = distanceTravelled;
    }

    public Double getFuelConsumed() {
        return fuelConsumed;
    }

    public void setFuelConsumed(Double fuelConsumed) {
        this.fuelConsumed = fuelConsumed;
    }

    public Double getEmissionValue() {
        return emissionValue;
    }

    public void setEmissionValue(Double emissionValue) {
        this.emissionValue = emissionValue;
    }

    public String getEmissionUnit() {
        return emissionUnit;
    }

    public void setEmissionUnit(String emissionUnit) {
        this.emissionUnit = emissionUnit;
    }

    @Override
    public String toString() {
        return "TransportEmissionView [transportId=" + transportId
                + ", vehicleType=" + vehicleType
                + ", fuelType=" + fuelType
                + ", distanceTravelled=" + distanceTravelled
                + ", fuelConsumed=" + fuelConsumed
                + ", emissionValue=" + emissionValue
                + ", emissionUnit=" + emissionUnit + "]";
    }
}
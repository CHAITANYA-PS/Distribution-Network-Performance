package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.health_assessment_alert. */
public class HealthAssessmentAlert {
    private Long alertId;
    private Long assessmentId;
    private BigDecimal thresholdValue;
    private String message;
    private Boolean readStatus;
    private OffsetDateTime createdAt;

    /** Object relationship for FK assessmentId; the scalar FK remains the persistence source of truth. */
    private DistributorHealthAssessment assessment;
    public HealthAssessmentAlert() {}
    public HealthAssessmentAlert(Long alertId, Long assessmentId, BigDecimal thresholdValue, String message, Boolean readStatus, OffsetDateTime createdAt) {
        this.alertId = alertId;
        this.assessmentId = assessmentId;
        this.thresholdValue = thresholdValue;
        this.message = message;
        this.readStatus = readStatus;
        this.createdAt = createdAt;
    }

    public Long getAlertId() { return alertId; }
    public void setAlertId(Long alertId) { this.alertId = alertId; }
    public Long getAssessmentId() { return assessmentId; }
    public void setAssessmentId(Long assessmentId) { this.assessmentId = assessmentId; }
    public BigDecimal getThresholdValue() { return thresholdValue; }
    public void setThresholdValue(BigDecimal thresholdValue) { this.thresholdValue = thresholdValue; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public Boolean getReadStatus() { return readStatus; }
    public void setReadStatus(Boolean readStatus) { this.readStatus = readStatus; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public DistributorHealthAssessment getAssessment() { return assessment; }
    public void setAssessment(DistributorHealthAssessment assessment) {
        this.assessment = assessment;
        this.assessmentId = assessment == null ? null : assessment.getAssessmentId();
    }
    @Override
    public String toString() {
        return "HealthAssessmentAlert{" + "alertId=" + alertId + ", " + "assessmentId=" + assessmentId + ", " + "thresholdValue=" + thresholdValue + ", " + "message=" + message + ", " + "readStatus=" + readStatus + ", " + "createdAt=" + createdAt + "}";
    }
}
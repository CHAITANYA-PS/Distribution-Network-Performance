package entity;

/** Maps to dsphere.invoice_status. */
public class InvoiceStatus {
    private Long invoiceStatusId;
    private String statusName;

    public InvoiceStatus() {}
    public InvoiceStatus(Long invoiceStatusId, String statusName) {
        this.invoiceStatusId = invoiceStatusId;
        this.statusName = statusName;
    }

    public Long getInvoiceStatusId() { return invoiceStatusId; }
    public void setInvoiceStatusId(Long invoiceStatusId) { this.invoiceStatusId = invoiceStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    @Override
    public String toString() {
        return "InvoiceStatus{" + "invoiceStatusId=" + invoiceStatusId + ", " + "statusName=" + statusName + "}";
    }
}
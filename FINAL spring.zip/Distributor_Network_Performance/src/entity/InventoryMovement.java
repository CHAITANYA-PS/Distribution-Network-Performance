package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.inventory_movement. */
public class InventoryMovement {
    private Long movementId;
    private Long inventoryDocumentId;
    private Long warehouseStockId;
    private Long movementTypeId;
    private BigDecimal quantity;
    private OffsetDateTime movementDate;

    /** Object relationship for FK inventoryDocumentId; the scalar FK remains the persistence source of truth. */
    private InventoryDocument inventoryDocument;
    /** Object relationship for FK warehouseStockId; the scalar FK remains the persistence source of truth. */
    private WarehouseStock warehouseStock;
    /** Object relationship for FK movementTypeId; the scalar FK remains the persistence source of truth. */
    private MovementType movementType;
    public InventoryMovement() {}
    public InventoryMovement(Long movementId, Long inventoryDocumentId, Long warehouseStockId, Long movementTypeId, BigDecimal quantity, OffsetDateTime movementDate) {
        this.movementId = movementId;
        this.inventoryDocumentId = inventoryDocumentId;
        this.warehouseStockId = warehouseStockId;
        this.movementTypeId = movementTypeId;
        this.quantity = quantity;
        this.movementDate = movementDate;
    }

    public Long getMovementId() { return movementId; }
    public void setMovementId(Long movementId) { this.movementId = movementId; }
    public Long getInventoryDocumentId() { return inventoryDocumentId; }
    public void setInventoryDocumentId(Long inventoryDocumentId) { this.inventoryDocumentId = inventoryDocumentId; }
    public Long getWarehouseStockId() { return warehouseStockId; }
    public void setWarehouseStockId(Long warehouseStockId) { this.warehouseStockId = warehouseStockId; }
    public Long getMovementTypeId() { return movementTypeId; }
    public void setMovementTypeId(Long movementTypeId) { this.movementTypeId = movementTypeId; }
    public BigDecimal getQuantity() { return quantity; }
    public void setQuantity(BigDecimal quantity) { this.quantity = quantity; }
    public OffsetDateTime getMovementDate() { return movementDate; }
    public void setMovementDate(OffsetDateTime movementDate) { this.movementDate = movementDate; }

    public InventoryDocument getInventoryDocument() { return inventoryDocument; }
    public void setInventoryDocument(InventoryDocument inventoryDocument) {
        this.inventoryDocument = inventoryDocument;
        this.inventoryDocumentId = inventoryDocument == null ? null : inventoryDocument.getInventoryDocumentId();
    }
    public WarehouseStock getWarehouseStock() { return warehouseStock; }
    public void setWarehouseStock(WarehouseStock warehouseStock) {
        this.warehouseStock = warehouseStock;
        this.warehouseStockId = warehouseStock == null ? null : warehouseStock.getWarehouseStockId();
    }
    public MovementType getMovementType() { return movementType; }
    public void setMovementType(MovementType movementType) {
        this.movementType = movementType;
        this.movementTypeId = movementType == null ? null : movementType.getMovementTypeId();
    }
    @Override
    public String toString() {
        return "InventoryMovement{" + "movementId=" + movementId + ", " + "inventoryDocumentId=" + inventoryDocumentId + ", " + "warehouseStockId=" + warehouseStockId + ", " + "movementTypeId=" + movementTypeId + ", " + "quantity=" + quantity + ", " + "movementDate=" + movementDate + "}";
    }
}
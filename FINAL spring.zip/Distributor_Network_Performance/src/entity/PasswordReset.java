package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.password_reset. */
public class PasswordReset {
    private Long resetId;
    private Long userId;
    private String token;
    private OffsetDateTime expiresAt;
    private OffsetDateTime usedAt;
    private OffsetDateTime createdAt;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    public PasswordReset() {}
    public PasswordReset(Long resetId, Long userId, String token, OffsetDateTime expiresAt, OffsetDateTime usedAt, OffsetDateTime createdAt) {
        this.resetId = resetId;
        this.userId = userId;
        this.token = token;
        this.expiresAt = expiresAt;
        this.usedAt = usedAt;
        this.createdAt = createdAt;
    }

    public Long getResetId() { return resetId; }
    public void setResetId(Long resetId) { this.resetId = resetId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getToken() { return token; }
    public void setToken(String token) { this.token = token; }
    public OffsetDateTime getExpiresAt() { return expiresAt; }
    public void setExpiresAt(OffsetDateTime expiresAt) { this.expiresAt = expiresAt; }
    public OffsetDateTime getUsedAt() { return usedAt; }
    public void setUsedAt(OffsetDateTime usedAt) { this.usedAt = usedAt; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    @Override
    public String toString() {
        return "PasswordReset{" + "resetId=" + resetId + ", " + "userId=" + userId + ", " + "token=" + token + ", " + "expiresAt=" + expiresAt + ", " + "usedAt=" + usedAt + ", " + "createdAt=" + createdAt + "}";
    }
}
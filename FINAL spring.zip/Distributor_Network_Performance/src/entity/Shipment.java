package entity;

import java.time.LocalDate;

/** Maps to dsphere.shipment. */
public class Shipment {
    private Long shipmentId;
    private String trackingNumber;
    private Long warehouseId;
    private Long shipmentStatusId;
    private LocalDate dispatchDate;
    private LocalDate deliveryDate;

    /** Object relationship for FK warehouseId; the scalar FK remains the persistence source of truth. */
    private Warehouse warehouse;
    /** Object relationship for FK shipmentStatusId; the scalar FK remains the persistence source of truth. */
    private ShipmentStatus shipmentStatus;
    public Shipment() {}
    public Shipment(Long shipmentId, String trackingNumber, Long warehouseId, Long shipmentStatusId, LocalDate dispatchDate, LocalDate deliveryDate) {
        this.shipmentId = shipmentId;
        this.trackingNumber = trackingNumber;
        this.warehouseId = warehouseId;
        this.shipmentStatusId = shipmentStatusId;
        this.dispatchDate = dispatchDate;
        this.deliveryDate = deliveryDate;
    }

    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }
    public String getTrackingNumber() { return trackingNumber; }
    public void setTrackingNumber(String trackingNumber) { this.trackingNumber = trackingNumber; }
    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }
    public Long getShipmentStatusId() { return shipmentStatusId; }
    public void setShipmentStatusId(Long shipmentStatusId) { this.shipmentStatusId = shipmentStatusId; }
    public LocalDate getDispatchDate() { return dispatchDate; }
    public void setDispatchDate(LocalDate dispatchDate) { this.dispatchDate = dispatchDate; }
    public LocalDate getDeliveryDate() { return deliveryDate; }
    public void setDeliveryDate(LocalDate deliveryDate) { this.deliveryDate = deliveryDate; }

    public Warehouse getWarehouse() { return warehouse; }
    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
        this.warehouseId = warehouse == null ? null : warehouse.getWarehouseId();
    }
    public ShipmentStatus getShipmentStatus() { return shipmentStatus; }
    public void setShipmentStatus(ShipmentStatus shipmentStatus) {
        this.shipmentStatus = shipmentStatus;
        this.shipmentStatusId = shipmentStatus == null ? null : shipmentStatus.getShipmentStatusId();
    }
    @Override
    public String toString() {
        return "Shipment{" + "shipmentId=" + shipmentId + ", " + "trackingNumber=" + trackingNumber + ", " + "warehouseId=" + warehouseId + ", " + "shipmentStatusId=" + shipmentStatusId + ", " + "dispatchDate=" + dispatchDate + ", " + "deliveryDate=" + deliveryDate + "}";
    }
}
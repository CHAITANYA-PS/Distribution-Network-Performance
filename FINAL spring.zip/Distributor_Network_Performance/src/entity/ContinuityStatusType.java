package entity;

/** Maps to dsphere.continuity_status_type. */
public class ContinuityStatusType {
    private Long continuityStatusId;
    private String statusName;
    private String description;

    public ContinuityStatusType() {}
    public ContinuityStatusType(Long continuityStatusId, String statusName, String description) {
        this.continuityStatusId = continuityStatusId;
        this.statusName = statusName;
        this.description = description;
    }

    public Long getContinuityStatusId() { return continuityStatusId; }
    public void setContinuityStatusId(Long continuityStatusId) { this.continuityStatusId = continuityStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    @Override
    public String toString() {
        return "ContinuityStatusType{" + "continuityStatusId=" + continuityStatusId + ", " + "statusName=" + statusName + ", " + "description=" + description + "}";
    }
}
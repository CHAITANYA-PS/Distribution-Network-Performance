package entity;
import java.time.OffsetDateTime;
public class UserSession {
 private Long sessionId; private Long userId; private String sessionTokenHash;
 private OffsetDateTime createdAt; private OffsetDateTime expiresAt; private OffsetDateTime revokedAt;
 private String ipAddress;
 public UserSession() {}
 public UserSession(Long sessionId, Long userId, String sessionTokenHash, OffsetDateTime createdAt,
  OffsetDateTime expiresAt, OffsetDateTime revokedAt, String ipAddress) {
  this.sessionId=sessionId; this.userId=userId; this.sessionTokenHash=sessionTokenHash;
  this.createdAt=createdAt; this.expiresAt=expiresAt; this.revokedAt=revokedAt; this.ipAddress=ipAddress;
 }
 public Long getSessionId(){return sessionId;} public void setSessionId(Long v){sessionId=v;}
 public Long getUserId(){return userId;} public void setUserId(Long v){userId=v;}
 public String getSessionTokenHash(){return sessionTokenHash;} public void setSessionTokenHash(String v){sessionTokenHash=v;}
 public OffsetDateTime getCreatedAt(){return createdAt;} public void setCreatedAt(OffsetDateTime v){createdAt=v;}
 public OffsetDateTime getExpiresAt(){return expiresAt;} public void setExpiresAt(OffsetDateTime v){expiresAt=v;}
 public OffsetDateTime getRevokedAt(){return revokedAt;} public void setRevokedAt(OffsetDateTime v){revokedAt=v;}
 public String getIpAddress(){return ipAddress;} public void setIpAddress(String v){ipAddress=v;}
 public boolean isActive(OffsetDateTime now){return revokedAt==null && expiresAt!=null && expiresAt.isAfter(now);}
 @Override public String toString(){return "UserSession{sessionId="+sessionId+", userId="+userId+
  ", createdAt="+createdAt+", expiresAt="+expiresAt+", revokedAt="+revokedAt+"}";}
 /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
 private AppUser user;
 public AppUser getUser(){return user;}
 public void setUser(AppUser user){this.user=user; this.userId=user==null?null:user.getUserId();}
}

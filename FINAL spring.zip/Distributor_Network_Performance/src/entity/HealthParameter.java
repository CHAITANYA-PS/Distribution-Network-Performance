package entity;

/** Maps to dsphere.health_parameter. */
public class HealthParameter {
    private Long parameterId;
    private String parameterName;
    private String description;
    private Boolean isActive;

    public HealthParameter() {}
    public HealthParameter(Long parameterId, String parameterName, String description, Boolean isActive) {
        this.parameterId = parameterId;
        this.parameterName = parameterName;
        this.description = description;
        this.isActive = isActive;
    }

    public Long getParameterId() { return parameterId; }
    public void setParameterId(Long parameterId) { this.parameterId = parameterId; }
    public String getParameterName() { return parameterName; }
    public void setParameterName(String parameterName) { this.parameterName = parameterName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Boolean getIsActive() { return isActive; }
    public void setIsActive(Boolean isActive) { this.isActive = isActive; }

    @Override
    public String toString() {
        return "HealthParameter{" + "parameterId=" + parameterId + ", " + "parameterName=" + parameterName + ", " + "description=" + description + ", " + "isActive=" + isActive + "}";
    }
}
package entity;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Maps to dsphere.distributor_order. */
public class DistributorOrder {
    private Long orderId;
    private String orderNumber;
    private Long distributorId;
    private Long orderStatusId;
    private LocalDate orderDate;
    private Long createdBy;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK orderStatusId; the scalar FK remains the persistence source of truth. */
    private OrderStatus orderStatus;
    /** Object relationship for FK createdBy; the scalar FK remains the persistence source of truth. */
    private AppUser creator;
    public DistributorOrder() {}
    public DistributorOrder(Long orderId, String orderNumber, Long distributorId, Long orderStatusId, LocalDate orderDate, Long createdBy, OffsetDateTime createdAt, OffsetDateTime updatedAt) {
        this.orderId = orderId;
        this.orderNumber = orderNumber;
        this.distributorId = distributorId;
        this.orderStatusId = orderStatusId;
        this.orderDate = orderDate;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public String getOrderNumber() { return orderNumber; }
    public void setOrderNumber(String orderNumber) { this.orderNumber = orderNumber; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getOrderStatusId() { return orderStatusId; }
    public void setOrderStatusId(Long orderStatusId) { this.orderStatusId = orderStatusId; }
    public LocalDate getOrderDate() { return orderDate; }
    public void setOrderDate(LocalDate orderDate) { this.orderDate = orderDate; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public OrderStatus getOrderStatus() { return orderStatus; }
    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
        this.orderStatusId = orderStatus == null ? null : orderStatus.getOrderStatusId();
    }
    public AppUser getCreator() { return creator; }
    public void setCreator(AppUser creator) {
        this.creator = creator;
        this.createdBy = creator == null ? null : creator.getUserId();
    }
    @Override
    public String toString() {
        return "DistributorOrder{" + "orderId=" + orderId + ", " + "orderNumber=" + orderNumber + ", " + "distributorId=" + distributorId + ", " + "orderStatusId=" + orderStatusId + ", " + "orderDate=" + orderDate + ", " + "createdBy=" + createdBy + ", " + "createdAt=" + createdAt + ", " + "updatedAt=" + updatedAt + "}";
    }
}
package entity;

/** Maps to dsphere.system_admin. */
public class SystemAdmin {
    private Long userId;
    private String adminLevel;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    public SystemAdmin() {}
    public SystemAdmin(Long userId, String adminLevel) {
        this.userId = userId;
        this.adminLevel = adminLevel;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getAdminLevel() { return adminLevel; }
    public void setAdminLevel(String adminLevel) { this.adminLevel = adminLevel; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    @Override
    public String toString() {
        return "SystemAdmin{" + "userId=" + userId + ", " + "adminLevel=" + adminLevel + "}";
    }
}
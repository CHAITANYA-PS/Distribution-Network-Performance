package entity;

import java.math.BigDecimal;

/** Maps to dsphere.warehouse_stock. */
public class WarehouseStock {
    private Long warehouseStockId;
    private Long warehouseId;
    private Long productBatchId;
    private Long ownerDistributorId;
    private BigDecimal reorderLevel;

    /** Object relationship for FK warehouseId; the scalar FK remains the persistence source of truth. */
    private Warehouse warehouse;
    /** Object relationship for FK productBatchId; the scalar FK remains the persistence source of truth. */
    private ProductBatch productBatch;
    /** Object relationship for FK ownerDistributorId; the scalar FK remains the persistence source of truth. */
    private Distributor ownerDistributor;
    public WarehouseStock() {}
    public WarehouseStock(Long warehouseStockId, Long warehouseId, Long productBatchId, Long ownerDistributorId, BigDecimal reorderLevel) {
        this.warehouseStockId = warehouseStockId;
        this.warehouseId = warehouseId;
        this.productBatchId = productBatchId;
        this.ownerDistributorId = ownerDistributorId;
        this.reorderLevel = reorderLevel;
    }

    public Long getWarehouseStockId() { return warehouseStockId; }
    public void setWarehouseStockId(Long warehouseStockId) { this.warehouseStockId = warehouseStockId; }
    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }
    public Long getProductBatchId() { return productBatchId; }
    public void setProductBatchId(Long productBatchId) { this.productBatchId = productBatchId; }
    public Long getOwnerDistributorId() { return ownerDistributorId; }
    public void setOwnerDistributorId(Long ownerDistributorId) { this.ownerDistributorId = ownerDistributorId; }
    public BigDecimal getReorderLevel() { return reorderLevel; }
    public void setReorderLevel(BigDecimal reorderLevel) { this.reorderLevel = reorderLevel; }

    public Warehouse getWarehouse() { return warehouse; }
    public void setWarehouse(Warehouse warehouse) {
        this.warehouse = warehouse;
        this.warehouseId = warehouse == null ? null : warehouse.getWarehouseId();
    }
    public ProductBatch getProductBatch() { return productBatch; }
    public void setProductBatch(ProductBatch productBatch) {
        this.productBatch = productBatch;
        this.productBatchId = productBatch == null ? null : productBatch.getProductBatchId();
    }
    public Distributor getOwnerDistributor() { return ownerDistributor; }
    public void setOwnerDistributor(Distributor ownerDistributor) {
        this.ownerDistributor = ownerDistributor;
        this.ownerDistributorId = ownerDistributor == null ? null : ownerDistributor.getDistributorId();
    }
    @Override
    public String toString() {
        return "WarehouseStock{" + "warehouseStockId=" + warehouseStockId + ", " + "warehouseId=" + warehouseId + ", " + "productBatchId=" + productBatchId + ", " + "ownerDistributorId=" + ownerDistributorId + ", " + "reorderLevel=" + reorderLevel + "}";
    }
}
package entity;

/** Maps to dsphere.measurement_unit. */
public class MeasurementUnit {
    private Long measurementUnitId;
    private String unitCode;
    private String unitName;

    public MeasurementUnit() {}
    public MeasurementUnit(Long measurementUnitId, String unitCode, String unitName) {
        this.measurementUnitId = measurementUnitId;
        this.unitCode = unitCode;
        this.unitName = unitName;
    }

    public Long getMeasurementUnitId() { return measurementUnitId; }
    public void setMeasurementUnitId(Long measurementUnitId) { this.measurementUnitId = measurementUnitId; }
    public String getUnitCode() { return unitCode; }
    public void setUnitCode(String unitCode) { this.unitCode = unitCode; }
    public String getUnitName() { return unitName; }
    public void setUnitName(String unitName) { this.unitName = unitName; }

    @Override
    public String toString() {
        return "MeasurementUnit{" + "measurementUnitId=" + measurementUnitId + ", " + "unitCode=" + unitCode + ", " + "unitName=" + unitName + "}";
    }
}
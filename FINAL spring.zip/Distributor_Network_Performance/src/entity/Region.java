package entity;

/** Maps to dsphere.region. */
public class Region {
    private Long regionId;
    private String regionName;
    private String description;

    public Region() {}
    public Region(Long regionId, String regionName, String description) {
        this.regionId = regionId;
        this.regionName = regionName;
        this.description = description;
    }

    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }
    public String getRegionName() { return regionName; }
    public void setRegionName(String regionName) { this.regionName = regionName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    @Override
    public String toString() {
        return "Region{" + "regionId=" + regionId + ", " + "regionName=" + regionName + ", " + "description=" + description + "}";
    }
}
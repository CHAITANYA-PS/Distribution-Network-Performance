package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.ticket. */
public class Ticket {
    private Long ticketId;
    private Long distributorId;
    private Long ticketCategoryId;
    private Long ticketStatusId;
    private Long ticketPriorityId;
    private String subject;
    private String description;
    private Long createdBy;
    private OffsetDateTime createdAt;
    private OffsetDateTime closedAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK ticketCategoryId; the scalar FK remains the persistence source of truth. */
    private TicketCategory ticketCategory;
    /** Object relationship for FK ticketStatusId; the scalar FK remains the persistence source of truth. */
    private TicketStatus ticketStatus;
    /** Object relationship for FK ticketPriorityId; the scalar FK remains the persistence source of truth. */
    private TicketPriority ticketPriority;
    /** Object relationship for FK createdBy; the scalar FK remains the persistence source of truth. */
    private AppUser creator;
    public Ticket() {}
    public Ticket(Long ticketId, Long distributorId, Long ticketCategoryId, Long ticketStatusId, Long ticketPriorityId, String subject, String description, Long createdBy, OffsetDateTime createdAt, OffsetDateTime closedAt) {
        this.ticketId = ticketId;
        this.distributorId = distributorId;
        this.ticketCategoryId = ticketCategoryId;
        this.ticketStatusId = ticketStatusId;
        this.ticketPriorityId = ticketPriorityId;
        this.subject = subject;
        this.description = description;
        this.createdBy = createdBy;
        this.createdAt = createdAt;
        this.closedAt = closedAt;
    }

    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getTicketCategoryId() { return ticketCategoryId; }
    public void setTicketCategoryId(Long ticketCategoryId) { this.ticketCategoryId = ticketCategoryId; }
    public Long getTicketStatusId() { return ticketStatusId; }
    public void setTicketStatusId(Long ticketStatusId) { this.ticketStatusId = ticketStatusId; }
    public Long getTicketPriorityId() { return ticketPriorityId; }
    public void setTicketPriorityId(Long ticketPriorityId) { this.ticketPriorityId = ticketPriorityId; }
    public String getSubject() { return subject; }
    public void setSubject(String subject) { this.subject = subject; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public Long getCreatedBy() { return createdBy; }
    public void setCreatedBy(Long createdBy) { this.createdBy = createdBy; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getClosedAt() { return closedAt; }
    public void setClosedAt(OffsetDateTime closedAt) { this.closedAt = closedAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public TicketCategory getTicketCategory() { return ticketCategory; }
    public void setTicketCategory(TicketCategory ticketCategory) {
        this.ticketCategory = ticketCategory;
        this.ticketCategoryId = ticketCategory == null ? null : ticketCategory.getTicketCategoryId();
    }
    public TicketStatus getTicketStatus() { return ticketStatus; }
    public void setTicketStatus(TicketStatus ticketStatus) {
        this.ticketStatus = ticketStatus;
        this.ticketStatusId = ticketStatus == null ? null : ticketStatus.getTicketStatusId();
    }
    public TicketPriority getTicketPriority() { return ticketPriority; }
    public void setTicketPriority(TicketPriority ticketPriority) {
        this.ticketPriority = ticketPriority;
        this.ticketPriorityId = ticketPriority == null ? null : ticketPriority.getTicketPriorityId();
    }
    public AppUser getCreator() { return creator; }
    public void setCreator(AppUser creator) {
        this.creator = creator;
        this.createdBy = creator == null ? null : creator.getUserId();
    }
    @Override
    public String toString() {
        return "Ticket{" + "ticketId=" + ticketId + ", " + "distributorId=" + distributorId + ", " + "ticketCategoryId=" + ticketCategoryId + ", " + "ticketStatusId=" + ticketStatusId + ", " + "ticketPriorityId=" + ticketPriorityId + ", " + "subject=" + subject + ", " + "description=" + description + ", " + "createdBy=" + createdBy + ", " + "createdAt=" + createdAt + ", " + "closedAt=" + closedAt + "}";
    }
}
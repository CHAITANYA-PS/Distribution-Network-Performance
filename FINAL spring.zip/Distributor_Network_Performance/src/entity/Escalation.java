package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.escalation. */
public class Escalation {
    private Long escalationId;
    private Long ticketId;
    private Long escalatedTo;
    private Integer escalationLevel;
    private String reason;
    private OffsetDateTime createdAt;

    /** Object relationship for FK ticketId; the scalar FK remains the persistence source of truth. */
    private Ticket ticket;
    /** Object relationship for FK escalatedTo; the scalar FK remains the persistence source of truth. */
    private AppUser escalatedToUser;
    public Escalation() {}
    public Escalation(Long escalationId, Long ticketId, Long escalatedTo, Integer escalationLevel, String reason, OffsetDateTime createdAt) {
        this.escalationId = escalationId;
        this.ticketId = ticketId;
        this.escalatedTo = escalatedTo;
        this.escalationLevel = escalationLevel;
        this.reason = reason;
        this.createdAt = createdAt;
    }

    public Long getEscalationId() { return escalationId; }
    public void setEscalationId(Long escalationId) { this.escalationId = escalationId; }
    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }
    public Long getEscalatedTo() { return escalatedTo; }
    public void setEscalatedTo(Long escalatedTo) { this.escalatedTo = escalatedTo; }
    public Integer getEscalationLevel() { return escalationLevel; }
    public void setEscalationLevel(Integer escalationLevel) { this.escalationLevel = escalationLevel; }
    public String getReason() { return reason; }
    public void setReason(String reason) { this.reason = reason; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
        this.ticketId = ticket == null ? null : ticket.getTicketId();
    }
    public AppUser getEscalatedToUser() { return escalatedToUser; }
    public void setEscalatedToUser(AppUser escalatedToUser) {
        this.escalatedToUser = escalatedToUser;
        this.escalatedTo = escalatedToUser == null ? null : escalatedToUser.getUserId();
    }
    @Override
    public String toString() {
        return "Escalation{" + "escalationId=" + escalationId + ", " + "ticketId=" + ticketId + ", " + "escalatedTo=" + escalatedTo + ", " + "escalationLevel=" + escalationLevel + ", " + "reason=" + reason + ", " + "createdAt=" + createdAt + "}";
    }
}
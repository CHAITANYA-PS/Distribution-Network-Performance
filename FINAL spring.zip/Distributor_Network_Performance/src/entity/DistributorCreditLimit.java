package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.distributor_credit_limit. */
public class DistributorCreditLimit {
    private Long creditLimitId;
    private Long distributorId;
    private BigDecimal creditLimit;
    private LocalDate validFrom;
    private LocalDate validTo;
    private Long approvedBy;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK approvedBy; the scalar FK remains the persistence source of truth. */
    private AppUser approver;
    public DistributorCreditLimit() {}
    public DistributorCreditLimit(Long creditLimitId, Long distributorId, BigDecimal creditLimit, LocalDate validFrom, LocalDate validTo, Long approvedBy) {
        this.creditLimitId = creditLimitId;
        this.distributorId = distributorId;
        this.creditLimit = creditLimit;
        this.validFrom = validFrom;
        this.validTo = validTo;
        this.approvedBy = approvedBy;
    }

    public Long getCreditLimitId() { return creditLimitId; }
    public void setCreditLimitId(Long creditLimitId) { this.creditLimitId = creditLimitId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public BigDecimal getCreditLimit() { return creditLimit; }
    public void setCreditLimit(BigDecimal creditLimit) { this.creditLimit = creditLimit; }
    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }
    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate validTo) { this.validTo = validTo; }
    public Long getApprovedBy() { return approvedBy; }
    public void setApprovedBy(Long approvedBy) { this.approvedBy = approvedBy; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public AppUser getApprover() { return approver; }
    public void setApprover(AppUser approver) {
        this.approver = approver;
        this.approvedBy = approver == null ? null : approver.getUserId();
    }
    @Override
    public String toString() {
        return "DistributorCreditLimit{" + "creditLimitId=" + creditLimitId + ", " + "distributorId=" + distributorId + ", " + "creditLimit=" + creditLimit + ", " + "validFrom=" + validFrom + ", " + "validTo=" + validTo + ", " + "approvedBy=" + approvedBy + "}";
    }
}
package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.commitment_progress. */
public class CommitmentProgress {
    private Long progressId;
    private Long commitmentId;
    private BigDecimal progressValue;
    private Long recordedBy;
    private OffsetDateTime recordedAt;
    private String remarks;

    /** Object relationship for FK commitmentId; the scalar FK remains the persistence source of truth. */
    private Commitment commitment;
    /** Object relationship for FK recordedBy; the scalar FK remains the persistence source of truth. */
    private AppUser recorder;
    public CommitmentProgress() {}
    public CommitmentProgress(Long progressId, Long commitmentId, BigDecimal progressValue, Long recordedBy, OffsetDateTime recordedAt, String remarks) {
        this.progressId = progressId;
        this.commitmentId = commitmentId;
        this.progressValue = progressValue;
        this.recordedBy = recordedBy;
        this.recordedAt = recordedAt;
        this.remarks = remarks;
    }

    public Long getProgressId() { return progressId; }
    public void setProgressId(Long progressId) { this.progressId = progressId; }
    public Long getCommitmentId() { return commitmentId; }
    public void setCommitmentId(Long commitmentId) { this.commitmentId = commitmentId; }
    public BigDecimal getProgressValue() { return progressValue; }
    public void setProgressValue(BigDecimal progressValue) { this.progressValue = progressValue; }
    public Long getRecordedBy() { return recordedBy; }
    public void setRecordedBy(Long recordedBy) { this.recordedBy = recordedBy; }
    public OffsetDateTime getRecordedAt() { return recordedAt; }
    public void setRecordedAt(OffsetDateTime recordedAt) { this.recordedAt = recordedAt; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }

    public Commitment getCommitment() { return commitment; }
    public void setCommitment(Commitment commitment) {
        this.commitment = commitment;
        this.commitmentId = commitment == null ? null : commitment.getCommitmentId();
    }
    public AppUser getRecorder() { return recorder; }
    public void setRecorder(AppUser recorder) {
        this.recorder = recorder;
        this.recordedBy = recorder == null ? null : recorder.getUserId();
    }
    @Override
    public String toString() {
        return "CommitmentProgress{" + "progressId=" + progressId + ", " + "commitmentId=" + commitmentId + ", " + "progressValue=" + progressValue + ", " + "recordedBy=" + recordedBy + ", " + "recordedAt=" + recordedAt + ", " + "remarks=" + remarks + "}";
    }
}
package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.payment. */
public class Payment {
    private Long paymentId;
    private Long invoiceId;
    private Long paymentMethodId;
    private Long paymentStatusId;
    private String transactionReference;
    private LocalDate paymentDate;
    private BigDecimal amount;

    /** Object relationship for FK invoiceId; the scalar FK remains the persistence source of truth. */
    private Invoice invoice;
    /** Object relationship for FK paymentMethodId; the scalar FK remains the persistence source of truth. */
    private PaymentMethod paymentMethod;
    /** Object relationship for FK paymentStatusId; the scalar FK remains the persistence source of truth. */
    private PaymentStatus paymentStatus;
    public Payment() {}
    public Payment(Long paymentId, Long invoiceId, Long paymentMethodId, Long paymentStatusId, String transactionReference, LocalDate paymentDate, BigDecimal amount) {
        this.paymentId = paymentId;
        this.invoiceId = invoiceId;
        this.paymentMethodId = paymentMethodId;
        this.paymentStatusId = paymentStatusId;
        this.transactionReference = transactionReference;
        this.paymentDate = paymentDate;
        this.amount = amount;
    }

    public Long getPaymentId() { return paymentId; }
    public void setPaymentId(Long paymentId) { this.paymentId = paymentId; }
    public Long getInvoiceId() { return invoiceId; }
    public void setInvoiceId(Long invoiceId) { this.invoiceId = invoiceId; }
    public Long getPaymentMethodId() { return paymentMethodId; }
    public void setPaymentMethodId(Long paymentMethodId) { this.paymentMethodId = paymentMethodId; }
    public Long getPaymentStatusId() { return paymentStatusId; }
    public void setPaymentStatusId(Long paymentStatusId) { this.paymentStatusId = paymentStatusId; }
    public String getTransactionReference() { return transactionReference; }
    public void setTransactionReference(String transactionReference) { this.transactionReference = transactionReference; }
    public LocalDate getPaymentDate() { return paymentDate; }
    public void setPaymentDate(LocalDate paymentDate) { this.paymentDate = paymentDate; }
    public BigDecimal getAmount() { return amount; }
    public void setAmount(BigDecimal amount) { this.amount = amount; }

    public Invoice getInvoice() { return invoice; }
    public void setInvoice(Invoice invoice) {
        this.invoice = invoice;
        this.invoiceId = invoice == null ? null : invoice.getInvoiceId();
    }
    public PaymentMethod getPaymentMethod() { return paymentMethod; }
    public void setPaymentMethod(PaymentMethod paymentMethod) {
        this.paymentMethod = paymentMethod;
        this.paymentMethodId = paymentMethod == null ? null : paymentMethod.getPaymentMethodId();
    }
    public PaymentStatus getPaymentStatus() { return paymentStatus; }
    public void setPaymentStatus(PaymentStatus paymentStatus) {
        this.paymentStatus = paymentStatus;
        this.paymentStatusId = paymentStatus == null ? null : paymentStatus.getPaymentStatusId();
    }
    @Override
    public String toString() {
        return "Payment{" + "paymentId=" + paymentId + ", " + "invoiceId=" + invoiceId + ", " + "paymentMethodId=" + paymentMethodId + ", " + "paymentStatusId=" + paymentStatusId + ", " + "transactionReference=" + transactionReference + ", " + "paymentDate=" + paymentDate + ", " + "amount=" + amount + "}";
    }
}
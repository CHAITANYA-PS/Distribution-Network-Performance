package entity;

import java.time.LocalDate;

/** Maps to dsphere.reporting_period. */
public class ReportingPeriod {
    private Long reportingPeriodId;
    private String periodName;
    private String periodType;
    private LocalDate startDate;
    private LocalDate endDate;

    public ReportingPeriod() {}
    public ReportingPeriod(Long reportingPeriodId, String periodName, String periodType, LocalDate startDate, LocalDate endDate) {
        this.reportingPeriodId = reportingPeriodId;
        this.periodName = periodName;
        this.periodType = periodType;
        this.startDate = startDate;
        this.endDate = endDate;
    }

    public Long getReportingPeriodId() { return reportingPeriodId; }
    public void setReportingPeriodId(Long reportingPeriodId) { this.reportingPeriodId = reportingPeriodId; }
    public String getPeriodName() { return periodName; }
    public void setPeriodName(String periodName) { this.periodName = periodName; }
    public String getPeriodType() { return periodType; }
    public void setPeriodType(String periodType) { this.periodType = periodType; }
    public LocalDate getStartDate() { return startDate; }
    public void setStartDate(LocalDate startDate) { this.startDate = startDate; }
    public LocalDate getEndDate() { return endDate; }
    public void setEndDate(LocalDate endDate) { this.endDate = endDate; }

    @Override
    public String toString() {
        return "ReportingPeriod{" + "reportingPeriodId=" + reportingPeriodId + ", " + "periodName=" + periodName + ", " + "periodType=" + periodType + ", " + "startDate=" + startDate + ", " + "endDate=" + endDate + "}";
    }
}
package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.health_parameter_weight. */
public class HealthParameterWeight {
    private Long parameterWeightId;
    private Long parameterId;
    private BigDecimal weight;
    private LocalDate validFrom;
    private LocalDate validTo;

    /** Object relationship for FK parameterId; the scalar FK remains the persistence source of truth. */
    private HealthParameter parameter;
    public HealthParameterWeight() {}
    public HealthParameterWeight(Long parameterWeightId, Long parameterId, BigDecimal weight, LocalDate validFrom, LocalDate validTo) {
        this.parameterWeightId = parameterWeightId;
        this.parameterId = parameterId;
        this.weight = weight;
        this.validFrom = validFrom;
        this.validTo = validTo;
    }

    public Long getParameterWeightId() { return parameterWeightId; }
    public void setParameterWeightId(Long parameterWeightId) { this.parameterWeightId = parameterWeightId; }
    public Long getParameterId() { return parameterId; }
    public void setParameterId(Long parameterId) { this.parameterId = parameterId; }
    public BigDecimal getWeight() { return weight; }
    public void setWeight(BigDecimal weight) { this.weight = weight; }
    public LocalDate getValidFrom() { return validFrom; }
    public void setValidFrom(LocalDate validFrom) { this.validFrom = validFrom; }
    public LocalDate getValidTo() { return validTo; }
    public void setValidTo(LocalDate validTo) { this.validTo = validTo; }

    public HealthParameter getParameter() { return parameter; }
    public void setParameter(HealthParameter parameter) {
        this.parameter = parameter;
        this.parameterId = parameter == null ? null : parameter.getParameterId();
    }
    @Override
    public String toString() {
        return "HealthParameterWeight{" + "parameterWeightId=" + parameterWeightId + ", " + "parameterId=" + parameterId + ", " + "weight=" + weight + ", " + "validFrom=" + validFrom + ", " + "validTo=" + validTo + "}";
    }
}
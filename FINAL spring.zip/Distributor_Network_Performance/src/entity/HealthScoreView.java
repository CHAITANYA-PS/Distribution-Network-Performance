package entity;

public record HealthScoreView() {

}

package entity;

import java.math.BigDecimal;
import java.time.LocalDate;

/** Maps to dsphere.transportation_activity. */
public class TransportationActivity {
    private Long transportationActivityId;
    private Long shipmentId;
    private Long emissionFactorId;
    private String origin;
    private String destination;
    private BigDecimal distanceKm;
    private LocalDate activityDate;

    /** Object relationship for FK shipmentId; the scalar FK remains the persistence source of truth. */
    private Shipment shipment;
    /** Object relationship for FK emissionFactorId; the scalar FK remains the persistence source of truth. */
    private EmissionFactor emissionFactor;
    public TransportationActivity() {}
    public TransportationActivity(Long transportationActivityId, Long shipmentId, Long emissionFactorId, String origin, String destination, BigDecimal distanceKm, LocalDate activityDate) {
        this.transportationActivityId = transportationActivityId;
        this.shipmentId = shipmentId;
        this.emissionFactorId = emissionFactorId;
        this.origin = origin;
        this.destination = destination;
        this.distanceKm = distanceKm;
        this.activityDate = activityDate;
    }

    public Long getTransportationActivityId() { return transportationActivityId; }
    public void setTransportationActivityId(Long transportationActivityId) { this.transportationActivityId = transportationActivityId; }
    public Long getShipmentId() { return shipmentId; }
    public void setShipmentId(Long shipmentId) { this.shipmentId = shipmentId; }
    public Long getEmissionFactorId() { return emissionFactorId; }
    public void setEmissionFactorId(Long emissionFactorId) { this.emissionFactorId = emissionFactorId; }
    public String getOrigin() { return origin; }
    public void setOrigin(String origin) { this.origin = origin; }
    public String getDestination() { return destination; }
    public void setDestination(String destination) { this.destination = destination; }
    public BigDecimal getDistanceKm() { return distanceKm; }
    public void setDistanceKm(BigDecimal distanceKm) { this.distanceKm = distanceKm; }
    public LocalDate getActivityDate() { return activityDate; }
    public void setActivityDate(LocalDate activityDate) { this.activityDate = activityDate; }

    public Shipment getShipment() { return shipment; }
    public void setShipment(Shipment shipment) {
        this.shipment = shipment;
        this.shipmentId = shipment == null ? null : shipment.getShipmentId();
    }
    public EmissionFactor getEmissionFactor() { return emissionFactor; }
    public void setEmissionFactor(EmissionFactor emissionFactor) {
        this.emissionFactor = emissionFactor;
        this.emissionFactorId = emissionFactor == null ? null : emissionFactor.getEmissionFactorId();
    }
    @Override
    public String toString() {
        return "TransportationActivity{" + "transportationActivityId=" + transportationActivityId + ", " + "shipmentId=" + shipmentId + ", " + "emissionFactorId=" + emissionFactorId + ", " + "origin=" + origin + ", " + "destination=" + destination + ", " + "distanceKm=" + distanceKm + ", " + "activityDate=" + activityDate + "}";
    }
}
package entity;

/** Maps to dsphere.recovery_plan_status. */
public class RecoveryPlanStatus {
    private Long recoveryStatusId;
    private String statusName;

    public RecoveryPlanStatus() {}
    public RecoveryPlanStatus(Long recoveryStatusId, String statusName) {
        this.recoveryStatusId = recoveryStatusId;
        this.statusName = statusName;
    }

    public Long getRecoveryStatusId() { return recoveryStatusId; }
    public void setRecoveryStatusId(Long recoveryStatusId) { this.recoveryStatusId = recoveryStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }

    @Override
    public String toString() {
        return "RecoveryPlanStatus{" + "recoveryStatusId=" + recoveryStatusId + ", " + "statusName=" + statusName + "}";
    }
}
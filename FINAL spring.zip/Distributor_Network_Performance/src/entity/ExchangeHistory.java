package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.exchange_history. */
public class ExchangeHistory {
    private Long exchangeHistoryId;
    private Long exchangeId;
    private Long exchangeStatusId;
    private Long changedBy;
    private String remarks;
    private OffsetDateTime changedAt;

    /** Object relationship for FK exchangeId; the scalar FK remains the persistence source of truth. */
    private ExchangeRequest exchange;
    /** Object relationship for FK exchangeStatusId; the scalar FK remains the persistence source of truth. */
    private ExchangeStatus exchangeStatus;
    /** Object relationship for FK changedBy; the scalar FK remains the persistence source of truth. */
    private AppUser changedByUser;
    public ExchangeHistory() {}
    public ExchangeHistory(Long exchangeHistoryId, Long exchangeId, Long exchangeStatusId, Long changedBy, String remarks, OffsetDateTime changedAt) {
        this.exchangeHistoryId = exchangeHistoryId;
        this.exchangeId = exchangeId;
        this.exchangeStatusId = exchangeStatusId;
        this.changedBy = changedBy;
        this.remarks = remarks;
        this.changedAt = changedAt;
    }

    public Long getExchangeHistoryId() { return exchangeHistoryId; }
    public void setExchangeHistoryId(Long exchangeHistoryId) { this.exchangeHistoryId = exchangeHistoryId; }
    public Long getExchangeId() { return exchangeId; }
    public void setExchangeId(Long exchangeId) { this.exchangeId = exchangeId; }
    public Long getExchangeStatusId() { return exchangeStatusId; }
    public void setExchangeStatusId(Long exchangeStatusId) { this.exchangeStatusId = exchangeStatusId; }
    public Long getChangedBy() { return changedBy; }
    public void setChangedBy(Long changedBy) { this.changedBy = changedBy; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public OffsetDateTime getChangedAt() { return changedAt; }
    public void setChangedAt(OffsetDateTime changedAt) { this.changedAt = changedAt; }

    public ExchangeRequest getExchange() { return exchange; }
    public void setExchange(ExchangeRequest exchange) {
        this.exchange = exchange;
        this.exchangeId = exchange == null ? null : exchange.getExchangeId();
    }
    public ExchangeStatus getExchangeStatus() { return exchangeStatus; }
    public void setExchangeStatus(ExchangeStatus exchangeStatus) {
        this.exchangeStatus = exchangeStatus;
        this.exchangeStatusId = exchangeStatus == null ? null : exchangeStatus.getExchangeStatusId();
    }
    public AppUser getChangedByUser() { return changedByUser; }
    public void setChangedByUser(AppUser changedByUser) {
        this.changedByUser = changedByUser;
        this.changedBy = changedByUser == null ? null : changedByUser.getUserId();
    }
    @Override
    public String toString() {
        return "ExchangeHistory{" + "exchangeHistoryId=" + exchangeHistoryId + ", " + "exchangeId=" + exchangeId + ", " + "exchangeStatusId=" + exchangeStatusId + ", " + "changedBy=" + changedBy + ", " + "remarks=" + remarks + ", " + "changedAt=" + changedAt + "}";
    }
}
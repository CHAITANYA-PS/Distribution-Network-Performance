package entity;

/** Maps to dsphere.risk_level. */
public class RiskLevel {
    private Long riskLevelId;
    private String riskLevelName;
    private Integer severityRank;

    public RiskLevel() {}
    public RiskLevel(Long riskLevelId, String riskLevelName, Integer severityRank) {
        this.riskLevelId = riskLevelId;
        this.riskLevelName = riskLevelName;
        this.severityRank = severityRank;
    }

    public Long getRiskLevelId() { return riskLevelId; }
    public void setRiskLevelId(Long riskLevelId) { this.riskLevelId = riskLevelId; }
    public String getRiskLevelName() { return riskLevelName; }
    public void setRiskLevelName(String riskLevelName) { this.riskLevelName = riskLevelName; }
    public Integer getSeverityRank() { return severityRank; }
    public void setSeverityRank(Integer severityRank) { this.severityRank = severityRank; }

    @Override
    public String toString() {
        return "RiskLevel{" + "riskLevelId=" + riskLevelId + ", " + "riskLevelName=" + riskLevelName + ", " + "severityRank=" + severityRank + "}";
    }
}
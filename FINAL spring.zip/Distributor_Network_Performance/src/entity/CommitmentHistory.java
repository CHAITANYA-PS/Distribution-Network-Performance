package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.commitment_history. */
public class CommitmentHistory {
    private Long historyId;
    private Long commitmentId;
    private String action;
    private Long actionBy;
    private String remarks;
    private OffsetDateTime actionAt;

    /** Object relationship for FK commitmentId; the scalar FK remains the persistence source of truth. */
    private Commitment commitment;
    /** Object relationship for FK actionBy; the scalar FK remains the persistence source of truth. */
    private AppUser actionUser;
    public CommitmentHistory() {}
    public CommitmentHistory(Long historyId, Long commitmentId, String action, Long actionBy, String remarks, OffsetDateTime actionAt) {
        this.historyId = historyId;
        this.commitmentId = commitmentId;
        this.action = action;
        this.actionBy = actionBy;
        this.remarks = remarks;
        this.actionAt = actionAt;
    }

    public Long getHistoryId() { return historyId; }
    public void setHistoryId(Long historyId) { this.historyId = historyId; }
    public Long getCommitmentId() { return commitmentId; }
    public void setCommitmentId(Long commitmentId) { this.commitmentId = commitmentId; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public Long getActionBy() { return actionBy; }
    public void setActionBy(Long actionBy) { this.actionBy = actionBy; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public OffsetDateTime getActionAt() { return actionAt; }
    public void setActionAt(OffsetDateTime actionAt) { this.actionAt = actionAt; }

    public Commitment getCommitment() { return commitment; }
    public void setCommitment(Commitment commitment) {
        this.commitment = commitment;
        this.commitmentId = commitment == null ? null : commitment.getCommitmentId();
    }
    public AppUser getActionUser() { return actionUser; }
    public void setActionUser(AppUser actionUser) {
        this.actionUser = actionUser;
        this.actionBy = actionUser == null ? null : actionUser.getUserId();
    }
    @Override
    public String toString() {
        return "CommitmentHistory{" + "historyId=" + historyId + ", " + "commitmentId=" + commitmentId + ", " + "action=" + action + ", " + "actionBy=" + actionBy + ", " + "remarks=" + remarks + ", " + "actionAt=" + actionAt + "}";
    }
}
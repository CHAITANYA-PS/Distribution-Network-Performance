package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.ticket_comment. */
public class TicketComment {
    private Long commentId;
    private Long ticketId;
    private Long userId;
    private String commentText;
    private OffsetDateTime createdAt;

    /** Object relationship for FK ticketId; the scalar FK remains the persistence source of truth. */
    private Ticket ticket;
    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    public TicketComment() {}
    public TicketComment(Long commentId, Long ticketId, Long userId, String commentText, OffsetDateTime createdAt) {
        this.commentId = commentId;
        this.ticketId = ticketId;
        this.userId = userId;
        this.commentText = commentText;
        this.createdAt = createdAt;
    }

    public Long getCommentId() { return commentId; }
    public void setCommentId(Long commentId) { this.commentId = commentId; }
    public Long getTicketId() { return ticketId; }
    public void setTicketId(Long ticketId) { this.ticketId = ticketId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getCommentText() { return commentText; }
    public void setCommentText(String commentText) { this.commentText = commentText; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public Ticket getTicket() { return ticket; }
    public void setTicket(Ticket ticket) {
        this.ticket = ticket;
        this.ticketId = ticket == null ? null : ticket.getTicketId();
    }
    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    @Override
    public String toString() {
        return "TicketComment{" + "commentId=" + commentId + ", " + "ticketId=" + ticketId + ", " + "userId=" + userId + ", " + "commentText=" + commentText + ", " + "createdAt=" + createdAt + "}";
    }
}
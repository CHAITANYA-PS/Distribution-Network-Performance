package entity;

/** Maps to dsphere.sales_manager. */
public class SalesManager {
    private Long userId;
    private Long regionId;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    /** Object relationship for FK regionId; the scalar FK remains the persistence source of truth. */
    private Region region;
    public SalesManager() {}
    public SalesManager(Long userId, Long regionId) {
        this.userId = userId;
        this.regionId = regionId;
    }

    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    public Region getRegion() { return region; }
    public void setRegion(Region region) {
        this.region = region;
        this.regionId = region == null ? null : region.getRegionId();
    }
    @Override
    public String toString() {
        return "SalesManager{" + "userId=" + userId + ", " + "regionId=" + regionId + "}";
    }
}
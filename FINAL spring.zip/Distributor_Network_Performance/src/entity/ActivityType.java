package entity;

/** Maps to dsphere.activity_type. */
public class ActivityType {
    private Long activityTypeId;
    private String activityTypeName;
    private String description;

    public ActivityType() {}
    public ActivityType(Long activityTypeId, String activityTypeName, String description) {
        this.activityTypeId = activityTypeId;
        this.activityTypeName = activityTypeName;
        this.description = description;
    }

    public Long getActivityTypeId() { return activityTypeId; }
    public void setActivityTypeId(Long activityTypeId) { this.activityTypeId = activityTypeId; }
    public String getActivityTypeName() { return activityTypeName; }
    public void setActivityTypeName(String activityTypeName) { this.activityTypeName = activityTypeName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }

    @Override
    public String toString() {
        return "ActivityType{" + "activityTypeId=" + activityTypeId + ", " + "activityTypeName=" + activityTypeName + ", " + "description=" + description + "}";
    }
}
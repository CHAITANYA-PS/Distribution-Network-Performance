package entity;

/** Maps to dsphere.order_status. */
public class OrderStatus {
    private Long orderStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public OrderStatus() {}
    public OrderStatus(Long orderStatusId, String statusName, Integer sequenceNumber, Boolean isTerminal) {
        this.orderStatusId = orderStatusId;
        this.statusName = statusName;
        this.sequenceNumber = sequenceNumber;
        this.isTerminal = isTerminal;
    }

    public Long getOrderStatusId() { return orderStatusId; }
    public void setOrderStatusId(Long orderStatusId) { this.orderStatusId = orderStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }
    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }
    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

    @Override
    public String toString() {
        return "OrderStatus{" + "orderStatusId=" + orderStatusId + ", " + "statusName=" + statusName + ", " + "sequenceNumber=" + sequenceNumber + ", " + "isTerminal=" + isTerminal + "}";
    }
}
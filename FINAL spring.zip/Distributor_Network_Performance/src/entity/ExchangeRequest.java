package entity;

import java.math.BigDecimal;
import java.time.OffsetDateTime;

/** Maps to dsphere.exchange_request. */
public class ExchangeRequest {
    private Long exchangeId;
    private Long distributorId;
    private Long productId;
    private BigDecimal requestedQuantity;
    private String sourceLocation;
    private Long exchangeStatusId;
    private Long requestedBy;
    private OffsetDateTime requestedAt;

    /** Object relationship for FK distributorId; the scalar FK remains the persistence source of truth. */
    private Distributor distributor;
    /** Object relationship for FK productId; the scalar FK remains the persistence source of truth. */
    private Product product;
    /** Object relationship for FK exchangeStatusId; the scalar FK remains the persistence source of truth. */
    private ExchangeStatus exchangeStatus;
    /** Object relationship for FK requestedBy; the scalar FK remains the persistence source of truth. */
    private AppUser requester;
    public ExchangeRequest() {}
    public ExchangeRequest(Long exchangeId, Long distributorId, Long productId, BigDecimal requestedQuantity, String sourceLocation, Long exchangeStatusId, Long requestedBy, OffsetDateTime requestedAt) {
        this.exchangeId = exchangeId;
        this.distributorId = distributorId;
        this.productId = productId;
        this.requestedQuantity = requestedQuantity;
        this.sourceLocation = sourceLocation;
        this.exchangeStatusId = exchangeStatusId;
        this.requestedBy = requestedBy;
        this.requestedAt = requestedAt;
    }

    public Long getExchangeId() { return exchangeId; }
    public void setExchangeId(Long exchangeId) { this.exchangeId = exchangeId; }
    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public BigDecimal getRequestedQuantity() { return requestedQuantity; }
    public void setRequestedQuantity(BigDecimal requestedQuantity) { this.requestedQuantity = requestedQuantity; }
    public String getSourceLocation() { return sourceLocation; }
    public void setSourceLocation(String sourceLocation) { this.sourceLocation = sourceLocation; }
    public Long getExchangeStatusId() { return exchangeStatusId; }
    public void setExchangeStatusId(Long exchangeStatusId) { this.exchangeStatusId = exchangeStatusId; }
    public Long getRequestedBy() { return requestedBy; }
    public void setRequestedBy(Long requestedBy) { this.requestedBy = requestedBy; }
    public OffsetDateTime getRequestedAt() { return requestedAt; }
    public void setRequestedAt(OffsetDateTime requestedAt) { this.requestedAt = requestedAt; }

    public Distributor getDistributor() { return distributor; }
    public void setDistributor(Distributor distributor) {
        this.distributor = distributor;
        this.distributorId = distributor == null ? null : distributor.getDistributorId();
    }
    public Product getProduct() { return product; }
    public void setProduct(Product product) {
        this.product = product;
        this.productId = product == null ? null : product.getProductId();
    }
    public ExchangeStatus getExchangeStatus() { return exchangeStatus; }
    public void setExchangeStatus(ExchangeStatus exchangeStatus) {
        this.exchangeStatus = exchangeStatus;
        this.exchangeStatusId = exchangeStatus == null ? null : exchangeStatus.getExchangeStatusId();
    }
    public AppUser getRequester() { return requester; }
    public void setRequester(AppUser requester) {
        this.requester = requester;
        this.requestedBy = requester == null ? null : requester.getUserId();
    }
    @Override
    public String toString() {
        return "ExchangeRequest{" + "exchangeId=" + exchangeId + ", " + "distributorId=" + distributorId + ", " + "productId=" + productId + ", " + "requestedQuantity=" + requestedQuantity + ", " + "sourceLocation=" + sourceLocation + ", " + "exchangeStatusId=" + exchangeStatusId + ", " + "requestedBy=" + requestedBy + ", " + "requestedAt=" + requestedAt + "}";
    }
}
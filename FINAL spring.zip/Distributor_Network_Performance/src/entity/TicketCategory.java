package entity;

/** Maps to dsphere.ticket_category. */
public class TicketCategory {
    private Long ticketCategoryId;
    private String categoryName;

    public TicketCategory() {}
    public TicketCategory(Long ticketCategoryId, String categoryName) {
        this.ticketCategoryId = ticketCategoryId;
        this.categoryName = categoryName;
    }

    public Long getTicketCategoryId() { return ticketCategoryId; }
    public void setTicketCategoryId(Long ticketCategoryId) { this.ticketCategoryId = ticketCategoryId; }
    public String getCategoryName() { return categoryName; }
    public void setCategoryName(String categoryName) { this.categoryName = categoryName; }

    @Override
    public String toString() {
        return "TicketCategory{" + "ticketCategoryId=" + ticketCategoryId + ", " + "categoryName=" + categoryName + "}";
    }
}
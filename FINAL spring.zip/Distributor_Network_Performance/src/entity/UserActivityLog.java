package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.user_activity_log. */
public class UserActivityLog {
    private Long logId;
    private Long userId;
    private String action;
    private String details;
    private String ipAddress;
    private OffsetDateTime createdAt;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    public UserActivityLog() {}
    public UserActivityLog(Long logId, Long userId, String action, String details, String ipAddress, OffsetDateTime createdAt) {
        this.logId = logId;
        this.userId = userId;
        this.action = action;
        this.details = details;
        this.ipAddress = ipAddress;
        this.createdAt = createdAt;
    }

    public Long getLogId() { return logId; }
    public void setLogId(Long logId) { this.logId = logId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public String getAction() { return action; }
    public void setAction(String action) { this.action = action; }
    public String getDetails() { return details; }
    public void setDetails(String details) { this.details = details; }
    public String getIpAddress() { return ipAddress; }
    public void setIpAddress(String ipAddress) { this.ipAddress = ipAddress; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    @Override
    public String toString() {
        return "UserActivityLog{" + "logId=" + logId + ", " + "userId=" + userId + ", " + "action=" + action + ", " + "details=" + details + ", " + "ipAddress=" + ipAddress + ", " + "createdAt=" + createdAt + "}";
    }
}
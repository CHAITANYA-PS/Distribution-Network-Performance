package entity;

/** Maps to dsphere.ticket_priority. */
public class TicketPriority {
    private Long ticketPriorityId;
    private String priorityName;
    private Integer severityRank;

    public TicketPriority() {}
    public TicketPriority(Long ticketPriorityId, String priorityName, Integer severityRank) {
        this.ticketPriorityId = ticketPriorityId;
        this.priorityName = priorityName;
        this.severityRank = severityRank;
    }

    public Long getTicketPriorityId() { return ticketPriorityId; }
    public void setTicketPriorityId(Long ticketPriorityId) { this.ticketPriorityId = ticketPriorityId; }
    public String getPriorityName() { return priorityName; }
    public void setPriorityName(String priorityName) { this.priorityName = priorityName; }
    public Integer getSeverityRank() { return severityRank; }
    public void setSeverityRank(Integer severityRank) { this.severityRank = severityRank; }

    @Override
    public String toString() {
        return "TicketPriority{" + "ticketPriorityId=" + ticketPriorityId + ", " + "priorityName=" + priorityName + ", " + "severityRank=" + severityRank + "}";
    }
}
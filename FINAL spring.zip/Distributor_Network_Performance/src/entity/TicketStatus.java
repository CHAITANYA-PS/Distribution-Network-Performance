package entity;

/** Maps to dsphere.ticket_status. */
public class TicketStatus {
    private Long ticketStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public TicketStatus() {}
    public TicketStatus(Long ticketStatusId, String statusName, Integer sequenceNumber, Boolean isTerminal) {
        this.ticketStatusId = ticketStatusId;
        this.statusName = statusName;
        this.sequenceNumber = sequenceNumber;
        this.isTerminal = isTerminal;
    }

    public Long getTicketStatusId() { return ticketStatusId; }
    public void setTicketStatusId(Long ticketStatusId) { this.ticketStatusId = ticketStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }
    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }
    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

    @Override
    public String toString() {
        return "TicketStatus{" + "ticketStatusId=" + ticketStatusId + ", " + "statusName=" + statusName + ", " + "sequenceNumber=" + sequenceNumber + ", " + "isTerminal=" + isTerminal + "}";
    }
}
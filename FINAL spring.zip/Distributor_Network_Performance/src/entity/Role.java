package entity;

/** Maps to dsphere.role. */
public class Role {
    private Long roleId;
    private String roleName;
    private String description;
    private String status;

    public Role() {}
    public Role(Long roleId, String roleName, String description, String status) {
        this.roleId = roleId;
        this.roleName = roleName;
        this.description = description;
        this.status = status;
    }

    public Long getRoleId() { return roleId; }
    public void setRoleId(Long roleId) { this.roleId = roleId; }
    public String getRoleName() { return roleName; }
    public void setRoleName(String roleName) { this.roleName = roleName; }
    public String getDescription() { return description; }
    public void setDescription(String description) { this.description = description; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Role{" + "roleId=" + roleId + ", " + "roleName=" + roleName + ", " + "description=" + description + ", " + "status=" + status + "}";
    }
}
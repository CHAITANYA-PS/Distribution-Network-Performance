package entity;

public class CreditUtilizationView {

}

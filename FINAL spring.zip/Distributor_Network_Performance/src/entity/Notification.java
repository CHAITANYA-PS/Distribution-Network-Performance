package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.notification. */
public class Notification {
    private Long notificationId;
    private Long userId;
    private Long notificationTypeId;
    private String message;
    private Boolean readStatus;
    private OffsetDateTime createdAt;

    /** Object relationship for FK userId; the scalar FK remains the persistence source of truth. */
    private AppUser user;
    /** Object relationship for FK notificationTypeId; the scalar FK remains the persistence source of truth. */
    private NotificationType notificationType;
    public Notification() {}
    public Notification(Long notificationId, Long userId, Long notificationTypeId, String message, Boolean readStatus, OffsetDateTime createdAt) {
        this.notificationId = notificationId;
        this.userId = userId;
        this.notificationTypeId = notificationTypeId;
        this.message = message;
        this.readStatus = readStatus;
        this.createdAt = createdAt;
    }

    public Long getNotificationId() { return notificationId; }
    public void setNotificationId(Long notificationId) { this.notificationId = notificationId; }
    public Long getUserId() { return userId; }
    public void setUserId(Long userId) { this.userId = userId; }
    public Long getNotificationTypeId() { return notificationTypeId; }
    public void setNotificationTypeId(Long notificationTypeId) { this.notificationTypeId = notificationTypeId; }
    public String getMessage() { return message; }
    public void setMessage(String message) { this.message = message; }
    public Boolean getReadStatus() { return readStatus; }
    public void setReadStatus(Boolean readStatus) { this.readStatus = readStatus; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }

    public AppUser getUser() { return user; }
    public void setUser(AppUser user) {
        this.user = user;
        this.userId = user == null ? null : user.getUserId();
    }
    public NotificationType getNotificationType() { return notificationType; }
    public void setNotificationType(NotificationType notificationType) {
        this.notificationType = notificationType;
        this.notificationTypeId = notificationType == null ? null : notificationType.getNotificationTypeId();
    }
    @Override
    public String toString() {
        return "Notification{" + "notificationId=" + notificationId + ", " + "userId=" + userId + ", " + "notificationTypeId=" + notificationTypeId + ", " + "message=" + message + ", " + "readStatus=" + readStatus + ", " + "createdAt=" + createdAt + "}";
    }
}
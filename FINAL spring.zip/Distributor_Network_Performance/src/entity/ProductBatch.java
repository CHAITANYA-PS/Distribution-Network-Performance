package entity;

import java.time.LocalDate;

/** Maps to dsphere.product_batch. */
public class ProductBatch {
    private Long productBatchId;
    private Long productId;
    private String batchNumber;
    private LocalDate manufacturingDate;
    private LocalDate expiryDate;
    private String operationalStatus;

    /** Object relationship for FK productId; the scalar FK remains the persistence source of truth. */
    private Product product;
    public ProductBatch() {}
    public ProductBatch(Long productBatchId, Long productId, String batchNumber, LocalDate manufacturingDate, LocalDate expiryDate, String operationalStatus) {
        this.productBatchId = productBatchId;
        this.productId = productId;
        this.batchNumber = batchNumber;
        this.manufacturingDate = manufacturingDate;
        this.expiryDate = expiryDate;
        this.operationalStatus = operationalStatus;
    }

    public Long getProductBatchId() { return productBatchId; }
    public void setProductBatchId(Long productBatchId) { this.productBatchId = productBatchId; }
    public Long getProductId() { return productId; }
    public void setProductId(Long productId) { this.productId = productId; }
    public String getBatchNumber() { return batchNumber; }
    public void setBatchNumber(String batchNumber) { this.batchNumber = batchNumber; }
    public LocalDate getManufacturingDate() { return manufacturingDate; }
    public void setManufacturingDate(LocalDate manufacturingDate) { this.manufacturingDate = manufacturingDate; }
    public LocalDate getExpiryDate() { return expiryDate; }
    public void setExpiryDate(LocalDate expiryDate) { this.expiryDate = expiryDate; }
    public String getOperationalStatus() { return operationalStatus; }
    public void setOperationalStatus(String operationalStatus) { this.operationalStatus = operationalStatus; }

    public Product getProduct() { return product; }
    public void setProduct(Product product) {
        this.product = product;
        this.productId = product == null ? null : product.getProductId();
    }
    @Override
    public String toString() {
        return "ProductBatch{" + "productBatchId=" + productBatchId + ", " + "productId=" + productId + ", " + "batchNumber=" + batchNumber + ", " + "manufacturingDate=" + manufacturingDate + ", " + "expiryDate=" + expiryDate + ", " + "operationalStatus=" + operationalStatus + "}";
    }
}
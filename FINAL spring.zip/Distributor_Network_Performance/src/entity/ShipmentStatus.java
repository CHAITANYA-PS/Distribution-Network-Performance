package entity;

/** Maps to dsphere.shipment_status. */
public class ShipmentStatus {
    private Long shipmentStatusId;
    private String statusName;
    private Integer sequenceNumber;
    private Boolean isTerminal;

    public ShipmentStatus() {}
    public ShipmentStatus(Long shipmentStatusId, String statusName, Integer sequenceNumber, Boolean isTerminal) {
        this.shipmentStatusId = shipmentStatusId;
        this.statusName = statusName;
        this.sequenceNumber = sequenceNumber;
        this.isTerminal = isTerminal;
    }

    public Long getShipmentStatusId() { return shipmentStatusId; }
    public void setShipmentStatusId(Long shipmentStatusId) { this.shipmentStatusId = shipmentStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }
    public Integer getSequenceNumber() { return sequenceNumber; }
    public void setSequenceNumber(Integer sequenceNumber) { this.sequenceNumber = sequenceNumber; }
    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

    @Override
    public String toString() {
        return "ShipmentStatus{" + "shipmentStatusId=" + shipmentStatusId + ", " + "statusName=" + statusName + ", " + "sequenceNumber=" + sequenceNumber + ", " + "isTerminal=" + isTerminal + "}";
    }
}
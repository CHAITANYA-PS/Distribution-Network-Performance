package entity;

/** Maps to dsphere.commitment_status. */
public class CommitmentStatus {
    private Long commitmentStatusId;
    private String statusName;
    private Boolean isTerminal;

    public CommitmentStatus() {}
    public CommitmentStatus(Long commitmentStatusId, String statusName, Boolean isTerminal) {
        this.commitmentStatusId = commitmentStatusId;
        this.statusName = statusName;
        this.isTerminal = isTerminal;
    }

    public Long getCommitmentStatusId() { return commitmentStatusId; }
    public void setCommitmentStatusId(Long commitmentStatusId) { this.commitmentStatusId = commitmentStatusId; }
    public String getStatusName() { return statusName; }
    public void setStatusName(String statusName) { this.statusName = statusName; }
    public Boolean getIsTerminal() { return isTerminal; }
    public void setIsTerminal(Boolean isTerminal) { this.isTerminal = isTerminal; }

    @Override
    public String toString() {
        return "CommitmentStatus{" + "commitmentStatusId=" + commitmentStatusId + ", " + "statusName=" + statusName + ", " + "isTerminal=" + isTerminal + "}";
    }
}
package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.order_status_history. */
public class OrderStatusHistory {
    private Long orderStatusHistoryId;
    private Long orderId;
    private Long orderStatusId;
    private Long changedBy;
    private String remarks;
    private OffsetDateTime changedAt;

    /** Object relationship for FK orderId; the scalar FK remains the persistence source of truth. */
    private DistributorOrder order;
    /** Object relationship for FK orderStatusId; the scalar FK remains the persistence source of truth. */
    private OrderStatus orderStatus;
    /** Object relationship for FK changedBy; the scalar FK remains the persistence source of truth. */
    private AppUser changedByUser;
    public OrderStatusHistory() {}
    public OrderStatusHistory(Long orderStatusHistoryId, Long orderId, Long orderStatusId, Long changedBy, String remarks, OffsetDateTime changedAt) {
        this.orderStatusHistoryId = orderStatusHistoryId;
        this.orderId = orderId;
        this.orderStatusId = orderStatusId;
        this.changedBy = changedBy;
        this.remarks = remarks;
        this.changedAt = changedAt;
    }

    public Long getOrderStatusHistoryId() { return orderStatusHistoryId; }
    public void setOrderStatusHistoryId(Long orderStatusHistoryId) { this.orderStatusHistoryId = orderStatusHistoryId; }
    public Long getOrderId() { return orderId; }
    public void setOrderId(Long orderId) { this.orderId = orderId; }
    public Long getOrderStatusId() { return orderStatusId; }
    public void setOrderStatusId(Long orderStatusId) { this.orderStatusId = orderStatusId; }
    public Long getChangedBy() { return changedBy; }
    public void setChangedBy(Long changedBy) { this.changedBy = changedBy; }
    public String getRemarks() { return remarks; }
    public void setRemarks(String remarks) { this.remarks = remarks; }
    public OffsetDateTime getChangedAt() { return changedAt; }
    public void setChangedAt(OffsetDateTime changedAt) { this.changedAt = changedAt; }

    public DistributorOrder getOrder() { return order; }
    public void setOrder(DistributorOrder order) {
        this.order = order;
        this.orderId = order == null ? null : order.getOrderId();
    }
    public OrderStatus getOrderStatus() { return orderStatus; }
    public void setOrderStatus(OrderStatus orderStatus) {
        this.orderStatus = orderStatus;
        this.orderStatusId = orderStatus == null ? null : orderStatus.getOrderStatusId();
    }
    public AppUser getChangedByUser() { return changedByUser; }
    public void setChangedByUser(AppUser changedByUser) {
        this.changedByUser = changedByUser;
        this.changedBy = changedByUser == null ? null : changedByUser.getUserId();
    }
    @Override
    public String toString() {
        return "OrderStatusHistory{" + "orderStatusHistoryId=" + orderStatusHistoryId + ", " + "orderId=" + orderId + ", " + "orderStatusId=" + orderStatusId + ", " + "changedBy=" + changedBy + ", " + "remarks=" + remarks + ", " + "changedAt=" + changedAt + "}";
    }
}
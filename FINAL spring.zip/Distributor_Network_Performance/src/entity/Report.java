package entity;

import java.time.OffsetDateTime;

/** Maps to dsphere.report. */
public class Report {
    private Long reportId;
    private String reportName;
    private String module;
    private String format;
    private Long generatedBy;
    private OffsetDateTime generatedAt;
    private String filePath;

    /** Object relationship for FK generatedBy; the scalar FK remains the persistence source of truth. */
    private AppUser generator;
    public Report() {}
    public Report(Long reportId, String reportName, String module, String format, Long generatedBy, OffsetDateTime generatedAt, String filePath) {
        this.reportId = reportId;
        this.reportName = reportName;
        this.module = module;
        this.format = format;
        this.generatedBy = generatedBy;
        this.generatedAt = generatedAt;
        this.filePath = filePath;
    }

    public Long getReportId() { return reportId; }
    public void setReportId(Long reportId) { this.reportId = reportId; }
    public String getReportName() { return reportName; }
    public void setReportName(String reportName) { this.reportName = reportName; }
    public String getModule() { return module; }
    public void setModule(String module) { this.module = module; }
    public String getFormat() { return format; }
    public void setFormat(String format) { this.format = format; }
    public Long getGeneratedBy() { return generatedBy; }
    public void setGeneratedBy(Long generatedBy) { this.generatedBy = generatedBy; }
    public OffsetDateTime getGeneratedAt() { return generatedAt; }
    public void setGeneratedAt(OffsetDateTime generatedAt) { this.generatedAt = generatedAt; }
    public String getFilePath() { return filePath; }
    public void setFilePath(String filePath) { this.filePath = filePath; }

    public AppUser getGenerator() { return generator; }
    public void setGenerator(AppUser generator) {
        this.generator = generator;
        this.generatedBy = generator == null ? null : generator.getUserId();
    }
    @Override
    public String toString() {
        return "Report{" + "reportId=" + reportId + ", " + "reportName=" + reportName + ", " + "module=" + module + ", " + "format=" + format + ", " + "generatedBy=" + generatedBy + ", " + "generatedAt=" + generatedAt + ", " + "filePath=" + filePath + "}";
    }
}
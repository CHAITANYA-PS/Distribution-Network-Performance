package entity;

/** Maps to dsphere.manufacturer. */
public class Manufacturer {
    private Long manufacturerId;
    private String manufacturerCode;
    private String manufacturerName;
    private String email;
    private String phone;
    private String address;
    private String status;

    public Manufacturer() {}
    public Manufacturer(Long manufacturerId, String manufacturerCode, String manufacturerName, String email, String phone, String address, String status) {
        this.manufacturerId = manufacturerId;
        this.manufacturerCode = manufacturerCode;
        this.manufacturerName = manufacturerName;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.status = status;
    }

    public Long getManufacturerId() { return manufacturerId; }
    public void setManufacturerId(Long manufacturerId) { this.manufacturerId = manufacturerId; }
    public String getManufacturerCode() { return manufacturerCode; }
    public void setManufacturerCode(String manufacturerCode) { this.manufacturerCode = manufacturerCode; }
    public String getManufacturerName() { return manufacturerName; }
    public void setManufacturerName(String manufacturerName) { this.manufacturerName = manufacturerName; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    @Override
    public String toString() {
        return "Manufacturer{" + "manufacturerId=" + manufacturerId + ", " + "manufacturerCode=" + manufacturerCode + ", " + "manufacturerName=" + manufacturerName + ", " + "email=" + email + ", " + "phone=" + phone + ", " + "address=" + address + ", " + "status=" + status + "}";
    }
}
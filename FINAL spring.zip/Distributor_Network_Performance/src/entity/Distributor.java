package entity;

import java.time.LocalDate;
import java.time.OffsetDateTime;

/** Maps to dsphere.distributor. */
public class Distributor {
    private Long distributorId;
    private String distributorCode;
    private String distributorName;
    private Long regionId;
    private String contactPerson;
    private String email;
    private String phone;
    private String address;
    private String status;
    private LocalDate onboardingDate;
    private OffsetDateTime createdAt;
    private OffsetDateTime updatedAt;

    /** Object relationship for FK regionId; the scalar FK remains the persistence source of truth. */
    private Region region;
    public Distributor() {}
    public Distributor(Long distributorId, String distributorCode, String distributorName, Long regionId, String contactPerson, String email, String phone, String address, String status, LocalDate onboardingDate, OffsetDateTime createdAt, OffsetDateTime updatedAt) {
        this.distributorId = distributorId;
        this.distributorCode = distributorCode;
        this.distributorName = distributorName;
        this.regionId = regionId;
        this.contactPerson = contactPerson;
        this.email = email;
        this.phone = phone;
        this.address = address;
        this.status = status;
        this.onboardingDate = onboardingDate;
        this.createdAt = createdAt;
        this.updatedAt = updatedAt;
    }

    public Long getDistributorId() { return distributorId; }
    public void setDistributorId(Long distributorId) { this.distributorId = distributorId; }
    public String getDistributorCode() { return distributorCode; }
    public void setDistributorCode(String distributorCode) { this.distributorCode = distributorCode; }
    public String getDistributorName() { return distributorName; }
    public void setDistributorName(String distributorName) { this.distributorName = distributorName; }
    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }
    public String getContactPerson() { return contactPerson; }
    public void setContactPerson(String contactPerson) { this.contactPerson = contactPerson; }
    public String getEmail() { return email; }
    public void setEmail(String email) { this.email = email; }
    public String getPhone() { return phone; }
    public void setPhone(String phone) { this.phone = phone; }
    public String getAddress() { return address; }
    public void setAddress(String address) { this.address = address; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }
    public LocalDate getOnboardingDate() { return onboardingDate; }
    public void setOnboardingDate(LocalDate onboardingDate) { this.onboardingDate = onboardingDate; }
    public OffsetDateTime getCreatedAt() { return createdAt; }
    public void setCreatedAt(OffsetDateTime createdAt) { this.createdAt = createdAt; }
    public OffsetDateTime getUpdatedAt() { return updatedAt; }
    public void setUpdatedAt(OffsetDateTime updatedAt) { this.updatedAt = updatedAt; }

    public Region getRegion() { return region; }
    public void setRegion(Region region) {
        this.region = region;
        this.regionId = region == null ? null : region.getRegionId();
    }
    @Override
    public String toString() {
        return "Distributor{" + "distributorId=" + distributorId + ", " + "distributorCode=" + distributorCode + ", " + "distributorName=" + distributorName + ", " + "regionId=" + regionId + ", " + "contactPerson=" + contactPerson + ", " + "email=" + email + ", " + "phone=" + phone + ", " + "address=" + address + ", " + "status=" + status + ", " + "onboardingDate=" + onboardingDate + ", " + "createdAt=" + createdAt + ", " + "updatedAt=" + updatedAt + "}";
    }
}
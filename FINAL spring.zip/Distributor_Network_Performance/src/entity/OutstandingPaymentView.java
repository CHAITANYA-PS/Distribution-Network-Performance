package entity;

import java.math.BigDecimal;

public class OutstandingPaymentView {

    private Long paymentId;
    private Long customerId;
    private String customerName;
    private BigDecimal outstandingAmount;
    private String paymentStatus;
    private String dueDate;

    public OutstandingPaymentView() {
    }

    public Long getPaymentId() {
        return paymentId;
    }

    public void setPaymentId(Long paymentId) {
        this.paymentId = paymentId;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public BigDecimal getOutstandingAmount() {
        return outstandingAmount;
    }

    public void setOutstandingAmount(BigDecimal outstandingAmount) {
        this.outstandingAmount = outstandingAmount;
    }

    public String getPaymentStatus() {
        return paymentStatus;
    }

    public void setPaymentStatus(String paymentStatus) {
        this.paymentStatus = paymentStatus;
    }

    public String getDueDate() {
        return dueDate;
    }

    public void setDueDate(String dueDate) {
        this.dueDate = dueDate;
    }

    @Override
    public String toString() {
        return "OutstandingPaymentView [paymentId=" + paymentId
                + ", customerId=" + customerId
                + ", customerName=" + customerName
                + ", outstandingAmount=" + outstandingAmount
                + ", paymentStatus=" + paymentStatus
                + ", dueDate=" + dueDate + "]";
    }
}
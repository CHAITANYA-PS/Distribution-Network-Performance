package entity;

public class CurrentStockView {

}

package entity;

import java.math.BigDecimal;

/** Maps to dsphere.risk_band. */
public class RiskBand {
    private Long riskBandId;
    private String riskCategory;
    private BigDecimal minimumScore;
    private BigDecimal maximumScore;

    public RiskBand() {}
    public RiskBand(Long riskBandId, String riskCategory, BigDecimal minimumScore, BigDecimal maximumScore) {
        this.riskBandId = riskBandId;
        this.riskCategory = riskCategory;
        this.minimumScore = minimumScore;
        this.maximumScore = maximumScore;
    }

    public Long getRiskBandId() { return riskBandId; }
    public void setRiskBandId(Long riskBandId) { this.riskBandId = riskBandId; }
    public String getRiskCategory() { return riskCategory; }
    public void setRiskCategory(String riskCategory) { this.riskCategory = riskCategory; }
    public BigDecimal getMinimumScore() { return minimumScore; }
    public void setMinimumScore(BigDecimal minimumScore) { this.minimumScore = minimumScore; }
    public BigDecimal getMaximumScore() { return maximumScore; }
    public void setMaximumScore(BigDecimal maximumScore) { this.maximumScore = maximumScore; }

    @Override
    public String toString() {
        return "RiskBand{" + "riskBandId=" + riskBandId + ", " + "riskCategory=" + riskCategory + ", " + "minimumScore=" + minimumScore + ", " + "maximumScore=" + maximumScore + "}";
    }
}
package entity;

import java.math.BigDecimal;

/** Maps to dsphere.warehouse. */
public class Warehouse {
    private Long warehouseId;
    private String warehouseCode;
    private String warehouseName;
    private Long regionId;
    private String location;
    private BigDecimal capacity;
    private String status;

    /** Object relationship for FK regionId; the scalar FK remains the persistence source of truth. */
    private Region region;
    public Warehouse() {}
    public Warehouse(Long warehouseId, String warehouseCode, String warehouseName, Long regionId, String location, BigDecimal capacity, String status) {
        this.warehouseId = warehouseId;
        this.warehouseCode = warehouseCode;
        this.warehouseName = warehouseName;
        this.regionId = regionId;
        this.location = location;
        this.capacity = capacity;
        this.status = status;
    }

    public Long getWarehouseId() { return warehouseId; }
    public void setWarehouseId(Long warehouseId) { this.warehouseId = warehouseId; }
    public String getWarehouseCode() { return warehouseCode; }
    public void setWarehouseCode(String warehouseCode) { this.warehouseCode = warehouseCode; }
    public String getWarehouseName() { return warehouseName; }
    public void setWarehouseName(String warehouseName) { this.warehouseName = warehouseName; }
    public Long getRegionId() { return regionId; }
    public void setRegionId(Long regionId) { this.regionId = regionId; }
    public String getLocation() { return location; }
    public void setLocation(String location) { this.location = location; }
    public BigDecimal getCapacity() { return capacity; }
    public void setCapacity(BigDecimal capacity) { this.capacity = capacity; }
    public String getStatus() { return status; }
    public void setStatus(String status) { this.status = status; }

    public Region getRegion() { return region; }
    public void setRegion(Region region) {
        this.region = region;
        this.regionId = region == null ? null : region.getRegionId();
    }
    @Override
    public String toString() {
        return "Warehouse{" + "warehouseId=" + warehouseId + ", " + "warehouseCode=" + warehouseCode + ", " + "warehouseName=" + warehouseName + ", " + "regionId=" + regionId + ", " + "location=" + location + ", " + "capacity=" + capacity + ", " + "status=" + status + "}";
    }
}
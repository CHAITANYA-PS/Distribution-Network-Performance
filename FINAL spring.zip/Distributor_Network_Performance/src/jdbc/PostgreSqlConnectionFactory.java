package jdbc;
import java.io.InputStream;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.util.Properties;

import dao.exception.DaoException;
public final class PostgreSqlConnectionFactory implements ConnectionFactory{
 private final String url,user,password,schema;
 public PostgreSqlConnectionFactory(){this("database.properties");}
 public PostgreSqlConnectionFactory(String resource){Properties p=new Properties();try(InputStream in=Thread.currentThread().getContextClassLoader().getResourceAsStream(resource)){if(in==null)throw new DaoException("Missing "+resource);p.load(in);}catch(Exception e){if(e instanceof DaoException)throw (DaoException)e;throw new DaoException("Cannot load database configuration",e);}url=req(p,"db.url");user=req(p,"db.username");password=req(p,"db.password");schema=p.getProperty("db.schema","dsphere");}
 @Override
public Connection getConnection() throws SQLException{Connection c=DriverManager.getConnection(url,user,password);c.setSchema(schema);return c;}
 private static String req(Properties p,String k){String v=p.getProperty(k);if(v==null||v.trim().isEmpty())throw new DaoException("Missing property: "+k);return v.trim();}
}

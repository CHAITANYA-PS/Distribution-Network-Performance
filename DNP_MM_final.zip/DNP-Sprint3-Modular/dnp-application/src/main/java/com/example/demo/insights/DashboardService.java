package com.example.demo.insights;

import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.HealthScoreHistory;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.distributor.repository.HealthScoreHistoryRepository;
import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.repository.RecoveryPlanRepository;
import com.example.demo.recovery.repository.TicketRepository;
import com.example.demo.recovery.service.RecoveryLookups;
import com.example.demo.sales.dto.CurrentStockRow;
import com.example.demo.sales.repository.InventoryAlertRepository;
import com.example.demo.sales.repository.ProductReturnRepository;
import com.example.demo.sales.service.CurrentStockService;
import com.example.demo.sales.service.ProductReturnService;
import com.example.demo.systemadmin.dto.ReportTable;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.service.LookupSupport;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/** One-page summary across all modules (distributors, tickets, stock, returns, recovery, health). */
@Service
@Transactional(readOnly = true)
public class DashboardService {
    private final DistributorRepository distributors;
    private final TicketRepository tickets;
    private final RecoveryLookups recoveryLookups;
    private final RecoveryPlanRepository plans;
    private final CurrentStockService stock;
    private final InventoryAlertRepository alerts;
    private final ProductReturnRepository returns;
    private final HealthScoreHistoryRepository scores;

    public DashboardService(DistributorRepository distributors, TicketRepository tickets, RecoveryLookups recoveryLookups,
            RecoveryPlanRepository plans, CurrentStockService stock, InventoryAlertRepository alerts, ProductReturnRepository returns,
            HealthScoreHistoryRepository scores) {
        this.distributors = distributors;
        this.tickets = tickets;
        this.recoveryLookups = recoveryLookups;
        this.plans = plans;
        this.stock = stock;
        this.alerts = alerts;
        this.returns = returns;
        this.scores = scores;
    }

    public ReportTable summary() {
        Long own = CurrentUser.isDistributorOnly() ? CurrentUser.distributorId() : null;
        List<Distributor> ds = distributors.findAll().stream().filter(d -> own == null || own.equals(d.getDistributorId())).toList();
        List<Ticket> ts = tickets.findAll().stream().filter(t -> own == null || own.equals(t.getDistributorId())).toList();
        Map<Long, String> statusName = new HashMap<>();
        long openTickets = 0;
        long overdueTickets = 0;
        OffsetDateTime now = OffsetDateTime.now();
        for (Ticket t : ts) {
            String s = statusName.computeIfAbsent(t.getTicketStatusId() == null ? -1L : t.getTicketStatusId(), recoveryLookups::statusName);
            boolean open = !LookupSupport.same(s, RecoveryLookups.CLOSED) && !LookupSupport.same(s, RecoveryLookups.RESOLVED);
            if (open) {
                openTickets++;
                if (t.getSlaDueAt() != null && now.isAfter(t.getSlaDueAt())) {
                    overdueTickets++;
                }
            }
        }
        List<CurrentStockRow> rows = stock.current(new CurrentStockService.Filter(null, null, null, null, null, null, false));
        BigDecimal stockValue = rows.stream().map(CurrentStockRow::stockValue).filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal expiredQty = rows.stream().filter(r -> "EXPIRED".equals(r.expiryState())).map(CurrentStockRow::quantity).reduce(BigDecimal.ZERO, BigDecimal::add);
        long nearExpiryRows = rows.stream().filter(r -> "NEAR_EXPIRY".equals(r.expiryState())).count();
        long lowStockRows = rows.stream().filter(CurrentStockRow::belowReorderLevel).count();
        long openAlerts = alerts.findAll().stream().filter(a -> "Open".equalsIgnoreCase(a.getStatus())).count();
        long openReturns = returns.findAll().stream().filter(r -> own == null || own.equals(r.getDistributorId()))
                .filter(r -> ProductReturnService.OPEN.contains(r.getStatus())).count();
        long recoveryMode = plans.findAll().stream().filter(p -> own == null || own.equals(p.getDistributorId()))
                .filter(p -> p.getClosedAt() == null && Boolean.TRUE.equals(p.getRecoveryMode())).count();
        Map<Long, HealthScoreHistory> latest = new HashMap<>();
        for (HealthScoreHistory h : scores.findAll()) {
            if (own != null && !own.equals(h.getDistributorId())) {
                continue;
            }
            latest.merge(h.getDistributorId(), h, (a, b) -> a.getCalculatedAt() != null && b.getCalculatedAt() != null
                    && a.getCalculatedAt().isAfter(b.getCalculatedAt()) ? a : b);
        }
        BigDecimal avgHealth = latest.isEmpty() ? null : latest.values().stream().map(HealthScoreHistory::getTotalScore)
                .reduce(BigDecimal.ZERO, BigDecimal::add).divide(BigDecimal.valueOf(latest.size()), 2, RoundingMode.HALF_UP);
        HealthScoreHistory lowest = latest.values().stream().min(Comparator.comparing(HealthScoreHistory::getTotalScore)).orElse(null);
        return ReportTable.of("Dashboard", List.of("metric", "value"))
                .row("Distributors", ds.size())
                .row("Active distributors", ds.stream().filter(d -> "Active".equalsIgnoreCase(d.getStatus())).count())
                .row("Open tickets", openTickets)
                .row("Tickets past SLA", overdueTickets)
                .row("Stock value", stockValue)
                .row("Expired stock quantity", expiredQty)
                .row("Stock rows near expiry", nearExpiryRows)
                .row("Stock rows at/below reorder level", lowStockRows)
                .row("Open inventory alerts", openAlerts)
                .row("Returns in progress", openReturns)
                .row("Distributors in Recovery Mode", recoveryMode)
                .row("Average health score", avgHealth)
                .row("Lowest health score (distributor id)", lowest == null ? null : lowest.getTotalScore() + " (" + lowest.getDistributorId() + ")")
                .total("generatedAt", now.toString());
    }
}

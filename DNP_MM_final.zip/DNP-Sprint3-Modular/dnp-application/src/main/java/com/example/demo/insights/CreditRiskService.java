package com.example.demo.insights;

import com.example.demo.distributor.entity.CreditRiskAssessment;
import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.DistributorCreditLimit;
import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.repository.CreditRiskAssessmentRepository;
import com.example.demo.distributor.repository.DistributorCreditLimitRepository;
import com.example.demo.distributor.repository.DistributorOrderRepository;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.finance.entity.Invoice;
import com.example.demo.finance.entity.Payment;
import com.example.demo.finance.entity.PaymentStatus;
import com.example.demo.finance.repository.InvoiceRepository;
import com.example.demo.finance.repository.PaymentRepository;
import com.example.demo.finance.repository.PaymentStatusRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Credit risk of a distributor from finance data:
 * outstanding = invoices of the distributor's orders - successful payments;
 * utilisation = outstanding / current credit limit;
 * risk score (0-100) = 70 x min(utilisation, 100 %) + 30 x share of the outstanding amount that is overdue.
 * Below 40 LOW, below 70 MEDIUM, otherwise HIGH (finance managers are notified).
 */
@Service
@Transactional
public class CreditRiskService {
    private static final Set<String> FAILED_WORDS = Set.of("fail", "reject", "revers", "cancel", "declin", "bounce");

    private final DistributorRepository distributors;
    private final DistributorOrderRepository orders;
    private final DistributorCreditLimitRepository limits;
    private final CreditRiskAssessmentRepository assessments;
    private final InvoiceRepository invoices;
    private final PaymentRepository payments;
    private final PaymentStatusRepository paymentStatuses;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public CreditRiskService(DistributorRepository distributors, DistributorOrderRepository orders, DistributorCreditLimitRepository limits,
            CreditRiskAssessmentRepository assessments, InvoiceRepository invoices, PaymentRepository payments,
            PaymentStatusRepository paymentStatuses, NotificationGateway notifications, UserRoleResolver users) {
        this.distributors = distributors;
        this.orders = orders;
        this.limits = limits;
        this.assessments = assessments;
        this.invoices = invoices;
        this.payments = payments;
        this.paymentStatuses = paymentStatuses;
        this.notifications = notifications;
        this.users = users;
    }

    public record CreditRisk(Long distributorId, String distributorName, Long creditLimitId, BigDecimal creditLimit,
            BigDecimal invoiced, BigDecimal paid, BigDecimal outstanding, BigDecimal overdueAmount, int overdueInvoices,
            BigDecimal utilisationPercent, BigDecimal riskScore, String riskLevel, Long riskAssessmentId) {
    }

    /** Works out the risk without saving it. */
    @Transactional(readOnly = true)
    public CreditRisk evaluate(Long distributorId) {
        Distributor d = distributors.findById(distributorId).orElseThrow(() -> new ResourceNotFoundException("Distributor not found: " + distributorId));
        List<Long> orderIds = orders.findByDistributorId(distributorId).stream().map(DistributorOrder::getOrderId).toList();
        List<Invoice> inv = orderIds.isEmpty() ? List.of() : invoices.findByOrderIdIn(orderIds);
        Map<Long, String> statusNames = paymentStatuses.findAll().stream()
                .collect(Collectors.toMap(PaymentStatus::getPaymentStatusId, s -> s.getStatusName() == null ? "" : s.getStatusName()));
        List<Long> invoiceIds = inv.stream().map(Invoice::getInvoiceId).toList();
        Map<Long, BigDecimal> paidByInvoice = (invoiceIds.isEmpty() ? List.<Payment>of() : payments.findByInvoiceIdIn(invoiceIds)).stream()
                .filter(p -> !failed(statusNames.get(p.getPaymentStatusId())))
                .collect(Collectors.toMap(Payment::getInvoiceId, p -> p.getAmount() == null ? BigDecimal.ZERO : p.getAmount(), BigDecimal::add));
        BigDecimal invoiced = BigDecimal.ZERO;
        BigDecimal paid = BigDecimal.ZERO;
        BigDecimal overdue = BigDecimal.ZERO;
        int overdueCount = 0;
        LocalDate today = LocalDate.now();
        for (Invoice i : inv) {
            BigDecimal amount = i.getInvoiceAmount() == null ? BigDecimal.ZERO : i.getInvoiceAmount();
            BigDecimal p = paidByInvoice.getOrDefault(i.getInvoiceId(), BigDecimal.ZERO);
            BigDecimal open = amount.subtract(p).max(BigDecimal.ZERO);
            invoiced = invoiced.add(amount);
            paid = paid.add(p);
            if (open.signum() > 0 && i.getDueDate() != null && i.getDueDate().isBefore(today)) {
                overdue = overdue.add(open);
                overdueCount++;
            }
        }
        BigDecimal outstanding = invoiced.subtract(paid).max(BigDecimal.ZERO);
        Optional<DistributorCreditLimit> limit = limits.findByDistributorId(distributorId).stream()
                .filter(l -> (l.getValidFrom() == null || !l.getValidFrom().isAfter(today)) && (l.getValidTo() == null || !l.getValidTo().isBefore(today)))
                .max(Comparator.comparing(l -> l.getValidFrom() == null ? LocalDate.MIN : l.getValidFrom()));
        BigDecimal creditLimit = limit.map(DistributorCreditLimit::getCreditLimit).orElse(null);
        BigDecimal utilisation = creditLimit == null || creditLimit.signum() == 0
                ? (outstanding.signum() > 0 ? BigDecimal.valueOf(100) : BigDecimal.ZERO)
                : outstanding.multiply(BigDecimal.valueOf(100)).divide(creditLimit, 2, RoundingMode.HALF_UP);
        BigDecimal overdueShare = outstanding.signum() == 0 ? BigDecimal.ZERO : overdue.divide(outstanding, 4, RoundingMode.HALF_UP);
        BigDecimal score = utilisation.min(BigDecimal.valueOf(100)).multiply(new BigDecimal("0.7"))
                .add(overdueShare.multiply(BigDecimal.valueOf(30))).setScale(2, RoundingMode.HALF_UP);
        String level = score.compareTo(BigDecimal.valueOf(40)) < 0 ? "LOW" : score.compareTo(BigDecimal.valueOf(70)) < 0 ? "MEDIUM" : "HIGH";
        return new CreditRisk(distributorId, d.getDistributorName(), limit.map(DistributorCreditLimit::getCreditLimitId).orElse(null),
                creditLimit, invoiced, paid, outstanding, overdue, overdueCount, utilisation, score, level, null);
    }

    /** Works out the risk and saves it as a credit_risk_assessment row. */
    public CreditRisk assess(Long distributorId) {
        CreditRisk r = evaluate(distributorId);
        CreditRiskAssessment a = new CreditRiskAssessment();
        a.setDistributorId(distributorId);
        a.setCreditLimitId(r.creditLimitId());
        a.setRiskScore(r.riskScore());
        a.setAssessedBy(CurrentUser.id());
        a.setAssessedAt(OffsetDateTime.now());
        a = assessments.save(a);
        AuditTrail.record("CREATE", "CreditRiskAssessment", a.getRiskAssessmentId(), null, a);
        if ("HIGH".equals(r.riskLevel())) {
            notifications.notify(users.usersWithRole(Roles.FINANCE_MANAGER), "Credit risk",
                    "Credit risk of " + r.distributorName() + " is HIGH (score " + r.riskScore() + ", utilisation " + r.utilisationPercent()
                            + "%, overdue " + r.overdueAmount() + ")");
        }
        return new CreditRisk(r.distributorId(), r.distributorName(), r.creditLimitId(), r.creditLimit(), r.invoiced(), r.paid(),
                r.outstanding(), r.overdueAmount(), r.overdueInvoices(), r.utilisationPercent(), r.riskScore(), r.riskLevel(),
                a.getRiskAssessmentId());
    }

    private static boolean failed(String status) {
        String s = status == null ? "" : status.toLowerCase(Locale.ROOT);
        return FAILED_WORDS.stream().anyMatch(s::contains);
    }
}

package com.example.demo.insights;

import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.repository.DistributorOrderRepository;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.recovery.service.RecoveryPlanWorkflowService;
import com.example.demo.sales.entity.SalesRecord;
import com.example.demo.sales.entity.SalesTarget;
import com.example.demo.sales.repository.SalesRecordRepository;
import com.example.demo.sales.repository.SalesTargetRepository;
import com.example.demo.systemadmin.entity.ReportingPeriod;
import com.example.demo.systemadmin.repository.ReportingPeriodRepository;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.Set;
import java.util.stream.Collectors;

/**
 * Distributor performance = recognised sales in a reporting period / sales target of that period. Below
 * recovery.threshold.percent the distributor is "RECOVERY": the recovery-mode job opens a recovery plan in
 * Recovery Mode for it (once, while no other plan is open).
 */
@Service
@Transactional
public class PerformanceService implements BackgroundJob {
    private final SalesTargetRepository targets;
    private final SalesRecordRepository records;
    private final DistributorOrderRepository orders;
    private final DistributorRepository distributors;
    private final ReportingPeriodRepository periods;
    private final SystemConfigService config;
    private final RecoveryPlanWorkflowService recovery;

    public PerformanceService(SalesTargetRepository targets, SalesRecordRepository records, DistributorOrderRepository orders,
            DistributorRepository distributors, ReportingPeriodRepository periods, SystemConfigService config,
            RecoveryPlanWorkflowService recovery) {
        this.targets = targets;
        this.records = records;
        this.orders = orders;
        this.distributors = distributors;
        this.periods = periods;
        this.config = config;
        this.recovery = recovery;
    }

    public record Performance(Long distributorId, String distributorName, Long reportingPeriodId, String periodName,
            LocalDate periodStart, LocalDate periodEnd, BigDecimal target, BigDecimal achieved, BigDecimal performancePercent,
            BigDecimal thresholdPercent, String status) {
    }

    /** Performance of every distributor that has a target in the period (default: the period covering today). */
    @Transactional(readOnly = true)
    public List<Performance> all(Long reportingPeriodId) {
        ReportingPeriod p = period(reportingPeriodId);
        Set<Long> ids = targets.findByReportingPeriodId(p.getReportingPeriodId()).stream()
                .map(SalesTarget::getDistributorId).filter(Objects::nonNull).collect(Collectors.toCollection(java.util.TreeSet::new));
        List<Performance> out = new ArrayList<>();
        for (Long id : ids) {
            out.add(of(id, p));
        }
        out.sort(Comparator.comparing(x -> x.performancePercent() == null ? BigDecimal.ZERO : x.performancePercent()));
        return out;
    }

    @Transactional(readOnly = true)
    public Performance of(Long distributorId, Long reportingPeriodId) {
        return of(distributorId, period(reportingPeriodId));
    }

    private Performance of(Long distributorId, ReportingPeriod p) {
        Distributor d = distributors.findById(distributorId).orElseThrow(() -> new ResourceNotFoundException("Distributor not found: " + distributorId));
        BigDecimal target = targets.findByDistributorId(distributorId).stream()
                .filter(t -> Objects.equals(t.getReportingPeriodId(), p.getReportingPeriodId()))
                .map(SalesTarget::getTargetValue).filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
        Set<Long> orderIds = orders.findByDistributorId(distributorId).stream().map(DistributorOrder::getOrderId).collect(Collectors.toSet());
        BigDecimal achieved = records.findBySaleDateBetween(p.getStartDate(), p.getEndDate()).stream()
                .filter(r -> orderIds.contains(r.getOrderId()))
                .map(SalesRecord::getRecognizedAmount).filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal threshold = config.decimal(SystemConfigService.RECOVERY_THRESHOLD, "60");
        BigDecimal pct = target.signum() == 0 ? null : achieved.multiply(BigDecimal.valueOf(100)).divide(target, 2, RoundingMode.HALF_UP);
        String status = pct == null ? "NO_TARGET" : pct.compareTo(BigDecimal.valueOf(100)) >= 0 ? "ACHIEVED"
                : pct.compareTo(threshold) >= 0 ? "ON_TRACK" : "RECOVERY";
        return new Performance(distributorId, d.getDistributorName(), p.getReportingPeriodId(), p.getPeriodName(), p.getStartDate(),
                p.getEndDate(), target, achieved, pct, threshold, status);
    }

    private ReportingPeriod period(Long id) {
        if (id != null) {
            return periods.findById(id).orElseThrow(() -> new ResourceNotFoundException("Reporting period not found: " + id));
        }
        LocalDate today = LocalDate.now();
        List<ReportingPeriod> all = periods.findAll();
        Optional<ReportingPeriod> current = all.stream()
                .filter(p -> p.getStartDate() != null && p.getEndDate() != null && !today.isBefore(p.getStartDate()) && !today.isAfter(p.getEndDate()))
                .min(Comparator.comparing(p -> p.getEndDate().toEpochDay() - p.getStartDate().toEpochDay()));
        return current.or(() -> all.stream().filter(p -> p.getEndDate() != null).max(Comparator.comparing(ReportingPeriod::getEndDate)))
                .orElseThrow(() -> new ResourceNotFoundException("No reporting period found; create one first"));
    }

    // ---- Recovery Mode job

    @Override
    public String name() {
        return "recovery-mode";
    }

    @Override
    public String description() {
        return "Puts distributors below recovery.threshold.percent of their sales target into Recovery Mode (opens a recovery plan)";
    }

    @Override
    public Map<String, Object> run() {
        int checked = 0;
        int opened = 0;
        List<Long> alreadyOpen = new ArrayList<>();
        Map<Long, String> reasons = new HashMap<>();
        for (Performance p : all(null)) {
            checked++;
            if (!"RECOVERY".equals(p.status())) {
                continue;
            }
            if (recovery.hasOpenPlan(p.distributorId())) {
                alreadyOpen.add(p.distributorId());
                continue;
            }
            String reason = "performance " + p.performancePercent() + "% of target in " + p.periodName() + " (threshold " + p.thresholdPercent() + "%)";
            recovery.openRecoveryMode(p.distributorId(), p.target().subtract(p.achieved()).max(BigDecimal.ZERO), reason);
            reasons.put(p.distributorId(), reason);
            opened++;
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("distributorsChecked", checked);
        out.put("recoveryPlansOpened", opened);
        out.put("alreadyInRecovery", alreadyOpen);
        out.put("reasons", reasons);
        return out;
    }
}

package com.example.demo.insights;

import com.example.demo.systemadmin.controller.ExportController;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.service.ExportService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Cross-module figures: performance vs target, credit risk, dashboard. */
@RestController
@RequestMapping("/api/v1")
public class InsightsController {
    private final PerformanceService performance;
    private final CreditRiskService creditRisk;
    private final DashboardService dashboard;
    private final ExportService export;

    public InsightsController(PerformanceService performance, CreditRiskService creditRisk, DashboardService dashboard, ExportService export) {
        this.performance = performance;
        this.creditRisk = creditRisk;
        this.dashboard = dashboard;
        this.export = export;
    }

    @Operation(summary = "Performance of all distributors with a target (default: current reporting period)")
    @GetMapping("/performance")
    public List<PerformanceService.Performance> performanceAll(@RequestParam(required = false) Long reportingPeriodId) {
        List<PerformanceService.Performance> all = performance.all(reportingPeriodId);
        if (CurrentUser.isDistributorOnly()) {
            return all.stream().filter(p -> p.distributorId().equals(CurrentUser.distributorId())).toList();
        }
        return all;
    }

    @Operation(summary = "Performance of one distributor: achieved sales / target")
    @GetMapping("/performance/{distributorId}")
    public PerformanceService.Performance performanceOf(@PathVariable Long distributorId, @RequestParam(required = false) Long reportingPeriodId) {
        CurrentUser.checkDistributor(distributorId);
        return performance.of(distributorId, reportingPeriodId);
    }

    @Operation(summary = "Credit risk of a distributor (calculated, not saved)")
    @GetMapping("/credit-risk/{distributorId}")
    public CreditRiskService.CreditRisk creditRisk(@PathVariable Long distributorId) {
        CurrentUser.checkDistributor(distributorId);
        return creditRisk.evaluate(distributorId);
    }

    @Operation(summary = "Calculate and save a credit risk assessment")
    @PostMapping("/credit-risk/calculate/{distributorId}")
    public CreditRiskService.CreditRisk assessCreditRisk(@PathVariable Long distributorId) {
        return creditRisk.assess(distributorId);
    }

    @Operation(summary = "Dashboard summary (a distributor sees only their own figures); format=xlsx|pdf|csv to download")
    @GetMapping("/dashboard/summary")
    public ResponseEntity<?> dashboard(@RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, dashboard.summary(), format);
    }
}

package com.example.demo;

import tools.jackson.databind.JsonNode;
import tools.jackson.databind.json.JsonMapper;
import org.junit.jupiter.api.MethodOrderer;
import org.junit.jupiter.api.Order;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.TestMethodOrder;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.webmvc.test.autoconfigure.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.context.ActiveProfiles;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

/**
 * Real controller -> service -> repository -> database (H2) flow. Nothing is mocked.
 * Covers CRUD, validation, business rules, optimistic locking and the JSON error model.
 */
@SpringBootTest
@AutoConfigureMockMvc
@ActiveProfiles("test")
@TestMethodOrder(MethodOrderer.OrderAnnotation.class)
class EndToEndFlowTest {
    @Autowired MockMvc mvc;
    @Autowired JsonMapper json;

    static long distributorId;
    static long invoiceId;
    static long firstPaymentId;

    private JsonNode body(MvcResult r) throws Exception { return json.readTree(r.getResponse().getContentAsString()); }

    private String dist(String code, String name, Long version) {
        return "{\"distributorCode\":\"" + code + "\",\"distributorName\":\"" + name + "\"" +
                ",\"regionId\":1,\"contactPerson\":\"Ravi\",\"email\":\"e2e@test.com\",\"address\":\"Chennai\"" +
                (version == null ? "" : ",\"version\":" + version) + "}";
    }

    /** Partial update body: only the name and the version the client last read. */
    private String rename(String name, long version) {
        return "{\"distributorName\":\"" + name + "\",\"version\":" + version + "}";
    }

    @Test @Order(1) void createDistributor_returns201_withDefaultsAndVersion0() throws Exception {
        MvcResult r = mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content(dist("E2E-1", "First", null)))
                .andExpect(status().isCreated()).andExpect(header().exists("Location"))
                .andExpect(jsonPath("$.status").value("Active")).andExpect(jsonPath("$.version").value(0))
                .andExpect(jsonPath("$.createdAt").exists()).andReturn();
        distributorId = body(r).get("distributorId").asLong();
    }

    @Test @Order(2) void readDistributor() throws Exception {
        mvc.perform(get("/api/v1/distributors/" + distributorId)).andExpect(status().isOk())
                .andExpect(jsonPath("$.distributorCode").value("E2E-1"));
        mvc.perform(get("/api/v1/distributors")).andExpect(status().isOk()).andExpect(jsonPath("$[0].distributorId").exists());
        mvc.perform(get("/api/v1/distributors?page=0&size=1")).andExpect(status().isOk())
                .andExpect(header().string("X-Total-Count", "1")).andExpect(jsonPath("$.length()").value(1));
        mvc.perform(get("/api/v1/distributors?size=0")).andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("INVALID_PARAMETER"));
    }

    @Test @Order(3) void partialUpdate_keepsOtherFields_andBumpsVersion() throws Exception {
        mvc.perform(put("/api/v1/distributors/" + distributorId).contentType(MediaType.APPLICATION_JSON)
                        .content(rename("Renamed", 0L)))
                .andExpect(status().isOk()).andExpect(jsonPath("$.distributorName").value("Renamed"))
                .andExpect(jsonPath("$.distributorCode").value("E2E-1")).andExpect(jsonPath("$.status").value("Active"))
                .andExpect(jsonPath("$.version").value(1));
    }

    @Test @Order(4) void staleUpdate_returns409ErrorModel() throws Exception {
        mvc.perform(put("/api/v1/distributors/" + distributorId).contentType(MediaType.APPLICATION_JSON)
                        .content(rename("Stale", 0L)))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("OPTIMISTIC_LOCK_CONFLICT"));
    }

    @Test @Order(5) void invalidBody_returns400WithFieldErrors() throws Exception {
        mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.distributorName").exists());
    }

    @Test @Order(6) void duplicateCode_returns409() throws Exception {
        mvc.perform(post("/api/v1/distributors").contentType(MediaType.APPLICATION_JSON).content(dist("E2E-1", "Dup", null)))
                .andExpect(status().isConflict()).andExpect(jsonPath("$.code").value("DUPLICATE_RESOURCE"));
    }

    @Test @Order(7) void invoiceAndPayments_enforceOutstandingBalance() throws Exception {
        MvcResult inv = mvc.perform(post("/api/v1/invoices").contentType(MediaType.APPLICATION_JSON)
                .content("{\"invoiceNumber\":\"INV-E2E\",\"orderId\":1,\"invoiceStatusId\":1,\"invoiceDate\":\"2026-01-01\","
                        + "\"dueDate\":\"2026-01-31\",\"invoiceAmount\":1000}")).andExpect(status().isCreated()).andReturn();
        invoiceId = body(inv).get("invoiceId").asLong();
        String p = "{\"invoiceId\":" + invoiceId + ",\"paymentMethodId\":1,\"paymentStatusId\":1,"
                + "\"transactionReference\":\"TXN-%s\",\"amount\":%s}";
        MvcResult first = mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("1", "600")))
                .andExpect(status().isCreated()).andReturn();
        firstPaymentId = body(first).get("paymentId").asLong();
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("2", "500")))
                .andExpect(status().isUnprocessableEntity()).andExpect(jsonPath("$.code").value("BUSINESS_RULE_VIOLATION"));
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("3", "400")))
                .andExpect(status().isCreated());
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON).content(p.formatted("4", "0")))
                .andExpect(status().isBadRequest());
        mvc.perform(post("/api/v1/payments").contentType(MediaType.APPLICATION_JSON)
                .content("{\"invoiceId\":999999,\"paymentMethodId\":1,\"paymentStatusId\":1,\"transactionReference\":\"TXN-5\",\"amount\":1}"))
                .andExpect(status().isNotFound());
    }

    @Test @Order(8) void domainControllersShareTheSameData() throws Exception {
        mvc.perform(get("/api/v1/inventory/products")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/orders")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/users")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/sustainability/commitments")).andExpect(status().isOk());
        mvc.perform(get("/api/v1/risk-management/assessments")).andExpect(status().isOk());
    }

    @Test @Order(9) void deletePayment_thenRowIsGone() throws Exception {
        mvc.perform(delete("/api/v1/payments/" + firstPaymentId)).andExpect(status().isNoContent());
        mvc.perform(get("/api/v1/payments/" + firstPaymentId)).andExpect(status().isNotFound());
    }

    @Test @Order(10) void deleteDistributor_thenNotFound() throws Exception {
        mvc.perform(delete("/api/v1/distributors/" + distributorId)).andExpect(status().isNoContent());
        MvcResult r = mvc.perform(get("/api/v1/distributors/" + distributorId)).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.code").value("RESOURCE_NOT_FOUND")).andReturn();
        assertEquals(404, body(r).get("status").asInt());
    }

    @Test @Order(11) void user_defaultsTimestampsAndHiddenPassword_thenPartialUpdate() throws Exception {
        MvcResult r = mvc.perform(post("/api/v1/users").contentType(MediaType.APPLICATION_JSON)
                        .content("{\"email\":\"u1@test.com\",\"userName\":\"User One\",\"passwordHash\":\"secret-hash\"}"))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.status").value("Pending")).andExpect(jsonPath("$.mfaEnabled").value(false))
                .andExpect(jsonPath("$.createdAt").exists()).andExpect(jsonPath("$.updatedAt").exists())
                .andExpect(jsonPath("$.passwordHash").doesNotExist()).andReturn();
        long userId = body(r).get("userId").asLong();
        mvc.perform(put("/api/v1/users/" + userId).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"userName\":\"User Renamed\",\"status\":\"Active\",\"version\":0}"))
                .andExpect(status().isOk()).andExpect(jsonPath("$.email").value("u1@test.com"))
                .andExpect(jsonPath("$.userName").value("User Renamed")).andExpect(jsonPath("$.version").value(1));
        mvc.perform(post("/api/v1/users").contentType(MediaType.APPLICATION_JSON).content("{\"userName\":\"No Email\"}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.email").exists());
        mvc.perform(put("/api/v1/users/" + userId).contentType(MediaType.APPLICATION_JSON)
                        .content("{\"status\":\"ACTIVE\",\"version\":1}"))
                .andExpect(status().isBadRequest()).andExpect(jsonPath("$.fieldErrors.status").exists());
    }
}

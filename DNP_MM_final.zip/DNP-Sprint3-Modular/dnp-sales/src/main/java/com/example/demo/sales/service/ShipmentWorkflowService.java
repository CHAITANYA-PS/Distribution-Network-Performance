package com.example.demo.sales.service;

import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.repository.DistributorOrderRepository;
import com.example.demo.manufacturer.entity.Product;
import com.example.demo.manufacturer.entity.ProductBatch;
import com.example.demo.manufacturer.repository.ProductBatchRepository;
import com.example.demo.manufacturer.repository.ProductRepository;
import com.example.demo.manufacturer.util.Ean13;
import com.example.demo.sales.dto.WorkflowRequests;
import com.example.demo.sales.entity.DeliveryDiscrepancy;
import com.example.demo.sales.entity.DeliveryReceipt;
import com.example.demo.sales.entity.DeliveryReceiptItem;
import com.example.demo.sales.entity.OrderItem;
import com.example.demo.sales.entity.ProductVerification;
import com.example.demo.sales.entity.Shipment;
import com.example.demo.sales.entity.ShipmentItem;
import com.example.demo.sales.entity.ShipmentStatus;
import com.example.demo.sales.entity.ShipmentStatusHistory;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.DeliveryDiscrepancyRepository;
import com.example.demo.sales.repository.DeliveryReceiptItemRepository;
import com.example.demo.sales.repository.DeliveryReceiptRepository;
import com.example.demo.sales.repository.OrderItemRepository;
import com.example.demo.sales.repository.ProductVerificationRepository;
import com.example.demo.sales.repository.ShipmentItemRepository;
import com.example.demo.sales.repository.ShipmentRepository;
import com.example.demo.sales.repository.ShipmentStatusHistoryRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.DuplicateResourceException;
import com.example.demo.systemadmin.service.ForbiddenOperationException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.TicketOpener;
import org.springframework.beans.factory.ObjectProvider;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.security.SecureRandom;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Dispatch and delivery without a barcode scanner:
 * <ol>
 *   <li>verify each packed item: the packer types / pastes the 13-digit product code, batch number and quantity;
 *       the system checks the check digit, that it is the ordered product, the right non-expired batch and the
 *       packed quantity;</li>
 *   <li>dispatch: only when every item is verified; stock leaves the warehouse and a 6-digit handover code is
 *       generated (printed on the delivery note, shown only once);</li>
 *   <li>delivery receipt: the distributor enters the handover code and the received / damaged quantities;
 *       differences become discrepancies, each with a ticket, and good stock is added to the distributor.</li>
 * </ol>
 */
@Service
@Transactional
public class ShipmentWorkflowService {
    public static final String DISPATCHED = "Dispatched";
    public static final String DELIVERED = "Delivered";
    private static final SecureRandom RANDOM = new SecureRandom();

    private final ShipmentRepository shipments;
    private final ShipmentItemRepository items;
    private final OrderItemRepository orderItems;
    private final DistributorOrderRepository orders;
    private final ProductRepository products;
    private final ProductBatchRepository batches;
    private final ProductVerificationRepository verifications;
    private final ShipmentStatusHistoryRepository history;
    private final DeliveryReceiptRepository receipts;
    private final DeliveryReceiptItemRepository receiptItems;
    private final DeliveryDiscrepancyRepository discrepancies;
    private final WarehouseStockRepository stocks;
    private final StockLedgerService ledger;
    private final SalesStatuses statuses;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;
    private final ObjectProvider<TicketOpener> tickets;

    public ShipmentWorkflowService(ShipmentRepository shipments, ShipmentItemRepository items, OrderItemRepository orderItems,
            DistributorOrderRepository orders, ProductRepository products, ProductBatchRepository batches,
            ProductVerificationRepository verifications, ShipmentStatusHistoryRepository history, DeliveryReceiptRepository receipts,
            DeliveryReceiptItemRepository receiptItems, DeliveryDiscrepancyRepository discrepancies, WarehouseStockRepository stocks,
            StockLedgerService ledger, SalesStatuses statuses, NotificationGateway notifications, UserRoleResolver users,
            ObjectProvider<TicketOpener> tickets) {
        this.shipments = shipments;
        this.items = items;
        this.orderItems = orderItems;
        this.orders = orders;
        this.products = products;
        this.batches = batches;
        this.verifications = verifications;
        this.history = history;
        this.receipts = receipts;
        this.receiptItems = receiptItems;
        this.discrepancies = discrepancies;
        this.stocks = stocks;
        this.ledger = ledger;
        this.statuses = statuses;
        this.notifications = notifications;
        this.users = users;
        this.tickets = tickets;
    }

    // ------------------------------------------------------------------ results

    public record VerificationResult(Long verificationId, Long shipmentItemId, String result, String verificationStatus,
            List<String> messages, String productName, String batchNumber) {
    }

    public record DispatchResult(Long shipmentId, String trackingNumber, String status, LocalDate dispatchDate,
            String handoverCode, int itemsDispatched, String note) {
    }

    public record ReceiptResult(DeliveryReceipt receipt, List<DeliveryReceiptItem> items, List<DeliveryDiscrepancy> discrepancies) {
    }

    // ------------------------------------------------------------------ 1. verify a packed item

    public VerificationResult verifyItem(Long shipmentId, Long shipmentItemId, WorkflowRequests.VerifyItem req) {
        Shipment shipment = shipment(shipmentId);
        if (shipment.getHandoverCode() != null) {
            throw new BusinessRuleException("Shipment " + shipmentId + " is already dispatched");
        }
        ShipmentItem item = items.findById(shipmentItemId)
                .filter(i -> Objects.equals(i.getShipmentId(), shipmentId))
                .orElseThrow(() -> new ResourceNotFoundException("Shipment item " + shipmentItemId + " not found in shipment " + shipmentId));
        OrderItem orderItem = orderItems.findById(item.getOrderItemId())
                .orElseThrow(() -> new BusinessRuleException("Order item " + item.getOrderItemId() + " of this shipment item no longer exists"));
        Product product = products.findById(orderItem.getProductId())
                .orElseThrow(() -> new BusinessRuleException("Product " + orderItem.getProductId() + " not found"));
        List<String> problems = new ArrayList<>();
        String code = req.productCode().trim();
        String codeProblem = Ean13.problem(code);
        if (codeProblem != null) {
            problems.add(codeProblem);
        } else if (product.getProductCode() == null) {
            problems.add("Product " + product.getProductName() + " has no product code yet; set it on the product first");
        } else if (!product.getProductCode().equals(code)) {
            String other = products.findByProductCode(code).map(Product::getProductName).orElse("no known product");
            problems.add("Wrong product: code " + code + " is " + other + ", but this line needs " + product.getProductName()
                    + " (" + product.getProductCode() + ")");
        }
        ProductBatch batch = resolveBatch(item, product, req.batchNumber().trim(), problems);
        if (item.getQuantity() != null && req.quantity().compareTo(item.getQuantity()) != 0) {
            problems.add("Quantity " + plain(req.quantity()) + " does not match the packed quantity " + plain(item.getQuantity()));
        }
        boolean ok = problems.isEmpty();
        ProductVerification v = new ProductVerification();
        v.setShipmentItemId(shipmentItemId);
        v.setEnteredCode(code.length() > 13 ? code.substring(0, 13) : code);
        v.setEnteredBatchNumber(req.batchNumber());
        v.setEnteredQuantity(req.quantity());
        v.setResult(ok ? "MATCH" : "MISMATCH");
        v.setMessage(ok ? "Product, batch and quantity match" : truncate(String.join("; ", problems), 500));
        v.setVerifiedBy(CurrentUser.id());
        v.setVerifiedAt(OffsetDateTime.now());
        v = verifications.save(v);
        if (ok && batch != null) {
            item.setProductBatchId(batch.getProductBatchId());
        }
        item.setVerificationStatus(ok ? "VERIFIED" : "MISMATCH");
        item.setVerifiedQuantity(req.quantity());
        items.save(item);
        AuditTrail.record("UPDATE", "ShipmentItem", shipmentItemId, null, v);
        return new VerificationResult(v.getVerificationId(), shipmentItemId, v.getResult(), item.getVerificationStatus(),
                ok ? List.of(v.getMessage()) : problems, product.getProductName(), batch == null ? req.batchNumber() : batch.getBatchNumber());
    }

    private ProductBatch resolveBatch(ShipmentItem item, Product product, String batchNumber, List<String> problems) {
        ProductBatch batch;
        if (item.getProductBatchId() != null) {
            batch = batches.findById(item.getProductBatchId()).orElse(null);
            if (batch != null && !batch.getBatchNumber().equalsIgnoreCase(batchNumber)) {
                problems.add("Wrong batch: " + batchNumber + " was entered, the packed batch is " + batch.getBatchNumber());
                return batch;
            }
        } else {
            batch = batches.findAll().stream()
                    .filter(b -> Objects.equals(b.getProductId(), product.getProductId()) && batchNumber.equalsIgnoreCase(b.getBatchNumber()))
                    .findFirst().orElse(null);
            if (batch == null) {
                problems.add("Batch " + batchNumber + " does not exist for " + product.getProductName());
                return null;
            }
        }
        if (batch != null && batch.getExpiryDate() != null && batch.getExpiryDate().isBefore(LocalDate.now())) {
            problems.add("Batch " + batch.getBatchNumber() + " expired on " + batch.getExpiryDate() + " and cannot be dispatched");
        }
        return batch;
    }

    // ------------------------------------------------------------------ 2. dispatch

    public DispatchResult dispatch(Long shipmentId, String remarks) {
        Shipment shipment = shipment(shipmentId);
        if (shipment.getHandoverCode() != null) {
            throw new BusinessRuleException("Shipment " + shipmentId + " is already dispatched");
        }
        if (shipment.getWarehouseId() == null) {
            throw new BusinessRuleException("Shipment " + shipmentId + " has no warehouse");
        }
        List<ShipmentItem> lines = items.findByShipmentId(shipmentId);
        if (lines.isEmpty()) {
            throw new BusinessRuleException("Shipment " + shipmentId + " has no items");
        }
        List<Long> notVerified = lines.stream().filter(i -> !"VERIFIED".equals(i.getVerificationStatus()))
                .map(ShipmentItem::getShipmentItemId).toList();
        if (!notVerified.isEmpty()) {
            throw new BusinessRuleException("Verify every item before dispatch. Not verified: shipment items " + notVerified);
        }
        for (ShipmentItem line : lines) {
            WarehouseStock source = stocks.findByWarehouseIdAndProductBatchId(shipment.getWarehouseId(), line.getProductBatchId()).stream()
                    .filter(s -> s.getOwnerDistributorId() == null && !Boolean.FALSE.equals(s.getIsSellable()))
                    .filter(s -> s.getQuantity() != null && s.getQuantity().compareTo(line.getQuantity()) >= 0)
                    .findFirst()
                    .orElseThrow(() -> new BusinessRuleException("Not enough sellable stock of batch " + line.getProductBatchId()
                            + " in warehouse " + shipment.getWarehouseId() + " for shipment item " + line.getShipmentItemId()));
            ledger.post(source.getWarehouseStockId(), StockLedgerService.OUT, line.getQuantity(), "Dispatch", "DSP");
        }
        String code = String.format("%06d", RANDOM.nextInt(1_000_000));
        ShipmentStatus status = statuses.shipment(DISPATCHED, 2, false);
        shipment.setHandoverCode(code);
        shipment.setDispatchedBy(CurrentUser.id());
        shipment.setDispatchDate(LocalDate.now());
        shipment.setShipmentStatusId(status.getShipmentStatusId());
        shipments.save(shipment);
        addHistory(shipmentId, status.getShipmentStatusId(), remarks == null ? "Dispatched after item verification" : remarks);
        AuditTrail.record("STATUS_CHANGE", "Shipment", shipmentId, null, Map.of("status", DISPATCHED, "items", lines.size()));
        Long distributorId = distributorOf(lines);
        if (distributorId != null) {
            notifications.notify(users.usersOfDistributor(distributorId), "Shipment dispatched", "Shipment "
                    + nz(shipment.getTrackingNumber(), String.valueOf(shipmentId)) + " has been dispatched with " + lines.size()
                    + " item(s). Confirm the delivery with the handover code on the delivery note.");
        }
        return new DispatchResult(shipmentId, shipment.getTrackingNumber(), DISPATCHED, shipment.getDispatchDate(), code, lines.size(),
                "Print the handover code on the delivery note. It is shown only now; the distributor needs it to confirm delivery.");
    }

    // ------------------------------------------------------------------ status changes and history

    public Shipment changeStatus(Long shipmentId, String statusName, String remarks) {
        Shipment shipment = shipment(shipmentId);
        if (LookupSupport.same(statusName, DISPATCHED)) {
            throw new BusinessRuleException("Use POST /api/v1/shipments/" + shipmentId + "/dispatch to dispatch");
        }
        if (LookupSupport.same(statusName, DELIVERED)) {
            throw new BusinessRuleException("A shipment becomes Delivered when the distributor confirms the delivery receipt");
        }
        ShipmentStatus current = shipment.getShipmentStatusId() == null ? null
                : statuses.shipmentStatuses().findById(shipment.getShipmentStatusId()).orElse(null);
        if (current != null && Boolean.TRUE.equals(current.getIsTerminal())) {
            throw new BusinessRuleException("Shipment is already " + current.getStatusName() + "; its status cannot change");
        }
        ShipmentStatus target = statuses.shipmentStatuses().findAll().stream()
                .filter(s -> LookupSupport.same(s.getStatusName(), statusName)).findFirst()
                .orElseThrow(() -> new BusinessRuleException("Unknown shipment status '" + statusName + "'"));
        shipment.setShipmentStatusId(target.getShipmentStatusId());
        Shipment saved = shipments.save(shipment);
        addHistory(shipmentId, target.getShipmentStatusId(), remarks);
        AuditTrail.record("STATUS_CHANGE", "Shipment", shipmentId, current == null ? null : current.getStatusName(), target.getStatusName());
        return saved;
    }

    @Transactional(readOnly = true)
    public List<ShipmentStatusHistory> history(Long shipmentId) {
        shipment(shipmentId);
        return history.findByShipmentIdOrderByChangedAtAsc(shipmentId);
    }

    @Transactional(readOnly = true)
    public List<ProductVerification> verifications(Long shipmentId) {
        shipment(shipmentId);
        List<ProductVerification> out = new ArrayList<>();
        for (ShipmentItem i : items.findByShipmentId(shipmentId)) {
            out.addAll(verifications.findByShipmentItemIdOrderByVerifiedAtDesc(i.getShipmentItemId()));
        }
        return out;
    }

    // ------------------------------------------------------------------ 3. delivery receipt

    public ReceiptResult confirmDelivery(Long shipmentId, WorkflowRequests.ConfirmDelivery req) {
        Shipment shipment = shipment(shipmentId);
        if (shipment.getHandoverCode() == null) {
            throw new BusinessRuleException("Shipment " + shipmentId + " has not been dispatched yet");
        }
        if (receipts.existsByShipmentId(shipmentId)) {
            throw new DuplicateResourceException("Delivery of shipment " + shipmentId + " is already confirmed");
        }
        List<ShipmentItem> lines = items.findByShipmentId(shipmentId);
        Long distributorId = distributorOf(lines);
        if (CurrentUser.isDistributorOnly() && !Objects.equals(CurrentUser.distributorId(), distributorId)) {
            throw new ForbiddenOperationException("This shipment is not for your distributor");
        }
        if (!shipment.getHandoverCode().equals(req.handoverCode())) {
            AuditTrail.record("UPDATE", "Shipment", shipmentId, null, "Wrong handover code entered");
            throw new BusinessRuleException("Handover code is wrong. Check the code on the delivery note.");
        }
        Map<Long, WorkflowRequests.ReceivedLine> given = new HashMap<>();
        if (req.items() != null) {
            for (WorkflowRequests.ReceivedLine l : req.items()) {
                boolean known = lines.stream().anyMatch(i -> i.getShipmentItemId().equals(l.shipmentItemId()));
                if (!known) {
                    throw new BusinessRuleException("Shipment item " + l.shipmentItemId() + " is not part of shipment " + shipmentId);
                }
                given.put(l.shipmentItemId(), l);
            }
        }
        DeliveryReceipt receipt = new DeliveryReceipt();
        receipt.setShipmentId(shipmentId);
        receipt.setDistributorId(distributorId);
        receipt.setStatus("CONFIRMED");
        receipt.setReceivedBy(CurrentUser.id());
        receipt.setReceivedAt(OffsetDateTime.now());
        receipt.setRemarks(req.remarks());
        receipt = receipts.save(receipt);
        Long warehouseId = req.destinationWarehouseId() != null ? req.destinationWarehouseId() : shipment.getWarehouseId();
        List<DeliveryReceiptItem> savedItems = new ArrayList<>();
        List<DeliveryDiscrepancy> found = new ArrayList<>();
        for (ShipmentItem line : lines) {
            BigDecimal expected = line.getQuantity() == null ? BigDecimal.ZERO : line.getQuantity();
            WorkflowRequests.ReceivedLine l = given.get(line.getShipmentItemId());
            BigDecimal received = l == null ? expected : l.receivedQuantity();
            BigDecimal damaged = l == null || l.damagedQuantity() == null ? BigDecimal.ZERO : l.damagedQuantity();
            if (damaged.compareTo(received) > 0) {
                throw new BusinessRuleException("Damaged quantity cannot be more than the received quantity (shipment item "
                        + line.getShipmentItemId() + ")");
            }
            DeliveryReceiptItem ri = new DeliveryReceiptItem();
            ri.setDeliveryReceiptId(receipt.getDeliveryReceiptId());
            ri.setShipmentItemId(line.getShipmentItemId());
            ri.setExpectedQuantity(expected);
            ri.setReceivedQuantity(received);
            ri.setDamagedQuantity(damaged);
            savedItems.add(receiptItems.save(ri));
            int diff = received.compareTo(expected);
            if (diff < 0) {
                found.add(discrepancy(receipt, line, "SHORTAGE", expected.subtract(received)));
            } else if (diff > 0) {
                found.add(discrepancy(receipt, line, "EXCESS", received.subtract(expected)));
            }
            if (damaged.signum() > 0) {
                found.add(discrepancy(receipt, line, "DAMAGED", damaged));
            }
            BigDecimal good = received.subtract(damaged);
            if (line.getProductBatchId() != null && good.signum() > 0) {
                WarehouseStock target = ledger.findOrCreate(warehouseId, line.getProductBatchId(), distributorId, true);
                ledger.post(target.getWarehouseStockId(), StockLedgerService.IN, good, "Delivery receipt", "DLV");
            }
            if (line.getProductBatchId() != null && damaged.signum() > 0) {
                WarehouseStock blocked = ledger.findOrCreate(warehouseId, line.getProductBatchId(), distributorId, false);
                ledger.post(blocked.getWarehouseStockId(), StockLedgerService.IN, damaged, "Damaged on delivery", "DMG");
            }
        }
        if (!found.isEmpty()) {
            receipt.setStatus("CONFIRMED_WITH_DISCREPANCY");
            receipt = receipts.save(receipt);
            raiseTickets(shipment, distributorId, found);
        }
        ShipmentStatus delivered = statuses.shipment(DELIVERED, 4, true);
        shipment.setShipmentStatusId(delivered.getShipmentStatusId());
        shipment.setDeliveryDate(LocalDate.now());
        shipments.save(shipment);
        addHistory(shipmentId, delivered.getShipmentStatusId(), found.isEmpty() ? "Delivered and confirmed"
                : "Delivered with " + found.size() + " discrepanc" + (found.size() == 1 ? "y" : "ies"));
        AuditTrail.record("CREATE", "DeliveryReceipt", receipt.getDeliveryReceiptId(), null, receipt);
        return new ReceiptResult(receipt, savedItems, found);
    }

    private DeliveryDiscrepancy discrepancy(DeliveryReceipt receipt, ShipmentItem line, String type, BigDecimal qty) {
        DeliveryDiscrepancy d = new DeliveryDiscrepancy();
        d.setDeliveryReceiptId(receipt.getDeliveryReceiptId());
        d.setShipmentItemId(line.getShipmentItemId());
        d.setDiscrepancyType(type);
        d.setQuantity(qty);
        d.setCreatedAt(OffsetDateTime.now());
        return discrepancies.save(d);
    }

    private void raiseTickets(Shipment shipment, Long distributorId, List<DeliveryDiscrepancy> found) {
        TicketOpener opener = tickets.getIfAvailable();
        String ref = nz(shipment.getTrackingNumber(), "shipment " + shipment.getShipmentId());
        for (DeliveryDiscrepancy d : found) {
            if (opener != null) {
                Long ticketId = opener.openSystemTicket(distributorId, "Delivery discrepancy", "High",
                        "Delivery " + d.getDiscrepancyType().toLowerCase() + " on " + ref,
                        d.getDiscrepancyType() + " of " + plain(d.getQuantity()) + " unit(s) on shipment item " + d.getShipmentItemId()
                                + " (" + ref + "), found when the delivery was confirmed.");
                d.setTicketId(ticketId);
                discrepancies.save(d);
            }
        }
        notifications.notify(users.usersWithRole(Roles.MANUFACTURER), "Delivery discrepancy",
                found.size() + " discrepanc" + (found.size() == 1 ? "y" : "ies") + " reported on " + ref + "; ticket(s) opened.");
    }

    // ------------------------------------------------------------------ helpers

    private Shipment shipment(Long id) {
        return shipments.findById(id).orElseThrow(() -> new ResourceNotFoundException("Shipment not found: " + id));
    }

    /** Distributor of a shipment: shipment item -> order item -> distributor order. */
    public Long distributorOf(List<ShipmentItem> lines) {
        for (ShipmentItem i : lines) {
            Long orderId = orderItems.findById(i.getOrderItemId()).map(OrderItem::getOrderId).orElse(null);
            if (orderId != null) {
                Long d = orders.findById(orderId).map(DistributorOrder::getDistributorId).orElse(null);
                if (d != null) {
                    return d;
                }
            }
        }
        return null;
    }

    private void addHistory(Long shipmentId, Long statusId, String remarks) {
        ShipmentStatusHistory h = new ShipmentStatusHistory();
        h.setShipmentId(shipmentId);
        h.setShipmentStatusId(statusId);
        h.setChangedBy(CurrentUser.id());
        h.setRemarks(truncate(remarks, 500));
        h.setChangedAt(OffsetDateTime.now());
        history.save(h);
    }

    private static String plain(BigDecimal v) {
        return v == null ? "0" : v.stripTrailingZeros().toPlainString();
    }

    private static String nz(String s, String fallback) {
        return s == null || s.isBlank() ? fallback : s;
    }

    private static String truncate(String s, int max) {
        return s == null || s.length() <= max ? s : s.substring(0, max);
    }

    /** Small summary used by the delivery-receipt GET. */
    public Map<String, Object> receiptDetails(Long shipmentId) {
        DeliveryReceipt r = receipts.findByShipmentId(shipmentId)
                .orElseThrow(() -> new ResourceNotFoundException("No delivery receipt for shipment " + shipmentId));
        if (CurrentUser.isDistributorOnly() && !Objects.equals(CurrentUser.distributorId(), r.getDistributorId())) {
            throw new ResourceNotFoundException("No delivery receipt for shipment " + shipmentId);
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("receipt", r);
        out.put("items", receiptItems.findByDeliveryReceiptId(r.getDeliveryReceiptId()));
        out.put("discrepancies", discrepancies.findByDeliveryReceiptId(r.getDeliveryReceiptId()));
        return out;
    }
}

package com.example.demo.sales.repository;

import com.example.demo.sales.entity.OrderTotalView;
import org.springframework.data.repository.Repository;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

/** Read-only repository: a view cannot be saved or deleted. */
public interface OrderTotalViewRepository extends Repository<OrderTotalView, Long> {
    List<OrderTotalView> findAll();

    Page<OrderTotalView> findAll(Pageable pageable);

    Optional<OrderTotalView> findById(Long id);
}

package com.example.demo.sales.repository;

import com.example.demo.sales.entity.ReturnCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReturnCategoryRepository extends JpaRepository<ReturnCategory, Long> {
}

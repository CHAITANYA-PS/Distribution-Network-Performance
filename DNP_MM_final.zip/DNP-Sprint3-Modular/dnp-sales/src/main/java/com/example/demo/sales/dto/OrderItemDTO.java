package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Request and response body for OrderItem. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class OrderItemDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long orderItemId;

    @NotNull(groups=OnCreate.class, message="Order id is required")
    private Long orderId;

    @NotNull(groups=OnCreate.class, message="Product id is required")
    private Long productId;

    @NotNull(groups=OnCreate.class, message="Quantity is required")
    @Positive(message="Quantity must be greater than 0")
    private BigDecimal quantity;

    @NotNull(groups=OnCreate.class, message="Unit price is required")
    @PositiveOrZero(message="Unit price must be 0 or greater")
    private BigDecimal unitPrice;
}

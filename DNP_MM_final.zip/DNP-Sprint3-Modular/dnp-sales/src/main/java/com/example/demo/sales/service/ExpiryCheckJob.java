package com.example.demo.sales.service;

import com.example.demo.manufacturer.entity.ProductBatch;
import com.example.demo.manufacturer.repository.ProductBatchRepository;
import com.example.demo.sales.entity.ProductReturn;
import com.example.demo.sales.entity.ReturnCategory;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.ReturnCategoryRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Component;

import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Daily expiry check (batch level). For every stock row that still holds stock:
 * <ul>
 *   <li>expired batch: blocked from sale, EXPIRED alert, and - when a distributor holds it - a return (R1) to the
 *       manufacturer's warehouse is raised automatically;</li>
 *   <li>batch expiring within expiry.near.days: NEAR_EXPIRY alert and a notice to the holder (they may raise an R2 return).</li>
 * </ul>
 * Alerts and returns are not duplicated when the job runs again.
 */
@Component
public class ExpiryCheckJob implements BackgroundJob {
    private final WarehouseStockRepository stocks;
    private final ProductBatchRepository batches;
    private final ReturnCategoryRepository categories;
    private final ProductReturnService returns;
    private final StockLedgerService ledger;
    private final SystemConfigService config;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public ExpiryCheckJob(WarehouseStockRepository stocks, ProductBatchRepository batches, ReturnCategoryRepository categories,
            ProductReturnService returns, StockLedgerService ledger, SystemConfigService config, NotificationGateway notifications,
            UserRoleResolver users) {
        this.stocks = stocks;
        this.batches = batches;
        this.categories = categories;
        this.returns = returns;
        this.ledger = ledger;
        this.config = config;
        this.notifications = notifications;
        this.users = users;
    }

    @Override
    public String name() {
        return "expiry-check";
    }

    @Override
    public String description() {
        return "Blocks expired batches, raises R1 returns for distributor-held expired stock, warns about near-expiry stock";
    }

    @Override
    public Map<String, Object> run() {
        int nearDays = config.integer(SystemConfigService.EXPIRY_NEAR_DAYS, 30);
        LocalDate today = LocalDate.now();
        Map<Long, ProductBatch> batchById = batches.findAll().stream()
                .collect(Collectors.toMap(ProductBatch::getProductBatchId, Function.identity()));
        int blocked = 0;
        int returnsRaised = 0;
        int nearAlerts = 0;
        int expiredAlerts = 0;
        for (WarehouseStock s : stocks.findAll()) {
            if (s.getQuantity() == null || s.getQuantity().signum() <= 0) {
                continue;
            }
            ProductBatch b = batchById.get(s.getProductBatchId());
            if (b == null || b.getExpiryDate() == null) {
                continue;
            }
            long days = ChronoUnit.DAYS.between(today, b.getExpiryDate());
            String qty = s.getQuantity().stripTrailingZeros().toPlainString();
            if (days < 0) {
                if (!Boolean.FALSE.equals(s.getIsSellable())) {
                    s.setIsSellable(false);
                    stocks.save(s);
                    blocked++;
                }
                if (ledger.raiseAlert(s.getWarehouseStockId(), "EXPIRED", "Batch " + b.getBatchNumber() + " expired on "
                        + b.getExpiryDate() + "; " + qty + " unit(s) blocked from sale")) {
                    expiredAlerts++;
                    notifyHolder(s, "Batch " + b.getBatchNumber() + " expired on " + b.getExpiryDate() + " (" + qty + " unit(s)); blocked from sale");
                }
                if (s.getOwnerDistributorId() != null && !returns.hasOpenReturn(s.getWarehouseStockId())) {
                    ProductReturn r = new ProductReturn();
                    r.setWarehouseStockId(s.getWarehouseStockId());
                    r.setReturnCategoryId(category("R1", "Expired").getReturnCategoryId());
                    r.setQuantity(s.getQuantity());
                    r.setReason("Raised automatically: batch " + b.getBatchNumber() + " expired on " + b.getExpiryDate());
                    returns.create(r);
                    returnsRaised++;
                }
            } else if (days <= nearDays) {
                if (ledger.raiseAlert(s.getWarehouseStockId(), "NEAR_EXPIRY", "Batch " + b.getBatchNumber() + " expires on "
                        + b.getExpiryDate() + " (" + days + " day(s)); " + qty + " unit(s) in stock")) {
                    nearAlerts++;
                    notifyHolder(s, "Batch " + b.getBatchNumber() + " expires in " + days + " day(s) (" + qty
                            + " unit(s)). Sell it first or raise an R2 return.");
                }
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("date", today.toString());
        out.put("nearExpiryDays", nearDays);
        out.put("stockRowsBlocked", blocked);
        out.put("expiredAlerts", expiredAlerts);
        out.put("nearExpiryAlerts", nearAlerts);
        out.put("returnsRaised", returnsRaised);
        return out;
    }

    private void notifyHolder(WarehouseStock s, String message) {
        if (s.getOwnerDistributorId() != null) {
            notifications.notify(users.usersOfDistributor(s.getOwnerDistributorId()), "Stock expiry", message);
        } else {
            notifications.notify(users.usersWithRole(Roles.MANUFACTURER), "Stock expiry", message);
        }
    }

    private ReturnCategory category(String code, String name) {
        return LookupSupport.findOrCreate(categories, ReturnCategory::getCategoryCode, code, () -> {
            ReturnCategory c = new ReturnCategory();
            c.setCategoryCode(code);
            c.setCategoryName(name);
            return c;
        });
    }
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ExchangeStatusDTO;
import com.example.demo.sales.entity.ExchangeStatus;
import com.example.demo.sales.service.ExchangeStatusService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/exchange-statuses")
public class ExchangeStatusController {
    private final ExchangeStatusService service;

    public ExchangeStatusController(ExchangeStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create ExchangeStatus")
    @PostMapping
    public ResponseEntity<ExchangeStatusDTO> create(@Validated(OnCreate.class) @RequestBody ExchangeStatusDTO body) {
        ExchangeStatus saved = service.create(DtoMapper.toEntity(body, ExchangeStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/exchange-statuses/" + saved.getExchangeStatusId())).body(DtoMapper.toDto(saved, ExchangeStatusDTO.class));
    }

    @Operation(summary = "Get one ExchangeStatus by id")
    @GetMapping("/{id}")
    public ExchangeStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ExchangeStatusDTO.class);
    }

    @Operation(summary = "List / search ExchangeStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ExchangeStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ExchangeStatusDTO.class));
        }
        Page<ExchangeStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ExchangeStatusDTO.class));
    }

    @Operation(summary = "Update ExchangeStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ExchangeStatusDTO update(@PathVariable Long id, @Valid @RequestBody ExchangeStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ExchangeStatus.class)), ExchangeStatusDTO.class);
    }

    @Operation(summary = "Delete ExchangeStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

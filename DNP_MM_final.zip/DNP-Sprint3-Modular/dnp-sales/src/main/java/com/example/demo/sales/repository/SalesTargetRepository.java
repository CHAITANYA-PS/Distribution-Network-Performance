package com.example.demo.sales.repository;

import com.example.demo.sales.entity.SalesTarget;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface SalesTargetRepository extends JpaRepository<SalesTarget, Long> {
    List<SalesTarget> findByReportingPeriodId(Long reportingPeriodId);
    List<SalesTarget> findByDistributorId(Long distributorId);
}

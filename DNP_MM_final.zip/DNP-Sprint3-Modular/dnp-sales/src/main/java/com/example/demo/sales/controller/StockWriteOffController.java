package com.example.demo.sales.controller;

import com.example.demo.sales.dto.StockWriteOffDTO;
import com.example.demo.sales.entity.StockWriteOff;
import com.example.demo.sales.service.StockWriteOffService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** StockWriteOff API. Create and read only: a write-off cannot be changed or deleted. */
@RestController
@RequestMapping("/api/v1/stock-write-offs")
public class StockWriteOffController {
    private final StockWriteOffService service;

    public StockWriteOffController(StockWriteOffService service) {
        this.service = service;
    }

    @Operation(summary = "Create StockWriteOff")
    @PostMapping
    public ResponseEntity<StockWriteOffDTO> create(@Validated(OnCreate.class) @RequestBody StockWriteOffDTO body) {
        StockWriteOff saved = service.create(DtoMapper.toEntity(body, StockWriteOff.class));
        return ResponseEntity.created(URI.create("/api/v1/stock-write-offs/" + saved.getWriteOffId())).body(DtoMapper.toDto(saved, StockWriteOffDTO.class));
    }

    @Operation(summary = "Get one StockWriteOff by id")
    @GetMapping("/{id}")
    public StockWriteOffDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), StockWriteOffDTO.class);
    }

    @Operation(summary = "List / search StockWriteOff", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<StockWriteOffDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), StockWriteOffDTO.class));
        }
        Page<StockWriteOff> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), StockWriteOffDTO.class));
    }
}

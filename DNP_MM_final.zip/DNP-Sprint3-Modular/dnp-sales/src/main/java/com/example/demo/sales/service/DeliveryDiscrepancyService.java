package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.sales.entity.DeliveryDiscrepancy;
import com.example.demo.sales.repository.DeliveryDiscrepancyRepository;
import org.springframework.stereotype.Service;

@Service
public class DeliveryDiscrepancyService extends AbstractCrudService<DeliveryDiscrepancy, Long> {
    public DeliveryDiscrepancyService(DeliveryDiscrepancyRepository repository) {
        super(repository, DeliveryDiscrepancy.class);
    }
}

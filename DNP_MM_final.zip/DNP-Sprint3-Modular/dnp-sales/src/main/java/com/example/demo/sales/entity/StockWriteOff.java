package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Stock write-offs (stock that cannot be sold or returned) (table dsphere.stock_write_off, added in V4). */
@Entity @Table(name="stock_write_off",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class StockWriteOff implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="write_off_id")
 private Long writeOffId;
 @NotNull(groups=OnCreate.class, message="Warehouse stock id is required")
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @NotNull(groups=OnCreate.class, message="Quantity is required")
 @Positive(message="Quantity must be greater than 0")
 @Column(name="quantity")
 private BigDecimal quantity;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @PositiveOrZero(message="Write off value must be 0 or greater")
 @Column(name="write_off_value")
 private BigDecimal writeOffValue;
 @NotBlank(groups=OnCreate.class, message="Reason is required")
 @Size(max=500, message="Reason must be at most 500 characters")
 @Column(name="reason", length=500)
 private String reason;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="written_off_by")
 private Long writtenOffBy;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="written_off_at")
 private OffsetDateTime writtenOffAt;
}

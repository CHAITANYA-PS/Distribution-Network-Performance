package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.sales.entity.ShipmentStatusHistory;
import com.example.demo.sales.repository.ShipmentStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentStatusHistoryService extends AbstractCrudService<ShipmentStatusHistory, Long> {
    public ShipmentStatusHistoryService(ShipmentStatusHistoryRepository repository) {
        super(repository, ShipmentStatusHistory.class);
    }
}

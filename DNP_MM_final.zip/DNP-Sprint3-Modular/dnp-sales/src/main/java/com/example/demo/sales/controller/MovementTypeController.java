package com.example.demo.sales.controller;

import com.example.demo.sales.dto.MovementTypeDTO;
import com.example.demo.sales.entity.MovementType;
import com.example.demo.sales.service.MovementTypeService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/movement-types")
public class MovementTypeController {
    private final MovementTypeService service;

    public MovementTypeController(MovementTypeService service) {
        this.service = service;
    }

    @Operation(summary = "Create MovementType")
    @PostMapping
    public ResponseEntity<MovementTypeDTO> create(@Validated(OnCreate.class) @RequestBody MovementTypeDTO body) {
        MovementType saved = service.create(DtoMapper.toEntity(body, MovementType.class));
        return ResponseEntity.created(URI.create("/api/v1/movement-types/" + saved.getMovementTypeId())).body(DtoMapper.toDto(saved, MovementTypeDTO.class));
    }

    @Operation(summary = "Get one MovementType by id")
    @GetMapping("/{id}")
    public MovementTypeDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), MovementTypeDTO.class);
    }

    @Operation(summary = "List / search MovementType", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<MovementTypeDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), MovementTypeDTO.class));
        }
        Page<MovementType> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), MovementTypeDTO.class));
    }

    @Operation(summary = "Update MovementType (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public MovementTypeDTO update(@PathVariable Long id, @Valid @RequestBody MovementTypeDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, MovementType.class)), MovementTypeDTO.class);
    }

    @Operation(summary = "Delete MovementType")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

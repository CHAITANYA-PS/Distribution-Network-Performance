package com.example.demo.sales.controller;

import com.example.demo.distributor.dto.DistributorOrderDTO;
import com.example.demo.sales.dto.ExchangeHistoryDTO;
import com.example.demo.sales.dto.ExchangeRequestDTO;
import com.example.demo.sales.dto.OrderStatusHistoryDTO;
import com.example.demo.sales.dto.ProductReturnDTO;
import com.example.demo.sales.dto.WorkflowRequests;
import com.example.demo.sales.service.ExchangeRequestService;
import com.example.demo.sales.service.OrderWorkflowService;
import com.example.demo.sales.service.ProductReturnService;
import com.example.demo.systemadmin.dto.DtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Business actions on product returns, exchange requests and orders (the CRUD APIs stay in their own controllers). */
@RestController
@RequestMapping("/api/v1")
public class SalesWorkflowController {
    private final ProductReturnService returns;
    private final ExchangeRequestService exchanges;
    private final OrderWorkflowService orders;

    public SalesWorkflowController(ProductReturnService returns, ExchangeRequestService exchanges, OrderWorkflowService orders) {
        this.returns = returns;
        this.exchanges = exchanges;
        this.orders = orders;
    }

    // ---- product returns: REQUESTED -> APPROVED -> IN_TRANSIT -> RECEIVED (or REJECTED)

    @Operation(summary = "Approve a return (manufacturer) and choose the warehouse it goes back to")
    @PostMapping("/product-returns/{id}/approve")
    public ProductReturnDTO approveReturn(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.ApproveReturn body) {
        return DtoMapper.toDto(returns.approve(id, body.targetWarehouseId(), body.remarks()), ProductReturnDTO.class);
    }

    @Operation(summary = "Reject a return (manufacturer)")
    @PostMapping("/product-returns/{id}/reject")
    public ProductReturnDTO rejectReturn(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.Reason body) {
        return DtoMapper.toDto(returns.reject(id, body.reason()), ProductReturnDTO.class);
    }

    @Operation(summary = "Ship an approved return: the stock leaves the holder")
    @PostMapping("/product-returns/{id}/ship")
    public ProductReturnDTO shipReturn(@PathVariable Long id) {
        return DtoMapper.toDto(returns.ship(id), ProductReturnDTO.class);
    }

    @Operation(summary = "Receive a return at the target warehouse (kept as not sellable)")
    @PostMapping("/product-returns/{id}/receive")
    public ProductReturnDTO receiveReturn(@PathVariable Long id) {
        return DtoMapper.toDto(returns.receive(id), ProductReturnDTO.class);
    }

    // ---- exchange requests: Requested -> Approved -> Completed (or Rejected)

    @Operation(summary = "Approve an exchange request (manufacturer): choose source stock and destination warehouse")
    @PostMapping("/exchange-requests/{id}/approve")
    public ExchangeRequestDTO approveExchange(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.ApproveExchange body) {
        return DtoMapper.toDto(exchanges.approve(id, body.sourceWarehouseStockId(), body.destinationWarehouseId(), body.remarks()),
                ExchangeRequestDTO.class);
    }

    @Operation(summary = "Reject an exchange request (manufacturer)")
    @PostMapping("/exchange-requests/{id}/reject")
    public ExchangeRequestDTO rejectExchange(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.Reason body) {
        return DtoMapper.toDto(exchanges.reject(id, body.reason()), ExchangeRequestDTO.class);
    }

    @Operation(summary = "Complete an approved exchange: transfers the stock")
    @PostMapping("/exchange-requests/{id}/complete")
    public ExchangeRequestDTO completeExchange(@PathVariable Long id, @RequestBody(required = false) WorkflowRequests.Remarks body) {
        return DtoMapper.toDto(exchanges.complete(id, body == null ? null : body.remarks()), ExchangeRequestDTO.class);
    }

    @Operation(summary = "Track an exchange request: every status change")
    @GetMapping("/exchange-requests/{id}/history")
    public List<ExchangeHistoryDTO> exchangeHistory(@PathVariable Long id) {
        return DtoMapper.toDtoList(exchanges.history(id), ExchangeHistoryDTO.class);
    }

    // ---- orders

    @Operation(summary = "Move an order to its next status", description = "Statuses only move forward (by sequence number).")
    @PostMapping("/distributor-orders/{id}/status")
    public DistributorOrderDTO orderStatus(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.StatusChange body) {
        return DtoMapper.toDto(orders.changeStatus(id, body.status(), body.remarks()), DistributorOrderDTO.class);
    }

    @Operation(summary = "Cancel an order (until it is shipped)")
    @PostMapping("/distributor-orders/{id}/cancel")
    public DistributorOrderDTO cancelOrder(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.Reason body) {
        return DtoMapper.toDto(orders.cancel(id, body.reason()), DistributorOrderDTO.class);
    }

    @Operation(summary = "Status history of an order")
    @GetMapping("/distributor-orders/{id}/history")
    public List<OrderStatusHistoryDTO> orderHistory(@PathVariable Long id) {
        return DtoMapper.toDtoList(orders.history(id), OrderStatusHistoryDTO.class);
    }
}

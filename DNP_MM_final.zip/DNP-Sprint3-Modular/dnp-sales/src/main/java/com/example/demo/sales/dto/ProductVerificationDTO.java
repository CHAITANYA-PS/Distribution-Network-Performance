package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for ProductVerification. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductVerificationDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long verificationId;

    @NotNull(groups=OnCreate.class, message="Shipment item id is required")
    private Long shipmentItemId;

    @NotBlank(groups=OnCreate.class, message="Entered code is required")
    @Size(max=13, message="Entered code must be at most 13 characters")
    private String enteredCode;

    @Size(max=100, message="Entered batch number must be at most 100 characters")
    private String enteredBatchNumber;

    @NotNull(groups=OnCreate.class, message="Entered quantity is required")
    @Positive(message="Entered quantity must be greater than 0")
    private BigDecimal enteredQuantity;

    @NotBlank(groups=OnCreate.class, message="Result is required")
    @Size(max=20, message="Result must be at most 20 characters")
    @Pattern(regexp="MATCH|MISMATCH", message="Result must be one of: MATCH, MISMATCH")
    private String result;

    @Size(max=500, message="Message must be at most 500 characters")
    private String message;

    private Long verifiedBy;

    private OffsetDateTime verifiedAt;
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.SalesTargetDTO;
import com.example.demo.sales.entity.SalesTarget;
import com.example.demo.sales.service.SalesTargetService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/sales-targets")
public class SalesTargetController {
    private final SalesTargetService service;

    public SalesTargetController(SalesTargetService service) {
        this.service = service;
    }

    @Operation(summary = "Create SalesTarget")
    @PostMapping
    public ResponseEntity<SalesTargetDTO> create(@Validated(OnCreate.class) @RequestBody SalesTargetDTO body) {
        SalesTarget saved = service.create(DtoMapper.toEntity(body, SalesTarget.class));
        return ResponseEntity.created(URI.create("/api/v1/sales-targets/" + saved.getTargetId())).body(DtoMapper.toDto(saved, SalesTargetDTO.class));
    }

    @Operation(summary = "Get one SalesTarget by id")
    @GetMapping("/{id}")
    public SalesTargetDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), SalesTargetDTO.class);
    }

    @Operation(summary = "List / search SalesTarget", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<SalesTargetDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), SalesTargetDTO.class));
        }
        Page<SalesTarget> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), SalesTargetDTO.class));
    }

    @Operation(summary = "Update SalesTarget (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public SalesTargetDTO update(@PathVariable Long id, @Valid @RequestBody SalesTargetDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, SalesTarget.class)), SalesTargetDTO.class);
    }

    @Operation(summary = "Delete SalesTarget")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for ShipmentStatusHistory. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ShipmentStatusHistoryDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long shipmentStatusHistoryId;

    @NotNull(groups=OnCreate.class, message="Shipment id is required")
    private Long shipmentId;

    @NotNull(groups=OnCreate.class, message="Shipment status id is required")
    private Long shipmentStatusId;

    private Long changedBy;

    @Size(max=500, message="Remarks must be at most 500 characters")
    private String remarks;

    private OffsetDateTime changedAt;
}

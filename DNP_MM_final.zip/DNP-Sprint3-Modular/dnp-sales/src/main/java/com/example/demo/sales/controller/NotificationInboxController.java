package com.example.demo.sales.controller;

import com.example.demo.sales.dto.NotificationDTO;
import com.example.demo.sales.entity.Notification;
import com.example.demo.sales.repository.NotificationRepository;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.service.InvalidRequestException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Objects;

/** The logged-in user's own notifications (alerts, reminders, escalations). */
@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationInboxController {
    private final NotificationRepository notifications;

    public NotificationInboxController(NotificationRepository notifications) {
        this.notifications = notifications;
    }

    @Operation(summary = "My notifications, newest first")
    @GetMapping("/mine")
    @Transactional(readOnly = true)
    public List<NotificationDTO> mine(@RequestParam(defaultValue = "false") boolean unreadOnly) {
        Long me = requireUser();
        return DtoMapper.toDtoList(notifications.findByUserIdOrderByCreatedAtDesc(me).stream()
                .filter(n -> !unreadOnly || !Boolean.TRUE.equals(n.getReadStatus())).toList(), NotificationDTO.class);
    }

    @Operation(summary = "Mark one of my notifications as read")
    @PostMapping("/{id}/read")
    @Transactional
    public NotificationDTO markRead(@PathVariable Long id) {
        Long me = requireUser();
        Notification n = notifications.findById(id).filter(x -> Objects.equals(x.getUserId(), me))
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + id));
        n.setReadStatus(true);
        return DtoMapper.toDto(notifications.save(n), NotificationDTO.class);
    }

    private static Long requireUser() {
        Long me = CurrentUser.id();
        if (me == null) {
            throw new InvalidRequestException("Log in to see your notifications");
        }
        return me;
    }
}

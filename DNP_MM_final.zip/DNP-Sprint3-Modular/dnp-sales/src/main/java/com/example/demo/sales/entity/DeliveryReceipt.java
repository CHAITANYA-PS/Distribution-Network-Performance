package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Delivery receipt (distributor confirms the delivery with the handover code) (table dsphere.delivery_receipt, added in V4). */
@Entity @Table(name="delivery_receipt",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DeliveryReceipt implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="delivery_receipt_id")
 private Long deliveryReceiptId;
 @NotNull(groups=OnCreate.class, message="Shipment id is required")
 @Column(name="shipment_id")
 private Long shipmentId;
 @Column(name="distributor_id")
 private Long distributorId;
 @NotBlank(groups=OnCreate.class, message="Status is required")
 @Size(max=30, message="Status must be at most 30 characters")
 @Pattern(regexp="CONFIRMED|CONFIRMED_WITH_DISCREPANCY", message="Status must be one of: CONFIRMED, CONFIRMED_WITH_DISCREPANCY")
 @Column(name="status")
 private String status;
 @Column(name="received_by")
 private Long receivedBy;
 @Column(name="received_at")
 private OffsetDateTime receivedAt;
 @Size(max=1000, message="Remarks must be at most 1000 characters")
 @Column(name="remarks", length=1000)
 private String remarks;
}

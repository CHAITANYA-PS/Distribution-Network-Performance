package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="order_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class OrderStatus implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="order_status_id")
 private Long orderStatusId;
 @NotBlank(groups=OnCreate.class, message="Status name is required")
 @Size(max=50, message="Status name must be at most 50 characters")
 @Column(name="status_name")
 private String statusName;
 @NotNull(groups=OnCreate.class, message="Sequence number is required")
 @Positive(message="Sequence number must be greater than 0")
 @Column(name="sequence_number")
 private Integer sequenceNumber;
 @CreateDefault("false")
 @Column(name="is_terminal")
 private Boolean isTerminal;
}
package com.example.demo.sales.controller;

import com.example.demo.sales.dto.OrderTotalViewDTO;
import com.example.demo.sales.entity.OrderTotalView;
import com.example.demo.sales.service.OrderTotalViewService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** Read-only endpoints over the OrderTotalView database view. */
@RestController
@RequestMapping("/api/v1/views/order-totals")
public class OrderTotalViewController {
    private final OrderTotalViewService service;

    public OrderTotalViewController(OrderTotalViewService service) {
        this.service = service;
    }

    @Operation(summary = "List OrderTotalView (optional paging)")
    @GetMapping
    public ResponseEntity<List<OrderTotalViewDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size) {
        if (page == null && size == null) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), OrderTotalViewDTO.class));
        }
        Page<OrderTotalView> result = service.getPage(page, size);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), OrderTotalViewDTO.class));
    }

    @Operation(summary = "Get one OrderTotalView by id")
    @GetMapping("/{id}")
    public OrderTotalViewDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), OrderTotalViewDTO.class);
    }
}

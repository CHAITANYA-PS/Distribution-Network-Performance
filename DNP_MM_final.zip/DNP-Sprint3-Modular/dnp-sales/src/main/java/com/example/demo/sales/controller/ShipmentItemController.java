package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ShipmentItemDTO;
import com.example.demo.sales.entity.ShipmentItem;
import com.example.demo.sales.service.ShipmentItemService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/shipment-items")
public class ShipmentItemController {
    private final ShipmentItemService service;

    public ShipmentItemController(ShipmentItemService service) {
        this.service = service;
    }

    @Operation(summary = "Create ShipmentItem")
    @PostMapping
    public ResponseEntity<ShipmentItemDTO> create(@Validated(OnCreate.class) @RequestBody ShipmentItemDTO body) {
        ShipmentItem saved = service.create(DtoMapper.toEntity(body, ShipmentItem.class));
        return ResponseEntity.created(URI.create("/api/v1/shipment-items/" + saved.getShipmentItemId())).body(DtoMapper.toDto(saved, ShipmentItemDTO.class));
    }

    @Operation(summary = "Get one ShipmentItem by id")
    @GetMapping("/{id}")
    public ShipmentItemDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ShipmentItemDTO.class);
    }

    @Operation(summary = "List / search ShipmentItem", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ShipmentItemDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ShipmentItemDTO.class));
        }
        Page<ShipmentItem> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ShipmentItemDTO.class));
    }

    @Operation(summary = "Update ShipmentItem (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ShipmentItemDTO update(@PathVariable Long id, @Valid @RequestBody ShipmentItemDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ShipmentItem.class)), ShipmentItemDTO.class);
    }

    @Operation(summary = "Delete ShipmentItem")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

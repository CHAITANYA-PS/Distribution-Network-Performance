package com.example.demo.sales.controller;

import com.example.demo.sales.dto.OrderStatusDTO;
import com.example.demo.sales.entity.OrderStatus;
import com.example.demo.sales.service.OrderStatusService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/order-statuses")
public class OrderStatusController {
    private final OrderStatusService service;

    public OrderStatusController(OrderStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create OrderStatus")
    @PostMapping
    public ResponseEntity<OrderStatusDTO> create(@Validated(OnCreate.class) @RequestBody OrderStatusDTO body) {
        OrderStatus saved = service.create(DtoMapper.toEntity(body, OrderStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/order-statuses/" + saved.getOrderStatusId())).body(DtoMapper.toDto(saved, OrderStatusDTO.class));
    }

    @Operation(summary = "Get one OrderStatus by id")
    @GetMapping("/{id}")
    public OrderStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), OrderStatusDTO.class);
    }

    @Operation(summary = "List / search OrderStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<OrderStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), OrderStatusDTO.class));
        }
        Page<OrderStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), OrderStatusDTO.class));
    }

    @Operation(summary = "Update OrderStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public OrderStatusDTO update(@PathVariable Long id, @Valid @RequestBody OrderStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, OrderStatus.class)), OrderStatusDTO.class);
    }

    @Operation(summary = "Delete OrderStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.sales.dto;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/** One line of the current stock report (stock row + product + batch + warehouse). */
public record CurrentStockRow(Long warehouseStockId, Long warehouseId, String warehouseName, Long productId, String sku,
        String productName, String productCode, Long productBatchId, String batchNumber, LocalDate expiryDate,
        Long daysToExpiry, String expiryState, BigDecimal quantity, BigDecimal reorderLevel, boolean belowReorderLevel,
        Boolean sellable, String stockType, Long ownerDistributorId, OffsetDateTime receivedAt, Long ageDays,
        BigDecimal unitCost, BigDecimal stockValue) {
}

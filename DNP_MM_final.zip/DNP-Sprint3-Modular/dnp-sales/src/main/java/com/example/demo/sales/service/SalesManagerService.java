package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.sales.entity.SalesManager;
import com.example.demo.sales.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesManagerService extends AbstractCrudService<SalesManager, Long> {
    public SalesManagerService(SalesManagerRepository repository) {
        super(repository, SalesManager.class);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}

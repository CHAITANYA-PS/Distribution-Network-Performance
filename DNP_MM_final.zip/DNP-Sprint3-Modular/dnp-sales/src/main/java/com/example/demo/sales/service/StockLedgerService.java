package com.example.demo.sales.service;

import com.example.demo.sales.entity.InventoryAlert;
import com.example.demo.sales.entity.InventoryDocument;
import com.example.demo.sales.entity.InventoryDocumentType;
import com.example.demo.sales.entity.InventoryMovement;
import com.example.demo.sales.entity.MovementType;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.InventoryAlertRepository;
import com.example.demo.sales.repository.InventoryDocumentRepository;
import com.example.demo.sales.repository.InventoryDocumentTypeRepository;
import com.example.demo.sales.repository.InventoryMovementRepository;
import com.example.demo.sales.repository.MovementTypeRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.format.DateTimeFormatter;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.ThreadLocalRandom;

/**
 * The stock quantity ledger. warehouse_stock.quantity is never typed in: it only changes through stock
 * movements (receipt, dispatch, transfer, return, write-off), each one recorded in inventory_movement with an
 * inventory document. The row is locked while it changes, and the quantity can never go below zero.
 */
@Service
@Transactional
public class StockLedgerService {
    public static final String IN = "IN";
    public static final String OUT = "OUT";

    private final WarehouseStockRepository stocks;
    private final InventoryMovementRepository movements;
    private final MovementTypeRepository movementTypes;
    private final InventoryDocumentRepository documents;
    private final InventoryDocumentTypeRepository documentTypes;
    private final InventoryAlertRepository alerts;

    public StockLedgerService(WarehouseStockRepository stocks, InventoryMovementRepository movements,
            MovementTypeRepository movementTypes, InventoryDocumentRepository documents,
            InventoryDocumentTypeRepository documentTypes, InventoryAlertRepository alerts) {
        this.stocks = stocks;
        this.movements = movements;
        this.movementTypes = movementTypes;
        this.documents = documents;
        this.documentTypes = documentTypes;
        this.alerts = alerts;
    }

    /** Locks one stock row for the rest of the transaction. */
    public WarehouseStock lock(Long warehouseStockId) {
        return stocks.findByIdForUpdate(warehouseStockId)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse stock not found: " + warehouseStockId));
    }

    /**
     * Records a system movement (with its own inventory document) and changes the quantity.
     * @param movementName e.g. "Dispatch", "Delivery receipt", "Return", "Write-off", "Exchange transfer"
     */
    public InventoryMovement post(Long warehouseStockId, String direction, BigDecimal quantity, String movementName, String documentPrefix) {
        WarehouseStock stock = lock(warehouseStockId);
        applyQuantity(stock, direction, quantity);
        InventoryDocument doc = new InventoryDocument();
        doc.setInventoryDocumentTypeId(documentType(movementName).getInventoryDocumentTypeId());
        doc.setDocumentNumber(documentNumber(documentPrefix));
        doc.setDocumentDate(LocalDate.now());
        doc.setCreatedBy(CurrentUser.id());
        doc.setCreatedAt(OffsetDateTime.now());
        doc = documents.save(doc);
        InventoryMovement m = new InventoryMovement();
        m.setInventoryDocumentId(doc.getInventoryDocumentId());
        m.setWarehouseStockId(warehouseStockId);
        m.setMovementTypeId(movementType(movementName, direction).getMovementTypeId());
        m.setQuantity(quantity);
        m.setMovementDate(OffsetDateTime.now());
        InventoryMovement saved = movements.save(m);
        AuditTrail.record("CREATE", "InventoryMovement", saved.getMovementId(), null, saved);
        return saved;
    }

    /** Applies a movement that a user created through the inventory-movements API. */
    public void applyUserMovement(InventoryMovement m) {
        MovementType type = movementTypes.findById(m.getMovementTypeId())
                .orElseThrow(() -> new BusinessRuleException("Movement type not found: " + m.getMovementTypeId()));
        WarehouseStock stock = lock(m.getWarehouseStockId());
        applyQuantity(stock, direction(type.getMovementDirection()), m.getQuantity());
    }

    /** Stock row for a batch in a warehouse and owner, created (quantity 0) when it does not exist yet. */
    public WarehouseStock findOrCreate(Long warehouseId, Long productBatchId, Long ownerDistributorId, boolean sellable) {
        List<WarehouseStock> rows = stocks.findByWarehouseIdAndProductBatchId(warehouseId, productBatchId);
        for (WarehouseStock s : rows) {
            boolean sameOwner = ownerDistributorId == null ? s.getOwnerDistributorId() == null : ownerDistributorId.equals(s.getOwnerDistributorId());
            if (sameOwner && Boolean.valueOf(sellable).equals(s.getIsSellable() == null ? Boolean.TRUE : s.getIsSellable())) {
                return s;
            }
        }
        WarehouseStock s = new WarehouseStock();
        s.setWarehouseId(warehouseId);
        s.setProductBatchId(productBatchId);
        s.setOwnerDistributorId(ownerDistributorId);
        s.setReorderLevel(BigDecimal.ZERO);
        s.setQuantity(BigDecimal.ZERO);
        s.setIsSellable(sellable);
        s.setStockType("STOCK_SELL");
        s.setReceivedAt(OffsetDateTime.now());
        s.setVersion(null);
        return stocks.save(s);
    }

    /** "IN" or "OUT" from a movement direction text (IN, INWARD, RECEIPT, + ... / OUT, OUTWARD, ISSUE, - ...). */
    public static String direction(String text) {
        String d = text == null ? "" : text.trim().toUpperCase(Locale.ROOT);
        if (d.startsWith("IN") || d.startsWith("RECEIPT") || d.startsWith("+") || d.equals("ADD")) {
            return IN;
        }
        if (d.startsWith("OUT") || d.startsWith("ISSUE") || d.startsWith("-") || d.equals("REMOVE")) {
            return OUT;
        }
        throw new BusinessRuleException("Movement direction '" + text + "' must be IN or OUT");
    }

    private void applyQuantity(WarehouseStock stock, String direction, BigDecimal quantity) {
        if (quantity == null || quantity.signum() <= 0) {
            throw new BusinessRuleException("Movement quantity must be greater than 0");
        }
        BigDecimal current = stock.getQuantity() == null ? BigDecimal.ZERO : stock.getQuantity();
        BigDecimal next = IN.equals(direction) ? current.add(quantity) : current.subtract(quantity);
        if (next.signum() < 0) {
            throw new BusinessRuleException("Not enough stock in warehouse stock " + stock.getWarehouseStockId()
                    + ": available " + current.stripTrailingZeros().toPlainString() + ", requested " + quantity.stripTrailingZeros().toPlainString());
        }
        stock.setQuantity(next);
        if (IN.equals(direction) && current.signum() == 0) {
            stock.setReceivedAt(OffsetDateTime.now());
        }
        stocks.save(stock);
        if (OUT.equals(direction) && stock.getReorderLevel() != null && next.compareTo(stock.getReorderLevel()) <= 0) {
            raiseAlert(stock.getWarehouseStockId(), "LOW_STOCK", "Stock " + stock.getWarehouseStockId() + " is at "
                    + next.stripTrailingZeros().toPlainString() + ", at or below its reorder level " + stock.getReorderLevel().stripTrailingZeros().toPlainString());
        }
    }

    /** Opens an inventory alert unless the same alert is already open for this stock row. Returns true when created. */
    public boolean raiseAlert(Long warehouseStockId, String type, String message) {
        if (alerts.existsByWarehouseStockIdAndAlertTypeAndStatus(warehouseStockId, type, "Open")) {
            return false;
        }
        InventoryAlert a = new InventoryAlert();
        a.setWarehouseStockId(warehouseStockId);
        a.setAlertType(type);
        a.setMessage(message.length() > 500 ? message.substring(0, 500) : message);
        a.setStatus("Open");
        a.setCreatedAt(OffsetDateTime.now());
        alerts.save(a);
        return true;
    }

    private MovementType movementType(String name, String direction) {
        return LookupSupport.findOrCreate(movementTypes, MovementType::getMovementTypeName, name, () -> {
            MovementType t = new MovementType();
            t.setMovementTypeName(name);
            t.setMovementDirection(direction);
            return t;
        });
    }

    private InventoryDocumentType documentType(String name) {
        return LookupSupport.findOrCreate(documentTypes, InventoryDocumentType::getDocumentTypeName, name, () -> {
            InventoryDocumentType t = new InventoryDocumentType();
            t.setDocumentTypeName(name);
            return t;
        });
    }

    private static String documentNumber(String prefix) {
        return prefix + "-" + OffsetDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMddHHmmss"))
                + "-" + ThreadLocalRandom.current().nextInt(1000, 10000);
    }
}

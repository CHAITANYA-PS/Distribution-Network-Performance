package com.example.demo.sales.service;

import com.example.demo.sales.dto.CurrentStockRow;
import com.example.demo.sales.entity.InventoryMovement;
import com.example.demo.sales.entity.MovementType;
import com.example.demo.sales.repository.InventoryMovementRepository;
import com.example.demo.sales.repository.MovementTypeRepository;
import com.example.demo.systemadmin.dto.ReportTable;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Inventory analytics on the current stock: aging buckets, holding cost, turnover, slow-moving stock, working
 * capital tied up in stock, and the pre-sell / stock-sell split. Thresholds come from system_config.
 */
@Service
@Transactional(readOnly = true)
public class InventoryAnalyticsService {
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);
    private static final BigDecimal DAYS_IN_YEAR = BigDecimal.valueOf(365);

    private final CurrentStockService stock;
    private final InventoryMovementRepository movements;
    private final MovementTypeRepository movementTypes;
    private final SystemConfigService config;

    public InventoryAnalyticsService(CurrentStockService stock, InventoryMovementRepository movements,
            MovementTypeRepository movementTypes, SystemConfigService config) {
        this.stock = stock;
        this.movements = movements;
        this.movementTypes = movementTypes;
        this.config = config;
    }

    private List<CurrentStockRow> rows(Long warehouseId) {
        return stock.current(new CurrentStockService.Filter(warehouseId, null, null, null, null, null, false));
    }

    /** Stock quantity and value by age since it was received (buckets from inventory.aging.buckets, e.g. 30,60,90). */
    public ReportTable aging(Long warehouseId) {
        List<Integer> limits = config.integers(SystemConfigService.AGING_BUCKETS, "30,60,90");
        List<String> names = new ArrayList<>();
        int from = 0;
        for (int l : limits) {
            names.add(from + "-" + l + " days");
            from = l + 1;
        }
        names.add("over " + limits.get(limits.size() - 1) + " days");
        Map<String, BigDecimal[]> buckets = new LinkedHashMap<>();
        names.forEach(n -> buckets.put(n, new BigDecimal[] {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO}));
        for (CurrentStockRow r : rows(warehouseId)) {
            long age = r.ageDays() == null ? 0 : r.ageDays();
            int i = 0;
            while (i < limits.size() && age > limits.get(i)) {
                i++;
            }
            BigDecimal[] b = buckets.get(names.get(i));
            b[0] = b[0].add(BigDecimal.ONE);
            b[1] = b[1].add(r.quantity());
            b[2] = b[2].add(nz(r.stockValue()));
        }
        ReportTable t = ReportTable.of("Stock aging", List.of("ageBucket", "stockRows", "quantity", "stockValue", "valuePercent"));
        BigDecimal totalValue = buckets.values().stream().map(b -> b[2]).reduce(BigDecimal.ZERO, BigDecimal::add);
        buckets.forEach((n, b) -> t.row(n, b[0].intValue(), b[1], b[2], percent(b[2], totalValue)));
        return t.total("stockValue", totalValue);
    }

    /** Yearly holding cost rate (inventory.holding.cost.rate.percent) applied to each stock row for the days it has been held. */
    public ReportTable holdingCost(Long warehouseId) {
        BigDecimal rate = config.decimal(SystemConfigService.HOLDING_COST_RATE, "18");
        ReportTable t = ReportTable.of("Holding cost", List.of("warehouseStockId", "warehouseName", "productName", "batchNumber",
                "quantity", "stockValue", "daysHeld", "holdingCostSoFar", "holdingCostPerMonth"));
        BigDecimal total = BigDecimal.ZERO;
        BigDecimal monthly = BigDecimal.ZERO;
        for (CurrentStockRow r : rows(warehouseId)) {
            BigDecimal value = nz(r.stockValue());
            long days = r.ageDays() == null ? 0 : r.ageDays();
            BigDecimal yearly = value.multiply(rate).divide(HUNDRED, 4, RoundingMode.HALF_UP);
            BigDecimal soFar = yearly.multiply(BigDecimal.valueOf(days)).divide(DAYS_IN_YEAR, 2, RoundingMode.HALF_UP);
            BigDecimal perMonth = yearly.divide(BigDecimal.valueOf(12), 2, RoundingMode.HALF_UP);
            t.row(r.warehouseStockId(), r.warehouseName(), r.productName(), r.batchNumber(), r.quantity(), value, days, soFar, perMonth);
            total = total.add(soFar);
            monthly = monthly.add(perMonth);
        }
        return t.total("holdingCostRatePercent", rate).total("holdingCostSoFar", total).total("holdingCostPerMonth", monthly);
    }

    /** Turnover per product over the last 365 days: outward quantity / current stock, and days of stock left. */
    public ReportTable turnover(Long warehouseId) {
        List<CurrentStockRow> current = rows(warehouseId);
        Map<Long, CurrentStockRow> byStock = current.stream().collect(Collectors.toMap(CurrentStockRow::warehouseStockId, Function.identity()));
        Map<Long, BigDecimal> outByProduct = new HashMap<>();
        OffsetDateTime since = OffsetDateTime.now().minusDays(365);
        Map<Long, String> direction = directions();
        for (InventoryMovement m : movements.findAll()) {
            CurrentStockRow r = byStock.get(m.getWarehouseStockId());
            if (r == null || r.productId() == null || m.getMovementDate() == null || m.getMovementDate().isBefore(since)) {
                continue;
            }
            if (StockLedgerService.OUT.equals(direction.get(m.getMovementTypeId()))) {
                outByProduct.merge(r.productId(), m.getQuantity(), BigDecimal::add);
            }
        }
        Map<Long, BigDecimal> stockByProduct = new LinkedHashMap<>();
        Map<Long, String> nameByProduct = new HashMap<>();
        for (CurrentStockRow r : current) {
            if (r.productId() != null) {
                stockByProduct.merge(r.productId(), r.quantity(), BigDecimal::add);
                nameByProduct.put(r.productId(), r.productName());
            }
        }
        ReportTable t = ReportTable.of("Inventory turnover", List.of("productId", "productName", "outwardQuantity365Days",
                "currentStock", "turnoverRatio", "daysOfStock"));
        stockByProduct.forEach((pid, qty) -> {
            BigDecimal out = outByProduct.getOrDefault(pid, BigDecimal.ZERO);
            BigDecimal ratio = qty.signum() == 0 ? null : out.divide(qty, 2, RoundingMode.HALF_UP);
            BigDecimal days = out.signum() == 0 ? null : qty.multiply(DAYS_IN_YEAR).divide(out, 0, RoundingMode.HALF_UP);
            t.row(pid, nameByProduct.get(pid), out, qty, ratio, days);
        });
        return t;
    }

    /** Stock rows with no outward movement for inventory.slow.moving.days (and held at least that long). */
    public ReportTable slowMoving(Long warehouseId) {
        int days = config.integer(SystemConfigService.SLOW_MOVING_DAYS, 60);
        OffsetDateTime limit = OffsetDateTime.now().minusDays(days);
        Map<Long, String> direction = directions();
        Map<Long, OffsetDateTime> lastOut = new HashMap<>();
        for (InventoryMovement m : movements.findAll()) {
            if (StockLedgerService.OUT.equals(direction.get(m.getMovementTypeId())) && m.getMovementDate() != null) {
                lastOut.merge(m.getWarehouseStockId(), m.getMovementDate(), (a, b) -> a.isAfter(b) ? a : b);
            }
        }
        ReportTable t = ReportTable.of("Slow-moving stock", List.of("warehouseStockId", "warehouseName", "productName", "batchNumber",
                "quantity", "stockValue", "daysHeld", "lastOutwardMovement"));
        BigDecimal value = BigDecimal.ZERO;
        for (CurrentStockRow r : rows(warehouseId)) {
            OffsetDateTime last = lastOut.get(r.warehouseStockId());
            boolean heldLong = r.ageDays() != null && r.ageDays() >= days;
            if (heldLong && (last == null || last.isBefore(limit))) {
                t.row(r.warehouseStockId(), r.warehouseName(), r.productName(), r.batchNumber(), r.quantity(), r.stockValue(),
                        r.ageDays(), last == null ? "never" : last.toLocalDate().toString());
                value = value.add(nz(r.stockValue()));
            }
        }
        return t.total("slowMovingDays", days).total("stockValue", value);
    }

    /** Money tied up in stock per warehouse: sellable, near expiry, expired / blocked. */
    public ReportTable workingCapital() {
        Map<String, BigDecimal[]> byWarehouse = new LinkedHashMap<>();
        for (CurrentStockRow r : rows(null)) {
            BigDecimal[] v = byWarehouse.computeIfAbsent(r.warehouseName() == null ? "warehouse " + r.warehouseId() : r.warehouseName(),
                    k -> new BigDecimal[] {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO});
            BigDecimal value = nz(r.stockValue());
            v[0] = v[0].add(value);
            if ("EXPIRED".equals(r.expiryState()) || Boolean.FALSE.equals(r.sellable())) {
                v[3] = v[3].add(value);
            } else if ("NEAR_EXPIRY".equals(r.expiryState())) {
                v[2] = v[2].add(value);
            } else {
                v[1] = v[1].add(value);
            }
        }
        ReportTable t = ReportTable.of("Working capital in stock", List.of("warehouse", "totalValue", "sellableValue",
                "nearExpiryValue", "blockedOrExpiredValue"));
        BigDecimal[] total = {BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO, BigDecimal.ZERO};
        byWarehouse.forEach((w, v) -> {
            t.row(w, v[0], v[1], v[2], v[3]);
            for (int i = 0; i < 4; i++) {
                total[i] = total[i].add(v[i]);
            }
        });
        return t.total("totalValue", total[0]).total("sellableValue", total[1]).total("nearExpiryValue", total[2])
                .total("blockedOrExpiredValue", total[3]);
    }

    /** Pre-sell (already sold, waiting to ship) versus stock-sell (held for future sale). */
    public ReportTable stockTypeSplit(Long warehouseId) {
        Map<String, BigDecimal[]> split = new LinkedHashMap<>();
        split.put("PRE_SELL", new BigDecimal[] {BigDecimal.ZERO, BigDecimal.ZERO});
        split.put("STOCK_SELL", new BigDecimal[] {BigDecimal.ZERO, BigDecimal.ZERO});
        for (CurrentStockRow r : rows(warehouseId)) {
            BigDecimal[] v = split.computeIfAbsent(r.stockType() == null ? "STOCK_SELL" : r.stockType(), k -> new BigDecimal[] {BigDecimal.ZERO, BigDecimal.ZERO});
            v[0] = v[0].add(r.quantity());
            v[1] = v[1].add(nz(r.stockValue()));
        }
        BigDecimal total = split.values().stream().map(v -> v[1]).reduce(BigDecimal.ZERO, BigDecimal::add);
        ReportTable t = ReportTable.of("Pre-sell vs stock-sell", List.of("stockType", "quantity", "stockValue", "valuePercent"));
        split.forEach((k, v) -> t.row(k, v[0], v[1], percent(v[1], total)));
        return t.total("stockValue", total);
    }

    private Map<Long, String> directions() {
        Map<Long, String> out = new HashMap<>();
        for (MovementType t : movementTypes.findAll()) {
            try {
                out.put(t.getMovementTypeId(), StockLedgerService.direction(t.getMovementDirection()));
            } catch (RuntimeException e) {
                // unknown direction text: the movement is ignored in the analytics
            }
        }
        return out;
    }

    private static BigDecimal nz(BigDecimal v) {
        return v == null ? BigDecimal.ZERO : v;
    }

    private static BigDecimal percent(BigDecimal part, BigDecimal total) {
        return total.signum() == 0 ? BigDecimal.ZERO : part.multiply(HUNDRED).divide(total, 2, RoundingMode.HALF_UP);
    }
}

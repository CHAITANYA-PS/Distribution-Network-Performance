package com.example.demo.sales.controller;

import com.example.demo.sales.dto.SalesManagerDTO;
import com.example.demo.sales.entity.SalesManager;
import com.example.demo.sales.service.SalesManagerService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/sales-managers")
public class SalesManagerController {
    private final SalesManagerService service;

    public SalesManagerController(SalesManagerService service) {
        this.service = service;
    }

    @Operation(summary = "Create SalesManager")
    @PostMapping
    public ResponseEntity<SalesManagerDTO> create(@Validated(OnCreate.class) @RequestBody SalesManagerDTO body) {
        SalesManager saved = service.create(DtoMapper.toEntity(body, SalesManager.class));
        return ResponseEntity.created(URI.create("/api/v1/sales-managers/" + saved.getUserId())).body(DtoMapper.toDto(saved, SalesManagerDTO.class));
    }

    @Operation(summary = "Get one SalesManager by id")
    @GetMapping("/{id}")
    public SalesManagerDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), SalesManagerDTO.class);
    }

    @Operation(summary = "List / search SalesManager", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<SalesManagerDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), SalesManagerDTO.class));
        }
        Page<SalesManager> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), SalesManagerDTO.class));
    }

    @Operation(summary = "Update SalesManager (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public SalesManagerDTO update(@PathVariable Long id, @Valid @RequestBody SalesManagerDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, SalesManager.class)), SalesManagerDTO.class);
    }

    @Operation(summary = "Delete SalesManager")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

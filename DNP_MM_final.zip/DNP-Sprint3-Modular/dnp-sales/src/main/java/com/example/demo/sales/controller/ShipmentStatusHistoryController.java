package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ShipmentStatusHistoryDTO;
import com.example.demo.sales.entity.ShipmentStatusHistory;
import com.example.demo.sales.service.ShipmentStatusHistoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** ShipmentStatusHistory API. Read-only: rows are written by the system (workflow actions), never typed in. */
@RestController
@RequestMapping("/api/v1/shipment-status-histories")
public class ShipmentStatusHistoryController {
    private final ShipmentStatusHistoryService service;

    public ShipmentStatusHistoryController(ShipmentStatusHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Get one ShipmentStatusHistory by id")
    @GetMapping("/{id}")
    public ShipmentStatusHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ShipmentStatusHistoryDTO.class);
    }

    @Operation(summary = "List / search ShipmentStatusHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ShipmentStatusHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ShipmentStatusHistoryDTO.class));
        }
        Page<ShipmentStatusHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ShipmentStatusHistoryDTO.class));
    }
}

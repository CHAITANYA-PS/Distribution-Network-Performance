package com.example.demo.sales.controller;

import com.example.demo.sales.dto.WarehouseDTO;
import com.example.demo.sales.entity.Warehouse;
import com.example.demo.sales.service.WarehouseService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/warehouses")
public class WarehouseController {
    private final WarehouseService service;

    public WarehouseController(WarehouseService service) {
        this.service = service;
    }

    @Operation(summary = "Create Warehouse")
    @PostMapping
    public ResponseEntity<WarehouseDTO> create(@Validated(OnCreate.class) @RequestBody WarehouseDTO body) {
        Warehouse saved = service.create(DtoMapper.toEntity(body, Warehouse.class));
        return ResponseEntity.created(URI.create("/api/v1/warehouses/" + saved.getWarehouseId())).body(DtoMapper.toDto(saved, WarehouseDTO.class));
    }

    @Operation(summary = "Get one Warehouse by id")
    @GetMapping("/{id}")
    public WarehouseDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), WarehouseDTO.class);
    }

    @Operation(summary = "List / search Warehouse", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<WarehouseDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), WarehouseDTO.class));
        }
        Page<Warehouse> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), WarehouseDTO.class));
    }

    @Operation(summary = "Update Warehouse (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public WarehouseDTO update(@PathVariable Long id, @Valid @RequestBody WarehouseDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Warehouse.class)), WarehouseDTO.class);
    }

    @Operation(summary = "Delete Warehouse")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

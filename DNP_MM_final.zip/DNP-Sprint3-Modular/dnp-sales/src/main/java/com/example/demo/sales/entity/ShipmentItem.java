package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import com.example.demo.systemadmin.entity.CreateDefault; import jakarta.validation.constraints.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="shipment_item",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ShipmentItem implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="shipment_item_id")
 private Long shipmentItemId;
 @Column(name="shipment_id")
 private Long shipmentId;
 @Column(name="order_item_id")
 private Long orderItemId;
 @Column(name="quantity")
 private BigDecimal quantity;
 // ---- V4 columns
 @Column(name="product_batch_id")
 private Long productBatchId;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @PositiveOrZero(message="Verified quantity must be 0 or greater")
 @Column(name="verified_quantity")
 private BigDecimal verifiedQuantity;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("PENDING")
 @Size(max=20, message="Verification status must be at most 20 characters")
 @Pattern(regexp="PENDING|VERIFIED|MISMATCH", message="Verification status must be one of: PENDING, VERIFIED, MISMATCH")
 @Column(name="verification_status")
 private String verificationStatus;
}
package com.example.demo.sales.controller;

import com.example.demo.sales.dto.InventoryAlertDTO;
import com.example.demo.sales.entity.InventoryAlert;
import com.example.demo.sales.service.InventoryAlertService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory-alerts")
public class InventoryAlertController {
    private final InventoryAlertService service;

    public InventoryAlertController(InventoryAlertService service) {
        this.service = service;
    }

    @Operation(summary = "Create InventoryAlert")
    @PostMapping
    public ResponseEntity<InventoryAlertDTO> create(@Validated(OnCreate.class) @RequestBody InventoryAlertDTO body) {
        InventoryAlert saved = service.create(DtoMapper.toEntity(body, InventoryAlert.class));
        return ResponseEntity.created(URI.create("/api/v1/inventory-alerts/" + saved.getAlertId())).body(DtoMapper.toDto(saved, InventoryAlertDTO.class));
    }

    @Operation(summary = "Get one InventoryAlert by id")
    @GetMapping("/{id}")
    public InventoryAlertDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), InventoryAlertDTO.class);
    }

    @Operation(summary = "List / search InventoryAlert", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<InventoryAlertDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), InventoryAlertDTO.class));
        }
        Page<InventoryAlert> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), InventoryAlertDTO.class));
    }

    @Operation(summary = "Update InventoryAlert (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public InventoryAlertDTO update(@PathVariable Long id, @Valid @RequestBody InventoryAlertDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, InventoryAlert.class)), InventoryAlertDTO.class);
    }

    @Operation(summary = "Delete InventoryAlert")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="order_status_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class OrderStatusHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="order_status_history_id")
 private Long orderStatusHistoryId;
 @Column(name="order_id")
 private Long orderId;
 @Column(name="order_status_id")
 private Long orderStatusId;
 @Column(name="changed_by")
 private Long changedBy;
 @Column(name="remarks")
 private String remarks;
 @Column(name="changed_at")
 private OffsetDateTime changedAt;
}
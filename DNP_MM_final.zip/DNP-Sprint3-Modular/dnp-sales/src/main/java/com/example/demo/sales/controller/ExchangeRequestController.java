package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ExchangeRequestDTO;
import com.example.demo.sales.entity.ExchangeRequest;
import com.example.demo.sales.service.ExchangeRequestService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/exchange-requests")
public class ExchangeRequestController {
    private final ExchangeRequestService service;

    public ExchangeRequestController(ExchangeRequestService service) {
        this.service = service;
    }

    @Operation(summary = "Create ExchangeRequest")
    @PostMapping
    public ResponseEntity<ExchangeRequestDTO> create(@Validated(OnCreate.class) @RequestBody ExchangeRequestDTO body) {
        ExchangeRequest saved = service.create(DtoMapper.toEntity(body, ExchangeRequest.class));
        return ResponseEntity.created(URI.create("/api/v1/exchange-requests/" + saved.getExchangeId())).body(DtoMapper.toDto(saved, ExchangeRequestDTO.class));
    }

    @Operation(summary = "Get one ExchangeRequest by id")
    @GetMapping("/{id}")
    public ExchangeRequestDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ExchangeRequestDTO.class);
    }

    @Operation(summary = "List / search ExchangeRequest", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ExchangeRequestDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ExchangeRequestDTO.class));
        }
        Page<ExchangeRequest> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ExchangeRequestDTO.class));
    }

    @Operation(summary = "Update ExchangeRequest (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ExchangeRequestDTO update(@PathVariable Long id, @Valid @RequestBody ExchangeRequestDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ExchangeRequest.class)), ExchangeRequestDTO.class);
    }

    @Operation(summary = "Delete ExchangeRequest")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

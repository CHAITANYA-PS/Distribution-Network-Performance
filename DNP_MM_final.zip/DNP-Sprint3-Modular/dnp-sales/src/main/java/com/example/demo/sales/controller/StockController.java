package com.example.demo.sales.controller;

import com.example.demo.sales.dto.CurrentStockRow;
import com.example.demo.sales.service.CurrentStockService;
import com.example.demo.systemadmin.controller.ExportController;
import com.example.demo.systemadmin.service.ExportService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

/** Current stock with filters, totals, and Excel/PDF/CSV download. */
@RestController
@RequestMapping("/api/v1/stocks")
public class StockController {
    private final CurrentStockService service;
    private final ExportService export;

    public StockController(CurrentStockService service, ExportService export) {
        this.service = service;
        this.export = export;
    }

    @Operation(summary = "Current stock", description = "Filters are optional. expiryState = OK, NEAR_EXPIRY, EXPIRED. "
            + "Empty rows are hidden unless includeEmpty=true. Add format=xlsx|pdf|csv to download.")
    @GetMapping("/current")
    public ResponseEntity<?> current(@RequestParam(required = false) Long warehouseId, @RequestParam(required = false) Long productId,
            @RequestParam(required = false) Long distributorId, @RequestParam(required = false) Boolean sellable,
            @RequestParam(required = false) String expiryState, @RequestParam(required = false) Boolean belowReorderLevel,
            @RequestParam(required = false) Boolean includeEmpty, @RequestParam(required = false) String format) {
        List<CurrentStockRow> rows = service.current(new CurrentStockService.Filter(warehouseId, productId, distributorId, sellable,
                expiryState, belowReorderLevel, includeEmpty));
        if (format == null || format.isBlank()) {
            return ResponseEntity.ok(rows);
        }
        List<String> headers = Arrays.stream(CurrentStockRow.class.getRecordComponents()).map(c -> c.getName()).toList();
        List<List<Object>> table = new ArrayList<>();
        for (CurrentStockRow r : rows) {
            List<Object> line = new ArrayList<>();
            for (var c : CurrentStockRow.class.getRecordComponents()) {
                try {
                    Object v = c.getAccessor().invoke(r);
                    line.add(v == null || v instanceof Number || v instanceof Boolean ? v : String.valueOf(v));
                } catch (ReflectiveOperationException e) {
                    line.add(null);
                }
            }
            table.add(line);
        }
        ExportService.ExportFile file = export.render("Current stock", format, headers, table);
        export.recordReport("CurrentStock", file);
        return ExportController.download(file);
    }

    @Operation(summary = "Stock totals per product (groupBy=product) or per warehouse (groupBy=warehouse)")
    @GetMapping("/summary")
    public List<Map<String, Object>> summary(@RequestParam(defaultValue = "product") String groupBy,
            @RequestParam(required = false) Long warehouseId, @RequestParam(required = false) Long distributorId) {
        return service.summary(groupBy, new CurrentStockService.Filter(warehouseId, null, distributorId, null, null, null, false));
    }
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.NotificationTypeDTO;
import com.example.demo.sales.entity.NotificationType;
import com.example.demo.sales.service.NotificationTypeService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/notification-types")
public class NotificationTypeController {
    private final NotificationTypeService service;

    public NotificationTypeController(NotificationTypeService service) {
        this.service = service;
    }

    @Operation(summary = "Create NotificationType")
    @PostMapping
    public ResponseEntity<NotificationTypeDTO> create(@Validated(OnCreate.class) @RequestBody NotificationTypeDTO body) {
        NotificationType saved = service.create(DtoMapper.toEntity(body, NotificationType.class));
        return ResponseEntity.created(URI.create("/api/v1/notification-types/" + saved.getNotificationTypeId())).body(DtoMapper.toDto(saved, NotificationTypeDTO.class));
    }

    @Operation(summary = "Get one NotificationType by id")
    @GetMapping("/{id}")
    public NotificationTypeDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), NotificationTypeDTO.class);
    }

    @Operation(summary = "List / search NotificationType", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<NotificationTypeDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), NotificationTypeDTO.class));
        }
        Page<NotificationType> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), NotificationTypeDTO.class));
    }

    @Operation(summary = "Update NotificationType (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public NotificationTypeDTO update(@PathVariable Long id, @Valid @RequestBody NotificationTypeDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, NotificationType.class)), NotificationTypeDTO.class);
    }

    @Operation(summary = "Delete NotificationType")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

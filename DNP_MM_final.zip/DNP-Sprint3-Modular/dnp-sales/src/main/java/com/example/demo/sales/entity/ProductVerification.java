package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Product verification before dispatch (product code + batch + quantity typed/pasted by the packer) (table dsphere.product_verification, added in V4). */
@Entity @Table(name="product_verification",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ProductVerification implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="verification_id")
 private Long verificationId;
 @NotNull(groups=OnCreate.class, message="Shipment item id is required")
 @Column(name="shipment_item_id")
 private Long shipmentItemId;
 @NotBlank(groups=OnCreate.class, message="Entered code is required")
 @Size(max=13, message="Entered code must be at most 13 characters")
 @Column(name="entered_code")
 private String enteredCode;
 @Size(max=100, message="Entered batch number must be at most 100 characters")
 @Column(name="entered_batch_number")
 private String enteredBatchNumber;
 @NotNull(groups=OnCreate.class, message="Entered quantity is required")
 @Positive(message="Entered quantity must be greater than 0")
 @Column(name="entered_quantity")
 private BigDecimal enteredQuantity;
 @NotBlank(groups=OnCreate.class, message="Result is required")
 @Size(max=20, message="Result must be at most 20 characters")
 @Pattern(regexp="MATCH|MISMATCH", message="Result must be one of: MATCH, MISMATCH")
 @Column(name="result")
 private String result;
 @Size(max=500, message="Message must be at most 500 characters")
 @Column(name="message", length=500)
 private String message;
 @Column(name="verified_by")
 private Long verifiedBy;
 @Column(name="verified_at")
 private OffsetDateTime verifiedAt;
}

package com.example.demo.sales.repository;

import com.example.demo.sales.entity.SalesRecord;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface SalesRecordRepository extends JpaRepository<SalesRecord, Long> {
    List<SalesRecord> findBySaleDateBetween(java.time.LocalDate from, java.time.LocalDate to);
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.InventoryDocumentDTO;
import com.example.demo.sales.entity.InventoryDocument;
import com.example.demo.sales.service.InventoryDocumentService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory-documents")
public class InventoryDocumentController {
    private final InventoryDocumentService service;

    public InventoryDocumentController(InventoryDocumentService service) {
        this.service = service;
    }

    @Operation(summary = "Create InventoryDocument")
    @PostMapping
    public ResponseEntity<InventoryDocumentDTO> create(@Validated(OnCreate.class) @RequestBody InventoryDocumentDTO body) {
        InventoryDocument saved = service.create(DtoMapper.toEntity(body, InventoryDocument.class));
        return ResponseEntity.created(URI.create("/api/v1/inventory-documents/" + saved.getInventoryDocumentId())).body(DtoMapper.toDto(saved, InventoryDocumentDTO.class));
    }

    @Operation(summary = "Get one InventoryDocument by id")
    @GetMapping("/{id}")
    public InventoryDocumentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), InventoryDocumentDTO.class);
    }

    @Operation(summary = "List / search InventoryDocument", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<InventoryDocumentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), InventoryDocumentDTO.class));
        }
        Page<InventoryDocument> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), InventoryDocumentDTO.class));
    }

    @Operation(summary = "Update InventoryDocument (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public InventoryDocumentDTO update(@PathVariable Long id, @Valid @RequestBody InventoryDocumentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, InventoryDocument.class)), InventoryDocumentDTO.class);
    }

    @Operation(summary = "Delete InventoryDocument")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

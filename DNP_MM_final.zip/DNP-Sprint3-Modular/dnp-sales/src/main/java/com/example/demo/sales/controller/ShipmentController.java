package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ShipmentDTO;
import com.example.demo.sales.entity.Shipment;
import com.example.demo.sales.service.ShipmentService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/shipments")
public class ShipmentController {
    private final ShipmentService service;

    public ShipmentController(ShipmentService service) {
        this.service = service;
    }

    @Operation(summary = "Create Shipment")
    @PostMapping
    public ResponseEntity<ShipmentDTO> create(@Validated(OnCreate.class) @RequestBody ShipmentDTO body) {
        Shipment saved = service.create(DtoMapper.toEntity(body, Shipment.class));
        return ResponseEntity.created(URI.create("/api/v1/shipments/" + saved.getShipmentId())).body(DtoMapper.toDto(saved, ShipmentDTO.class));
    }

    @Operation(summary = "Get one Shipment by id")
    @GetMapping("/{id}")
    public ShipmentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ShipmentDTO.class);
    }

    @Operation(summary = "List / search Shipment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ShipmentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ShipmentDTO.class));
        }
        Page<Shipment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ShipmentDTO.class));
    }

    @Operation(summary = "Update Shipment (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ShipmentDTO update(@PathVariable Long id, @Valid @RequestBody ShipmentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Shipment.class)), ShipmentDTO.class);
    }

    @Operation(summary = "Delete Shipment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.sales.controller;

import com.example.demo.sales.service.InventoryAnalyticsService;
import com.example.demo.systemadmin.controller.ExportController;
import com.example.demo.systemadmin.service.ExportService;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

/** Inventory analytics. Every report is JSON by default, or a file with format=xlsx|pdf|csv. */
@RestController
@RequestMapping("/api/v1/inventory-analytics")
public class InventoryAnalyticsController {
    private final InventoryAnalyticsService service;
    private final ExportService export;

    public InventoryAnalyticsController(InventoryAnalyticsService service, ExportService export) {
        this.service = service;
        this.export = export;
    }

    @Operation(summary = "Stock aging buckets")
    @GetMapping("/aging")
    public ResponseEntity<?> aging(@RequestParam(required = false) Long warehouseId, @RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, service.aging(warehouseId), format);
    }

    @Operation(summary = "Holding cost of the stock")
    @GetMapping("/holding-cost")
    public ResponseEntity<?> holdingCost(@RequestParam(required = false) Long warehouseId, @RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, service.holdingCost(warehouseId), format);
    }

    @Operation(summary = "Inventory turnover per product (last 365 days)")
    @GetMapping("/turnover")
    public ResponseEntity<?> turnover(@RequestParam(required = false) Long warehouseId, @RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, service.turnover(warehouseId), format);
    }

    @Operation(summary = "Slow-moving stock")
    @GetMapping("/slow-moving")
    public ResponseEntity<?> slowMoving(@RequestParam(required = false) Long warehouseId, @RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, service.slowMoving(warehouseId), format);
    }

    @Operation(summary = "Working capital tied up in stock, per warehouse")
    @GetMapping("/working-capital")
    public ResponseEntity<?> workingCapital(@RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, service.workingCapital(), format);
    }

    @Operation(summary = "Pre-sell vs stock-sell split")
    @GetMapping("/stock-type")
    public ResponseEntity<?> stockType(@RequestParam(required = false) Long warehouseId, @RequestParam(required = false) String format) {
        return ExportController.reportOrFile(export, service.stockTypeSplit(warehouseId), format);
    }
}

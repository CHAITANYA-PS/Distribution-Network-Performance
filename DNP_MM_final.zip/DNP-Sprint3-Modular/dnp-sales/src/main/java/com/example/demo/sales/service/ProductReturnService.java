package com.example.demo.sales.service;

import com.example.demo.sales.entity.ProductReturn;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.ProductReturnRepository;
import com.example.demo.sales.repository.ReturnCategoryRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;

/**
 * Returns of expired / near-expiry / damaged / recalled stock (categories R1-R4) to the manufacturer's warehouse.
 * Flow: REQUESTED -> APPROVED (manufacturer picks the target warehouse) -> IN_TRANSIT (stock leaves the
 * distributor) -> RECEIVED (stock arrives, blocked from sale). REQUESTED or APPROVED can be REJECTED.
 */
@Service
public class ProductReturnService extends AbstractCrudService<ProductReturn, Long> {
    public static final List<String> OPEN = List.of("REQUESTED", "APPROVED", "IN_TRANSIT");

    private final ProductReturnRepository returns;
    private final WarehouseStockRepository stocks;
    private final ReturnCategoryRepository categories;
    private final StockLedgerService ledger;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public ProductReturnService(ProductReturnRepository repository, WarehouseStockRepository stocks, ReturnCategoryRepository categories,
            StockLedgerService ledger, NotificationGateway notifications, UserRoleResolver users) {
        super(repository, ProductReturn.class);
        this.returns = repository;
        this.stocks = stocks;
        this.categories = categories;
        this.ledger = ledger;
        this.notifications = notifications;
        this.users = users;
    }

    @Override
    protected void beforeCreate(ProductReturn r) {
        WarehouseStock stock = stocks.findById(r.getWarehouseStockId())
                .orElseThrow(() -> new BusinessRuleException("Warehouse stock not found: " + r.getWarehouseStockId()));
        if (!categories.existsById(r.getReturnCategoryId())) {
            throw new BusinessRuleException("Return category not found: " + r.getReturnCategoryId());
        }
        BigDecimal available = stock.getQuantity() == null ? BigDecimal.ZERO : stock.getQuantity();
        if (r.getQuantity().compareTo(available) > 0) {
            throw new BusinessRuleException("Return quantity " + r.getQuantity().stripTrailingZeros().toPlainString()
                    + " is more than the stock " + available.stripTrailingZeros().toPlainString());
        }
        r.setProductBatchId(stock.getProductBatchId());
        r.setDistributorId(stock.getOwnerDistributorId());
        r.setStatus("REQUESTED");
        r.setWarehouseReceivedAt(null);
    }

    @Override
    protected void afterCreate(ProductReturn saved) {
        saved.setReturnNumber(LookupSupport.reference("RET", saved.getProductReturnId()));
        returns.save(saved);
        notifications.notify(users.usersWithRole(Roles.MANUFACTURER), "Product return",
                "Return " + saved.getReturnNumber() + " requested for " + saved.getQuantity().stripTrailingZeros().toPlainString()
                        + " unit(s) of stock " + saved.getWarehouseStockId() + "; please approve it");
    }

    @Override
    protected void beforeUpdate(Long id, ProductReturn r, ProductReturn existing) {
        if (!"REQUESTED".equals(existing.getStatus())) {
            throw new BusinessRuleException("Only a REQUESTED return can be edited (this one is " + existing.getStatus() + ")");
        }
        r.setWarehouseStockId(existing.getWarehouseStockId());
    }

    @Override
    protected void beforeDelete(ProductReturn existing) {
        if (!"REQUESTED".equals(existing.getStatus()) && !"REJECTED".equals(existing.getStatus())) {
            throw new BusinessRuleException("A return that is " + existing.getStatus() + " cannot be deleted");
        }
    }

    public ProductReturn approve(Long id, Long targetWarehouseId, String remarks) {
        ProductReturn r = load(id, "REQUESTED");
        if (targetWarehouseId != null) {
            r.setTargetWarehouseId(targetWarehouseId);
        }
        if (r.getTargetWarehouseId() == null) {
            throw new BusinessRuleException("Give the target warehouse (targetWarehouseId) the stock returns to");
        }
        return move(r, "APPROVED", remarks, "approved");
    }

    public ProductReturn reject(Long id, String reason) {
        ProductReturn r = returns.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product return not found: " + id));
        if (!"REQUESTED".equals(r.getStatus()) && !"APPROVED".equals(r.getStatus())) {
            throw new BusinessRuleException("Only a REQUESTED or APPROVED return can be rejected (this one is " + r.getStatus() + ")");
        }
        r.setReason(reason);
        return move(r, "REJECTED", reason, "rejected");
    }

    /** The stock leaves the distributor / source warehouse. */
    public ProductReturn ship(Long id) {
        ProductReturn r = load(id, "APPROVED");
        ledger.post(r.getWarehouseStockId(), StockLedgerService.OUT, r.getQuantity(), "Return dispatch", "RTN");
        return move(r, "IN_TRANSIT", null, "shipped");
    }

    /** The stock arrives at the target warehouse; it is kept as not sellable. */
    public ProductReturn receive(Long id) {
        ProductReturn r = load(id, "IN_TRANSIT");
        WarehouseStock target = ledger.findOrCreate(r.getTargetWarehouseId(), r.getProductBatchId(), null, false);
        ledger.post(target.getWarehouseStockId(), StockLedgerService.IN, r.getQuantity(), "Return receipt", "RTR");
        r.setWarehouseReceivedAt(OffsetDateTime.now());
        return move(r, "RECEIVED", null, "received at the warehouse");
    }

    /** True when the stock row already has a return in progress. */
    public boolean hasOpenReturn(Long warehouseStockId) {
        return returns.existsByWarehouseStockIdAndStatusIn(warehouseStockId, OPEN);
    }

    private ProductReturn load(Long id, String expected) {
        ProductReturn r = returns.findById(id).orElseThrow(() -> new ResourceNotFoundException("Product return not found: " + id));
        if (CurrentUser.isDistributorOnly() && r.getDistributorId() != null && !r.getDistributorId().equals(CurrentUser.distributorId())) {
            throw new ResourceNotFoundException("Product return not found: " + id);
        }
        if (!expected.equals(r.getStatus())) {
            throw new BusinessRuleException("Return " + nz(r.getReturnNumber(), id) + " is " + r.getStatus() + "; expected " + expected);
        }
        return r;
    }

    private ProductReturn move(ProductReturn r, String status, String remarks, String verb) {
        String old = r.getStatus();
        r.setStatus(status);
        ProductReturn saved = returns.save(r);
        AuditTrail.record("STATUS_CHANGE", "ProductReturn", r.getProductReturnId(), Map.of("status", old),
                remarks == null ? Map.of("status", status) : Map.of("status", status, "remarks", remarks));
        if (r.getDistributorId() != null) {
            notifications.notify(users.usersOfDistributor(r.getDistributorId()), "Product return",
                    "Return " + nz(r.getReturnNumber(), r.getProductReturnId()) + " was " + verb + (remarks == null ? "" : ": " + remarks));
        }
        return saved;
    }

    private static String nz(String s, Long id) {
        return s == null ? String.valueOf(id) : s;
    }
}

package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for ProductReturn. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductReturnDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long productReturnId;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=30, message="Return number must be at most 30 characters")
    private String returnNumber;

    @NotNull(groups=OnCreate.class, message="Warehouse stock id is required")
    private Long warehouseStockId;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long productBatchId;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long distributorId;

    @NotNull(groups=OnCreate.class, message="Return category id is required")
    private Long returnCategoryId;

    private Long targetWarehouseId;

    @NotNull(groups=OnCreate.class, message="Quantity is required")
    @Positive(message="Quantity must be greater than 0")
    private BigDecimal quantity;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=20, message="Status must be at most 20 characters")
    @Pattern(regexp="REQUESTED|APPROVED|IN_TRANSIT|RECEIVED|REJECTED", message="Status must be one of: REQUESTED, APPROVED, IN_TRANSIT, RECEIVED, REJECTED")
    private String status;

    @Size(max=500, message="Reason must be at most 500 characters")
    private String reason;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long requestedBy;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime createdAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime warehouseReceivedAt;
}

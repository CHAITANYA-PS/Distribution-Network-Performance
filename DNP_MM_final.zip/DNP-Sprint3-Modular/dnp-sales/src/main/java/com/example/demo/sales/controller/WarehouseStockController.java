package com.example.demo.sales.controller;

import com.example.demo.sales.dto.WarehouseStockDTO;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.service.WarehouseStockService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/warehouse-stocks")
public class WarehouseStockController {
    private final WarehouseStockService service;

    public WarehouseStockController(WarehouseStockService service) {
        this.service = service;
    }

    @Operation(summary = "Create WarehouseStock")
    @PostMapping
    public ResponseEntity<WarehouseStockDTO> create(@Validated(OnCreate.class) @RequestBody WarehouseStockDTO body) {
        WarehouseStock saved = service.create(DtoMapper.toEntity(body, WarehouseStock.class));
        return ResponseEntity.created(URI.create("/api/v1/warehouse-stocks/" + saved.getWarehouseStockId())).body(DtoMapper.toDto(saved, WarehouseStockDTO.class));
    }

    @Operation(summary = "Get one WarehouseStock by id")
    @GetMapping("/{id}")
    public WarehouseStockDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), WarehouseStockDTO.class);
    }

    @Operation(summary = "List / search WarehouseStock", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<WarehouseStockDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), WarehouseStockDTO.class));
        }
        Page<WarehouseStock> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), WarehouseStockDTO.class));
    }

    @Operation(summary = "Update WarehouseStock (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public WarehouseStockDTO update(@PathVariable Long id, @Valid @RequestBody WarehouseStockDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, WarehouseStock.class)), WarehouseStockDTO.class);
    }

    @Operation(summary = "Delete WarehouseStock")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

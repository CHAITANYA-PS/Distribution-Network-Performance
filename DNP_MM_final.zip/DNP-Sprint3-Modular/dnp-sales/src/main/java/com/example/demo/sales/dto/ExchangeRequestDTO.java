package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for ExchangeRequest. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ExchangeRequestDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long exchangeId;

    private Long distributorId;

    private Long productId;

    private BigDecimal requestedQuantity;

    private String sourceLocation;

    private Long exchangeStatusId;

    private Long requestedBy;

    private OffsetDateTime requestedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=30, message="Request number must be at most 30 characters")
    private String requestNumber;

    private Long sourceWarehouseStockId;

    private Long destinationWarehouseId;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long decidedBy;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime decidedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=500, message="Decision remarks must be at most 500 characters")
    private String decisionRemarks;
}

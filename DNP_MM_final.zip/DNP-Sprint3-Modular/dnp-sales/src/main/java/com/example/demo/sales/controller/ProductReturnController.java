package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ProductReturnDTO;
import com.example.demo.sales.entity.ProductReturn;
import com.example.demo.sales.service.ProductReturnService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** ProductReturn API. Create, read, update, delete. */
@RestController
@RequestMapping("/api/v1/product-returns")
public class ProductReturnController {
    private final ProductReturnService service;

    public ProductReturnController(ProductReturnService service) {
        this.service = service;
    }

    @Operation(summary = "Create ProductReturn")
    @PostMapping
    public ResponseEntity<ProductReturnDTO> create(@Validated(OnCreate.class) @RequestBody ProductReturnDTO body) {
        ProductReturn saved = service.create(DtoMapper.toEntity(body, ProductReturn.class));
        return ResponseEntity.created(URI.create("/api/v1/product-returns/" + saved.getProductReturnId())).body(DtoMapper.toDto(saved, ProductReturnDTO.class));
    }

    @Operation(summary = "Get one ProductReturn by id")
    @GetMapping("/{id}")
    public ProductReturnDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ProductReturnDTO.class);
    }

    @Operation(summary = "List / search ProductReturn", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ProductReturnDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ProductReturnDTO.class));
        }
        Page<ProductReturn> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ProductReturnDTO.class));
    }

    @Operation(summary = "Update ProductReturn (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ProductReturnDTO update(@PathVariable Long id, @Valid @RequestBody ProductReturnDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ProductReturn.class)), ProductReturnDTO.class);
    }

    @Operation(summary = "Delete ProductReturn")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

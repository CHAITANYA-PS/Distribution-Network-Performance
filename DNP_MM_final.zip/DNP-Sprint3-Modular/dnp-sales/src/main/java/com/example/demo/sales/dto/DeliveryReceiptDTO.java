package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for DeliveryReceipt. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DeliveryReceiptDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long deliveryReceiptId;

    @NotNull(groups=OnCreate.class, message="Shipment id is required")
    private Long shipmentId;

    private Long distributorId;

    @NotBlank(groups=OnCreate.class, message="Status is required")
    @Size(max=30, message="Status must be at most 30 characters")
    @Pattern(regexp="CONFIRMED|CONFIRMED_WITH_DISCREPANCY", message="Status must be one of: CONFIRMED, CONFIRMED_WITH_DISCREPANCY")
    private String status;

    private Long receivedBy;

    private OffsetDateTime receivedAt;

    @Size(max=1000, message="Remarks must be at most 1000 characters")
    private String remarks;
}

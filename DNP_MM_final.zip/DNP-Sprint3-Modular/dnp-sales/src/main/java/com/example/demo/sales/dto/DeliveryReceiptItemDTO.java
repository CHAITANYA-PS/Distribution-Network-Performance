package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Request and response body for DeliveryReceiptItem. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DeliveryReceiptItemDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long deliveryReceiptItemId;

    @NotNull(groups=OnCreate.class, message="Delivery receipt id is required")
    private Long deliveryReceiptId;

    @NotNull(groups=OnCreate.class, message="Shipment item id is required")
    private Long shipmentItemId;

    @NotNull(groups=OnCreate.class, message="Expected quantity is required")
    @PositiveOrZero(message="Expected quantity must be 0 or greater")
    private BigDecimal expectedQuantity;

    @NotNull(groups=OnCreate.class, message="Received quantity is required")
    @PositiveOrZero(message="Received quantity must be 0 or greater")
    private BigDecimal receivedQuantity;

    @PositiveOrZero(message="Damaged quantity must be 0 or greater")
    private BigDecimal damagedQuantity;
}

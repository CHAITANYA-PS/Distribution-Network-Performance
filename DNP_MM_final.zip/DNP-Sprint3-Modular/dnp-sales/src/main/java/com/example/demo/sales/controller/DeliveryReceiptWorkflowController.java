package com.example.demo.sales.controller;

import com.example.demo.sales.dto.DeliveryDiscrepancyDTO;
import com.example.demo.sales.dto.DeliveryReceiptDTO;
import com.example.demo.sales.dto.DeliveryReceiptItemDTO;
import com.example.demo.sales.dto.WorkflowRequests;
import com.example.demo.sales.entity.DeliveryDiscrepancy;
import com.example.demo.sales.entity.DeliveryReceipt;
import com.example.demo.sales.entity.DeliveryReceiptItem;
import com.example.demo.sales.service.ShipmentWorkflowService;
import com.example.demo.systemadmin.dto.DtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/** Distributor confirms a delivery with the handover code; differences become discrepancies with tickets. */
@RestController
@RequestMapping("/api/v1/delivery-receipts")
public class DeliveryReceiptWorkflowController {
    private final ShipmentWorkflowService service;

    public DeliveryReceiptWorkflowController(ShipmentWorkflowService service) {
        this.service = service;
    }

    /** Receipt with its lines and discrepancies. */
    public record ReceiptView(DeliveryReceiptDTO receipt, List<DeliveryReceiptItemDTO> items, List<DeliveryDiscrepancyDTO> discrepancies) {
    }

    @Operation(summary = "Confirm a delivery", description = "handoverCode = the 6 digits on the delivery note. items is optional: "
            + "lines left out count as fully received. Shortage / excess / damaged lines become discrepancies with a ticket each.")
    @PostMapping("/{shipmentId}/confirm")
    @ResponseStatus(HttpStatus.CREATED)
    public ReceiptView confirm(@PathVariable Long shipmentId, @Valid @RequestBody WorkflowRequests.ConfirmDelivery body) {
        ShipmentWorkflowService.ReceiptResult r = service.confirmDelivery(shipmentId, body);
        return new ReceiptView(DtoMapper.toDto(r.receipt(), DeliveryReceiptDTO.class),
                DtoMapper.toDtoList(r.items(), DeliveryReceiptItemDTO.class),
                DtoMapper.toDtoList(r.discrepancies(), DeliveryDiscrepancyDTO.class));
    }

    @Operation(summary = "Delivery receipt of a shipment, with lines and discrepancies")
    @GetMapping("/by-shipment/{shipmentId}")
    @SuppressWarnings("unchecked")
    public ReceiptView byShipment(@PathVariable Long shipmentId) {
        Map<String, Object> d = service.receiptDetails(shipmentId);
        return new ReceiptView(DtoMapper.toDto((DeliveryReceipt) d.get("receipt"), DeliveryReceiptDTO.class),
                DtoMapper.toDtoList((List<DeliveryReceiptItem>) d.get("items"), DeliveryReceiptItemDTO.class),
                DtoMapper.toDtoList((List<DeliveryDiscrepancy>) d.get("discrepancies"), DeliveryDiscrepancyDTO.class));
    }
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.InventoryMovementDTO;
import com.example.demo.sales.entity.InventoryMovement;
import com.example.demo.sales.service.InventoryMovementService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory-movements")
public class InventoryMovementController {
    private final InventoryMovementService service;

    public InventoryMovementController(InventoryMovementService service) {
        this.service = service;
    }

    @Operation(summary = "Create InventoryMovement")
    @PostMapping
    public ResponseEntity<InventoryMovementDTO> create(@Validated(OnCreate.class) @RequestBody InventoryMovementDTO body) {
        InventoryMovement saved = service.create(DtoMapper.toEntity(body, InventoryMovement.class));
        return ResponseEntity.created(URI.create("/api/v1/inventory-movements/" + saved.getMovementId())).body(DtoMapper.toDto(saved, InventoryMovementDTO.class));
    }

    @Operation(summary = "Get one InventoryMovement by id")
    @GetMapping("/{id}")
    public InventoryMovementDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), InventoryMovementDTO.class);
    }

    @Operation(summary = "List / search InventoryMovement", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<InventoryMovementDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), InventoryMovementDTO.class));
        }
        Page<InventoryMovement> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), InventoryMovementDTO.class));
    }

    @Operation(summary = "Update InventoryMovement (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public InventoryMovementDTO update(@PathVariable Long id, @Valid @RequestBody InventoryMovementDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, InventoryMovement.class)), InventoryMovementDTO.class);
    }

    @Operation(summary = "Delete InventoryMovement")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

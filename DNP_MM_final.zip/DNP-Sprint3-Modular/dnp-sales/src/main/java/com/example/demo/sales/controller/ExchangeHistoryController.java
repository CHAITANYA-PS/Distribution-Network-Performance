package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ExchangeHistoryDTO;
import com.example.demo.sales.entity.ExchangeHistory;
import com.example.demo.sales.service.ExchangeHistoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/exchange-histories")
public class ExchangeHistoryController {
    private final ExchangeHistoryService service;

    public ExchangeHistoryController(ExchangeHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create ExchangeHistory")
    @PostMapping
    public ResponseEntity<ExchangeHistoryDTO> create(@Validated(OnCreate.class) @RequestBody ExchangeHistoryDTO body) {
        ExchangeHistory saved = service.create(DtoMapper.toEntity(body, ExchangeHistory.class));
        return ResponseEntity.created(URI.create("/api/v1/exchange-histories/" + saved.getExchangeHistoryId())).body(DtoMapper.toDto(saved, ExchangeHistoryDTO.class));
    }

    @Operation(summary = "Get one ExchangeHistory by id")
    @GetMapping("/{id}")
    public ExchangeHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ExchangeHistoryDTO.class);
    }

    @Operation(summary = "List / search ExchangeHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ExchangeHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ExchangeHistoryDTO.class));
        }
        Page<ExchangeHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ExchangeHistoryDTO.class));
    }

    @Operation(summary = "Update ExchangeHistory (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ExchangeHistoryDTO update(@PathVariable Long id, @Valid @RequestBody ExchangeHistoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ExchangeHistory.class)), ExchangeHistoryDTO.class);
    }

    @Operation(summary = "Delete ExchangeHistory")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

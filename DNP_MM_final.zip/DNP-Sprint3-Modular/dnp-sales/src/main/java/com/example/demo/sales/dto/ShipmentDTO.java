package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;

/**
 * Request and response body for Shipment. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ShipmentDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long shipmentId;

    private String trackingNumber;

    private Long warehouseId;

    private Long shipmentStatusId;

    private LocalDate dispatchDate;

    private LocalDate deliveryDate;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long dispatchedBy;
}

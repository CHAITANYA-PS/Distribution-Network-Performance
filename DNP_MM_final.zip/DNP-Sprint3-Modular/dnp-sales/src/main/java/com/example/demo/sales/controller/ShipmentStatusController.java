package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ShipmentStatusDTO;
import com.example.demo.sales.entity.ShipmentStatus;
import com.example.demo.sales.service.ShipmentStatusService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/shipment-statuses")
public class ShipmentStatusController {
    private final ShipmentStatusService service;

    public ShipmentStatusController(ShipmentStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create ShipmentStatus")
    @PostMapping
    public ResponseEntity<ShipmentStatusDTO> create(@Validated(OnCreate.class) @RequestBody ShipmentStatusDTO body) {
        ShipmentStatus saved = service.create(DtoMapper.toEntity(body, ShipmentStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/shipment-statuses/" + saved.getShipmentStatusId())).body(DtoMapper.toDto(saved, ShipmentStatusDTO.class));
    }

    @Operation(summary = "Get one ShipmentStatus by id")
    @GetMapping("/{id}")
    public ShipmentStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ShipmentStatusDTO.class);
    }

    @Operation(summary = "List / search ShipmentStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ShipmentStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ShipmentStatusDTO.class));
        }
        Page<ShipmentStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ShipmentStatusDTO.class));
    }

    @Operation(summary = "Update ShipmentStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ShipmentStatusDTO update(@PathVariable Long id, @Valid @RequestBody ShipmentStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ShipmentStatus.class)), ShipmentStatusDTO.class);
    }

    @Operation(summary = "Delete ShipmentStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

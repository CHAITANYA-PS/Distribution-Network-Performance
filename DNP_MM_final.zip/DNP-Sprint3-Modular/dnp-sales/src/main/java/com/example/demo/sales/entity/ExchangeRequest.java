package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="exchange_request",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ExchangeRequest implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="exchange_id")
 private Long exchangeId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="product_id")
 private Long productId;
 @Column(name="requested_quantity")
 private BigDecimal requestedQuantity;
 @Column(name="source_location")
 private String sourceLocation;
 @Column(name="exchange_status_id")
 private Long exchangeStatusId;
 @Column(name="requested_by")
 private Long requestedBy;
 @Column(name="requested_at")
 private OffsetDateTime requestedAt;
 // ---- V4 columns
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=30, message="Request number must be at most 30 characters")
 @Column(name="request_number")
 private String requestNumber;
 @Column(name="source_warehouse_stock_id")
 private Long sourceWarehouseStockId;
 @Column(name="destination_warehouse_id")
 private Long destinationWarehouseId;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="decided_by")
 private Long decidedBy;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="decided_at")
 private OffsetDateTime decidedAt;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=500, message="Decision remarks must be at most 500 characters")
 @Column(name="decision_remarks", length=500)
 private String decisionRemarks;
}
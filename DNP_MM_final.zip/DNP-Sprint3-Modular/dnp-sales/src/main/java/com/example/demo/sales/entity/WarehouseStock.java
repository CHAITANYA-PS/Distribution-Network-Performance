package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import java.time.OffsetDateTime; import com.example.demo.systemadmin.entity.CreateDefault; import jakarta.validation.constraints.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="warehouse_stock",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class WarehouseStock implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @Column(name="warehouse_id")
 private Long warehouseId;
 @Column(name="product_batch_id")
 private Long productBatchId;
 @Column(name="owner_distributor_id")
 private Long ownerDistributorId;
 @Column(name="reorder_level")
 private BigDecimal reorderLevel;
 // ---- V4 columns
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("0")
 @PositiveOrZero(message="Quantity must be 0 or greater")
 @Column(name="quantity")
 private BigDecimal quantity;
 @CreateDefault("true")
 @Column(name="is_sellable")
 private Boolean isSellable;
 @Column(name="received_at")
 private OffsetDateTime receivedAt;
 @CreateDefault("STOCK_SELL")
 @Size(max=10, message="Stock type must be at most 10 characters")
 @Pattern(regexp="PRE_SELL|STOCK_SELL", message="Stock type must be one of: PRE_SELL, STOCK_SELL")
 @Column(name="stock_type")
 private String stockType;
}
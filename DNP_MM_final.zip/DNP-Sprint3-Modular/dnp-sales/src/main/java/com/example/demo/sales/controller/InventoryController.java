package com.example.demo.sales.controller;

import com.example.demo.manufacturer.dto.ProductDTO;
import com.example.demo.manufacturer.entity.Product;
import com.example.demo.manufacturer.service.ProductService;
import com.example.demo.sales.dto.WarehouseStockDTO;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.service.WarehouseStockService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** Inventory: products and warehouse stock. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/inventory")
public class InventoryController {
    private final ProductService productService;
    private final WarehouseStockService warehouseStockService;

    public InventoryController(ProductService productService, WarehouseStockService warehouseStockService) {
        this.productService = productService;
        this.warehouseStockService = warehouseStockService;
    }

    @Operation(summary = "Create Product")
    @PostMapping("/products")
    public ResponseEntity<ProductDTO> createProduct(@Validated(OnCreate.class) @RequestBody ProductDTO body) {
        Product saved = productService.create(DtoMapper.toEntity(body, Product.class));
        return ResponseEntity.created(URI.create("/api/v1/inventory/products/" + saved.getProductId())).body(DtoMapper.toDto(saved, ProductDTO.class));
    }

    @Operation(summary = "List / search Product", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("/products")
    public ResponseEntity<List<ProductDTO>> getAllProduct(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(productService.getAll(), ProductDTO.class));
        }
        Page<Product> result = productService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ProductDTO.class));
    }

    @Operation(summary = "Get one Product by id")
    @GetMapping("/products/{id}")
    public ProductDTO getProduct(@PathVariable Long id) {
        return DtoMapper.toDto(productService.get(id), ProductDTO.class);
    }

    @Operation(summary = "Update Product (send only the fields to change, plus version)")
    @PutMapping("/products/{id}")
    public ProductDTO updateProduct(@PathVariable Long id, @Valid @RequestBody ProductDTO body) {
        return DtoMapper.toDto(productService.update(id, DtoMapper.toEntity(body, Product.class)), ProductDTO.class);
    }

    @Operation(summary = "Delete Product")
    @DeleteMapping("/products/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteProduct(@PathVariable Long id) {
        productService.delete(id);
    }

    @Operation(summary = "Create WarehouseStock")
    @PostMapping("/stocks")
    public ResponseEntity<WarehouseStockDTO> createWarehouseStock(@Validated(OnCreate.class) @RequestBody WarehouseStockDTO body) {
        WarehouseStock saved = warehouseStockService.create(DtoMapper.toEntity(body, WarehouseStock.class));
        return ResponseEntity.created(URI.create("/api/v1/inventory/stocks/" + saved.getWarehouseStockId())).body(DtoMapper.toDto(saved, WarehouseStockDTO.class));
    }

    @Operation(summary = "List / search WarehouseStock", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("/stocks")
    public ResponseEntity<List<WarehouseStockDTO>> getAllWarehouseStock(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(warehouseStockService.getAll(), WarehouseStockDTO.class));
        }
        Page<WarehouseStock> result = warehouseStockService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), WarehouseStockDTO.class));
    }

    @Operation(summary = "Get one WarehouseStock by id")
    @GetMapping("/stocks/{id}")
    public WarehouseStockDTO getWarehouseStock(@PathVariable Long id) {
        return DtoMapper.toDto(warehouseStockService.get(id), WarehouseStockDTO.class);
    }

    @Operation(summary = "Update WarehouseStock (send only the fields to change, plus version)")
    @PutMapping("/stocks/{id}")
    public WarehouseStockDTO updateWarehouseStock(@PathVariable Long id, @Valid @RequestBody WarehouseStockDTO body) {
        return DtoMapper.toDto(warehouseStockService.update(id, DtoMapper.toEntity(body, WarehouseStock.class)), WarehouseStockDTO.class);
    }

    @Operation(summary = "Delete WarehouseStock")
    @DeleteMapping("/stocks/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteWarehouseStock(@PathVariable Long id) {
        warehouseStockService.delete(id);
    }
}

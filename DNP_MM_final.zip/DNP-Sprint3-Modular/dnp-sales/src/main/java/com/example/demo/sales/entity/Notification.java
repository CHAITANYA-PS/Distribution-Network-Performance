package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="notification",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Notification implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="notification_id")
 private Long notificationId;
 @NotNull(groups=OnCreate.class, message="User id is required")
 @Column(name="user_id")
 private Long userId;
 @NotNull(groups=OnCreate.class, message="Notification type id is required")
 @Column(name="notification_type_id")
 private Long notificationTypeId;
 @NotBlank(groups=OnCreate.class, message="Message is required")
 @Column(name="message")
 private String message;
 @CreateDefault("false")
 @Column(name="read_status")
 private Boolean readStatus;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
package com.example.demo.sales.service;

import com.example.demo.manufacturer.entity.Product;
import com.example.demo.manufacturer.entity.ProductBatch;
import com.example.demo.manufacturer.repository.ProductBatchRepository;
import com.example.demo.manufacturer.repository.ProductRepository;
import com.example.demo.sales.dto.CurrentStockRow;
import com.example.demo.sales.entity.Warehouse;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.WarehouseRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Current stock: every stock row joined with its product, batch and warehouse, with expiry state
 * (OK / NEAR_EXPIRY / EXPIRED), age, value and reorder warning. A distributor only sees their own stock.
 */
@Service
@Transactional(readOnly = true)
public class CurrentStockService {
    private final WarehouseStockRepository stocks;
    private final ProductBatchRepository batches;
    private final ProductRepository products;
    private final WarehouseRepository warehouses;
    private final SystemConfigService config;

    public CurrentStockService(WarehouseStockRepository stocks, ProductBatchRepository batches, ProductRepository products,
            WarehouseRepository warehouses, SystemConfigService config) {
        this.stocks = stocks;
        this.batches = batches;
        this.products = products;
        this.warehouses = warehouses;
        this.config = config;
    }

    /** Filter values; null means "any". */
    public record Filter(Long warehouseId, Long productId, Long distributorId, Boolean sellable, String expiryState,
            Boolean belowReorderLevel, Boolean includeEmpty) {
    }

    public List<CurrentStockRow> current(Filter f) {
        int nearDays = config.integer(SystemConfigService.EXPIRY_NEAR_DAYS, 30);
        Map<Long, ProductBatch> batchById = batches.findAll().stream().collect(Collectors.toMap(ProductBatch::getProductBatchId, Function.identity()));
        Map<Long, Product> productById = products.findAll().stream().collect(Collectors.toMap(Product::getProductId, Function.identity()));
        Map<Long, Warehouse> warehouseById = warehouses.findAll().stream().collect(Collectors.toMap(Warehouse::getWarehouseId, Function.identity()));
        Long ownDistributor = CurrentUser.isDistributorOnly() ? CurrentUser.distributorId() : null;
        LocalDate today = LocalDate.now();
        List<CurrentStockRow> out = new ArrayList<>();
        for (WarehouseStock s : stocks.findAll()) {
            if (ownDistributor != null && !ownDistributor.equals(s.getOwnerDistributorId())) {
                continue;
            }
            BigDecimal qty = s.getQuantity() == null ? BigDecimal.ZERO : s.getQuantity();
            ProductBatch b = batchById.get(s.getProductBatchId());
            Product p = b == null ? null : productById.get(b.getProductId());
            Warehouse w = warehouseById.get(s.getWarehouseId());
            LocalDate expiry = b == null ? null : b.getExpiryDate();
            Long days = expiry == null ? null : ChronoUnit.DAYS.between(today, expiry);
            String state = days == null ? "UNKNOWN" : days < 0 ? "EXPIRED" : days <= nearDays ? "NEAR_EXPIRY" : "OK";
            boolean below = s.getReorderLevel() != null && qty.compareTo(s.getReorderLevel()) <= 0;
            BigDecimal cost = p == null ? null : p.getUnitCost();
            OffsetDateTime received = s.getReceivedAt();
            CurrentStockRow row = new CurrentStockRow(s.getWarehouseStockId(), s.getWarehouseId(), w == null ? null : w.getWarehouseName(),
                    p == null ? null : p.getProductId(), p == null ? null : p.getSku(), p == null ? null : p.getProductName(),
                    p == null ? null : p.getProductCode(), s.getProductBatchId(), b == null ? null : b.getBatchNumber(), expiry, days, state,
                    qty, s.getReorderLevel(), below, s.getIsSellable(), s.getStockType(), s.getOwnerDistributorId(), received,
                    received == null ? null : ChronoUnit.DAYS.between(received.toLocalDate(), today),
                    cost, cost == null ? null : cost.multiply(qty));
            if (matches(row, f)) {
                out.add(row);
            }
        }
        out.sort(Comparator.comparing(CurrentStockRow::warehouseStockId));
        return out;
    }

    /** Totals per product or per warehouse ("product" / "warehouse"). */
    public List<Map<String, Object>> summary(String groupBy, Filter f) {
        boolean byWarehouse = "warehouse".equalsIgnoreCase(groupBy);
        Map<Object, Map<String, Object>> groups = new LinkedHashMap<>();
        for (CurrentStockRow r : current(f)) {
            Object key = byWarehouse ? r.warehouseId() : r.productId();
            Map<String, Object> g = groups.computeIfAbsent(key, k -> {
                Map<String, Object> m = new LinkedHashMap<>();
                if (byWarehouse) {
                    m.put("warehouseId", r.warehouseId());
                    m.put("warehouseName", r.warehouseName());
                } else {
                    m.put("productId", r.productId());
                    m.put("sku", r.sku());
                    m.put("productName", r.productName());
                }
                m.put("totalQuantity", BigDecimal.ZERO);
                m.put("sellableQuantity", BigDecimal.ZERO);
                m.put("expiredQuantity", BigDecimal.ZERO);
                m.put("nearExpiryQuantity", BigDecimal.ZERO);
                m.put("stockValue", BigDecimal.ZERO);
                return m;
            });
            add(g, "totalQuantity", r.quantity());
            if (!Boolean.FALSE.equals(r.sellable()) && !"EXPIRED".equals(r.expiryState())) {
                add(g, "sellableQuantity", r.quantity());
            }
            if ("EXPIRED".equals(r.expiryState())) {
                add(g, "expiredQuantity", r.quantity());
            }
            if ("NEAR_EXPIRY".equals(r.expiryState())) {
                add(g, "nearExpiryQuantity", r.quantity());
            }
            add(g, "stockValue", r.stockValue());
        }
        return new ArrayList<>(groups.values());
    }

    private static void add(Map<String, Object> g, String key, BigDecimal v) {
        if (v != null) {
            g.put(key, ((BigDecimal) g.get(key)).add(v));
        }
    }

    private static boolean matches(CurrentStockRow r, Filter f) {
        if (f == null) {
            return r.quantity().signum() > 0;
        }
        return (Boolean.TRUE.equals(f.includeEmpty()) || r.quantity().signum() > 0)
                && (f.warehouseId() == null || f.warehouseId().equals(r.warehouseId()))
                && (f.productId() == null || f.productId().equals(r.productId()))
                && (f.distributorId() == null || f.distributorId().equals(r.ownerDistributorId()))
                && (f.sellable() == null || Objects.equals(f.sellable(), r.sellable() == null || r.sellable()))
                && (f.expiryState() == null || f.expiryState().equalsIgnoreCase(r.expiryState()))
                && (f.belowReorderLevel() == null || f.belowReorderLevel() == r.belowReorderLevel());
    }
}

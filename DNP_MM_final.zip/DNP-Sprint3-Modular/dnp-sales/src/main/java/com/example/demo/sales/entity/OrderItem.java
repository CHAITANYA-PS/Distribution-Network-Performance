package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="order_item",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class OrderItem implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="order_item_id")
 private Long orderItemId;
 @NotNull(groups=OnCreate.class, message="Order id is required")
 @Column(name="order_id")
 private Long orderId;
 @NotNull(groups=OnCreate.class, message="Product id is required")
 @Column(name="product_id")
 private Long productId;
 @NotNull(groups=OnCreate.class, message="Quantity is required")
 @Positive(message="Quantity must be greater than 0")
 @Column(name="quantity")
 private BigDecimal quantity;
 @NotNull(groups=OnCreate.class, message="Unit price is required")
 @PositiveOrZero(message="Unit price must be 0 or greater")
 @Column(name="unit_price")
 private BigDecimal unitPrice;
}
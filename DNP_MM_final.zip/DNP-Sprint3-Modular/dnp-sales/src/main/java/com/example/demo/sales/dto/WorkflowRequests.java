package com.example.demo.sales.dto;

import jakarta.validation.Valid;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.Positive;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;
import java.util.List;

/** Request bodies of the warehouse / dispatch / delivery / return / exchange / order actions. */
public final class WorkflowRequests {
    private WorkflowRequests() {
    }

    /** What the packer types or pastes from the pack: 13-digit product code, batch number and counted quantity. */
    public record VerifyItem(
            @NotBlank(message = "Product code is required") @Pattern(regexp = "\\d{13}", message = "Product code must be 13 digits") String productCode,
            @NotBlank(message = "Batch number is required") @Size(max = 100) String batchNumber,
            @NotNull(message = "Quantity is required") @Positive(message = "Quantity must be greater than 0") BigDecimal quantity) {
    }

    public record Remarks(@Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    public record StatusChange(@NotBlank(message = "Status is required") @Size(max = 50) String status,
            @Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    /** One line of a delivery confirmation; lines left out are taken as fully received, nothing damaged. */
    public record ReceivedLine(@NotNull(message = "Shipment item id is required") Long shipmentItemId,
            @NotNull(message = "Received quantity is required") @PositiveOrZero(message = "Received quantity must be 0 or greater") BigDecimal receivedQuantity,
            @PositiveOrZero(message = "Damaged quantity must be 0 or greater") BigDecimal damagedQuantity) {
    }

    public record ConfirmDelivery(
            @NotBlank(message = "Handover code is required") @Pattern(regexp = "\\d{6}", message = "Handover code is 6 digits") String handoverCode,
            Long destinationWarehouseId,
            @Size(max = 1000, message = "Remarks must be at most 1000 characters") String remarks,
            @Valid List<ReceivedLine> items) {
    }

    public record ApproveReturn(Long targetWarehouseId, @Size(max = 500) String remarks) {
    }

    public record ApproveExchange(@NotNull(message = "Source warehouse stock id is required") Long sourceWarehouseStockId,
            @NotNull(message = "Destination warehouse id is required") Long destinationWarehouseId,
            @Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    public record Reason(@NotBlank(message = "Reason is required") @Size(max = 500, message = "Reason must be at most 500 characters") String reason) {
    }
}

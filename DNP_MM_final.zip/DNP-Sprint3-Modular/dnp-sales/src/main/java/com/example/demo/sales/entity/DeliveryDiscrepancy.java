package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Delivery discrepancies (shortage / excess / damaged / wrong product); each opens a ticket (table dsphere.delivery_discrepancy, added in V4). */
@Entity @Table(name="delivery_discrepancy",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DeliveryDiscrepancy implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="discrepancy_id")
 private Long discrepancyId;
 @NotNull(groups=OnCreate.class, message="Delivery receipt id is required")
 @Column(name="delivery_receipt_id")
 private Long deliveryReceiptId;
 @Column(name="shipment_item_id")
 private Long shipmentItemId;
 @NotBlank(groups=OnCreate.class, message="Discrepancy type is required")
 @Size(max=20, message="Discrepancy type must be at most 20 characters")
 @Pattern(regexp="SHORTAGE|EXCESS|DAMAGED|WRONG_PRODUCT", message="Discrepancy type must be one of: SHORTAGE, EXCESS, DAMAGED, WRONG_PRODUCT")
 @Column(name="discrepancy_type")
 private String discrepancyType;
 @NotNull(groups=OnCreate.class, message="Quantity is required")
 @PositiveOrZero(message="Quantity must be 0 or greater")
 @Column(name="quantity")
 private BigDecimal quantity;
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}

package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.sales.entity.ProductVerification;
import com.example.demo.sales.repository.ProductVerificationRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductVerificationService extends AbstractCrudService<ProductVerification, Long> {
    public ProductVerificationService(ProductVerificationRepository repository) {
        super(repository, ProductVerification.class);
    }
}

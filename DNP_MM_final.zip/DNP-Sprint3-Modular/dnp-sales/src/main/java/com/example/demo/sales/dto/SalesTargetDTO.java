package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for SalesTarget. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class SalesTargetDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long targetId;

    private Long distributorId;

    private Long reportingPeriodId;

    private BigDecimal targetValue;

    private OffsetDateTime createdAt;
}

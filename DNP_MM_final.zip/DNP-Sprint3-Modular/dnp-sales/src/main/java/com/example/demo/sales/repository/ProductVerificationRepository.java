package com.example.demo.sales.repository;

import com.example.demo.sales.entity.ProductVerification;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface ProductVerificationRepository extends JpaRepository<ProductVerification, Long> {
    List<ProductVerification> findByShipmentItemIdOrderByVerifiedAtDesc(Long shipmentItemId);
}

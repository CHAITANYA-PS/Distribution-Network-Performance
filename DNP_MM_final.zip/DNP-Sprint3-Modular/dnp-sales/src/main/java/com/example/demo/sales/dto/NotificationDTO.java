package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for Notification. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class NotificationDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long notificationId;

    @NotNull(groups=OnCreate.class, message="User id is required")
    private Long userId;

    @NotNull(groups=OnCreate.class, message="Notification type id is required")
    private Long notificationTypeId;

    @NotBlank(groups=OnCreate.class, message="Message is required")
    private String message;

    private Boolean readStatus;

    private OffsetDateTime createdAt;
}

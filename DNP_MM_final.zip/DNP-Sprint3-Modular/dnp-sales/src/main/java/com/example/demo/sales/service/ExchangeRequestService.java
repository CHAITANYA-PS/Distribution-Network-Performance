package com.example.demo.sales.service;

import com.example.demo.manufacturer.repository.ProductBatchRepository;
import com.example.demo.sales.entity.ExchangeHistory;
import com.example.demo.sales.entity.ExchangeRequest;
import com.example.demo.sales.entity.ExchangeStatus;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.ExchangeHistoryRepository;
import com.example.demo.sales.repository.ExchangeRequestRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Stock exchange requests: a distributor asks for stock of a product; the manufacturer approves it by choosing
 * the source stock and the destination warehouse (or rejects it); completing it transfers the stock through the
 * ledger. Flow: Requested -> Approved -> Completed, or Requested -> Rejected. Every step is kept in exchange_history.
 */
@Service
public class ExchangeRequestService extends AbstractCrudService<ExchangeRequest, Long> {
    public static final String REQUESTED = "Requested";
    public static final String APPROVED = "Approved";
    public static final String REJECTED = "Rejected";
    public static final String COMPLETED = "Completed";

    private final ExchangeRequestRepository requests;
    private final ExchangeHistoryRepository history;
    private final WarehouseStockRepository stocks;
    private final ProductBatchRepository batches;
    private final StockLedgerService ledger;
    private final SalesStatuses statuses;
    private final SystemConfigService config;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public ExchangeRequestService(ExchangeRequestRepository repository, ExchangeHistoryRepository history, WarehouseStockRepository stocks,
            ProductBatchRepository batches, StockLedgerService ledger, SalesStatuses statuses, SystemConfigService config,
            NotificationGateway notifications, UserRoleResolver users) {
        super(repository, ExchangeRequest.class);
        this.requests = repository;
        this.history = history;
        this.stocks = stocks;
        this.batches = batches;
        this.ledger = ledger;
        this.statuses = statuses;
        this.config = config;
        this.notifications = notifications;
        this.users = users;
    }

    @Override
    protected Optional<ExchangeRequest> findForUpdate(Long id) {
        return requests.findByIdForUpdate(id);
    }

    @Override
    protected void beforeCreate(ExchangeRequest r) {
        checkQuantity(r);
        if (r.getRequestedAt() == null) {
            r.setRequestedAt(OffsetDateTime.now());
        }
        r.setExchangeStatusId(statuses.exchange(REQUESTED, 1, false).getExchangeStatusId());
    }

    @Override
    protected void afterCreate(ExchangeRequest saved) {
        saved.setRequestNumber(LookupSupport.reference("EXR", saved.getExchangeId()));
        requests.save(saved);
        addHistory(saved.getExchangeId(), saved.getExchangeStatusId(), "Request created");
        notifications.notify(users.usersWithRole(Roles.MANUFACTURER), "Exchange request",
                "Exchange request " + saved.getRequestNumber() + " for " + plain(saved.getRequestedQuantity()) + " unit(s) of product "
                        + saved.getProductId() + " is waiting for approval");
    }

    @Override
    protected void beforeUpdate(Long id, ExchangeRequest r, ExchangeRequest existing) {
        checkQuantity(r);
        if (!isStatus(existing, REQUESTED)) {
            throw new BusinessRuleException("Only a request in status Requested can be edited");
        }
        if (!Objects.equals(r.getExchangeStatusId(), existing.getExchangeStatusId())) {
            throw new BusinessRuleException("Use the approve / reject / complete actions to change the status");
        }
    }

    public ExchangeRequest approve(Long id, Long sourceWarehouseStockId, Long destinationWarehouseId, String remarks) {
        ExchangeRequest r = load(id, REQUESTED);
        WarehouseStock source = stocks.findById(sourceWarehouseStockId)
                .orElseThrow(() -> new BusinessRuleException("Source warehouse stock not found: " + sourceWarehouseStockId));
        Long productOfStock = batches.findById(source.getProductBatchId()).map(b -> b.getProductId()).orElse(null);
        if (!Objects.equals(productOfStock, r.getProductId())) {
            throw new BusinessRuleException("Source stock " + sourceWarehouseStockId + " holds product " + productOfStock
                    + ", but the request is for product " + r.getProductId());
        }
        if (Boolean.FALSE.equals(source.getIsSellable())) {
            throw new BusinessRuleException("Source stock " + sourceWarehouseStockId + " is blocked from sale");
        }
        if (source.getQuantity() == null || source.getQuantity().compareTo(r.getRequestedQuantity()) < 0) {
            throw new BusinessRuleException("Source stock has only " + plain(source.getQuantity()) + " unit(s); "
                    + plain(r.getRequestedQuantity()) + " requested");
        }
        r.setSourceWarehouseStockId(sourceWarehouseStockId);
        r.setDestinationWarehouseId(destinationWarehouseId);
        return decide(r, APPROVED, 2, remarks);
    }

    public ExchangeRequest reject(Long id, String reason) {
        return decide(load(id, REQUESTED), REJECTED, 9, reason);
    }

    /** Transfers the stock: out of the source row, into the requesting distributor's row in the destination warehouse. */
    public ExchangeRequest complete(Long id, String remarks) {
        ExchangeRequest r = load(id, APPROVED);
        WarehouseStock source = ledger.lock(r.getSourceWarehouseStockId());
        ledger.post(source.getWarehouseStockId(), StockLedgerService.OUT, r.getRequestedQuantity(), "Exchange transfer out", "EXO");
        WarehouseStock target = ledger.findOrCreate(r.getDestinationWarehouseId(), source.getProductBatchId(), r.getDistributorId(), true);
        ledger.post(target.getWarehouseStockId(), StockLedgerService.IN, r.getRequestedQuantity(), "Exchange transfer in", "EXI");
        ExchangeStatus done = statuses.exchange(COMPLETED, 3, true);
        r.setExchangeStatusId(done.getExchangeStatusId());
        ExchangeRequest saved = requests.save(r);
        addHistory(id, done.getExchangeStatusId(), remarks == null ? "Stock transferred to warehouse stock " + target.getWarehouseStockId() : remarks);
        AuditTrail.record("STATUS_CHANGE", "ExchangeRequest", id, APPROVED, COMPLETED);
        notifyRequester(r, "completed: stock is now in warehouse " + r.getDestinationWarehouseId());
        return saved;
    }

    public List<ExchangeHistory> history(Long id) {
        get(id);
        return history.findByExchangeIdOrderByChangedAtAsc(id);
    }

    private ExchangeRequest decide(ExchangeRequest r, String status, int sequence, String remarks) {
        ExchangeStatus s = statuses.exchange(status, sequence, REJECTED.equals(status));
        r.setExchangeStatusId(s.getExchangeStatusId());
        r.setDecidedBy(CurrentUser.id());
        r.setDecidedAt(OffsetDateTime.now());
        r.setDecisionRemarks(remarks);
        ExchangeRequest saved = requests.save(r);
        addHistory(r.getExchangeId(), s.getExchangeStatusId(), remarks == null ? status : status + ": " + remarks);
        AuditTrail.record(APPROVED.equals(status) ? "APPROVE" : "REJECT", "ExchangeRequest", r.getExchangeId(), REQUESTED,
                Map.of("status", status, "remarks", remarks == null ? "" : remarks));
        notifyRequester(r, status.toLowerCase() + (remarks == null ? "" : ": " + remarks));
        return saved;
    }

    private ExchangeRequest load(Long id, String expected) {
        ExchangeRequest r = requests.findByIdForUpdate(id).orElseThrow(() -> new ResourceNotFoundException("Exchange request not found: " + id));
        if (!isStatus(r, expected)) {
            String current = LookupSupport.nameOf(statuses.exchangeStatuses(), r.getExchangeStatusId(), ExchangeStatus::getStatusName);
            throw new BusinessRuleException("Exchange request is " + current + "; this action needs status " + expected);
        }
        return r;
    }

    private boolean isStatus(ExchangeRequest r, String name) {
        String current = LookupSupport.nameOf(statuses.exchangeStatuses(), r.getExchangeStatusId(), ExchangeStatus::getStatusName);
        return LookupSupport.same(current, name) || (current == null && REQUESTED.equals(name));
    }

    private void addHistory(Long exchangeId, Long statusId, String remarks) {
        ExchangeHistory h = new ExchangeHistory();
        h.setExchangeId(exchangeId);
        h.setExchangeStatusId(statusId);
        h.setChangedBy(CurrentUser.id());
        h.setRemarks(remarks != null && remarks.length() > 500 ? remarks.substring(0, 500) : remarks);
        h.setChangedAt(OffsetDateTime.now());
        history.save(h);
    }

    private void notifyRequester(ExchangeRequest r, String what) {
        if (r.getDistributorId() != null) {
            notifications.notify(users.usersOfDistributor(r.getDistributorId()), "Exchange request",
                    "Exchange request " + (r.getRequestNumber() == null ? r.getExchangeId() : r.getRequestNumber()) + " " + what);
        }
    }

    private void checkQuantity(ExchangeRequest r) {
        if (r.getRequestedQuantity() == null || r.getRequestedQuantity().signum() <= 0) {
            throw new BusinessRuleException("Requested quantity must be greater than zero");
        }
        BigDecimal max = config.decimal(SystemConfigService.EXCHANGE_MAX_QUANTITY, "10000");
        if (r.getRequestedQuantity().compareTo(max) > 0) {
            throw new BusinessRuleException("Requested quantity is above the limit of " + plain(max) + " per request");
        }
    }

    private static String plain(BigDecimal v) {
        return v == null ? "0" : v.stripTrailingZeros().toPlainString();
    }
}

package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for DeliveryDiscrepancy. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DeliveryDiscrepancyDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long discrepancyId;

    @NotNull(groups=OnCreate.class, message="Delivery receipt id is required")
    private Long deliveryReceiptId;

    private Long shipmentItemId;

    @NotBlank(groups=OnCreate.class, message="Discrepancy type is required")
    @Size(max=20, message="Discrepancy type must be at most 20 characters")
    @Pattern(regexp="SHORTAGE|EXCESS|DAMAGED|WRONG_PRODUCT", message="Discrepancy type must be one of: SHORTAGE, EXCESS, DAMAGED, WRONG_PRODUCT")
    private String discrepancyType;

    @NotNull(groups=OnCreate.class, message="Quantity is required")
    @PositiveOrZero(message="Quantity must be 0 or greater")
    private BigDecimal quantity;

    private Long ticketId;

    private OffsetDateTime createdAt;
}

package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Product returns (expired / near-expiry / damaged stock going back to the manufacturer's warehouse) (table dsphere.product_return, added in V4). */
@Entity @Table(name="product_return",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ProductReturn implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="product_return_id")
 private Long productReturnId;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=30, message="Return number must be at most 30 characters")
 @Column(name="return_number")
 private String returnNumber;
 @NotNull(groups=OnCreate.class, message="Warehouse stock id is required")
 @Column(name="warehouse_stock_id")
 private Long warehouseStockId;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="product_batch_id")
 private Long productBatchId;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="distributor_id")
 private Long distributorId;
 @NotNull(groups=OnCreate.class, message="Return category id is required")
 @Column(name="return_category_id")
 private Long returnCategoryId;
 @Column(name="target_warehouse_id")
 private Long targetWarehouseId;
 @NotNull(groups=OnCreate.class, message="Quantity is required")
 @Positive(message="Quantity must be greater than 0")
 @Column(name="quantity")
 private BigDecimal quantity;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("REQUESTED")
 @Size(max=20, message="Status must be at most 20 characters")
 @Pattern(regexp="REQUESTED|APPROVED|IN_TRANSIT|RECEIVED|REJECTED", message="Status must be one of: REQUESTED, APPROVED, IN_TRANSIT, RECEIVED, REJECTED")
 @Column(name="status")
 private String status;
 @Size(max=500, message="Reason must be at most 500 characters")
 @Column(name="reason", length=500)
 private String reason;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="requested_by")
 private Long requestedBy;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="warehouse_received_at")
 private OffsetDateTime warehouseReceivedAt;
}

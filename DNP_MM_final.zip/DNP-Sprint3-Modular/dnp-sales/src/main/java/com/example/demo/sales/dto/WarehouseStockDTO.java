package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for WarehouseStock. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class WarehouseStockDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long warehouseStockId;

    private Long warehouseId;

    private Long productBatchId;

    private Long ownerDistributorId;

    private BigDecimal reorderLevel;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Quantity must be 0 or greater")
    private BigDecimal quantity;

    private Boolean isSellable;

    private OffsetDateTime receivedAt;

    @Size(max=10, message="Stock type must be at most 10 characters")
    @Pattern(regexp="PRE_SELL|STOCK_SELL", message="Stock type must be one of: PRE_SELL, STOCK_SELL")
    private String stockType;
}

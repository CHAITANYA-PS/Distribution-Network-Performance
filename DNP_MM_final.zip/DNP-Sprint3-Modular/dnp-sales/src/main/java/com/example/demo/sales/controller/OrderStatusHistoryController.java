package com.example.demo.sales.controller;

import com.example.demo.sales.dto.OrderStatusHistoryDTO;
import com.example.demo.sales.entity.OrderStatusHistory;
import com.example.demo.sales.service.OrderStatusHistoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/order-status-histories")
public class OrderStatusHistoryController {
    private final OrderStatusHistoryService service;

    public OrderStatusHistoryController(OrderStatusHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create OrderStatusHistory")
    @PostMapping
    public ResponseEntity<OrderStatusHistoryDTO> create(@Validated(OnCreate.class) @RequestBody OrderStatusHistoryDTO body) {
        OrderStatusHistory saved = service.create(DtoMapper.toEntity(body, OrderStatusHistory.class));
        return ResponseEntity.created(URI.create("/api/v1/order-status-histories/" + saved.getOrderStatusHistoryId())).body(DtoMapper.toDto(saved, OrderStatusHistoryDTO.class));
    }

    @Operation(summary = "Get one OrderStatusHistory by id")
    @GetMapping("/{id}")
    public OrderStatusHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), OrderStatusHistoryDTO.class);
    }

    @Operation(summary = "List / search OrderStatusHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<OrderStatusHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), OrderStatusHistoryDTO.class));
        }
        Page<OrderStatusHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), OrderStatusHistoryDTO.class));
    }

    @Operation(summary = "Update OrderStatusHistory (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public OrderStatusHistoryDTO update(@PathVariable Long id, @Valid @RequestBody OrderStatusHistoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, OrderStatusHistory.class)), OrderStatusHistoryDTO.class);
    }

    @Operation(summary = "Delete OrderStatusHistory")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.NotificationDTO;
import com.example.demo.sales.entity.Notification;
import com.example.demo.sales.service.NotificationService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationController {
    private final NotificationService service;

    public NotificationController(NotificationService service) {
        this.service = service;
    }

    @Operation(summary = "Create Notification")
    @PostMapping
    public ResponseEntity<NotificationDTO> create(@Validated(OnCreate.class) @RequestBody NotificationDTO body) {
        Notification saved = service.create(DtoMapper.toEntity(body, Notification.class));
        return ResponseEntity.created(URI.create("/api/v1/notifications/" + saved.getNotificationId())).body(DtoMapper.toDto(saved, NotificationDTO.class));
    }

    @Operation(summary = "Get one Notification by id")
    @GetMapping("/{id}")
    public NotificationDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), NotificationDTO.class);
    }

    @Operation(summary = "List / search Notification", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<NotificationDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), NotificationDTO.class));
        }
        Page<Notification> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), NotificationDTO.class));
    }

    @Operation(summary = "Update Notification (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public NotificationDTO update(@PathVariable Long id, @Valid @RequestBody NotificationDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Notification.class)), NotificationDTO.class);
    }

    @Operation(summary = "Delete Notification")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ReturnCategoryDTO;
import com.example.demo.sales.entity.ReturnCategory;
import com.example.demo.sales.service.ReturnCategoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** ReturnCategory API. Create, read, update, delete. */
@RestController
@RequestMapping("/api/v1/return-categories")
public class ReturnCategoryController {
    private final ReturnCategoryService service;

    public ReturnCategoryController(ReturnCategoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create ReturnCategory")
    @PostMapping
    public ResponseEntity<ReturnCategoryDTO> create(@Validated(OnCreate.class) @RequestBody ReturnCategoryDTO body) {
        ReturnCategory saved = service.create(DtoMapper.toEntity(body, ReturnCategory.class));
        return ResponseEntity.created(URI.create("/api/v1/return-categories/" + saved.getReturnCategoryId())).body(DtoMapper.toDto(saved, ReturnCategoryDTO.class));
    }

    @Operation(summary = "Get one ReturnCategory by id")
    @GetMapping("/{id}")
    public ReturnCategoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ReturnCategoryDTO.class);
    }

    @Operation(summary = "List / search ReturnCategory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ReturnCategoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ReturnCategoryDTO.class));
        }
        Page<ReturnCategory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ReturnCategoryDTO.class));
    }

    @Operation(summary = "Update ReturnCategory (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ReturnCategoryDTO update(@PathVariable Long id, @Valid @RequestBody ReturnCategoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ReturnCategory.class)), ReturnCategoryDTO.class);
    }

    @Operation(summary = "Delete ReturnCategory")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

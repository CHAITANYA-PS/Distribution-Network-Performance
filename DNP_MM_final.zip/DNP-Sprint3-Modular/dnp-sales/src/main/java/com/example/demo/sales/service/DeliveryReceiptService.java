package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.sales.entity.DeliveryReceipt;
import com.example.demo.sales.repository.DeliveryReceiptRepository;
import org.springframework.stereotype.Service;

@Service
public class DeliveryReceiptService extends AbstractCrudService<DeliveryReceipt, Long> {
    public DeliveryReceiptService(DeliveryReceiptRepository repository) {
        super(repository, DeliveryReceipt.class);
    }
}

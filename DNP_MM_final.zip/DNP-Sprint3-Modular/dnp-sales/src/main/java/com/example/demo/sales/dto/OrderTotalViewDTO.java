package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Response body for the read-only view OrderTotalView (no create / update).
 */
@Getter
@Setter
@NoArgsConstructor
public class OrderTotalViewDTO {
    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long orderId;

    private String customerName;

    private Integer totalItems;

    private BigDecimal totalAmount;

    private String orderStatus;
}

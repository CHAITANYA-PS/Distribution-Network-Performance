package com.example.demo.sales.controller;

import com.example.demo.distributor.dto.DistributorOrderDTO;
import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.service.DistributorOrderService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** Distributor orders. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/orders")
public class OrderController {
    private final DistributorOrderService distributorOrderService;

    public OrderController(DistributorOrderService distributorOrderService) {
        this.distributorOrderService = distributorOrderService;
    }

    @Operation(summary = "Create DistributorOrder")
    @PostMapping("")
    public ResponseEntity<DistributorOrderDTO> createDistributorOrder(@Validated(OnCreate.class) @RequestBody DistributorOrderDTO body) {
        DistributorOrder saved = distributorOrderService.create(DtoMapper.toEntity(body, DistributorOrder.class));
        return ResponseEntity.created(URI.create("/api/v1/orders/" + saved.getOrderId())).body(DtoMapper.toDto(saved, DistributorOrderDTO.class));
    }

    @Operation(summary = "List / search DistributorOrder", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("")
    public ResponseEntity<List<DistributorOrderDTO>> getAllDistributorOrder(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(distributorOrderService.getAll(), DistributorOrderDTO.class));
        }
        Page<DistributorOrder> result = distributorOrderService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), DistributorOrderDTO.class));
    }

    @Operation(summary = "Get one DistributorOrder by id")
    @GetMapping("/{id}")
    public DistributorOrderDTO getDistributorOrder(@PathVariable Long id) {
        return DtoMapper.toDto(distributorOrderService.get(id), DistributorOrderDTO.class);
    }

    @Operation(summary = "Update DistributorOrder (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public DistributorOrderDTO updateDistributorOrder(@PathVariable Long id, @Valid @RequestBody DistributorOrderDTO body) {
        return DtoMapper.toDto(distributorOrderService.update(id, DtoMapper.toEntity(body, DistributorOrder.class)), DistributorOrderDTO.class);
    }

    @Operation(summary = "Delete DistributorOrder")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteDistributorOrder(@PathVariable Long id) {
        distributorOrderService.delete(id);
    }
}

package com.example.demo.sales.service;

import com.example.demo.sales.entity.ExchangeStatus;
import com.example.demo.sales.entity.OrderStatus;
import com.example.demo.sales.entity.ShipmentStatus;
import com.example.demo.sales.repository.ExchangeStatusRepository;
import com.example.demo.sales.repository.OrderStatusRepository;
import com.example.demo.sales.repository.ShipmentStatusRepository;
import com.example.demo.systemadmin.service.LookupSupport;
import org.springframework.stereotype.Component;

/**
 * Status rows used by the workflows. They are looked up by name and created the first time they are needed,
 * so the workflows also work on a fresh database. Sequence numbers give the normal order of the flow.
 */
@Component
public class SalesStatuses {
    private final ShipmentStatusRepository shipmentStatuses;
    private final OrderStatusRepository orderStatuses;
    private final ExchangeStatusRepository exchangeStatuses;

    public SalesStatuses(ShipmentStatusRepository shipmentStatuses, OrderStatusRepository orderStatuses,
            ExchangeStatusRepository exchangeStatuses) {
        this.shipmentStatuses = shipmentStatuses;
        this.orderStatuses = orderStatuses;
        this.exchangeStatuses = exchangeStatuses;
    }

    public ShipmentStatus shipment(String name, int sequence, boolean terminal) {
        return LookupSupport.findOrCreate(shipmentStatuses, ShipmentStatus::getStatusName, name, () -> {
            ShipmentStatus s = new ShipmentStatus();
            s.setStatusName(name);
            s.setSequenceNumber(sequence);
            s.setIsTerminal(terminal);
            return s;
        });
    }

    public OrderStatus order(String name, int sequence, boolean terminal) {
        return LookupSupport.findOrCreate(orderStatuses, OrderStatus::getStatusName, name, () -> {
            OrderStatus s = new OrderStatus();
            s.setStatusName(name);
            s.setSequenceNumber(sequence);
            s.setIsTerminal(terminal);
            return s;
        });
    }

    public ExchangeStatus exchange(String name, int sequence, boolean terminal) {
        return LookupSupport.findOrCreate(exchangeStatuses, ExchangeStatus::getStatusName, name, () -> {
            ExchangeStatus s = new ExchangeStatus();
            s.setStatusName(name);
            s.setSequenceNumber(sequence);
            s.setIsTerminal(terminal);
            return s;
        });
    }

    public ShipmentStatusRepository shipmentStatuses() {
        return shipmentStatuses;
    }

    public OrderStatusRepository orderStatuses() {
        return orderStatuses;
    }

    public ExchangeStatusRepository exchangeStatuses() {
        return exchangeStatuses;
    }
}

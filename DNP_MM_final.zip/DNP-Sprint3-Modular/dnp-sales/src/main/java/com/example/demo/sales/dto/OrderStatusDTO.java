package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request and response body for OrderStatus. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class OrderStatusDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long orderStatusId;

    @NotBlank(groups=OnCreate.class, message="Status name is required")
    @Size(max=50, message="Status name must be at most 50 characters")
    private String statusName;

    @NotNull(groups=OnCreate.class, message="Sequence number is required")
    @Positive(message="Sequence number must be greater than 0")
    private Integer sequenceNumber;

    private Boolean isTerminal;
}

package com.example.demo.sales.controller;

import com.example.demo.sales.dto.InventoryDocumentTypeDTO;
import com.example.demo.sales.entity.InventoryDocumentType;
import com.example.demo.sales.service.InventoryDocumentTypeService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/inventory-document-types")
public class InventoryDocumentTypeController {
    private final InventoryDocumentTypeService service;

    public InventoryDocumentTypeController(InventoryDocumentTypeService service) {
        this.service = service;
    }

    @Operation(summary = "Create InventoryDocumentType")
    @PostMapping
    public ResponseEntity<InventoryDocumentTypeDTO> create(@Validated(OnCreate.class) @RequestBody InventoryDocumentTypeDTO body) {
        InventoryDocumentType saved = service.create(DtoMapper.toEntity(body, InventoryDocumentType.class));
        return ResponseEntity.created(URI.create("/api/v1/inventory-document-types/" + saved.getInventoryDocumentTypeId())).body(DtoMapper.toDto(saved, InventoryDocumentTypeDTO.class));
    }

    @Operation(summary = "Get one InventoryDocumentType by id")
    @GetMapping("/{id}")
    public InventoryDocumentTypeDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), InventoryDocumentTypeDTO.class);
    }

    @Operation(summary = "List / search InventoryDocumentType", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<InventoryDocumentTypeDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), InventoryDocumentTypeDTO.class));
        }
        Page<InventoryDocumentType> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), InventoryDocumentTypeDTO.class));
    }

    @Operation(summary = "Update InventoryDocumentType (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public InventoryDocumentTypeDTO update(@PathVariable Long id, @Valid @RequestBody InventoryDocumentTypeDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, InventoryDocumentType.class)), InventoryDocumentTypeDTO.class);
    }

    @Operation(summary = "Delete InventoryDocumentType")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

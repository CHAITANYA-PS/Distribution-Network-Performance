package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import lombok.*; import java.time.LocalDate;
@Entity @Table(name="shipment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Shipment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="shipment_id")
 private Long shipmentId;
 @Column(name="tracking_number")
 private String trackingNumber;
 @Column(name="warehouse_id")
 private Long warehouseId;
 @Column(name="shipment_status_id")
 private Long shipmentStatusId;
 @Column(name="dispatch_date")
 private LocalDate dispatchDate;
 @Column(name="delivery_date")
 private LocalDate deliveryDate;
 // ---- V4 columns
 @com.fasterxml.jackson.annotation.JsonIgnore
 @Size(max=10, message="Handover code must be at most 10 characters")
 @Column(name="handover_code")
 private String handoverCode;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="dispatched_by")
 private Long dispatchedBy;
}
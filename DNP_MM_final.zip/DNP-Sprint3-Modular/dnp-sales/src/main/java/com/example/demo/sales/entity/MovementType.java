package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="movement_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class MovementType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="movement_type_id")
 private Long movementTypeId;
 @Column(name="movement_type_name")
 private String movementTypeName;
 @Column(name="movement_direction")
 private String movementDirection;
}
package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.sales.entity.ReturnCategory;
import com.example.demo.sales.repository.ReturnCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ReturnCategoryService extends AbstractCrudService<ReturnCategory, Long> {
    public ReturnCategoryService(ReturnCategoryRepository repository) {
        super(repository, ReturnCategory.class);
    }
}

package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.ReadOnlyViewService;

import com.example.demo.sales.entity.OrderTotalView;
import com.example.demo.sales.repository.OrderTotalViewRepository;
import org.springframework.stereotype.Service;

import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;

import java.util.List;
import java.util.Optional;

@Service
public class OrderTotalViewService extends ReadOnlyViewService<OrderTotalView, Long> {
    private final OrderTotalViewRepository repository;

    public OrderTotalViewService(OrderTotalViewRepository repository) {
        super("OrderTotalView");
        this.repository = repository;
    }

    @Override
    protected List<OrderTotalView> findAllRows() {
        return repository.findAll();
    }

    @Override
    protected Optional<OrderTotalView> findRow(Long id) {
        return repository.findById(id);
    }

    @Override
    protected Page<OrderTotalView> findPageRows(Pageable pageable) {
        return repository.findAll(pageable);
    }

    @Override
    protected String idProperty() {
        return "orderId";
    }
}

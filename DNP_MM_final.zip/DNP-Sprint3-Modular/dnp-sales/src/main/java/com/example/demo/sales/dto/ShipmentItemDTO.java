package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Request and response body for ShipmentItem. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ShipmentItemDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long shipmentItemId;

    private Long shipmentId;

    private Long orderItemId;

    private BigDecimal quantity;

    private Long productBatchId;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Verified quantity must be 0 or greater")
    private BigDecimal verifiedQuantity;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=20, message="Verification status must be at most 20 characters")
    @Pattern(regexp="PENDING|VERIFIED|MISMATCH", message="Verification status must be one of: PENDING, VERIFIED, MISMATCH")
    private String verificationStatus;
}

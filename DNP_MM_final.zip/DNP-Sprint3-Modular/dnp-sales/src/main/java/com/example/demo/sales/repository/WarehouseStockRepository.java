package com.example.demo.sales.repository;

import com.example.demo.sales.entity.WarehouseStock;
import org.springframework.data.jpa.repository.JpaRepository;
import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

import java.util.List;
public interface WarehouseStockRepository extends JpaRepository<WarehouseStock, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = "jakarta.persistence.lock.timeout", value = "5000"))
    @Query("select x from WarehouseStock x where x.warehouseStockId = :id")
    Optional<WarehouseStock> findByIdForUpdate(@Param("id") Long id);

    List<WarehouseStock> findByWarehouseIdAndProductBatchId(Long warehouseId, Long productBatchId);
    List<WarehouseStock> findByProductBatchId(Long productBatchId);
}


package com.example.demo.sales.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Return categories R1 - R4 (table dsphere.return_category, added in V4). */
@Entity @Table(name="return_category",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ReturnCategory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="return_category_id")
 private Long returnCategoryId;
 @NotBlank(groups=OnCreate.class, message="Category code is required")
 @Size(max=5, message="Category code must be at most 5 characters")
 @Column(name="category_code")
 private String categoryCode;
 @NotBlank(groups=OnCreate.class, message="Category name is required")
 @Size(max=100, message="Category name must be at most 100 characters")
 @Column(name="category_name")
 private String categoryName;
 @Size(max=500, message="Description must be at most 500 characters")
 @Column(name="description", length=500)
 private String description;
}

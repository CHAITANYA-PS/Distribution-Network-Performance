package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.sales.entity.DeliveryReceiptItem;
import com.example.demo.sales.repository.DeliveryReceiptItemRepository;
import org.springframework.stereotype.Service;

@Service
public class DeliveryReceiptItemService extends AbstractCrudService<DeliveryReceiptItem, Long> {
    public DeliveryReceiptItemService(DeliveryReceiptItemRepository repository) {
        super(repository, DeliveryReceiptItem.class);
    }
}

package com.example.demo.sales.repository;

import com.example.demo.sales.entity.InventoryAlert;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface InventoryAlertRepository extends JpaRepository<InventoryAlert, Long> {
    boolean existsByWarehouseStockIdAndAlertTypeAndStatus(Long warehouseStockId, String alertType, String status);
}

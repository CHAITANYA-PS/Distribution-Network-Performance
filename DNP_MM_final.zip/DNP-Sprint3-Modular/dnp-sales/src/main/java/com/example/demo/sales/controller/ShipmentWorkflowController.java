package com.example.demo.sales.controller;

import com.example.demo.sales.dto.ProductVerificationDTO;
import com.example.demo.sales.dto.ShipmentDTO;
import com.example.demo.sales.dto.ShipmentStatusHistoryDTO;
import com.example.demo.sales.dto.WorkflowRequests;
import com.example.demo.sales.service.ShipmentWorkflowService;
import com.example.demo.systemadmin.dto.DtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;

/** Shipment actions: verify packed items by product code, dispatch, status changes and history. */
@RestController
@RequestMapping("/api/v1/shipments")
public class ShipmentWorkflowController {
    private final ShipmentWorkflowService service;

    public ShipmentWorkflowController(ShipmentWorkflowService service) {
        this.service = service;
    }

    @Operation(summary = "Verify a packed item (no scanner)", description = "Type or paste the 13-digit product code, the batch number "
            + "and the counted quantity from the pack. result = MATCH or MISMATCH with the reasons; every attempt is recorded.")
    @PostMapping("/{id}/items/{itemId}/verify")
    public ShipmentWorkflowService.VerificationResult verify(@PathVariable Long id, @PathVariable Long itemId,
            @Valid @RequestBody WorkflowRequests.VerifyItem body) {
        return service.verifyItem(id, itemId, body);
    }

    @Operation(summary = "Dispatch the shipment", description = "Allowed only when every item is VERIFIED. Takes the stock out of the "
            + "warehouse and returns the 6-digit handover code (shown only once) to print on the delivery note.")
    @PostMapping("/{id}/dispatch")
    public ShipmentWorkflowService.DispatchResult dispatch(@PathVariable Long id, @RequestBody(required = false) WorkflowRequests.Remarks body) {
        return service.dispatch(id, body == null ? null : body.remarks());
    }

    @Operation(summary = "Change shipment status (e.g. In Transit)", description = "Dispatched and Delivered are set by the dispatch "
            + "and delivery-receipt actions.")
    @PostMapping("/{id}/status")
    public ShipmentDTO status(@PathVariable Long id, @Valid @RequestBody WorkflowRequests.StatusChange body) {
        return DtoMapper.toDto(service.changeStatus(id, body.status(), body.remarks()), ShipmentDTO.class);
    }

    @Operation(summary = "Status history of a shipment")
    @GetMapping("/{id}/status-history")
    public List<ShipmentStatusHistoryDTO> history(@PathVariable Long id) {
        return DtoMapper.toDtoList(service.history(id), ShipmentStatusHistoryDTO.class);
    }

    @Operation(summary = "All verification attempts of the items of a shipment")
    @GetMapping("/{id}/verifications")
    public List<ProductVerificationDTO> verifications(@PathVariable Long id) {
        return DtoMapper.toDtoList(service.verifications(id), ProductVerificationDTO.class);
    }
}

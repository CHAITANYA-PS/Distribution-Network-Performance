package com.example.demo.sales.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for StockWriteOff. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class StockWriteOffDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long writeOffId;

    @NotNull(groups=OnCreate.class, message="Warehouse stock id is required")
    private Long warehouseStockId;

    @NotNull(groups=OnCreate.class, message="Quantity is required")
    @Positive(message="Quantity must be greater than 0")
    private BigDecimal quantity;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Write off value must be 0 or greater")
    private BigDecimal writeOffValue;

    @NotBlank(groups=OnCreate.class, message="Reason is required")
    @Size(max=500, message="Reason must be at most 500 characters")
    private String reason;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long writtenOffBy;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime writtenOffAt;
}

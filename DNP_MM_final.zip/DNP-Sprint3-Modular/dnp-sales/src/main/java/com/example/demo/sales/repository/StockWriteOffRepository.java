package com.example.demo.sales.repository;

import com.example.demo.sales.entity.StockWriteOff;
import org.springframework.data.jpa.repository.JpaRepository;

public interface StockWriteOffRepository extends JpaRepository<StockWriteOff, Long> {
}

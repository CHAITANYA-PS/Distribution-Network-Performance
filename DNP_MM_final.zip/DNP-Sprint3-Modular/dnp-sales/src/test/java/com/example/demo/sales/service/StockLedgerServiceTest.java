package com.example.demo.sales.service;

import com.example.demo.sales.entity.InventoryDocument;
import com.example.demo.sales.entity.InventoryDocumentType;
import com.example.demo.sales.entity.InventoryMovement;
import com.example.demo.sales.entity.MovementType;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.InventoryAlertRepository;
import com.example.demo.sales.repository.InventoryDocumentRepository;
import com.example.demo.sales.repository.InventoryDocumentTypeRepository;
import com.example.demo.sales.repository.InventoryMovementRepository;
import com.example.demo.sales.repository.MovementTypeRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.service.BusinessRuleException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** The quantity ledger: movements change the stock, which can never go below zero; low stock raises an alert. */
@ExtendWith(MockitoExtension.class)
class StockLedgerServiceTest {
    @Mock WarehouseStockRepository stocks;
    @Mock InventoryMovementRepository movements;
    @Mock MovementTypeRepository movementTypes;
    @Mock InventoryDocumentRepository documents;
    @Mock InventoryDocumentTypeRepository documentTypes;
    @Mock InventoryAlertRepository alerts;
    @InjectMocks StockLedgerService ledger;

    private static WarehouseStock stock(String qty, String reorder) {
        WarehouseStock s = new WarehouseStock();
        s.setWarehouseStockId(1L);
        s.setQuantity(new BigDecimal(qty));
        s.setReorderLevel(new BigDecimal(reorder));
        return s;
    }

    private static MovementType type(long id, String direction) {
        MovementType t = new MovementType();
        t.setMovementTypeId(id);
        t.setMovementTypeName("Manual");
        t.setMovementDirection(direction);
        return t;
    }

    @Test
    void direction_acceptsCommonWords() {
        assertEquals("IN", StockLedgerService.direction("Inward"));
        assertEquals("OUT", StockLedgerService.direction("out"));
        assertEquals("OUT", StockLedgerService.direction("ISSUE"));
        assertThrows(BusinessRuleException.class, () -> StockLedgerService.direction("sideways"));
    }

    @Test
    void outMovement_moreThanAvailable_isRejected() {
        WarehouseStock s = stock("5", "0");
        when(stocks.findByIdForUpdate(1L)).thenReturn(Optional.of(s));
        when(movementTypes.findById(2L)).thenReturn(Optional.of(type(2L, "OUT")));
        InventoryMovement m = new InventoryMovement();
        m.setWarehouseStockId(1L);
        m.setMovementTypeId(2L);
        m.setQuantity(new BigDecimal("6"));
        assertThrows(BusinessRuleException.class, () -> ledger.applyUserMovement(m));
        assertEquals(0, s.getQuantity().compareTo(new BigDecimal("5")));
        verify(stocks, never()).save(any(WarehouseStock.class));
    }

    @Test
    void inMovement_addsToTheStock() {
        WarehouseStock s = stock("5", "0");
        when(stocks.findByIdForUpdate(1L)).thenReturn(Optional.of(s));
        when(movementTypes.findById(3L)).thenReturn(Optional.of(type(3L, "IN")));
        InventoryMovement m = new InventoryMovement();
        m.setWarehouseStockId(1L);
        m.setMovementTypeId(3L);
        m.setQuantity(new BigDecimal("7"));
        ledger.applyUserMovement(m);
        assertEquals(0, s.getQuantity().compareTo(new BigDecimal("12")));
        verify(stocks).save(s);
    }

    @Test
    void systemMovement_recordsDocumentAndMovement_andRaisesLowStockAlert() {
        WarehouseStock s = stock("10", "5");
        when(stocks.findByIdForUpdate(1L)).thenReturn(Optional.of(s));
        InventoryDocumentType docType = new InventoryDocumentType();
        docType.setInventoryDocumentTypeId(4L);
        docType.setDocumentTypeName("Dispatch");
        when(documentTypes.findAll()).thenReturn(List.of(docType));
        when(movementTypes.findAll()).thenReturn(List.of(type(2L, "OUT")));
        when(movementTypes.save(any(MovementType.class))).thenAnswer(a -> {
            MovementType t = a.getArgument(0);
            t.setMovementTypeId(8L);
            return t;
        });
        when(documents.save(any(InventoryDocument.class))).thenAnswer(a -> {
            InventoryDocument d = a.getArgument(0);
            d.setInventoryDocumentId(20L);
            return d;
        });
        when(movements.save(any(InventoryMovement.class))).thenAnswer(a -> a.getArgument(0));
        when(alerts.existsByWarehouseStockIdAndAlertTypeAndStatus(1L, "LOW_STOCK", "Open")).thenReturn(false);
        InventoryMovement m = ledger.post(1L, StockLedgerService.OUT, new BigDecimal("6"), "Dispatch", "DSP");
        assertEquals(0, s.getQuantity().compareTo(new BigDecimal("4")));
        assertEquals(20L, m.getInventoryDocumentId());
        assertEquals(8L, m.getMovementTypeId());
        verify(alerts).save(any());
    }
}

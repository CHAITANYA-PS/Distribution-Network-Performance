package com.example.demo.sales.service;

import com.example.demo.sales.entity.InventoryMovement;
import com.example.demo.sales.repository.InventoryMovementRepository;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Movements are the stock ledger: creating one changes the stock, they can never be edited or deleted. */
@ExtendWith(MockitoExtension.class)
class InventoryMovementServiceTest {
    @Mock InventoryMovementRepository repository;
    @Mock StockLedgerService ledger;
    @InjectMocks InventoryMovementService service;

    private InventoryMovement row(Long id, Long version) {
        InventoryMovement x = new InventoryMovement();
        x.setMovementId(id);
        x.setVersion(version);
        x.setWarehouseStockId(1L);
        x.setMovementTypeId(1L);
        x.setQuantity(BigDecimal.TEN);
        return x;
    }

    @Test
    void create_appliesTheMovementToTheStock_thenSaves() {
        when(repository.save(any(InventoryMovement.class))).thenAnswer(a -> a.getArgument(0));
        InventoryMovement m = row(99L, 5L);
        service.create(m);
        verify(ledger).applyUserMovement(m);
        verify(repository).save(any(InventoryMovement.class));
        assertNull(m.getMovementId());
    }

    @Test
    void update_isRejected() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertThrows(BusinessRuleException.class, () -> service.update(1L, row(null, null)));
        verify(repository, never()).save(any(InventoryMovement.class));
    }

    @Test
    void delete_isRejected() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertThrows(BusinessRuleException.class, () -> service.delete(1L));
        verify(repository, never()).deleteById(any());
    }

    @Test
    void getAll_returnsEveryRow() {
        when(repository.findAll()).thenReturn(List.of(row(1L, 0L), row(2L, 0L)));
        assertEquals(2, service.getAll().size());
    }

    @Test
    void get_missing_throwsNotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.get(2L));
    }
}

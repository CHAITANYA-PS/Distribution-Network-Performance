package com.example.demo.sales.service;

import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.sales.entity.InventoryAlert;
import com.example.demo.sales.repository.InventoryAlertRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Logic-only test: the repository is a Mockito mock, no database is used. */
@ExtendWith(MockitoExtension.class)
class InventoryAlertServiceTest {
    @Mock InventoryAlertRepository repository;
    @InjectMocks InventoryAlertService service;

    private InventoryAlert row(Long id, Long version) {
        InventoryAlert x = new InventoryAlert();
        x.setAlertId(id);
        x.setVersion(version);
        return x;
    }

    @Test
    void create_clearsClientIdAndVersion_thenSaves() {
        when(repository.save(any(InventoryAlert.class))).thenAnswer(a -> a.getArgument(0));
        InventoryAlert result = service.create(row(99L, 5L));
        assertNull(result.getAlertId());
        assertNull(result.getVersion());
        verify(repository).save(any(InventoryAlert.class));
    }

    @Test
    void create_nullBody_isRejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(null));
        verifyNoInteractions(repository);
    }

    @Test
    void get_existing_returnsRow() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertEquals(1L, service.get(1L).getAlertId());
    }

    @Test
    void get_missing_throwsNotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.get(2L));
    }

    @Test
    void getAll_returnsEveryRow() {
        when(repository.findAll()).thenReturn(List.of(row(1L, 0L), row(2L, 0L)));
        assertEquals(2, service.getAll().size());
    }

    @Test
    void update_existing_keepsPathIdAndStoredVersion() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        when(repository.save(any(InventoryAlert.class))).thenAnswer(a -> a.getArgument(0));
        InventoryAlert result = service.update(1L, row(null, null));
        assertEquals(1L, result.getAlertId());
        assertEquals(3L, result.getVersion());
    }

    @Test
    void update_staleVersion_raisesOptimisticLockFailure() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> service.update(1L, row(null, 2L)));
        verify(repository, never()).save(any(InventoryAlert.class));
    }

    @Test
    void update_missing_throwsNotFound() {
        when(repository.findById(9L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(9L, row(null, null)));
    }

    @Test
    void delete_existing_deletesById() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        service.delete(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void delete_missing_throwsNotFoundAndDeletesNothing() {
        when(repository.findById(8L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.delete(8L));
        verify(repository, never()).deleteById(any());
    }
}

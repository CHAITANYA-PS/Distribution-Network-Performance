package com.example.demo.sales.service;

import com.example.demo.manufacturer.entity.ProductBatch;
import com.example.demo.manufacturer.repository.ProductBatchRepository;
import com.example.demo.sales.entity.ExchangeRequest;
import com.example.demo.sales.entity.ExchangeStatus;
import com.example.demo.sales.entity.WarehouseStock;
import com.example.demo.sales.repository.ExchangeHistoryRepository;
import com.example.demo.sales.repository.ExchangeRequestRepository;
import com.example.demo.sales.repository.ExchangeStatusRepository;
import com.example.demo.sales.repository.WarehouseStockRepository;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.Year;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Exchange requests: quantity limit, Requested status + request number on create, approval checks. */
@ExtendWith(MockitoExtension.class)
class ExchangeRequestServiceTest {
    @Mock ExchangeRequestRepository repository;
    @Mock ExchangeHistoryRepository history;
    @Mock WarehouseStockRepository stocks;
    @Mock ProductBatchRepository batches;
    @Mock StockLedgerService ledger;
    @Mock SalesStatuses statuses;
    @Mock SystemConfigService config;
    @Mock NotificationGateway notifications;
    @Mock UserRoleResolver users;
    @Mock ExchangeStatusRepository statusRepository;
    @InjectMocks ExchangeRequestService service;

    private static ExchangeStatus status(long id, String name) {
        ExchangeStatus s = new ExchangeStatus();
        s.setExchangeStatusId(id);
        s.setStatusName(name);
        return s;
    }

    private static ExchangeRequest request(String qty) {
        ExchangeRequest r = new ExchangeRequest();
        r.setDistributorId(1L);
        r.setProductId(10L);
        r.setRequestedQuantity(new BigDecimal(qty));
        return r;
    }

    @Test
    void create_aboveTheConfiguredLimit_isRejected() {
        when(config.decimal(SystemConfigService.EXCHANGE_MAX_QUANTITY, "10000")).thenReturn(new BigDecimal("100"));
        assertThrows(BusinessRuleException.class, () -> service.create(request("500")));
        verify(repository, never()).save(any(ExchangeRequest.class));
    }

    @Test
    void create_zeroQuantity_isRejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(request("0")));
    }

    @Test
    void create_startsRequested_withNumberAndHistory() {
        when(config.decimal(SystemConfigService.EXCHANGE_MAX_QUANTITY, "10000")).thenReturn(new BigDecimal("10000"));
        when(statuses.exchange(ExchangeRequestService.REQUESTED, 1, false)).thenReturn(status(1L, "Requested"));
        when(repository.save(any(ExchangeRequest.class))).thenAnswer(a -> {
            ExchangeRequest r = a.getArgument(0);
            if (r.getExchangeId() == null) {
                r.setExchangeId(7L);
            }
            return r;
        });
        ExchangeRequest saved = service.create(request("25"));
        assertEquals(1L, saved.getExchangeStatusId());
        assertEquals("EXR-" + Year.now().getValue() + "-000007", saved.getRequestNumber());
        assertNotNull(saved.getRequestedAt());
        verify(history).save(any());
    }

    @Test
    void approve_sourceStockOfAnotherProduct_isRejected() {
        ExchangeRequest r = request("5");
        r.setExchangeId(1L);
        r.setExchangeStatusId(1L);
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(r));
        when(statuses.exchangeStatuses()).thenReturn(statusRepository);
        when(statusRepository.findById(1L)).thenReturn(Optional.of(status(1L, "Requested")));
        WarehouseStock s = new WarehouseStock();
        s.setWarehouseStockId(5L);
        s.setProductBatchId(50L);
        s.setQuantity(new BigDecimal("100"));
        when(stocks.findById(5L)).thenReturn(Optional.of(s));
        ProductBatch b = new ProductBatch();
        b.setProductBatchId(50L);
        b.setProductId(11L);
        when(batches.findById(50L)).thenReturn(Optional.of(b));
        assertThrows(BusinessRuleException.class, () -> service.approve(1L, 5L, 2L, null));
        verify(repository, never()).save(any(ExchangeRequest.class));
    }

    @Test
    void approve_notInRequestedStatus_isRejected() {
        ExchangeRequest r = request("5");
        r.setExchangeId(1L);
        r.setExchangeStatusId(3L);
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(r));
        when(statuses.exchangeStatuses()).thenReturn(statusRepository);
        when(statusRepository.findById(3L)).thenReturn(Optional.of(status(3L, "Completed")));
        assertThrows(BusinessRuleException.class, () -> service.approve(1L, 5L, 2L, null));
    }
}

package com.example.demo.manufacturer.util;

import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

/** The typed product code is checked with the EAN-13 check digit (no barcode scanner needed). */
class Ean13Test {
    @Test
    void validCode_isAccepted() {
        assertTrue(Ean13.isValid("4006381333931"));
        assertNull(Ean13.problem("4006381333931"));
    }

    @Test
    void oneWrongDigit_isCaught() {
        assertFalse(Ean13.isValid("4006381333932"));
        assertTrue(Ean13.problem("4006381333932").contains("should be 1"));
    }

    @Test
    void swappedNeighbourDigits_areCaught() {
        assertFalse(Ean13.isValid("4006383133931"));
    }

    @Test
    void wrongLengthOrLetters_areExplained() {
        assertTrue(Ean13.problem("123").contains("13 digits"));
        assertTrue(Ean13.problem("40063813339AB").contains("digits only"));
        assertNotNull(Ean13.problem(""));
    }

    @Test
    void internalCodes_areValid() {
        assertEquals("2000000000428", Ean13.forNumber(42));
        assertTrue(Ean13.isValid(Ean13.forNumber(123456789)));
    }
}

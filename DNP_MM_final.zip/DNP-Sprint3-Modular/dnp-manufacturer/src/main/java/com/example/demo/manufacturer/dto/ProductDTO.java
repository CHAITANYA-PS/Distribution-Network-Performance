package com.example.demo.manufacturer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;

/**
 * Request and response body for Product. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ProductDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long productId;

    @NotBlank(groups=OnCreate.class, message="Sku is required")
    @Size(max=100, message="Sku must be at most 100 characters")
    private String sku;

    @NotBlank(groups=OnCreate.class, message="Product name is required")
    @Size(max=200, message="Product name must be at most 200 characters")
    private String productName;

    @NotNull(groups=OnCreate.class, message="Category id is required")
    private Long categoryId;

    @NotBlank(groups=OnCreate.class, message="Unit is required")
    @Size(max=30, message="Unit must be at most 30 characters")
    private String unit;

    @NotNull(groups=OnCreate.class, message="Shelf life days is required")
    @PositiveOrZero(message="Shelf life days must be 0 or greater")
    private Integer shelfLifeDays;

    @Size(max=20, message="Status must be at most 20 characters")
    @Pattern(regexp="Active|Inactive|Discontinued", message="Status must be one of: Active, Inactive, Discontinued")
    private String status;

    @Size(max=13, message="Product code must be at most 13 characters")
    private String productCode;

    @PositiveOrZero(message="Unit cost must be 0 or greater")
    private BigDecimal unitCost;
}

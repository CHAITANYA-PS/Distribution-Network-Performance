package com.example.demo.manufacturer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request and response body for Manufacturer. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class ManufacturerDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long manufacturerId;

    @NotBlank(groups=OnCreate.class, message="Manufacturer code is required")
    @Size(max=50, message="Manufacturer code must be at most 50 characters")
    private String manufacturerCode;

    @NotBlank(groups=OnCreate.class, message="Manufacturer name is required")
    @Size(max=200, message="Manufacturer name must be at most 200 characters")
    private String manufacturerName;

    @Size(max=255, message="Email must be at most 255 characters")
    @Email(message="Email must be a valid email address")
    private String email;

    @Size(max=20, message="Phone must be at most 20 characters")
    private String phone;

    private String address;

    @Size(max=20, message="Status must be at most 20 characters")
    @Pattern(regexp="Active|Inactive|Suspended", message="Status must be one of: Active, Inactive, Suspended")
    private String status;
}

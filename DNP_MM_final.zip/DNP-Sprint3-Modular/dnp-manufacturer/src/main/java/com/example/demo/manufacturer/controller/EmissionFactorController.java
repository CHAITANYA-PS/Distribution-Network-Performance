package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.EmissionFactorDTO;
import com.example.demo.manufacturer.entity.EmissionFactor;
import com.example.demo.manufacturer.service.EmissionFactorService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/emission-factors")
public class EmissionFactorController {
    private final EmissionFactorService service;

    public EmissionFactorController(EmissionFactorService service) {
        this.service = service;
    }

    @Operation(summary = "Create EmissionFactor")
    @PostMapping
    public ResponseEntity<EmissionFactorDTO> create(@Validated(OnCreate.class) @RequestBody EmissionFactorDTO body) {
        EmissionFactor saved = service.create(DtoMapper.toEntity(body, EmissionFactor.class));
        return ResponseEntity.created(URI.create("/api/v1/emission-factors/" + saved.getEmissionFactorId())).body(DtoMapper.toDto(saved, EmissionFactorDTO.class));
    }

    @Operation(summary = "Get one EmissionFactor by id")
    @GetMapping("/{id}")
    public EmissionFactorDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), EmissionFactorDTO.class);
    }

    @Operation(summary = "List / search EmissionFactor", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<EmissionFactorDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), EmissionFactorDTO.class));
        }
        Page<EmissionFactor> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), EmissionFactorDTO.class));
    }

    @Operation(summary = "Update EmissionFactor (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public EmissionFactorDTO update(@PathVariable Long id, @Valid @RequestBody EmissionFactorDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, EmissionFactor.class)), EmissionFactorDTO.class);
    }

    @Operation(summary = "Delete EmissionFactor")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDate;
@Entity @Table(name="product_batch",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ProductBatch implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="product_batch_id")
 private Long productBatchId;
 @Column(name="product_id")
 private Long productId;
 @Column(name="batch_number")
 private String batchNumber;
 @Column(name="manufacturing_date")
 private LocalDate manufacturingDate;
 @Column(name="expiry_date")
 private LocalDate expiryDate;
 @Column(name="operational_status")
 private String operationalStatus;
}
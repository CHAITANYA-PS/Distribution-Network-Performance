package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.ProductBatchDTO;
import com.example.demo.manufacturer.entity.ProductBatch;
import com.example.demo.manufacturer.service.ProductBatchService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/product-batches")
public class ProductBatchController {
    private final ProductBatchService service;

    public ProductBatchController(ProductBatchService service) {
        this.service = service;
    }

    @Operation(summary = "Create ProductBatch")
    @PostMapping
    public ResponseEntity<ProductBatchDTO> create(@Validated(OnCreate.class) @RequestBody ProductBatchDTO body) {
        ProductBatch saved = service.create(DtoMapper.toEntity(body, ProductBatch.class));
        return ResponseEntity.created(URI.create("/api/v1/product-batches/" + saved.getProductBatchId())).body(DtoMapper.toDto(saved, ProductBatchDTO.class));
    }

    @Operation(summary = "Get one ProductBatch by id")
    @GetMapping("/{id}")
    public ProductBatchDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ProductBatchDTO.class);
    }

    @Operation(summary = "List / search ProductBatch", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ProductBatchDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ProductBatchDTO.class));
        }
        Page<ProductBatch> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ProductBatchDTO.class));
    }

    @Operation(summary = "Update ProductBatch (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ProductBatchDTO update(@PathVariable Long id, @Valid @RequestBody ProductBatchDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ProductBatch.class)), ProductBatchDTO.class);
    }

    @Operation(summary = "Delete ProductBatch")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

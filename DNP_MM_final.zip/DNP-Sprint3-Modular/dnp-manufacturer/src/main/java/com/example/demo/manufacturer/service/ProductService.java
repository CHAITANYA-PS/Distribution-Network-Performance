package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.Product;
import com.example.demo.manufacturer.repository.ProductRepository;
import com.example.demo.manufacturer.util.Ean13;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.DuplicateResourceException;
import com.example.demo.systemadmin.service.InvalidRequestException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.LinkedHashMap;
import java.util.Map;

/**
 * Products. Every product has a 13-digit EAN-13 product code: either the code printed on the pack (validated
 * with its check digit) or, when none is given, an internal code generated from the product id.
 */
@Service
public class ProductService extends AbstractCrudService<Product, Long> {
    private final ProductRepository products;

    public ProductService(ProductRepository repository) {
        super(repository, Product.class);
        this.products = repository;
    }

    @Override
    protected void beforeCreate(Product p) {
        checkCode(p.getProductCode(), null);
    }

    @Override
    protected void afterCreate(Product saved) {
        if (saved.getProductId() != null && (saved.getProductCode() == null || saved.getProductCode().isBlank())) {
            saved.setProductCode(Ean13.forNumber(saved.getProductId()));
            products.save(saved);
        }
    }

    @Override
    protected void beforeUpdate(Long id, Product p, Product existing) {
        checkCode(p.getProductCode(), id);
    }

    /** Finds a product by its 13-digit code (404 when unknown, 400 when the code itself is invalid). */
    @Transactional(readOnly = true)
    public Product findByCode(String code) {
        String problem = Ean13.problem(code);
        if (problem != null) {
            throw new InvalidRequestException(problem);
        }
        return products.findByProductCode(code).orElseThrow(() -> new ResourceNotFoundException("No product with code " + code));
    }

    /** Validation result for a typed code, used by the warehouse screen before it is submitted. */
    public static Map<String, Object> validate(String code) {
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("code", code);
        String problem = Ean13.problem(code);
        out.put("valid", problem == null);
        if (problem != null) {
            out.put("message", problem);
        }
        if (code != null && code.matches("\\d{12,13}")) {
            out.put("expectedCheckDigit", Ean13.checkDigit(code.substring(0, 12)));
        }
        return out;
    }

    private void checkCode(String code, Long id) {
        if (code == null || code.isBlank()) {
            return;
        }
        String problem = Ean13.problem(code);
        if (problem != null) {
            throw new InvalidRequestException(problem);
        }
        boolean taken = id == null ? products.existsByProductCode(code) : products.existsByProductCodeAndProductIdNot(code, id);
        if (taken) {
            throw new DuplicateResourceException("Product code " + code + " is already used by another product");
        }
    }
}

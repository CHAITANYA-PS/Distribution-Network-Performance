package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.ManufacturerUserDTO;
import com.example.demo.manufacturer.entity.ManufacturerUser;
import com.example.demo.manufacturer.service.ManufacturerUserService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/manufacturer-users")
public class ManufacturerUserController {
    private final ManufacturerUserService service;

    public ManufacturerUserController(ManufacturerUserService service) {
        this.service = service;
    }

    @Operation(summary = "Create ManufacturerUser")
    @PostMapping
    public ResponseEntity<ManufacturerUserDTO> create(@Validated(OnCreate.class) @RequestBody ManufacturerUserDTO body) {
        ManufacturerUser saved = service.create(DtoMapper.toEntity(body, ManufacturerUser.class));
        return ResponseEntity.created(URI.create("/api/v1/manufacturer-users/" + saved.getUserId())).body(DtoMapper.toDto(saved, ManufacturerUserDTO.class));
    }

    @Operation(summary = "Get one ManufacturerUser by id")
    @GetMapping("/{id}")
    public ManufacturerUserDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ManufacturerUserDTO.class);
    }

    @Operation(summary = "List / search ManufacturerUser", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ManufacturerUserDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ManufacturerUserDTO.class));
        }
        Page<ManufacturerUser> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ManufacturerUserDTO.class));
    }

    @Operation(summary = "Update ManufacturerUser (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ManufacturerUserDTO update(@PathVariable Long id, @Valid @RequestBody ManufacturerUserDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, ManufacturerUser.class)), ManufacturerUserDTO.class);
    }

    @Operation(summary = "Delete ManufacturerUser")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

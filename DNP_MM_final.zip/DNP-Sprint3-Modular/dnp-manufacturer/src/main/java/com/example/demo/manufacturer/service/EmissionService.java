package com.example.demo.manufacturer.service;

import com.example.demo.manufacturer.entity.EmissionFactor;
import com.example.demo.manufacturer.repository.EmissionFactorRepository;
import com.example.demo.systemadmin.entity.TransportationActivity;
import com.example.demo.systemadmin.repository.TransportationActivityRepository;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.EmissionCalculator;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.YearMonth;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

/**
 * Emissions (sustainability): emission = distance (km) x emission factor of the activity (kg CO2 per km).
 * Calculated automatically whenever a transportation activity is saved; an alert goes to the manufacturer
 * users when one activity is above emission.alert.kg. Monthly totals are compared with emission.monthly.target.kg.
 */
@Service
@Transactional
public class EmissionService implements EmissionCalculator, BackgroundJob {
    private final EmissionFactorRepository factors;
    private final TransportationActivityRepository activities;
    private final SystemConfigService config;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public EmissionService(EmissionFactorRepository factors, TransportationActivityRepository activities,
            SystemConfigService config, NotificationGateway notifications, UserRoleResolver users) {
        this.factors = factors;
        this.activities = activities;
        this.config = config;
        this.notifications = notifications;
        this.users = users;
    }

    @Override
    public void calculate(TransportationActivity a) {
        if (a.getDistanceKm() == null || a.getEmissionFactorId() == null) {
            a.setEmissionKg(null);
            return;
        }
        EmissionFactor f = factors.findById(a.getEmissionFactorId()).orElse(null);
        if (f == null || f.getFactorValue() == null) {
            a.setEmissionKg(null);
            return;
        }
        BigDecimal kg = a.getDistanceKm().multiply(f.getFactorValue()).setScale(3, RoundingMode.HALF_UP);
        a.setEmissionKg(kg);
        BigDecimal limit = config.decimal(SystemConfigService.EMISSION_ALERT_KG, "1000");
        if (kg.compareTo(limit) > 0) {
            notifications.notify(users.usersWithRole(Roles.MANUFACTURER), "Emission alert",
                    "Transport " + nz(a.getOrigin()) + " -> " + nz(a.getDestination()) + " on " + a.getActivityDate()
                            + " produced " + kg + " kg CO2, above the alert level of " + limit + " kg");
        }
    }

    /** Calculates (or recalculates) one stored activity. */
    public TransportationActivity recalculate(Long activityId) {
        TransportationActivity a = activities.findById(activityId)
                .orElseThrow(() -> new com.example.demo.systemadmin.service.ResourceNotFoundException("Transportation activity not found: " + activityId));
        calculate(a);
        return activities.save(a);
    }

    /** Totals per month of one year, with the monthly target and whether it was exceeded. */
    @Transactional(readOnly = true)
    public Map<String, Object> summary(int year) {
        BigDecimal target = config.decimal(SystemConfigService.EMISSION_MONTHLY_TARGET_KG, "50000");
        Map<YearMonth, BigDecimal> perMonth = new TreeMap<>();
        Map<YearMonth, Integer> trips = new TreeMap<>();
        for (int m = 1; m <= 12; m++) {
            perMonth.put(YearMonth.of(year, m), BigDecimal.ZERO);
            trips.put(YearMonth.of(year, m), 0);
        }
        BigDecimal total = BigDecimal.ZERO;
        for (TransportationActivity a : activities.findAll()) {
            if (a.getActivityDate() == null || a.getActivityDate().getYear() != year || a.getEmissionKg() == null) {
                continue;
            }
            YearMonth ym = YearMonth.from(a.getActivityDate());
            perMonth.merge(ym, a.getEmissionKg(), BigDecimal::add);
            trips.merge(ym, 1, Integer::sum);
            total = total.add(a.getEmissionKg());
        }
        List<Map<String, Object>> months = new ArrayList<>();
        perMonth.forEach((ym, kg) -> {
            Map<String, Object> row = new LinkedHashMap<>();
            row.put("month", ym.toString());
            row.put("activities", trips.get(ym));
            row.put("emissionKg", kg);
            row.put("targetKg", target);
            row.put("aboveTarget", kg.compareTo(target) > 0);
            months.add(row);
        });
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("year", year);
        out.put("totalEmissionKg", total);
        out.put("yearlyTargetKg", target.multiply(BigDecimal.valueOf(12)));
        out.put("months", months);
        return out;
    }

    // ---- background job: fills emissions that are missing (e.g. rows loaded before V4)

    @Override
    public String name() {
        return "emission-recalculation";
    }

    @Override
    public String description() {
        return "Calculates the CO2 emission of every transportation activity that has none yet";
    }

    @Override
    public Map<String, Object> run() {
        int done = 0;
        for (TransportationActivity a : activities.findAll()) {
            if (a.getEmissionKg() == null && a.getDistanceKm() != null && a.getEmissionFactorId() != null) {
                calculate(a);
                if (a.getEmissionKg() != null) {
                    activities.save(a);
                    done++;
                }
            }
        }
        return Map.of("calculated", done, "date", LocalDate.now().toString());
    }

    private static String nz(String s) {
        return s == null ? "?" : s;
    }
}

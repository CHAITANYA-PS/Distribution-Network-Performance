package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="manufacturer_user",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ManufacturerUser implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @NotNull(groups=OnCreate.class, message="User id is required (send the id of an existing user)")
 @Column(name="user_id")
 private Long userId;
 @NotNull(groups=OnCreate.class, message="Manufacturer id is required")
 @Column(name="manufacturer_id")
 private Long manufacturerId;
}
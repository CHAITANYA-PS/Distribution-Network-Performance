package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.ManufacturerDTO;
import com.example.demo.manufacturer.entity.Manufacturer;
import com.example.demo.manufacturer.service.ManufacturerService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/manufacturers")
public class ManufacturerController {
    private final ManufacturerService service;

    public ManufacturerController(ManufacturerService service) {
        this.service = service;
    }

    @Operation(summary = "Create Manufacturer")
    @PostMapping
    public ResponseEntity<ManufacturerDTO> create(@Validated(OnCreate.class) @RequestBody ManufacturerDTO body) {
        Manufacturer saved = service.create(DtoMapper.toEntity(body, Manufacturer.class));
        return ResponseEntity.created(URI.create("/api/v1/manufacturers/" + saved.getManufacturerId())).body(DtoMapper.toDto(saved, ManufacturerDTO.class));
    }

    @Operation(summary = "Get one Manufacturer by id")
    @GetMapping("/{id}")
    public ManufacturerDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ManufacturerDTO.class);
    }

    @Operation(summary = "List / search Manufacturer", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ManufacturerDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ManufacturerDTO.class));
        }
        Page<Manufacturer> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ManufacturerDTO.class));
    }

    @Operation(summary = "Update Manufacturer (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ManufacturerDTO update(@PathVariable Long id, @Valid @RequestBody ManufacturerDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Manufacturer.class)), ManufacturerDTO.class);
    }

    @Operation(summary = "Delete Manufacturer")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

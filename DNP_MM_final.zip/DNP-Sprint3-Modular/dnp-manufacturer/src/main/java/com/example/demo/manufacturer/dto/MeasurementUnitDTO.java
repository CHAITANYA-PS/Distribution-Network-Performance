package com.example.demo.manufacturer.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request and response body for MeasurementUnit. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class MeasurementUnitDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long measurementUnitId;

    @NotBlank(groups=OnCreate.class, message="Unit code is required")
    @Size(max=20, message="Unit code must be at most 20 characters")
    private String unitCode;

    @NotBlank(groups=OnCreate.class, message="Unit name is required")
    @Size(max=100, message="Unit name must be at most 100 characters")
    private String unitName;
}

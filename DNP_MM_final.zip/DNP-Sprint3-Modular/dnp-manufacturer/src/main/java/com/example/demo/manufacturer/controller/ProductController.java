package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.ProductDTO;
import com.example.demo.manufacturer.entity.Product;
import com.example.demo.manufacturer.service.ProductService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/products")
public class ProductController {
    private final ProductService service;

    public ProductController(ProductService service) {
        this.service = service;
    }

    @Operation(summary = "Create Product")
    @PostMapping
    public ResponseEntity<ProductDTO> create(@Validated(OnCreate.class) @RequestBody ProductDTO body) {
        Product saved = service.create(DtoMapper.toEntity(body, Product.class));
        return ResponseEntity.created(URI.create("/api/v1/products/" + saved.getProductId())).body(DtoMapper.toDto(saved, ProductDTO.class));
    }

    @Operation(summary = "Get one Product by id")
    @GetMapping("/{id}")
    public ProductDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), ProductDTO.class);
    }

    @Operation(summary = "List / search Product", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<ProductDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), ProductDTO.class));
        }
        Page<Product> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), ProductDTO.class));
    }

    @Operation(summary = "Update Product (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public ProductDTO update(@PathVariable Long id, @Valid @RequestBody ProductDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Product.class)), ProductDTO.class);
    }

    @Operation(summary = "Delete Product")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.MeasurementUnitDTO;
import com.example.demo.manufacturer.entity.MeasurementUnit;
import com.example.demo.manufacturer.service.MeasurementUnitService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/measurement-units")
public class MeasurementUnitController {
    private final MeasurementUnitService service;

    public MeasurementUnitController(MeasurementUnitService service) {
        this.service = service;
    }

    @Operation(summary = "Create MeasurementUnit")
    @PostMapping
    public ResponseEntity<MeasurementUnitDTO> create(@Validated(OnCreate.class) @RequestBody MeasurementUnitDTO body) {
        MeasurementUnit saved = service.create(DtoMapper.toEntity(body, MeasurementUnit.class));
        return ResponseEntity.created(URI.create("/api/v1/measurement-units/" + saved.getMeasurementUnitId())).body(DtoMapper.toDto(saved, MeasurementUnitDTO.class));
    }

    @Operation(summary = "Get one MeasurementUnit by id")
    @GetMapping("/{id}")
    public MeasurementUnitDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), MeasurementUnitDTO.class);
    }

    @Operation(summary = "List / search MeasurementUnit", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<MeasurementUnitDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), MeasurementUnitDTO.class));
        }
        Page<MeasurementUnit> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), MeasurementUnitDTO.class));
    }

    @Operation(summary = "Update MeasurementUnit (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public MeasurementUnitDTO update(@PathVariable Long id, @Valid @RequestBody MeasurementUnitDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, MeasurementUnit.class)), MeasurementUnitDTO.class);
    }

    @Operation(summary = "Delete MeasurementUnit")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.service.EmissionService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.dto.TransportationActivityDTO;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.time.Year;
import java.util.Map;

/** Emission calculation and monthly emission summary against the target. */
@RestController
@RequestMapping("/api/v1/emissions")
public class EmissionController {
    private final EmissionService service;

    public EmissionController(EmissionService service) {
        this.service = service;
    }

    @Operation(summary = "Monthly emission totals for a year, compared with the monthly target")
    @GetMapping("/summary")
    public Map<String, Object> summary(@RequestParam(required = false) Integer year) {
        return service.summary(year == null ? Year.now().getValue() : year);
    }

    @Operation(summary = "Recalculate the emission of one transportation activity")
    @PostMapping("/calculate/{activityId}")
    public TransportationActivityDTO calculate(@PathVariable Long activityId) {
        return DtoMapper.toDto(service.recalculate(activityId), TransportationActivityDTO.class);
    }
}

package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="manufacturer",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Manufacturer implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="manufacturer_id")
 private Long manufacturerId;
 @NotBlank(groups=OnCreate.class, message="Manufacturer code is required")
 @Size(max=50, message="Manufacturer code must be at most 50 characters")
 @Column(name="manufacturer_code")
 private String manufacturerCode;
 @NotBlank(groups=OnCreate.class, message="Manufacturer name is required")
 @Size(max=200, message="Manufacturer name must be at most 200 characters")
 @Column(name="manufacturer_name")
 private String manufacturerName;
 @Size(max=255, message="Email must be at most 255 characters")
 @Email(message="Email must be a valid email address")
 @Column(name="email")
 private String email;
 @Size(max=20, message="Phone must be at most 20 characters")
 @Column(name="phone")
 private String phone;
 @Column(name="address")
 private String address;
 @CreateDefault("Active")
 @Size(max=20, message="Status must be at most 20 characters")
 @Pattern(regexp="Active|Inactive|Suspended", message="Status must be one of: Active, Inactive, Suspended")
 @Column(name="status")
 private String status;
}
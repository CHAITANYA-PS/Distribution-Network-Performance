package com.example.demo.manufacturer.util;

/**
 * EAN-13 product codes: 12 digits plus a check digit, the number printed under a retail barcode.
 * No scanner is needed: the warehouse user types or pastes the 13 digits from the pack, and the check digit
 * catches almost every typing mistake (a wrong digit or two swapped neighbouring digits).
 */
public final class Ean13 {
    /** GS1 "in-store" prefix used for codes this system generates (200-299 are reserved for internal use). */
    public static final String INTERNAL_PREFIX = "200";

    private Ean13() {
    }

    /** Check digit for the first 12 digits: weights 1,3,1,3... from the left; (10 - sum mod 10) mod 10. */
    public static int checkDigit(String first12) {
        if (first12 == null || !first12.matches("\\d{12}")) {
            throw new IllegalArgumentException("Exactly 12 digits are needed to work out the check digit");
        }
        int sum = 0;
        for (int i = 0; i < 12; i++) {
            int d = first12.charAt(i) - '0';
            sum += (i % 2 == 0) ? d : d * 3;
        }
        return (10 - sum % 10) % 10;
    }

    /** True when the code is 13 digits and its last digit is the correct check digit. */
    public static boolean isValid(String code) {
        return code != null && code.matches("\\d{13}") && checkDigit(code.substring(0, 12)) == code.charAt(12) - '0';
    }

    /** Explains why a code is wrong, or returns null when it is valid. */
    public static String problem(String code) {
        if (code == null || code.isBlank()) {
            return "Product code is empty";
        }
        if (!code.matches("\\d+")) {
            return "Product code must contain digits only";
        }
        if (code.length() != 13) {
            return "Product code must be 13 digits (it has " + code.length() + ")";
        }
        int expected = checkDigit(code.substring(0, 12));
        if (expected != code.charAt(12) - '0') {
            return "Check digit is wrong: the last digit should be " + expected + " - please re-type the code";
        }
        return null;
    }

    /** Builds a valid internal code from a number, e.g. product id 42 -> 2000000000428. */
    public static String forNumber(long number) {
        String first12 = INTERNAL_PREFIX + String.format("%09d", number);
        if (first12.length() != 12) {
            throw new IllegalArgumentException("Number too large for an internal product code: " + number);
        }
        return first12 + checkDigit(first12);
    }
}

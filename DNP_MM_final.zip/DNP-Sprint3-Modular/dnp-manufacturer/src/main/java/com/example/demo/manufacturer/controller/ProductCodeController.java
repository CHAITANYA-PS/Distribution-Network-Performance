package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.ProductDTO;
import com.example.demo.manufacturer.service.ProductService;
import com.example.demo.systemadmin.dto.DtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Product code (EAN-13) look-up and check - the "no scanner" alternative: the code is typed or pasted. */
@RestController
@RequestMapping("/api/v1/products")
public class ProductCodeController {
    private final ProductService service;

    public ProductCodeController(ProductService service) {
        this.service = service;
    }

    @Operation(summary = "Check a typed product code", description = "Returns valid=true/false and the expected check digit, "
            + "e.g. 4006381333931 is valid, 4006381333932 is not")
    @GetMapping("/validate-code")
    public Map<String, Object> validate(@RequestParam String code) {
        return ProductService.validate(code.trim());
    }

    @Operation(summary = "Find a product by its 13-digit product code")
    @GetMapping("/by-code/{code}")
    public ProductDTO byCode(@PathVariable String code) {
        return DtoMapper.toDto(service.findByCode(code.trim()), ProductDTO.class);
    }
}

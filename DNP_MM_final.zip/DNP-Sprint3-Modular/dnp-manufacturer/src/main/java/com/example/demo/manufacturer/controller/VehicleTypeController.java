package com.example.demo.manufacturer.controller;

import com.example.demo.manufacturer.dto.VehicleTypeDTO;
import com.example.demo.manufacturer.entity.VehicleType;
import com.example.demo.manufacturer.service.VehicleTypeService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/vehicle-types")
public class VehicleTypeController {
    private final VehicleTypeService service;

    public VehicleTypeController(VehicleTypeService service) {
        this.service = service;
    }

    @Operation(summary = "Create VehicleType")
    @PostMapping
    public ResponseEntity<VehicleTypeDTO> create(@Validated(OnCreate.class) @RequestBody VehicleTypeDTO body) {
        VehicleType saved = service.create(DtoMapper.toEntity(body, VehicleType.class));
        return ResponseEntity.created(URI.create("/api/v1/vehicle-types/" + saved.getVehicleTypeId())).body(DtoMapper.toDto(saved, VehicleTypeDTO.class));
    }

    @Operation(summary = "Get one VehicleType by id")
    @GetMapping("/{id}")
    public VehicleTypeDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), VehicleTypeDTO.class);
    }

    @Operation(summary = "List / search VehicleType", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<VehicleTypeDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), VehicleTypeDTO.class));
        }
        Page<VehicleType> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), VehicleTypeDTO.class));
    }

    @Operation(summary = "Update VehicleType (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public VehicleTypeDTO update(@PathVariable Long id, @Valid @RequestBody VehicleTypeDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, VehicleType.class)), VehicleTypeDTO.class);
    }

    @Operation(summary = "Delete VehicleType")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

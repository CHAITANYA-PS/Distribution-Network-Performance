package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="vehicle_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class VehicleType implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="vehicle_type_id")
 private Long vehicleTypeId;
 @Column(name="vehicle_name")
 private String vehicleName;
 @Column(name="fuel_type")
 private String fuelType;
}
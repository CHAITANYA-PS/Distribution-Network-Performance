package com.example.demo.manufacturer.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.manufacturer.entity.ManufacturerUser;
import com.example.demo.manufacturer.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerUserService extends AbstractCrudService<ManufacturerUser, Long> {
    public ManufacturerUserService(ManufacturerUserRepository repository) {
        super(repository, ManufacturerUser.class);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}

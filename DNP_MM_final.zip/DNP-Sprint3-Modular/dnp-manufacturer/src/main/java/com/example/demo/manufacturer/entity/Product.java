package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import java.math.BigDecimal; import lombok.*;
@Entity @Table(name="product",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Product implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="product_id")
 private Long productId;
 @NotBlank(groups=OnCreate.class, message="Sku is required")
 @Size(max=100, message="Sku must be at most 100 characters")
 @Column(name="sku")
 private String sku;
 @NotBlank(groups=OnCreate.class, message="Product name is required")
 @Size(max=200, message="Product name must be at most 200 characters")
 @Column(name="product_name")
 private String productName;
 @NotNull(groups=OnCreate.class, message="Category id is required")
 @Column(name="category_id")
 private Long categoryId;
 @NotBlank(groups=OnCreate.class, message="Unit is required")
 @Size(max=30, message="Unit must be at most 30 characters")
 @Column(name="unit")
 private String unit;
 @NotNull(groups=OnCreate.class, message="Shelf life days is required")
 @PositiveOrZero(message="Shelf life days must be 0 or greater")
 @Column(name="shelf_life_days")
 private Integer shelfLifeDays;
 @CreateDefault("Active")
 @Size(max=20, message="Status must be at most 20 characters")
 @Pattern(regexp="Active|Inactive|Discontinued", message="Status must be one of: Active, Inactive, Discontinued")
 @Column(name="status")
 private String status;
 // ---- V4 columns
 @Size(max=13, message="Product code must be at most 13 characters")
 @Column(name="product_code")
 private String productCode;
 @PositiveOrZero(message="Unit cost must be 0 or greater")
 @Column(name="unit_cost")
 private BigDecimal unitCost;
}
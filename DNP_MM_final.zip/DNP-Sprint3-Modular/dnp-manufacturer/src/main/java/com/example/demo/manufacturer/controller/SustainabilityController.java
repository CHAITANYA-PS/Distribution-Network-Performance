package com.example.demo.manufacturer.controller;

import com.example.demo.distributor.dto.CommitmentDTO;
import com.example.demo.distributor.entity.Commitment;
import com.example.demo.distributor.service.CommitmentService;
import com.example.demo.manufacturer.dto.EmissionFactorDTO;
import com.example.demo.manufacturer.entity.EmissionFactor;
import com.example.demo.manufacturer.service.EmissionFactorService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** Sustainability commitments and emission factors. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/sustainability")
public class SustainabilityController {
    private final CommitmentService commitmentService;
    private final EmissionFactorService emissionFactorService;

    public SustainabilityController(CommitmentService commitmentService, EmissionFactorService emissionFactorService) {
        this.commitmentService = commitmentService;
        this.emissionFactorService = emissionFactorService;
    }

    @Operation(summary = "Create Commitment")
    @PostMapping("/commitments")
    public ResponseEntity<CommitmentDTO> createCommitment(@Validated(OnCreate.class) @RequestBody CommitmentDTO body) {
        Commitment saved = commitmentService.create(DtoMapper.toEntity(body, Commitment.class));
        return ResponseEntity.created(URI.create("/api/v1/sustainability/commitments/" + saved.getCommitmentId())).body(DtoMapper.toDto(saved, CommitmentDTO.class));
    }

    @Operation(summary = "List / search Commitment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("/commitments")
    public ResponseEntity<List<CommitmentDTO>> getAllCommitment(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(commitmentService.getAll(), CommitmentDTO.class));
        }
        Page<Commitment> result = commitmentService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), CommitmentDTO.class));
    }

    @Operation(summary = "Get one Commitment by id")
    @GetMapping("/commitments/{id}")
    public CommitmentDTO getCommitment(@PathVariable Long id) {
        return DtoMapper.toDto(commitmentService.get(id), CommitmentDTO.class);
    }

    @Operation(summary = "Update Commitment (send only the fields to change, plus version)")
    @PutMapping("/commitments/{id}")
    public CommitmentDTO updateCommitment(@PathVariable Long id, @Valid @RequestBody CommitmentDTO body) {
        return DtoMapper.toDto(commitmentService.update(id, DtoMapper.toEntity(body, Commitment.class)), CommitmentDTO.class);
    }

    @Operation(summary = "Delete Commitment")
    @DeleteMapping("/commitments/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCommitment(@PathVariable Long id) {
        commitmentService.delete(id);
    }

    @Operation(summary = "Create EmissionFactor")
    @PostMapping("/emission-factors")
    public ResponseEntity<EmissionFactorDTO> createEmissionFactor(@Validated(OnCreate.class) @RequestBody EmissionFactorDTO body) {
        EmissionFactor saved = emissionFactorService.create(DtoMapper.toEntity(body, EmissionFactor.class));
        return ResponseEntity.created(URI.create("/api/v1/sustainability/emission-factors/" + saved.getEmissionFactorId())).body(DtoMapper.toDto(saved, EmissionFactorDTO.class));
    }

    @Operation(summary = "List / search EmissionFactor", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping("/emission-factors")
    public ResponseEntity<List<EmissionFactorDTO>> getAllEmissionFactor(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(emissionFactorService.getAll(), EmissionFactorDTO.class));
        }
        Page<EmissionFactor> result = emissionFactorService.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), EmissionFactorDTO.class));
    }

    @Operation(summary = "Get one EmissionFactor by id")
    @GetMapping("/emission-factors/{id}")
    public EmissionFactorDTO getEmissionFactor(@PathVariable Long id) {
        return DtoMapper.toDto(emissionFactorService.get(id), EmissionFactorDTO.class);
    }

    @Operation(summary = "Update EmissionFactor (send only the fields to change, plus version)")
    @PutMapping("/emission-factors/{id}")
    public EmissionFactorDTO updateEmissionFactor(@PathVariable Long id, @Valid @RequestBody EmissionFactorDTO body) {
        return DtoMapper.toDto(emissionFactorService.update(id, DtoMapper.toEntity(body, EmissionFactor.class)), EmissionFactorDTO.class);
    }

    @Operation(summary = "Delete EmissionFactor")
    @DeleteMapping("/emission-factors/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteEmissionFactor(@PathVariable Long id) {
        emissionFactorService.delete(id);
    }
}

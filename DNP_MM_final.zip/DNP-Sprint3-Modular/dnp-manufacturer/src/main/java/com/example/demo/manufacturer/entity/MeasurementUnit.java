package com.example.demo.manufacturer.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="measurement_unit",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class MeasurementUnit implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="measurement_unit_id")
 private Long measurementUnitId;
 @NotBlank(groups=OnCreate.class, message="Unit code is required")
 @Size(max=20, message="Unit code must be at most 20 characters")
 @Column(name="unit_code")
 private String unitCode;
 @NotBlank(groups=OnCreate.class, message="Unit name is required")
 @Size(max=100, message="Unit name must be at most 100 characters")
 @Column(name="unit_name")
 private String unitName;
}
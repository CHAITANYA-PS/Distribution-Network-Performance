package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** SLA per ticket priority (hours to resolve) (table dsphere.sla_policy, added in V4). */
@Entity @Table(name="sla_policy",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class SlaPolicy implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="sla_policy_id")
 private Long slaPolicyId;
 @NotNull(groups=OnCreate.class, message="Ticket priority id is required")
 @Column(name="ticket_priority_id")
 private Long ticketPriorityId;
 @NotNull(groups=OnCreate.class, message="Response hours is required")
 @Positive(message="Response hours must be greater than 0")
 @Column(name="response_hours")
 private Integer responseHours;
 @NotNull(groups=OnCreate.class, message="Resolution hours is required")
 @Positive(message="Resolution hours must be greater than 0")
 @Column(name="resolution_hours")
 private Integer resolutionHours;
}

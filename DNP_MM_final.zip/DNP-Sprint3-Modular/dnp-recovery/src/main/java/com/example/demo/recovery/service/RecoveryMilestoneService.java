package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.RecoveryMilestone;
import com.example.demo.recovery.repository.RecoveryMilestoneRepository;
import com.example.demo.recovery.repository.RecoveryPlanRepository;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

/** Milestones of a recovery plan. New milestones start PENDING; completing one goes through the complete action. */
@Service
public class RecoveryMilestoneService extends AbstractCrudService<RecoveryMilestone, Long> {
    private final RecoveryPlanRepository plans;
    private final RecoveryPlanWorkflowService workflow;

    public RecoveryMilestoneService(RecoveryMilestoneRepository repository, RecoveryPlanRepository plans, RecoveryPlanWorkflowService workflow) {
        super(repository, RecoveryMilestone.class);
        this.plans = plans;
        this.workflow = workflow;
    }

    @Override
    protected void beforeCreate(RecoveryMilestone m) {
        var plan = plans.findById(m.getRecoveryPlanId())
                .orElseThrow(() -> new BusinessRuleException("Recovery plan not found: " + m.getRecoveryPlanId()));
        if (plan.getClosedAt() != null) {
            throw new BusinessRuleException("Recovery plan " + plan.getRecoveryPlanId() + " is closed");
        }
        if (plan.getEndDate() != null && m.getDueDate() != null && m.getDueDate().isAfter(plan.getEndDate())) {
            throw new BusinessRuleException("Milestone due date is after the plan end date " + plan.getEndDate());
        }
        m.setStatus("PENDING");
    }

    @Override
    protected void afterUpdate(RecoveryMilestone saved) {
        plans.findById(saved.getRecoveryPlanId()).ifPresent(workflow::recalculate);
    }
}

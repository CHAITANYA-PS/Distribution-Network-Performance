package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Recovery plan milestones (table dsphere.recovery_milestone, added in V4). */
@Entity @Table(name="recovery_milestone",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryMilestone implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="milestone_id")
 private Long milestoneId;
 @NotNull(groups=OnCreate.class, message="Recovery plan id is required")
 @Column(name="recovery_plan_id")
 private Long recoveryPlanId;
 @NotBlank(groups=OnCreate.class, message="Title is required")
 @Size(max=200, message="Title must be at most 200 characters")
 @Column(name="title")
 private String title;
 @PositiveOrZero(message="Target amount must be 0 or greater")
 @Column(name="target_amount")
 private BigDecimal targetAmount;
 @CreateDefault("0")
 @PositiveOrZero(message="Achieved amount must be 0 or greater")
 @Column(name="achieved_amount")
 private BigDecimal achievedAmount;
 @NotNull(groups=OnCreate.class, message="Due date is required")
 @Column(name="due_date")
 private LocalDate dueDate;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("PENDING")
 @Size(max=20, message="Status must be at most 20 characters")
 @Pattern(regexp="PENDING|COMPLETED|MISSED", message="Status must be one of: PENDING, COMPLETED, MISSED")
 @Column(name="status")
 private String status;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="completed_at")
 private OffsetDateTime completedAt;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}

package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.SlaPolicyDTO;
import com.example.demo.recovery.entity.SlaPolicy;
import com.example.demo.recovery.service.SlaPolicyService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** SlaPolicy API. Create, read, update, delete. */
@RestController
@RequestMapping("/api/v1/sla-policies")
public class SlaPolicyController {
    private final SlaPolicyService service;

    public SlaPolicyController(SlaPolicyService service) {
        this.service = service;
    }

    @Operation(summary = "Create SlaPolicy")
    @PostMapping
    public ResponseEntity<SlaPolicyDTO> create(@Validated(OnCreate.class) @RequestBody SlaPolicyDTO body) {
        SlaPolicy saved = service.create(DtoMapper.toEntity(body, SlaPolicy.class));
        return ResponseEntity.created(URI.create("/api/v1/sla-policies/" + saved.getSlaPolicyId())).body(DtoMapper.toDto(saved, SlaPolicyDTO.class));
    }

    @Operation(summary = "Get one SlaPolicy by id")
    @GetMapping("/{id}")
    public SlaPolicyDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), SlaPolicyDTO.class);
    }

    @Operation(summary = "List / search SlaPolicy", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<SlaPolicyDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), SlaPolicyDTO.class));
        }
        Page<SlaPolicy> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), SlaPolicyDTO.class));
    }

    @Operation(summary = "Update SlaPolicy (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public SlaPolicyDTO update(@PathVariable Long id, @Valid @RequestBody SlaPolicyDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, SlaPolicy.class)), SlaPolicyDTO.class);
    }

    @Operation(summary = "Delete SlaPolicy")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.RecoveryPlanTicketDTO;
import com.example.demo.recovery.entity.RecoveryPlanTicket;
import com.example.demo.recovery.service.RecoveryPlanTicketService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/recovery-plan-tickets")
public class RecoveryPlanTicketController {
    private final RecoveryPlanTicketService service;

    public RecoveryPlanTicketController(RecoveryPlanTicketService service) {
        this.service = service;
    }

    @Operation(summary = "Create RecoveryPlanTicket")
    @PostMapping
    public ResponseEntity<RecoveryPlanTicketDTO> create(@Validated(OnCreate.class) @RequestBody RecoveryPlanTicketDTO body) {
        RecoveryPlanTicket saved = service.create(DtoMapper.toEntity(body, RecoveryPlanTicket.class));
        return ResponseEntity.created(URI.create("/api/v1/recovery-plan-tickets/" + saved.getRecoveryPlanTicketId())).body(DtoMapper.toDto(saved, RecoveryPlanTicketDTO.class));
    }

    @Operation(summary = "Get one RecoveryPlanTicket by id")
    @GetMapping("/{id}")
    public RecoveryPlanTicketDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RecoveryPlanTicketDTO.class);
    }

    @Operation(summary = "List / search RecoveryPlanTicket", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RecoveryPlanTicketDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RecoveryPlanTicketDTO.class));
        }
        Page<RecoveryPlanTicket> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RecoveryPlanTicketDTO.class));
    }

    @Operation(summary = "Update RecoveryPlanTicket (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RecoveryPlanTicketDTO update(@PathVariable Long id, @Valid @RequestBody RecoveryPlanTicketDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RecoveryPlanTicket.class)), RecoveryPlanTicketDTO.class);
    }

    @Operation(summary = "Delete RecoveryPlanTicket")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

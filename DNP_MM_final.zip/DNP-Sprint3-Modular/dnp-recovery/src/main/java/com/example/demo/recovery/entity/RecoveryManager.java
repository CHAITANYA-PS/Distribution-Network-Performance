package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="recovery_manager",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryManager implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @NotNull(groups=OnCreate.class, message="User id is required (send the id of an existing user)")
 @Column(name="user_id")
 private Long userId;
 @NotNull(groups=OnCreate.class, message="Region id is required")
 @Column(name="region_id")
 private Long regionId;
}
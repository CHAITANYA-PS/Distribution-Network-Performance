package com.example.demo.recovery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * Request and response body for RecoveryMilestone. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class RecoveryMilestoneDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long milestoneId;

    @NotNull(groups=OnCreate.class, message="Recovery plan id is required")
    private Long recoveryPlanId;

    @NotBlank(groups=OnCreate.class, message="Title is required")
    @Size(max=200, message="Title must be at most 200 characters")
    private String title;

    @PositiveOrZero(message="Target amount must be 0 or greater")
    private BigDecimal targetAmount;

    @PositiveOrZero(message="Achieved amount must be 0 or greater")
    private BigDecimal achievedAmount;

    @NotNull(groups=OnCreate.class, message="Due date is required")
    private LocalDate dueDate;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=20, message="Status must be at most 20 characters")
    @Pattern(regexp="PENDING|COMPLETED|MISSED", message="Status must be one of: PENDING, COMPLETED, MISSED")
    private String status;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime completedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime createdAt;
}

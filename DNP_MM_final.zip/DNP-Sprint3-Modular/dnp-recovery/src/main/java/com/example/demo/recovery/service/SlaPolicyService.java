package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.recovery.entity.SlaPolicy;
import com.example.demo.recovery.repository.SlaPolicyRepository;
import org.springframework.stereotype.Service;

@Service
public class SlaPolicyService extends AbstractCrudService<SlaPolicy, Long> {
    public SlaPolicyService(SlaPolicyRepository repository) {
        super(repository, SlaPolicy.class);
    }
}

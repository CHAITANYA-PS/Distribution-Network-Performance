package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketStatusHistoryDTO;
import com.example.demo.recovery.entity.TicketStatusHistory;
import com.example.demo.recovery.service.TicketStatusHistoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** TicketStatusHistory API. Read-only: rows are written by the system (workflow actions), never typed in. */
@RestController
@RequestMapping("/api/v1/ticket-status-histories")
public class TicketStatusHistoryController {
    private final TicketStatusHistoryService service;

    public TicketStatusHistoryController(TicketStatusHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Get one TicketStatusHistory by id")
    @GetMapping("/{id}")
    public TicketStatusHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketStatusHistoryDTO.class);
    }

    @Operation(summary = "List / search TicketStatusHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketStatusHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketStatusHistoryDTO.class));
        }
        Page<TicketStatusHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketStatusHistoryDTO.class));
    }
}

package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.RecoveryMilestone;
import com.example.demo.recovery.entity.RecoveryPlan;
import com.example.demo.recovery.repository.RecoveryMilestoneRepository;
import com.example.demo.recovery.repository.RecoveryPlanRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;

/**
 * Recovery plans: milestones (PENDING -> COMPLETED / MISSED), progress = recovered / target, closing with an
 * outcome. The milestone job marks overdue milestones as MISSED and tells the recovery managers.
 */
@Service
@Transactional
public class RecoveryPlanWorkflowService implements BackgroundJob {
    public static final String ACTIVE = "Active";
    public static final String CLOSED = "Closed";

    private final RecoveryPlanRepository plans;
    private final RecoveryMilestoneRepository milestones;
    private final RecoveryLookups lookups;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public RecoveryPlanWorkflowService(RecoveryPlanRepository plans, RecoveryMilestoneRepository milestones, RecoveryLookups lookups,
            NotificationGateway notifications, UserRoleResolver users) {
        this.plans = plans;
        this.milestones = milestones;
        this.lookups = lookups;
        this.notifications = notifications;
        this.users = users;
    }

    /** Progress of a plan: recovered amount, target, %, milestones by status, days left. */
    @Transactional(readOnly = true)
    public Map<String, Object> progress(Long planId) {
        RecoveryPlan p = plan(planId);
        List<RecoveryMilestone> ms = milestones.findByRecoveryPlanId(planId);
        Map<String, Long> byStatus = new LinkedHashMap<>();
        for (String s : List.of("PENDING", "COMPLETED", "MISSED")) {
            byStatus.put(s, ms.stream().filter(m -> s.equals(m.getStatus())).count());
        }
        BigDecimal recovered = p.getRecoveredAmount() == null ? BigDecimal.ZERO : p.getRecoveredAmount();
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("recoveryPlanId", planId);
        out.put("distributorId", p.getDistributorId());
        out.put("status", lookups.planStatusName(p.getRecoveryStatusId()));
        out.put("recoveryMode", p.getRecoveryMode());
        out.put("targetAmount", p.getTargetAmount());
        out.put("recoveredAmount", recovered);
        out.put("progressPercent", percent(recovered, p.getTargetAmount()));
        out.put("milestones", byStatus);
        out.put("daysLeft", p.getEndDate() == null ? null : java.time.temporal.ChronoUnit.DAYS.between(LocalDate.now(), p.getEndDate()));
        out.put("outcome", p.getOutcome());
        return out;
    }

    public RecoveryMilestone completeMilestone(Long milestoneId, BigDecimal achieved) {
        RecoveryMilestone m = milestones.findById(milestoneId)
                .orElseThrow(() -> new ResourceNotFoundException("Recovery milestone not found: " + milestoneId));
        if ("COMPLETED".equals(m.getStatus())) {
            throw new BusinessRuleException("Milestone is already completed");
        }
        RecoveryPlan p = plan(m.getRecoveryPlanId());
        requireOpen(p);
        m.setAchievedAmount(achieved);
        m.setStatus("COMPLETED");
        m.setCompletedAt(OffsetDateTime.now());
        RecoveryMilestone saved = milestones.save(m);
        recalculate(p);
        AuditTrail.record("STATUS_CHANGE", "RecoveryMilestone", milestoneId, "PENDING", "COMPLETED");
        return saved;
    }

    /** Recovered amount of a plan = sum of achieved amounts of its milestones. */
    public RecoveryPlan recalculate(RecoveryPlan p) {
        BigDecimal sum = milestones.findByRecoveryPlanId(p.getRecoveryPlanId()).stream()
                .map(RecoveryMilestone::getAchievedAmount).filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
        p.setRecoveredAmount(sum);
        return plans.save(p);
    }

    public RecoveryPlan close(Long planId, String outcome, String remarks) {
        RecoveryPlan p = plan(planId);
        requireOpen(p);
        p.setOutcome(outcome);
        p.setOutcomeRemarks(remarks);
        p.setClosedAt(OffsetDateTime.now());
        p.setRecoveryMode(false);
        p.setRecoveryStatusId(lookups.planStatus(CLOSED).getRecoveryStatusId());
        RecoveryPlan saved = plans.save(p);
        AuditTrail.record("STATUS_CHANGE", "RecoveryPlan", planId, null, Map.of("outcome", outcome, "remarks", remarks == null ? "" : remarks));
        notifications.notify(users.usersWithRole(Roles.SALES_MANAGER), "Recovery plan closed",
                "Recovery plan " + planId + " for distributor " + p.getDistributorId() + " closed: " + outcome);
        return saved;
    }

    /** Opens a plan in Recovery Mode (used by the automatic Recovery Mode job). */
    public RecoveryPlan openRecoveryMode(Long distributorId, BigDecimal targetAmount, String reason) {
        RecoveryPlan p = new RecoveryPlan();
        p.setDistributorId(distributorId);
        p.setRecoveryStatusId(lookups.planStatus(ACTIVE).getRecoveryStatusId());
        p.setTargetAmount(targetAmount);
        p.setStartDate(LocalDate.now());
        p.setEndDate(LocalDate.now().plusDays(90));
        p.setCreatedBy(CurrentUser.id());
        p.setCreatedAt(OffsetDateTime.now());
        p.setRecoveryMode(true);
        p.setRecoveredAmount(BigDecimal.ZERO);
        RecoveryPlan saved = plans.save(p);
        AuditTrail.record("CREATE", "RecoveryPlan", saved.getRecoveryPlanId(), null, saved);
        notifications.notify(users.usersWithRole(Roles.RECOVERY_MANAGER), "Recovery Mode",
                "Distributor " + distributorId + " is in Recovery Mode: " + reason + ". Plan " + saved.getRecoveryPlanId() + " opened.");
        return saved;
    }

    /** True when the distributor already has a plan that is not closed. */
    @Transactional(readOnly = true)
    public boolean hasOpenPlan(Long distributorId) {
        return plans.findByDistributorId(distributorId).stream().anyMatch(p -> p.getClosedAt() == null);
    }

    // ---- job

    @Override
    public String name() {
        return "recovery-milestone-check";
    }

    @Override
    public String description() {
        return "Marks pending recovery milestones past their due date as MISSED and notifies the recovery managers";
    }

    @Override
    public Map<String, Object> run() {
        int missed = 0;
        for (RecoveryMilestone m : milestones.findAll()) {
            if ("PENDING".equals(m.getStatus()) && m.getDueDate() != null && m.getDueDate().isBefore(LocalDate.now())) {
                m.setStatus("MISSED");
                milestones.save(m);
                missed++;
                notifications.notify(users.usersWithRole(Roles.RECOVERY_MANAGER), "Milestone missed",
                        "Milestone '" + m.getTitle() + "' of recovery plan " + m.getRecoveryPlanId() + " was due on " + m.getDueDate());
            }
        }
        return Map.of("milestonesMissed", missed);
    }

    private RecoveryPlan plan(Long id) {
        return plans.findById(id).orElseThrow(() -> new ResourceNotFoundException("Recovery plan not found: " + id));
    }

    private void requireOpen(RecoveryPlan p) {
        if (p.getClosedAt() != null) {
            throw new BusinessRuleException("Recovery plan " + p.getRecoveryPlanId() + " is closed (" + p.getOutcome() + ")");
        }
    }

    private static BigDecimal percent(BigDecimal part, BigDecimal total) {
        if (total == null || total.signum() == 0) {
            return null;
        }
        return part.multiply(BigDecimal.valueOf(100)).divide(total, 2, RoundingMode.HALF_UP);
    }
}

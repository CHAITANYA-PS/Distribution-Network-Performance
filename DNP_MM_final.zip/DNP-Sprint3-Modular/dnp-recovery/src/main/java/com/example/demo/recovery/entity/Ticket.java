package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import com.example.demo.systemadmin.entity.CreateDefault; import jakarta.validation.constraints.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="ticket",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Ticket implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="ticket_category_id")
 private Long ticketCategoryId;
 @Column(name="ticket_status_id")
 private Long ticketStatusId;
 @Column(name="ticket_priority_id")
 private Long ticketPriorityId;
 @Column(name="subject")
 private String subject;
 @Column(name="description")
 private String description;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="closed_at")
 private OffsetDateTime closedAt;
 // ---- V4 columns
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=30, message="Reference number must be at most 30 characters")
 @Column(name="reference_number")
 private String referenceNumber;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="assigned_to")
 private Long assignedTo;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="sla_due_at")
 private OffsetDateTime slaDueAt;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="resolved_at")
 private OffsetDateTime resolvedAt;
 @Size(max=2000, message="Findings must be at most 2000 characters")
 @Column(name="findings", length=2000)
 private String findings;
 @Size(max=2000, message="Corrective action must be at most 2000 characters")
 @Column(name="corrective_action", length=2000)
 private String correctiveAction;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("0")
 @PositiveOrZero(message="Reopen count must be 0 or greater")
 @Column(name="reopen_count")
 private Integer reopenCount;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @CreateDefault("0")
 @PositiveOrZero(message="Escalation level must be 0 or greater")
 @Column(name="escalation_level")
 private Integer escalationLevel;
}
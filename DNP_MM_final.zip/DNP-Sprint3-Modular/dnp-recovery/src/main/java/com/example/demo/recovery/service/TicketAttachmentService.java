package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.recovery.entity.TicketAttachment;
import com.example.demo.recovery.repository.TicketAttachmentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketAttachmentService extends AbstractCrudService<TicketAttachment, Long> {
    public TicketAttachmentService(TicketAttachmentRepository repository) {
        super(repository, TicketAttachment.class);
    }
}

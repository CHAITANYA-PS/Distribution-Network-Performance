package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Ticket status history (open, in progress, resolved, closed, reopened ...) (table dsphere.ticket_status_history, added in V4). */
@Entity @Table(name="ticket_status_history",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketStatusHistory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_status_history_id")
 private Long ticketStatusHistoryId;
 @NotNull(groups=OnCreate.class, message="Ticket id is required")
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="from_status_id")
 private Long fromStatusId;
 @NotNull(groups=OnCreate.class, message="To status id is required")
 @Column(name="to_status_id")
 private Long toStatusId;
 @Column(name="changed_by")
 private Long changedBy;
 @Size(max=500, message="Remarks must be at most 500 characters")
 @Column(name="remarks", length=500)
 private String remarks;
 @Column(name="changed_at")
 private OffsetDateTime changedAt;
}

package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.recovery.entity.TicketStatusHistory;
import com.example.demo.recovery.repository.TicketStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusHistoryService extends AbstractCrudService<TicketStatusHistory, Long> {
    public TicketStatusHistoryService(TicketStatusHistoryRepository repository) {
        super(repository, TicketStatusHistory.class);
    }
}

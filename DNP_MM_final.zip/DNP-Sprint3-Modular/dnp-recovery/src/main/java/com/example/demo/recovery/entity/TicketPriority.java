package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="ticket_priority",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketPriority implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_priority_id")
 private Long ticketPriorityId;
 @Column(name="priority_name")
 private String priorityName;
 @Column(name="severity_rank")
 private Integer severityRank;
}
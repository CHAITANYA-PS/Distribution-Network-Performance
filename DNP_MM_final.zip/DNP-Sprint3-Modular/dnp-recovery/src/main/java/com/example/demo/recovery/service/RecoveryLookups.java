package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.RecoveryPlanStatus;
import com.example.demo.recovery.entity.TicketCategory;
import com.example.demo.recovery.entity.TicketPriority;
import com.example.demo.recovery.entity.TicketStatus;
import com.example.demo.recovery.repository.RecoveryPlanStatusRepository;
import com.example.demo.recovery.repository.TicketCategoryRepository;
import com.example.demo.recovery.repository.TicketPriorityRepository;
import com.example.demo.recovery.repository.TicketStatusRepository;
import com.example.demo.systemadmin.service.LookupSupport;
import org.springframework.stereotype.Component;

/** Ticket / recovery status rows by name, created the first time they are needed. */
@Component
public class RecoveryLookups {
    public static final String OPEN = "Open";
    public static final String IN_PROGRESS = "In Progress";
    public static final String RESOLVED = "Resolved";
    public static final String CLOSED = "Closed";
    public static final String REOPENED = "Reopened";

    private final TicketStatusRepository ticketStatuses;
    private final TicketPriorityRepository priorities;
    private final TicketCategoryRepository categories;
    private final RecoveryPlanStatusRepository planStatuses;

    public RecoveryLookups(TicketStatusRepository ticketStatuses, TicketPriorityRepository priorities, TicketCategoryRepository categories,
            RecoveryPlanStatusRepository planStatuses) {
        this.ticketStatuses = ticketStatuses;
        this.priorities = priorities;
        this.categories = categories;
        this.planStatuses = planStatuses;
    }

    public TicketStatus status(String name) {
        int seq = switch (name) {
            case OPEN -> 1;
            case IN_PROGRESS -> 2;
            case RESOLVED -> 3;
            case CLOSED -> 4;
            default -> 5;
        };
        return LookupSupport.findOrCreate(ticketStatuses, TicketStatus::getStatusName, name, () -> {
            TicketStatus s = new TicketStatus();
            s.setStatusName(name);
            s.setSequenceNumber(seq);
            s.setIsTerminal(CLOSED.equals(name));
            return s;
        });
    }

    public String statusName(Long id) {
        return LookupSupport.nameOf(ticketStatuses, id, TicketStatus::getStatusName);
    }

    public TicketPriority priority(String name) {
        int rank = switch (name.toLowerCase()) {
            case "critical" -> 1;
            case "high" -> 2;
            case "medium" -> 3;
            default -> 4;
        };
        return LookupSupport.findOrCreate(priorities, TicketPriority::getPriorityName, name, () -> {
            TicketPriority p = new TicketPriority();
            p.setPriorityName(name);
            p.setSeverityRank(rank);
            return p;
        });
    }

    public TicketCategory category(String name) {
        return LookupSupport.findOrCreate(categories, TicketCategory::getCategoryName, name, () -> {
            TicketCategory c = new TicketCategory();
            c.setCategoryName(name);
            return c;
        });
    }

    public RecoveryPlanStatus planStatus(String name) {
        return LookupSupport.findOrCreate(planStatuses, RecoveryPlanStatus::getStatusName, name, () -> {
            RecoveryPlanStatus s = new RecoveryPlanStatus();
            s.setStatusName(name);
            return s;
        });
    }

    public String planStatusName(Long id) {
        return LookupSupport.nameOf(planStatuses, id, RecoveryPlanStatus::getStatusName);
    }
}

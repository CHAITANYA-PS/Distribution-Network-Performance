package com.example.demo.recovery.dto;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import jakarta.validation.constraints.Pattern;
import jakarta.validation.constraints.PositiveOrZero;
import jakarta.validation.constraints.Size;

import java.math.BigDecimal;

/** Request bodies of the ticket and recovery-plan actions. */
public final class RecoveryRequests {
    private RecoveryRequests() {
    }

    public record Assign(@NotNull(message = "assignedTo (user id) is required") Long assignedTo,
            @Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    public record StatusChange(@NotBlank(message = "Status is required") String status,
            @Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    public record Resolve(@NotBlank(message = "Findings are required") @Size(max = 2000) String findings,
            @NotBlank(message = "Corrective action is required") @Size(max = 2000) String correctiveAction) {
    }

    public record Remarks(@Size(max = 500, message = "Remarks must be at most 500 characters") String remarks) {
    }

    public record Reason(@NotBlank(message = "Reason is required") @Size(max = 500) String reason) {
    }

    public record Escalate(Long escalatedTo, @NotBlank(message = "Reason is required") @Size(max = 500) String reason) {
    }

    public record CompleteMilestone(@NotNull(message = "Achieved amount is required")
            @PositiveOrZero(message = "Achieved amount must be 0 or greater") BigDecimal achievedAmount) {
    }

    public record ClosePlan(@NotBlank(message = "Outcome is required")
            @Pattern(regexp = "RECOVERED|PARTIALLY_RECOVERED|NOT_RECOVERED|CANCELLED",
                    message = "Outcome must be one of: RECOVERED, PARTIALLY_RECOVERED, NOT_RECOVERED, CANCELLED") String outcome,
            @Size(max = 1000) String remarks) {
    }
}

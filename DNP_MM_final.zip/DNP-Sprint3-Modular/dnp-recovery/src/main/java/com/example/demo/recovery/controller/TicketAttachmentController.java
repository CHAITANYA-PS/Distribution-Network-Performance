package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketAttachmentDTO;
import com.example.demo.recovery.entity.TicketAttachment;
import com.example.demo.recovery.service.TicketAttachmentService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** TicketAttachment API. Upload through POST /api/v1/tickets/{id}/attachments; here: list, read, delete. */
@RestController
@RequestMapping("/api/v1/ticket-attachments")
public class TicketAttachmentController {
    private final TicketAttachmentService service;

    public TicketAttachmentController(TicketAttachmentService service) {
        this.service = service;
    }

    @Operation(summary = "Get one TicketAttachment by id")
    @GetMapping("/{id}")
    public TicketAttachmentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketAttachmentDTO.class);
    }

    @Operation(summary = "List / search TicketAttachment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketAttachmentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketAttachmentDTO.class));
        }
        Page<TicketAttachment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketAttachmentDTO.class));
    }

    @Operation(summary = "Delete TicketAttachment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

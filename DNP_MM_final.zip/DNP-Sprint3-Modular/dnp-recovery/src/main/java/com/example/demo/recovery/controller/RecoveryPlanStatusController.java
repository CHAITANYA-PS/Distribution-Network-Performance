package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.RecoveryPlanStatusDTO;
import com.example.demo.recovery.entity.RecoveryPlanStatus;
import com.example.demo.recovery.service.RecoveryPlanStatusService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/recovery-plan-statuses")
public class RecoveryPlanStatusController {
    private final RecoveryPlanStatusService service;

    public RecoveryPlanStatusController(RecoveryPlanStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create RecoveryPlanStatus")
    @PostMapping
    public ResponseEntity<RecoveryPlanStatusDTO> create(@Validated(OnCreate.class) @RequestBody RecoveryPlanStatusDTO body) {
        RecoveryPlanStatus saved = service.create(DtoMapper.toEntity(body, RecoveryPlanStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/recovery-plan-statuses/" + saved.getRecoveryStatusId())).body(DtoMapper.toDto(saved, RecoveryPlanStatusDTO.class));
    }

    @Operation(summary = "Get one RecoveryPlanStatus by id")
    @GetMapping("/{id}")
    public RecoveryPlanStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RecoveryPlanStatusDTO.class);
    }

    @Operation(summary = "List / search RecoveryPlanStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RecoveryPlanStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RecoveryPlanStatusDTO.class));
        }
        Page<RecoveryPlanStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RecoveryPlanStatusDTO.class));
    }

    @Operation(summary = "Update RecoveryPlanStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RecoveryPlanStatusDTO update(@PathVariable Long id, @Valid @RequestBody RecoveryPlanStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RecoveryPlanStatus.class)), RecoveryPlanStatusDTO.class);
    }

    @Operation(summary = "Delete RecoveryPlanStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

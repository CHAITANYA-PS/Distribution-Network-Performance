package com.example.demo.recovery.service;

import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.recovery.entity.TicketAssignmentHistory;
import com.example.demo.recovery.repository.TicketAssignmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketAssignmentHistoryService extends AbstractCrudService<TicketAssignmentHistory, Long> {
    public TicketAssignmentHistoryService(TicketAssignmentHistoryRepository repository) {
        super(repository, TicketAssignmentHistory.class);
    }
}

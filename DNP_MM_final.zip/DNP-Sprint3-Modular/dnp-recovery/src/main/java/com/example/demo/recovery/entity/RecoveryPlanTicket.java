package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="recovery_plan_ticket",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryPlanTicket implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="recovery_plan_ticket_id")
 private Long recoveryPlanTicketId;
 @Column(name="recovery_plan_id")
 private Long recoveryPlanId;
 @Column(name="ticket_id")
 private Long ticketId;
}
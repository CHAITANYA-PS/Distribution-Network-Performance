package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.RecoveryMilestoneDTO;
import com.example.demo.recovery.dto.RecoveryPlanDTO;
import com.example.demo.recovery.dto.RecoveryRequests;
import com.example.demo.recovery.service.RecoveryPlanWorkflowService;
import com.example.demo.systemadmin.dto.DtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.Map;

/** Recovery plan actions: progress, milestone completion, closing with an outcome. */
@RestController
@RequestMapping("/api/v1")
public class RecoveryWorkflowController {
    private final RecoveryPlanWorkflowService service;

    public RecoveryWorkflowController(RecoveryPlanWorkflowService service) {
        this.service = service;
    }

    @Operation(summary = "Progress of a recovery plan (recovered vs target, milestones)")
    @GetMapping("/recovery-plans/{id}/progress")
    public Map<String, Object> progress(@PathVariable Long id) {
        return service.progress(id);
    }

    @Operation(summary = "Close a recovery plan with its outcome")
    @PostMapping("/recovery-plans/{id}/close")
    public RecoveryPlanDTO close(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.ClosePlan body) {
        return DtoMapper.toDto(service.close(id, body.outcome(), body.remarks()), RecoveryPlanDTO.class);
    }

    @Operation(summary = "Complete a milestone with the amount achieved")
    @PostMapping("/recovery-milestones/{id}/complete")
    public RecoveryMilestoneDTO complete(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.CompleteMilestone body) {
        return DtoMapper.toDto(service.completeMilestone(id, body.achievedAmount()), RecoveryMilestoneDTO.class);
    }
}

package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketStatusDTO;
import com.example.demo.recovery.entity.TicketStatus;
import com.example.demo.recovery.service.TicketStatusService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/ticket-statuses")
public class TicketStatusController {
    private final TicketStatusService service;

    public TicketStatusController(TicketStatusService service) {
        this.service = service;
    }

    @Operation(summary = "Create TicketStatus")
    @PostMapping
    public ResponseEntity<TicketStatusDTO> create(@Validated(OnCreate.class) @RequestBody TicketStatusDTO body) {
        TicketStatus saved = service.create(DtoMapper.toEntity(body, TicketStatus.class));
        return ResponseEntity.created(URI.create("/api/v1/ticket-statuses/" + saved.getTicketStatusId())).body(DtoMapper.toDto(saved, TicketStatusDTO.class));
    }

    @Operation(summary = "Get one TicketStatus by id")
    @GetMapping("/{id}")
    public TicketStatusDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketStatusDTO.class);
    }

    @Operation(summary = "List / search TicketStatus", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketStatusDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketStatusDTO.class));
        }
        Page<TicketStatus> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketStatusDTO.class));
    }

    @Operation(summary = "Update TicketStatus (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public TicketStatusDTO update(@PathVariable Long id, @Valid @RequestBody TicketStatusDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, TicketStatus.class)), TicketStatusDTO.class);
    }

    @Operation(summary = "Delete TicketStatus")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

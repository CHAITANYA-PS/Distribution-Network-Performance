package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.SlaPolicy;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface SlaPolicyRepository extends JpaRepository<SlaPolicy, Long> {
    Optional<SlaPolicy> findByTicketPriorityId(Long ticketPriorityId);
}

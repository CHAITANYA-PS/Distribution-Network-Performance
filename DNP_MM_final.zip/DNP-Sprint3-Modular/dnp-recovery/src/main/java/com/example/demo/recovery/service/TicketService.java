package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.entity.TicketStatusHistory;
import com.example.demo.recovery.repository.SlaPolicyRepository;
import com.example.demo.recovery.repository.TicketRepository;
import com.example.demo.recovery.repository.TicketStatusHistoryRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.Objects;

/**
 * Tickets. On create: status Open (when not given), priority Medium and category General when missing,
 * a reference number (TKT-yyyy-nnnnnn) and the SLA due time from the priority's SLA policy.
 * The status is changed only through the lifecycle actions (assign, status, resolve, close, reopen, escalate).
 */
@Service
public class TicketService extends AbstractCrudService<Ticket, Long> {
    private final TicketRepository tickets;
    private final RecoveryLookups lookups;
    private final SlaPolicyRepository slas;
    private final SystemConfigService config;
    private final TicketStatusHistoryRepository statusHistory;

    public TicketService(TicketRepository repository, RecoveryLookups lookups, SlaPolicyRepository slas, SystemConfigService config,
            TicketStatusHistoryRepository statusHistory) {
        super(repository, Ticket.class);
        this.tickets = repository;
        this.lookups = lookups;
        this.slas = slas;
        this.config = config;
        this.statusHistory = statusHistory;
    }

    @Override
    protected void beforeCreate(Ticket t) {
        t.setTicketStatusId(lookups.status(RecoveryLookups.OPEN).getTicketStatusId());
        if (t.getTicketPriorityId() == null) {
            t.setTicketPriorityId(lookups.priority("Medium").getTicketPriorityId());
        }
        if (t.getTicketCategoryId() == null) {
            t.setTicketCategoryId(lookups.category("General").getTicketCategoryId());
        }
        if (t.getCreatedAt() == null) {
            t.setCreatedAt(OffsetDateTime.now());
        }
        t.setSlaDueAt(t.getCreatedAt().plusHours(slaHours(t.getTicketPriorityId())));
        t.setClosedAt(null);
        t.setResolvedAt(null);
    }

    @Override
    protected void afterCreate(Ticket saved) {
        saved.setReferenceNumber(LookupSupport.reference("TKT", saved.getTicketId()));
        tickets.save(saved);
        TicketStatusHistory h = new TicketStatusHistory();
        h.setTicketId(saved.getTicketId());
        h.setToStatusId(saved.getTicketStatusId());
        h.setChangedBy(CurrentUser.id());
        h.setRemarks("Ticket raised");
        h.setChangedAt(OffsetDateTime.now());
        statusHistory.save(h);
    }

    @Override
    protected void beforeUpdate(Long id, Ticket t, Ticket existing) {
        if (!Objects.equals(t.getTicketStatusId(), existing.getTicketStatusId())) {
            throw new BusinessRuleException("Change the status with POST /api/v1/tickets/" + id + "/status (or assign / resolve / close / reopen)");
        }
        if (!Objects.equals(t.getTicketPriorityId(), existing.getTicketPriorityId()) && existing.getCreatedAt() != null) {
            t.setSlaDueAt(existing.getCreatedAt().plusHours(slaHours(t.getTicketPriorityId())));
        }
    }

    @Override
    protected void beforeDelete(Ticket existing) {
        throw new BusinessRuleException("Tickets are kept for the audit trail; close the ticket instead of deleting it");
    }

    /** Resolution hours of the priority's SLA policy, or ticket.default.sla.hours. */
    public int slaHours(Long priorityId) {
        return slas.findByTicketPriorityId(priorityId).map(p -> p.getResolutionHours())
                .orElseGet(() -> config.integer(SystemConfigService.DEFAULT_SLA_HOURS, 72));
    }
}

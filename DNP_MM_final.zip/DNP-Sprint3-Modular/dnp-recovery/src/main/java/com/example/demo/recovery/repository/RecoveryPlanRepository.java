package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.RecoveryPlan;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface RecoveryPlanRepository extends JpaRepository<RecoveryPlan, Long> {
    List<RecoveryPlan> findByDistributorId(Long distributorId);
}

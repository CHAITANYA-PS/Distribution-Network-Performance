package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketAssignmentHistoryDTO;
import com.example.demo.recovery.entity.TicketAssignmentHistory;
import com.example.demo.recovery.service.TicketAssignmentHistoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** TicketAssignmentHistory API. Read-only: rows are written by the system (workflow actions), never typed in. */
@RestController
@RequestMapping("/api/v1/ticket-assignment-histories")
public class TicketAssignmentHistoryController {
    private final TicketAssignmentHistoryService service;

    public TicketAssignmentHistoryController(TicketAssignmentHistoryService service) {
        this.service = service;
    }

    @Operation(summary = "Get one TicketAssignmentHistory by id")
    @GetMapping("/{id}")
    public TicketAssignmentHistoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketAssignmentHistoryDTO.class);
    }

    @Operation(summary = "List / search TicketAssignmentHistory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketAssignmentHistoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketAssignmentHistoryDTO.class));
        }
        Page<TicketAssignmentHistory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketAssignmentHistoryDTO.class));
    }
}

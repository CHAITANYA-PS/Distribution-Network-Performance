package com.example.demo.recovery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request and response body for SlaPolicy. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class SlaPolicyDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long slaPolicyId;

    @NotNull(groups=OnCreate.class, message="Ticket priority id is required")
    private Long ticketPriorityId;

    @NotNull(groups=OnCreate.class, message="Response hours is required")
    @Positive(message="Response hours must be greater than 0")
    private Integer responseHours;

    @NotNull(groups=OnCreate.class, message="Resolution hours is required")
    @Positive(message="Resolution hours must be greater than 0")
    private Integer resolutionHours;
}

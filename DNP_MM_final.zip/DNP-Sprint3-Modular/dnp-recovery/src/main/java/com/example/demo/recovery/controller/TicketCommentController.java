package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketCommentDTO;
import com.example.demo.recovery.entity.TicketComment;
import com.example.demo.recovery.service.TicketCommentService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/ticket-comments")
public class TicketCommentController {
    private final TicketCommentService service;

    public TicketCommentController(TicketCommentService service) {
        this.service = service;
    }

    @Operation(summary = "Create TicketComment")
    @PostMapping
    public ResponseEntity<TicketCommentDTO> create(@Validated(OnCreate.class) @RequestBody TicketCommentDTO body) {
        TicketComment saved = service.create(DtoMapper.toEntity(body, TicketComment.class));
        return ResponseEntity.created(URI.create("/api/v1/ticket-comments/" + saved.getCommentId())).body(DtoMapper.toDto(saved, TicketCommentDTO.class));
    }

    @Operation(summary = "Get one TicketComment by id")
    @GetMapping("/{id}")
    public TicketCommentDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketCommentDTO.class);
    }

    @Operation(summary = "List / search TicketComment", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketCommentDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketCommentDTO.class));
        }
        Page<TicketComment> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketCommentDTO.class));
    }

    @Operation(summary = "Update TicketComment (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public TicketCommentDTO update(@PathVariable Long id, @Valid @RequestBody TicketCommentDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, TicketComment.class)), TicketCommentDTO.class);
    }

    @Operation(summary = "Delete TicketComment")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketCategoryDTO;
import com.example.demo.recovery.entity.TicketCategory;
import com.example.demo.recovery.service.TicketCategoryService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/ticket-categories")
public class TicketCategoryController {
    private final TicketCategoryService service;

    public TicketCategoryController(TicketCategoryService service) {
        this.service = service;
    }

    @Operation(summary = "Create TicketCategory")
    @PostMapping
    public ResponseEntity<TicketCategoryDTO> create(@Validated(OnCreate.class) @RequestBody TicketCategoryDTO body) {
        TicketCategory saved = service.create(DtoMapper.toEntity(body, TicketCategory.class));
        return ResponseEntity.created(URI.create("/api/v1/ticket-categories/" + saved.getTicketCategoryId())).body(DtoMapper.toDto(saved, TicketCategoryDTO.class));
    }

    @Operation(summary = "Get one TicketCategory by id")
    @GetMapping("/{id}")
    public TicketCategoryDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketCategoryDTO.class);
    }

    @Operation(summary = "List / search TicketCategory", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketCategoryDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketCategoryDTO.class));
        }
        Page<TicketCategory> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketCategoryDTO.class));
    }

    @Operation(summary = "Update TicketCategory (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public TicketCategoryDTO update(@PathVariable Long id, @Valid @RequestBody TicketCategoryDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, TicketCategory.class)), TicketCategoryDTO.class);
    }

    @Operation(summary = "Delete TicketCategory")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.recovery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * Request and response body for RecoveryPlan. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class RecoveryPlanDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long recoveryPlanId;

    private Long distributorId;

    private Long recoveryStatusId;

    private BigDecimal targetAmount;

    private LocalDate startDate;

    private LocalDate endDate;

    private Long createdBy;

    private OffsetDateTime createdAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Boolean recoveryMode;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Recovered amount must be 0 or greater")
    private BigDecimal recoveredAmount;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=30, message="Outcome must be at most 30 characters")
    @Pattern(regexp="RECOVERED|PARTIALLY_RECOVERED|NOT_RECOVERED|CANCELLED", message="Outcome must be one of: RECOVERED, PARTIALLY_RECOVERED, NOT_RECOVERED, CANCELLED")
    private String outcome;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=1000, message="Outcome remarks must be at most 1000 characters")
    private String outcomeRemarks;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime closedAt;
}

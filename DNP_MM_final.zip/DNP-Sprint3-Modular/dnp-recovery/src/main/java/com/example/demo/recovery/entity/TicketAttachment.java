package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.example.demo.systemadmin.entity.OnCreate;
import com.example.demo.systemadmin.entity.CreateDefault;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate; import java.time.OffsetDateTime;
/** Ticket evidence files (photos, PDFs); the file itself is stored on disk (dnp.upload-dir) (table dsphere.ticket_attachment, added in V4). */
@Entity @Table(name="ticket_attachment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketAttachment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="attachment_id")
 private Long attachmentId;
 @NotNull(groups=OnCreate.class, message="Ticket id is required")
 @Column(name="ticket_id")
 private Long ticketId;
 @NotBlank(groups=OnCreate.class, message="File name is required")
 @Size(max=255, message="File name must be at most 255 characters")
 @Column(name="file_name")
 private String fileName;
 @Size(max=100, message="Content type must be at most 100 characters")
 @Column(name="content_type")
 private String contentType;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @PositiveOrZero(message="Size bytes must be 0 or greater")
 @Column(name="size_bytes")
 private Long sizeBytes;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Size(max=500, message="Storage path must be at most 500 characters")
 @Column(name="storage_path", length=500)
 private String storagePath;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="uploaded_by")
 private Long uploadedBy;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Column(name="uploaded_at")
 private OffsetDateTime uploadedAt;
}

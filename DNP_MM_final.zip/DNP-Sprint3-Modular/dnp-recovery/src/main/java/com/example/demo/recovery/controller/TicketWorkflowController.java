package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.EscalationDTO;
import com.example.demo.recovery.dto.RecoveryRequests;
import com.example.demo.recovery.dto.TicketAssignmentHistoryDTO;
import com.example.demo.recovery.dto.TicketAttachmentDTO;
import com.example.demo.recovery.dto.TicketDTO;
import com.example.demo.recovery.dto.TicketStatusHistoryDTO;
import com.example.demo.recovery.entity.Escalation;
import com.example.demo.recovery.entity.TicketAssignmentHistory;
import com.example.demo.recovery.entity.TicketAttachment;
import com.example.demo.recovery.entity.TicketStatusHistory;
import com.example.demo.recovery.service.TicketWorkflowService;
import com.example.demo.systemadmin.dto.DtoMapper;
import io.swagger.v3.oas.annotations.Operation;
import jakarta.validation.Valid;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseStatus;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import java.util.List;
import java.util.Map;

/** Ticket lifecycle actions (the CRUD API stays in TicketController). */
@RestController
@RequestMapping("/api/v1/tickets")
public class TicketWorkflowController {
    private final TicketWorkflowService service;

    public TicketWorkflowController(TicketWorkflowService service) {
        this.service = service;
    }

    /** Full history of a ticket. */
    public record TicketHistory(Long ticketId, String referenceNumber, List<TicketStatusHistoryDTO> statusChanges,
            List<TicketAssignmentHistoryDTO> assignments, List<EscalationDTO> escalations) {
    }

    @Operation(summary = "Assign or reassign a ticket", description = "An Open ticket moves to In Progress when it is assigned.")
    @PostMapping("/{id}/assign")
    public TicketDTO assign(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.Assign body) {
        return DtoMapper.toDto(service.assign(id, body.assignedTo(), body.remarks()), TicketDTO.class);
    }

    @Operation(summary = "Change ticket status", description = "Open -> In Progress -> Resolved -> Closed; Resolved/Closed -> Reopened.")
    @PostMapping("/{id}/status")
    public TicketDTO status(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.StatusChange body) {
        return DtoMapper.toDto(service.changeStatus(id, body.status(), body.remarks()), TicketDTO.class);
    }

    @Operation(summary = "Resolve a ticket with findings and corrective action")
    @PostMapping("/{id}/resolve")
    public TicketDTO resolve(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.Resolve body) {
        return DtoMapper.toDto(service.resolve(id, body.findings(), body.correctiveAction()), TicketDTO.class);
    }

    @Operation(summary = "Close a resolved ticket")
    @PostMapping("/{id}/close")
    public TicketDTO close(@PathVariable Long id, @RequestBody(required = false) RecoveryRequests.Remarks body) {
        return DtoMapper.toDto(service.close(id, body == null ? null : body.remarks()), TicketDTO.class);
    }

    @Operation(summary = "Reopen a resolved or closed ticket")
    @PostMapping("/{id}/reopen")
    public TicketDTO reopen(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.Reason body) {
        return DtoMapper.toDto(service.reopen(id, body.reason()), TicketDTO.class);
    }

    @Operation(summary = "Escalate a ticket now", description = "escalatedTo is optional: by default a Recovery Manager (level 1) or System Admin.")
    @PostMapping("/{id}/escalate")
    @ResponseStatus(HttpStatus.CREATED)
    public EscalationDTO escalate(@PathVariable Long id, @Valid @RequestBody RecoveryRequests.Escalate body) {
        return DtoMapper.toDto(service.escalate(id, body.escalatedTo(), body.reason()), EscalationDTO.class);
    }

    @Operation(summary = "Status, assignment and escalation history of a ticket")
    @GetMapping("/{id}/history")
    @SuppressWarnings("unchecked")
    public TicketHistory history(@PathVariable Long id) {
        Map<String, Object> h = service.history(id);
        return new TicketHistory(id, (String) h.get("referenceNumber"),
                DtoMapper.toDtoList((List<TicketStatusHistory>) h.get("statusChanges"), TicketStatusHistoryDTO.class),
                DtoMapper.toDtoList((List<TicketAssignmentHistory>) h.get("assignments"), TicketAssignmentHistoryDTO.class),
                DtoMapper.toDtoList((List<Escalation>) h.get("escalations"), EscalationDTO.class));
    }

    @Operation(summary = "Upload an evidence file (PDF, image or text, up to 5 MB)")
    @PostMapping(value = "/{id}/attachments", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    @ResponseStatus(HttpStatus.CREATED)
    public TicketAttachmentDTO upload(@PathVariable Long id, @RequestParam("file") MultipartFile file) {
        return DtoMapper.toDto(service.upload(id, file), TicketAttachmentDTO.class);
    }

    @Operation(summary = "Evidence files of a ticket")
    @GetMapping("/{id}/attachments")
    public List<TicketAttachmentDTO> attachments(@PathVariable Long id) {
        return DtoMapper.toDtoList(service.attachments(id), TicketAttachmentDTO.class);
    }

    @Operation(summary = "Download an evidence file")
    @GetMapping("/{id}/attachments/{attachmentId}/download")
    public ResponseEntity<byte[]> download(@PathVariable Long id, @PathVariable Long attachmentId) {
        Map.Entry<TicketAttachment, byte[]> f = service.download(id, attachmentId);
        return ResponseEntity.ok()
                .header(HttpHeaders.CONTENT_DISPOSITION, "attachment; filename=\"" + f.getKey().getFileName() + "\"")
                .contentType(MediaType.parseMediaType(f.getKey().getContentType() == null ? "application/octet-stream" : f.getKey().getContentType()))
                .body(f.getValue());
    }
}

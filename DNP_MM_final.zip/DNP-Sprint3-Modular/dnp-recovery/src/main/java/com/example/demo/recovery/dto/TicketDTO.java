package com.example.demo.recovery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for Ticket. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class TicketDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long ticketId;

    private Long distributorId;

    private Long ticketCategoryId;

    private Long ticketStatusId;

    private Long ticketPriorityId;

    private String subject;

    private String description;

    private Long createdBy;

    private OffsetDateTime createdAt;

    private OffsetDateTime closedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=30, message="Reference number must be at most 30 characters")
    private String referenceNumber;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long assignedTo;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime slaDueAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime resolvedAt;

    @Size(max=2000, message="Findings must be at most 2000 characters")
    private String findings;

    @Size(max=2000, message="Corrective action must be at most 2000 characters")
    private String correctiveAction;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Reopen count must be 0 or greater")
    private Integer reopenCount;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Escalation level must be 0 or greater")
    private Integer escalationLevel;
}

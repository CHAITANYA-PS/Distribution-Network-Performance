package com.example.demo.recovery.entity;
import com.example.demo.systemadmin.entity.locking.VersionedEntity;
import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="ticket_comment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketComment implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @JsonProperty(access=JsonProperty.Access.READ_ONLY)
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="comment_id")
 private Long commentId;
 @Column(name="ticket_id")
 private Long ticketId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="comment_text")
 private String commentText;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
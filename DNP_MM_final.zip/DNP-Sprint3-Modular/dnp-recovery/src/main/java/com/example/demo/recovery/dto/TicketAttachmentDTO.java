package com.example.demo.recovery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for TicketAttachment. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class TicketAttachmentDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long attachmentId;

    @NotNull(groups=OnCreate.class, message="Ticket id is required")
    private Long ticketId;

    @NotBlank(groups=OnCreate.class, message="File name is required")
    @Size(max=255, message="File name must be at most 255 characters")
    private String fileName;

    @Size(max=100, message="Content type must be at most 100 characters")
    private String contentType;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @PositiveOrZero(message="Size bytes must be 0 or greater")
    private Long sizeBytes;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=500, message="Storage path must be at most 500 characters")
    private String storagePath;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long uploadedBy;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime uploadedAt;
}

package com.example.demo.recovery.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for TicketAssignmentHistory. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class TicketAssignmentHistoryDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long assignmentId;

    @NotNull(groups=OnCreate.class, message="Ticket id is required")
    private Long ticketId;

    @NotNull(groups=OnCreate.class, message="Assigned to is required")
    private Long assignedTo;

    private Long assignedBy;

    private OffsetDateTime assignedAt;

    @Size(max=500, message="Remarks must be at most 500 characters")
    private String remarks;
}

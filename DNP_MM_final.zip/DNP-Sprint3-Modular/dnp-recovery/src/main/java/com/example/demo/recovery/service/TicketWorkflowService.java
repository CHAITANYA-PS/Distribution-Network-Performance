package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.Escalation;
import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.entity.TicketAssignmentHistory;
import com.example.demo.recovery.entity.TicketAttachment;
import com.example.demo.recovery.entity.TicketStatus;
import com.example.demo.recovery.entity.TicketStatusHistory;
import com.example.demo.recovery.repository.EscalationRepository;
import com.example.demo.recovery.repository.TicketAssignmentHistoryRepository;
import com.example.demo.recovery.repository.TicketAttachmentRepository;
import com.example.demo.recovery.repository.TicketRepository;
import com.example.demo.recovery.repository.TicketStatusHistoryRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.InvalidRequestException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.TicketOpener;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Set;
import java.util.UUID;

/**
 * Ticket lifecycle: assign / reassign (with history), status changes along the allowed flow, resolve with
 * findings and corrective action, close, reopen, manual escalation, evidence files, SLA escalation job.
 * <pre>
 *   Open -> In Progress -> Resolved -> Closed
 *   Resolved / Closed -> Reopened -> In Progress / Resolved
 * </pre>
 */
@Service
@Transactional
public class TicketWorkflowService implements TicketOpener, BackgroundJob {
    private static final Map<String, Set<String>> FLOW = Map.of(
            "open", Set.of(RecoveryLookups.IN_PROGRESS, RecoveryLookups.RESOLVED),
            "inprogress", Set.of(RecoveryLookups.RESOLVED),
            "reopened", Set.of(RecoveryLookups.IN_PROGRESS, RecoveryLookups.RESOLVED),
            "resolved", Set.of(RecoveryLookups.CLOSED, RecoveryLookups.REOPENED),
            "closed", Set.of(RecoveryLookups.REOPENED));
    private static final Set<String> ALLOWED_TYPES = Set.of("application/pdf", "image/png", "image/jpeg", "image/gif", "image/webp", "text/plain");
    private static final int MAX_LEVEL = 3;

    private final TicketRepository tickets;
    private final TicketService ticketService;
    private final RecoveryLookups lookups;
    private final TicketStatusHistoryRepository statusHistory;
    private final TicketAssignmentHistoryRepository assignments;
    private final TicketAttachmentRepository attachments;
    private final EscalationRepository escalations;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;
    private final Path uploadDir;

    public TicketWorkflowService(TicketRepository tickets, TicketService ticketService, RecoveryLookups lookups,
            TicketStatusHistoryRepository statusHistory, TicketAssignmentHistoryRepository assignments, TicketAttachmentRepository attachments,
            EscalationRepository escalations, NotificationGateway notifications, UserRoleResolver users,
            @Value("${dnp.upload-dir:uploads}") String uploadDir) {
        this.tickets = tickets;
        this.ticketService = ticketService;
        this.lookups = lookups;
        this.statusHistory = statusHistory;
        this.assignments = assignments;
        this.attachments = attachments;
        this.escalations = escalations;
        this.notifications = notifications;
        this.users = users;
        this.uploadDir = Paths.get(uploadDir).toAbsolutePath().normalize();
    }

    // ------------------------------------------------------------------ actions

    public Ticket assign(Long id, Long assignedTo, String remarks) {
        Ticket t = load(id);
        requireNotClosed(t);
        Long previous = t.getAssignedTo();
        t.setAssignedTo(assignedTo);
        TicketAssignmentHistory h = new TicketAssignmentHistory();
        h.setTicketId(id);
        h.setAssignedTo(assignedTo);
        h.setAssignedBy(CurrentUser.id());
        h.setAssignedAt(OffsetDateTime.now());
        h.setRemarks(previous == null ? remarks : "Reassigned from user " + previous + (remarks == null ? "" : ": " + remarks));
        assignments.save(h);
        Ticket saved = tickets.save(t);
        if (LookupSupport.same(lookups.statusName(t.getTicketStatusId()), RecoveryLookups.OPEN)) {
            saved = changeStatus(id, RecoveryLookups.IN_PROGRESS, "Assigned to user " + assignedTo);
        }
        notifications.notify(assignedTo, "Ticket assigned", "Ticket " + ref(t) + " (" + t.getSubject() + ") is assigned to you");
        return saved;
    }

    public Ticket changeStatus(Long id, String target, String remarks) {
        Ticket t = load(id);
        String current = lookups.statusName(t.getTicketStatusId());
        String key = current == null ? "open" : current.replaceAll("[\\s_-]", "").toLowerCase(Locale.ROOT);
        Set<String> allowed = FLOW.getOrDefault(key, Set.of());
        String wanted = allowed.stream().filter(s -> LookupSupport.same(s, target)).findFirst()
                .orElseThrow(() -> new BusinessRuleException("Ticket is " + current + "; it can move to " + allowed + ", not to " + target));
        if (RecoveryLookups.RESOLVED.equals(wanted) && (t.getFindings() == null || t.getCorrectiveAction() == null)) {
            throw new BusinessRuleException("Use POST /api/v1/tickets/" + id + "/resolve with findings and corrective action");
        }
        TicketStatus to = lookups.status(wanted);
        Long from = t.getTicketStatusId();
        t.setTicketStatusId(to.getTicketStatusId());
        if (RecoveryLookups.CLOSED.equals(wanted)) {
            t.setClosedAt(OffsetDateTime.now());
        }
        if (RecoveryLookups.REOPENED.equals(wanted)) {
            t.setReopenCount((t.getReopenCount() == null ? 0 : t.getReopenCount()) + 1);
            t.setClosedAt(null);
            t.setResolvedAt(null);
            t.setSlaDueAt(OffsetDateTime.now().plusHours(ticketService.slaHours(t.getTicketPriorityId())));
            t.setEscalationLevel(0);
        }
        Ticket saved = tickets.save(t);
        TicketStatusHistory h = new TicketStatusHistory();
        h.setTicketId(id);
        h.setFromStatusId(from);
        h.setToStatusId(to.getTicketStatusId());
        h.setChangedBy(CurrentUser.id());
        h.setRemarks(remarks != null && remarks.length() > 500 ? remarks.substring(0, 500) : remarks);
        h.setChangedAt(OffsetDateTime.now());
        statusHistory.save(h);
        AuditTrail.record("STATUS_CHANGE", "Ticket", id, current, wanted);
        notifyRaiser(t, "is now " + wanted + (remarks == null ? "" : ": " + remarks));
        return saved;
    }

    public Ticket resolve(Long id, String findings, String correctiveAction) {
        Ticket t = load(id);
        t.setFindings(findings);
        t.setCorrectiveAction(correctiveAction);
        t.setResolvedAt(OffsetDateTime.now());
        tickets.save(t);
        return changeStatus(id, RecoveryLookups.RESOLVED, "Resolved: " + correctiveAction);
    }

    public Ticket close(Long id, String remarks) {
        return changeStatus(id, RecoveryLookups.CLOSED, remarks == null ? "Closed" : remarks);
    }

    public Ticket reopen(Long id, String reason) {
        return changeStatus(id, RecoveryLookups.REOPENED, "Reopened: " + reason);
    }

    public Escalation escalate(Long id, Long escalatedTo, String reason) {
        Ticket t = load(id);
        requireNotClosed(t);
        return doEscalate(t, escalatedTo, reason);
    }

    @Transactional(readOnly = true)
    public Map<String, Object> history(Long id) {
        Ticket t = load(id);
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("ticketId", id);
        out.put("referenceNumber", t.getReferenceNumber());
        out.put("statusChanges", statusHistory.findByTicketIdOrderByChangedAtAsc(id));
        out.put("assignments", assignments.findByTicketIdOrderByAssignedAtAsc(id));
        out.put("escalations", escalations.findByTicketId(id));
        return out;
    }

    // ------------------------------------------------------------------ evidence files

    public TicketAttachment upload(Long id, MultipartFile file) {
        Ticket t = load(id);
        if (file == null || file.isEmpty()) {
            throw new InvalidRequestException("Choose a file to upload");
        }
        String type = file.getContentType() == null ? "" : file.getContentType().toLowerCase(Locale.ROOT);
        if (!ALLOWED_TYPES.contains(type)) {
            throw new InvalidRequestException("File type " + type + " is not allowed. Allowed: PDF, PNG, JPEG, GIF, WEBP, TXT");
        }
        String original = file.getOriginalFilename() == null ? "file" : Paths.get(file.getOriginalFilename()).getFileName().toString();
        String safe = original.replaceAll("[^A-Za-z0-9._-]", "_");
        Path dir = uploadDir.resolve("tickets").resolve(String.valueOf(id));
        Path target = dir.resolve(UUID.randomUUID() + "-" + safe).normalize();
        if (!target.startsWith(uploadDir)) {
            throw new InvalidRequestException("Invalid file name");
        }
        try {
            Files.createDirectories(dir);
            file.transferTo(target);
        } catch (IOException e) {
            throw new IllegalStateException("File could not be stored: " + e.getMessage(), e);
        }
        TicketAttachment a = new TicketAttachment();
        a.setTicketId(t.getTicketId());
        a.setFileName(safe.length() > 255 ? safe.substring(0, 255) : safe);
        a.setContentType(type);
        a.setSizeBytes(file.getSize());
        a.setStoragePath(uploadDir.relativize(target).toString());
        a.setUploadedBy(CurrentUser.id());
        a.setUploadedAt(OffsetDateTime.now());
        TicketAttachment saved = attachments.save(a);
        AuditTrail.record("CREATE", "TicketAttachment", saved.getAttachmentId(), null, saved);
        return saved;
    }

    @Transactional(readOnly = true)
    public List<TicketAttachment> attachments(Long id) {
        load(id);
        return attachments.findByTicketId(id);
    }

    /** File bytes of an attachment, with its name and type. */
    @Transactional(readOnly = true)
    public Map.Entry<TicketAttachment, byte[]> download(Long id, Long attachmentId) {
        load(id);
        TicketAttachment a = attachments.findById(attachmentId).filter(x -> Objects.equals(x.getTicketId(), id))
                .orElseThrow(() -> new ResourceNotFoundException("Attachment " + attachmentId + " not found on ticket " + id));
        Path p = uploadDir.resolve(a.getStoragePath()).normalize();
        if (!p.startsWith(uploadDir) || !Files.exists(p)) {
            throw new ResourceNotFoundException("The stored file of attachment " + attachmentId + " is missing");
        }
        try {
            return Map.entry(a, Files.readAllBytes(p));
        } catch (IOException e) {
            throw new IllegalStateException("File could not be read: " + e.getMessage(), e);
        }
    }

    // ------------------------------------------------------------------ TicketOpener (system tickets)

    @Override
    public Long openSystemTicket(Long distributorId, String category, String priority, String subject, String description) {
        Ticket t = new Ticket();
        t.setDistributorId(distributorId);
        t.setTicketCategoryId(lookups.category(category).getTicketCategoryId());
        t.setTicketPriorityId(lookups.priority(priority).getTicketPriorityId());
        t.setSubject(subject.length() > 200 ? subject.substring(0, 200) : subject);
        t.setDescription(description);
        Ticket saved = ticketService.create(t);
        notifications.notify(users.usersWithRole(Roles.RECOVERY_MANAGER), "New ticket", "Ticket " + saved.getReferenceNumber() + " opened: " + subject);
        return saved.getTicketId();
    }

    // ------------------------------------------------------------------ SLA escalation job

    @Override
    public String name() {
        return "ticket-sla-escalation";
    }

    @Override
    public String description() {
        return "Escalates open tickets past their SLA due time (one level per 24 hours overdue, up to level 3)";
    }

    @Override
    public Map<String, Object> run() {
        OffsetDateTime now = OffsetDateTime.now();
        int escalated = 0;
        int overdue = 0;
        for (Ticket t : tickets.findAll()) {
            String status = lookups.statusName(t.getTicketStatusId());
            if (t.getSlaDueAt() == null || LookupSupport.same(status, RecoveryLookups.RESOLVED) || LookupSupport.same(status, RecoveryLookups.CLOSED)) {
                continue;
            }
            if (now.isAfter(t.getSlaDueAt())) {
                overdue++;
                int level = t.getEscalationLevel() == null ? 0 : t.getEscalationLevel();
                if (level < MAX_LEVEL && now.isAfter(t.getSlaDueAt().plusHours(24L * level))) {
                    doEscalate(t, null, "SLA breached: due " + t.getSlaDueAt().toLocalDateTime());
                    escalated++;
                }
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("overdueTickets", overdue);
        out.put("escalated", escalated);
        return out;
    }

    // ------------------------------------------------------------------ helpers

    private Escalation doEscalate(Ticket t, Long escalatedTo, String reason) {
        int level = (t.getEscalationLevel() == null ? 0 : t.getEscalationLevel()) + 1;
        Long to = escalatedTo;
        if (to == null) {
            List<Long> managers = new ArrayList<>(users.usersWithRole(level >= 2 ? Roles.SYSTEM_ADMIN : Roles.RECOVERY_MANAGER));
            if (managers.isEmpty()) {
                managers.addAll(users.usersWithRole(Roles.SYSTEM_ADMIN));
            }
            to = managers.isEmpty() ? null : managers.get(0);
        }
        Escalation e = new Escalation();
        e.setTicketId(t.getTicketId());
        e.setEscalatedTo(to);
        e.setEscalationLevel(level);
        e.setReason(reason != null && reason.length() > 500 ? reason.substring(0, 500) : reason);
        e.setCreatedAt(OffsetDateTime.now());
        Escalation saved = escalations.save(e);
        t.setEscalationLevel(level);
        tickets.save(t);
        AuditTrail.record("UPDATE", "Ticket", t.getTicketId(), null, Map.of("escalationLevel", level, "reason", String.valueOf(reason)));
        notifications.notify(to, "Ticket escalation", "Ticket " + ref(t) + " escalated to level " + level + ": " + reason);
        return saved;
    }

    private Ticket load(Long id) {
        return ticketService.get(id);
    }

    private void requireNotClosed(Ticket t) {
        if (LookupSupport.same(lookups.statusName(t.getTicketStatusId()), RecoveryLookups.CLOSED)) {
            throw new BusinessRuleException("Ticket " + ref(t) + " is closed; reopen it first");
        }
    }

    private void notifyRaiser(Ticket t, String what) {
        if (t.getCreatedBy() != null) {
            notifications.notify(t.getCreatedBy(), "Ticket update", "Ticket " + ref(t) + " " + what);
        }
    }

    private static String ref(Ticket t) {
        return t.getReferenceNumber() == null ? String.valueOf(t.getTicketId()) : t.getReferenceNumber();
    }
}

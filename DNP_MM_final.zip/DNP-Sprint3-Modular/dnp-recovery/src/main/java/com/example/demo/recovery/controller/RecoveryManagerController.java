package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.RecoveryManagerDTO;
import com.example.demo.recovery.entity.RecoveryManager;
import com.example.demo.recovery.service.RecoveryManagerService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/recovery-managers")
public class RecoveryManagerController {
    private final RecoveryManagerService service;

    public RecoveryManagerController(RecoveryManagerService service) {
        this.service = service;
    }

    @Operation(summary = "Create RecoveryManager")
    @PostMapping
    public ResponseEntity<RecoveryManagerDTO> create(@Validated(OnCreate.class) @RequestBody RecoveryManagerDTO body) {
        RecoveryManager saved = service.create(DtoMapper.toEntity(body, RecoveryManager.class));
        return ResponseEntity.created(URI.create("/api/v1/recovery-managers/" + saved.getUserId())).body(DtoMapper.toDto(saved, RecoveryManagerDTO.class));
    }

    @Operation(summary = "Get one RecoveryManager by id")
    @GetMapping("/{id}")
    public RecoveryManagerDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RecoveryManagerDTO.class);
    }

    @Operation(summary = "List / search RecoveryManager", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RecoveryManagerDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RecoveryManagerDTO.class));
        }
        Page<RecoveryManager> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RecoveryManagerDTO.class));
    }

    @Operation(summary = "Update RecoveryManager (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RecoveryManagerDTO update(@PathVariable Long id, @Valid @RequestBody RecoveryManagerDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RecoveryManager.class)), RecoveryManagerDTO.class);
    }

    @Operation(summary = "Delete RecoveryManager")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

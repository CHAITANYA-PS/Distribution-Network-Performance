package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.RecoveryMilestoneDTO;
import com.example.demo.recovery.entity.RecoveryMilestone;
import com.example.demo.recovery.service.RecoveryMilestoneService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

/** RecoveryMilestone API. Create, read, update, delete. */
@RestController
@RequestMapping("/api/v1/recovery-milestones")
public class RecoveryMilestoneController {
    private final RecoveryMilestoneService service;

    public RecoveryMilestoneController(RecoveryMilestoneService service) {
        this.service = service;
    }

    @Operation(summary = "Create RecoveryMilestone")
    @PostMapping
    public ResponseEntity<RecoveryMilestoneDTO> create(@Validated(OnCreate.class) @RequestBody RecoveryMilestoneDTO body) {
        RecoveryMilestone saved = service.create(DtoMapper.toEntity(body, RecoveryMilestone.class));
        return ResponseEntity.created(URI.create("/api/v1/recovery-milestones/" + saved.getMilestoneId())).body(DtoMapper.toDto(saved, RecoveryMilestoneDTO.class));
    }

    @Operation(summary = "Get one RecoveryMilestone by id")
    @GetMapping("/{id}")
    public RecoveryMilestoneDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), RecoveryMilestoneDTO.class);
    }

    @Operation(summary = "List / search RecoveryMilestone", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<RecoveryMilestoneDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), RecoveryMilestoneDTO.class));
        }
        Page<RecoveryMilestone> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), RecoveryMilestoneDTO.class));
    }

    @Operation(summary = "Update RecoveryMilestone (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public RecoveryMilestoneDTO update(@PathVariable Long id, @Valid @RequestBody RecoveryMilestoneDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, RecoveryMilestone.class)), RecoveryMilestoneDTO.class);
    }

    @Operation(summary = "Delete RecoveryMilestone")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

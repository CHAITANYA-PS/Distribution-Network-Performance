package com.example.demo.recovery.controller;

import com.example.demo.recovery.dto.TicketDTO;
import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.service.TicketService;
import com.example.demo.systemadmin.dto.DtoMapper;
import com.example.demo.systemadmin.entity.OnCreate;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import jakarta.validation.Valid;
import java.net.URI;
import java.util.List;
import java.util.Map;
import org.springframework.data.domain.Page;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/tickets")
public class TicketController {
    private final TicketService service;

    public TicketController(TicketService service) {
        this.service = service;
    }

    @Operation(summary = "Create Ticket")
    @PostMapping
    public ResponseEntity<TicketDTO> create(@Validated(OnCreate.class) @RequestBody TicketDTO body) {
        Ticket saved = service.create(DtoMapper.toEntity(body, Ticket.class));
        return ResponseEntity.created(URI.create("/api/v1/tickets/" + saved.getTicketId())).body(DtoMapper.toDto(saved, TicketDTO.class));
    }

    @Operation(summary = "Get one Ticket by id")
    @GetMapping("/{id}")
    public TicketDTO get(@PathVariable Long id) {
        return DtoMapper.toDto(service.get(id), TicketDTO.class);
    }

    @Operation(summary = "List / search Ticket", description = "page/size/sort are optional (sort=field or field,desc). Filters: any field of the record, e.g. " + "{\"status\":\"Active\"} (text matches when it contains the value, case-insensitive).")
    @GetMapping
    public ResponseEntity<List<TicketDTO>> getAll(@RequestParam(required = false) Integer page,
            @RequestParam(required = false) Integer size, @RequestParam(required = false) String sort,
            @Parameter(description = "Optional filters, any field: value") @RequestParam Map<String, String> filters) {
        if (filters.isEmpty()) {
            return ResponseEntity.ok(DtoMapper.toDtoList(service.getAll(), TicketDTO.class));
        }
        Page<Ticket> result = service.search(filters);
        return ResponseEntity.ok().header("X-Total-Count", String.valueOf(result.getTotalElements()))
                .body(DtoMapper.toDtoList(result.getContent(), TicketDTO.class));
    }

    @Operation(summary = "Update Ticket (send only the fields to change, plus version)")
    @PutMapping("/{id}")
    public TicketDTO update(@PathVariable Long id, @Valid @RequestBody TicketDTO body) {
        return DtoMapper.toDto(service.update(id, DtoMapper.toEntity(body, Ticket.class)), TicketDTO.class);
    }

    @Operation(summary = "Delete Ticket")
    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

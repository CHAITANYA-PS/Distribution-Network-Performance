package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.RecoveryPlan;
import com.example.demo.recovery.repository.RecoveryPlanRepository;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

/** Recovery plans. A new plan is Active unless a status is given; the end date cannot be before the start date. */
@Service
public class RecoveryPlanService extends AbstractCrudService<RecoveryPlan, Long> {
    private final RecoveryLookups lookups;

    public RecoveryPlanService(RecoveryPlanRepository repository, RecoveryLookups lookups) {
        super(repository, RecoveryPlan.class);
        this.lookups = lookups;
    }

    @Override
    protected void beforeCreate(RecoveryPlan p) {
        if (p.getRecoveryStatusId() == null) {
            p.setRecoveryStatusId(lookups.planStatus(RecoveryPlanWorkflowService.ACTIVE).getRecoveryStatusId());
        }
        checkDates(p);
    }

    @Override
    protected void beforeUpdate(Long id, RecoveryPlan p, RecoveryPlan existing) {
        if (existing.getClosedAt() != null) {
            throw new BusinessRuleException("Recovery plan " + id + " is closed and cannot be changed");
        }
        checkDates(p);
    }

    private static void checkDates(RecoveryPlan p) {
        if (p.getStartDate() != null && p.getEndDate() != null && p.getEndDate().isBefore(p.getStartDate())) {
            throw new BusinessRuleException("End date cannot be before the start date");
        }
    }
}

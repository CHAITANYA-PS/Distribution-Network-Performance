package com.example.demo.recovery.repository;

import com.example.demo.recovery.entity.RecoveryMilestone;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface RecoveryMilestoneRepository extends JpaRepository<RecoveryMilestone, Long> {
    List<RecoveryMilestone> findByRecoveryPlanId(Long recoveryPlanId);
}

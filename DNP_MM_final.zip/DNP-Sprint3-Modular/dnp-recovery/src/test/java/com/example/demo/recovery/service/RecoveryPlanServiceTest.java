package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.RecoveryPlan;
import com.example.demo.recovery.entity.RecoveryPlanStatus;
import com.example.demo.recovery.repository.RecoveryPlanRepository;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class RecoveryPlanServiceTest {
    @Mock RecoveryPlanRepository repository;
    @Mock RecoveryLookups lookups;
    @InjectMocks RecoveryPlanService service;

    private RecoveryPlan row(Long id, Long version) {
        RecoveryPlan x = new RecoveryPlan();
        x.setRecoveryPlanId(id);
        x.setVersion(version);
        x.setRecoveryStatusId(1L);
        return x;
    }

    @Test
    void create_withoutStatus_startsActive() {
        RecoveryPlanStatus active = new RecoveryPlanStatus();
        active.setRecoveryStatusId(2L);
        when(lookups.planStatus("Active")).thenReturn(active);
        when(repository.save(any(RecoveryPlan.class))).thenAnswer(a -> a.getArgument(0));
        RecoveryPlan p = new RecoveryPlan();
        p.setDistributorId(1L);
        assertEquals(2L, service.create(p).getRecoveryStatusId());
    }

    @Test
    void create_endBeforeStart_isRejected() {
        RecoveryPlan p = row(null, null);
        p.setStartDate(LocalDate.of(2026, 5, 1));
        p.setEndDate(LocalDate.of(2026, 4, 1));
        assertThrows(BusinessRuleException.class, () -> service.create(p));
        verify(repository, never()).save(any(RecoveryPlan.class));
    }

    @Test
    void update_closedPlan_isRejected() {
        RecoveryPlan closed = row(1L, 0L);
        closed.setClosedAt(OffsetDateTime.now());
        when(repository.findById(1L)).thenReturn(Optional.of(closed));
        assertThrows(BusinessRuleException.class, () -> service.update(1L, row(null, null)));
    }

    @Test
    void update_openPlan_keepsStoredVersion() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        when(repository.save(any(RecoveryPlan.class))).thenAnswer(a -> a.getArgument(0));
        assertEquals(3L, service.update(1L, row(null, null)).getVersion());
    }

    @Test
    void getAll_returnsEveryRow() {
        when(repository.findAll()).thenReturn(List.of(row(1L, 0L), row(2L, 0L)));
        assertEquals(2, service.getAll().size());
    }

    @Test
    void delete_missing_throwsNotFound() {
        when(repository.findById(8L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.delete(8L));
    }
}

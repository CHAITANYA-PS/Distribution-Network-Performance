package com.example.demo.recovery.service;

import com.example.demo.recovery.entity.SlaPolicy;
import com.example.demo.recovery.entity.Ticket;
import com.example.demo.recovery.entity.TicketCategory;
import com.example.demo.recovery.entity.TicketPriority;
import com.example.demo.recovery.entity.TicketStatus;
import com.example.demo.recovery.repository.SlaPolicyRepository;
import com.example.demo.recovery.repository.TicketRepository;
import com.example.demo.recovery.repository.TicketStatusHistoryRepository;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.time.Year;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Ticket rules: defaults, reference number, SLA due time, status only through the lifecycle actions, no delete. */
@ExtendWith(MockitoExtension.class)
class TicketServiceTest {
    @Mock TicketRepository repository;
    @Mock RecoveryLookups lookups;
    @Mock SlaPolicyRepository slas;
    @Mock SystemConfigService config;
    @Mock TicketStatusHistoryRepository statusHistory;
    @InjectMocks TicketService service;

    private static TicketStatus status(long id, String name) {
        TicketStatus s = new TicketStatus();
        s.setTicketStatusId(id);
        s.setStatusName(name);
        return s;
    }

    private Ticket row(Long id, Long version) {
        Ticket x = new Ticket();
        x.setTicketId(id);
        x.setVersion(version);
        x.setTicketStatusId(1L);
        x.setTicketPriorityId(3L);
        return x;
    }

    @Test
    void create_setsOpenStatusDefaultsReferenceAndSla() {
        TicketPriority medium = new TicketPriority();
        medium.setTicketPriorityId(3L);
        TicketCategory general = new TicketCategory();
        general.setTicketCategoryId(9L);
        when(lookups.status(RecoveryLookups.OPEN)).thenReturn(status(1L, "Open"));
        when(lookups.priority("Medium")).thenReturn(medium);
        when(lookups.category("General")).thenReturn(general);
        when(slas.findByTicketPriorityId(3L)).thenReturn(Optional.empty());
        when(config.integer(SystemConfigService.DEFAULT_SLA_HOURS, 72)).thenReturn(48);
        when(repository.save(any(Ticket.class))).thenAnswer(a -> {
            Ticket t = a.getArgument(0);
            if (t.getTicketId() == null) {
                t.setTicketId(5L);
            }
            return t;
        });
        Ticket t = new Ticket();
        t.setSubject("Short delivery");
        t.setTicketStatusId(4L);
        Ticket saved = service.create(t);
        assertEquals(1L, saved.getTicketStatusId());
        assertEquals(3L, saved.getTicketPriorityId());
        assertEquals(9L, saved.getTicketCategoryId());
        assertEquals("TKT-" + Year.now().getValue() + "-000005", saved.getReferenceNumber());
        assertEquals(saved.getCreatedAt().plusHours(48), saved.getSlaDueAt());
        verify(statusHistory).save(any());
    }

    @Test
    void slaHours_comesFromThePriorityPolicy() {
        SlaPolicy p = new SlaPolicy();
        p.setResolutionHours(8);
        when(slas.findByTicketPriorityId(1L)).thenReturn(Optional.of(p));
        assertEquals(8, service.slaHours(1L));
    }

    @Test
    void update_changingTheStatusDirectly_isRejected() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        Ticket change = new Ticket();
        change.setTicketStatusId(4L);
        assertThrows(BusinessRuleException.class, () -> service.update(1L, change));
        verify(repository, never()).save(any(Ticket.class));
    }

    @Test
    void update_otherFields_isAllowed() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 2L)));
        when(repository.save(any(Ticket.class))).thenAnswer(a -> a.getArgument(0));
        Ticket change = new Ticket();
        change.setDescription("More details");
        Ticket result = service.update(1L, change);
        assertEquals("More details", result.getDescription());
        assertEquals(2L, result.getVersion());
    }

    @Test
    void delete_isRejected_ticketsAreKept() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertThrows(BusinessRuleException.class, () -> service.delete(1L));
        verify(repository, never()).deleteById(any());
    }

    @Test
    void get_missing_throwsNotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.get(2L));
    }
}

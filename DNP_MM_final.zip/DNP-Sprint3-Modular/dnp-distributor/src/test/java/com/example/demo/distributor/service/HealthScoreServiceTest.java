package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.DistributorHealthAssessment;
import com.example.demo.distributor.entity.HealthParameter;
import com.example.demo.distributor.entity.HealthParameterWeight;
import com.example.demo.distributor.entity.HealthScoreHistory;
import com.example.demo.distributor.entity.RiskBand;
import com.example.demo.distributor.repository.DistributorHealthAssessmentRepository;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.distributor.repository.HealthAssessmentAlertRepository;
import com.example.demo.distributor.repository.HealthParameterRepository;
import com.example.demo.distributor.repository.HealthParameterWeightRepository;
import com.example.demo.distributor.repository.HealthScoreHistoryRepository;
import com.example.demo.distributor.repository.RiskBandRepository;
import com.example.demo.systemadmin.repository.ReportingPeriodRepository;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Weighted health score: weights must total 100 %, score = sum(score x weight), mapped to a risk band. */
@ExtendWith(MockitoExtension.class)
class HealthScoreServiceTest {
    @Mock HealthParameterWeightRepository weights;
    @Mock HealthParameterRepository parameters;
    @Mock DistributorHealthAssessmentRepository assessments;
    @Mock HealthScoreHistoryRepository history;
    @Mock HealthAssessmentAlertRepository alerts;
    @Mock RiskBandRepository bands;
    @Mock DistributorRepository distributors;
    @Mock ReportingPeriodRepository periods;
    @Mock SystemConfigService config;
    @Mock NotificationGateway notifications;
    @Mock UserRoleResolver users;
    @InjectMocks HealthScoreService service;

    private static HealthParameterWeight weight(long id, long parameterId, String w) {
        HealthParameterWeight x = new HealthParameterWeight();
        x.setParameterWeightId(id);
        x.setParameterId(parameterId);
        x.setWeight(new BigDecimal(w));
        x.setValidFrom(LocalDate.now().minusDays(10));
        return x;
    }

    private static DistributorHealthAssessment assessment(long id, long weightId, String score) {
        DistributorHealthAssessment a = new DistributorHealthAssessment();
        a.setAssessmentId(id);
        a.setDistributorId(1L);
        a.setParameterWeightId(weightId);
        a.setScore(new BigDecimal(score));
        a.setAssessedAt(OffsetDateTime.now());
        return a;
    }

    private static Distributor distributor() {
        Distributor d = new Distributor();
        d.setDistributorId(1L);
        d.setDistributorName("Chennai Distributor");
        return d;
    }

    @Test
    void weightsNotTotalling100_isRejected() {
        when(distributors.findById(1L)).thenReturn(Optional.of(distributor()));
        when(weights.findAll()).thenReturn(List.of(weight(1L, 1L, "0.6")));
        assertThrows(BusinessRuleException.class, () -> service.calculate(1L, null));
        verify(history, never()).save(any());
    }

    @Test
    void score_isTheWeightedSum_andGetsItsRiskBand() {
        when(distributors.findById(1L)).thenReturn(Optional.of(distributor()));
        when(weights.findAll()).thenReturn(List.of(weight(1L, 11L, "0.6"), weight(2L, 12L, "0.4")));
        HealthParameter p1 = new HealthParameter();
        p1.setParameterId(11L);
        p1.setParameterName("Payment discipline");
        HealthParameter p2 = new HealthParameter();
        p2.setParameterId(12L);
        p2.setParameterName("Order regularity");
        when(parameters.findAll()).thenReturn(List.of(p1, p2));
        when(assessments.findByDistributorId(1L)).thenReturn(List.of(assessment(100L, 1L, "80"), assessment(101L, 2L, "50")));
        RiskBand medium = new RiskBand();
        medium.setRiskBandId(2L);
        medium.setRiskCategory("Medium");
        medium.setMinimumScore(new BigDecimal("50"));
        medium.setMaximumScore(new BigDecimal("75"));
        when(bands.findAll()).thenReturn(List.of(medium));
        when(history.save(any(HealthScoreHistory.class))).thenAnswer(a -> a.getArgument(0));
        when(config.decimal(SystemConfigService.HEALTH_ALERT_THRESHOLD, "50")).thenReturn(new BigDecimal("50"));

        HealthScoreService.HealthScoreResult r = service.calculate(1L, null);

        assertEquals(0, r.totalScore().compareTo(new BigDecimal("68.00")));
        assertEquals("Medium", r.riskCategory());
        assertEquals(2, r.breakdown().size());
        assertTrue(r.missingParameters().isEmpty());
        assertFalse(r.alertRaised());
    }
}

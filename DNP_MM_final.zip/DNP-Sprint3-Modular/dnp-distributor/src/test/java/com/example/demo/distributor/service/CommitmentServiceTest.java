package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Commitment;
import com.example.demo.distributor.entity.CommitmentStatus;
import com.example.demo.distributor.repository.CommitmentRepository;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class CommitmentServiceTest {
    @Mock CommitmentRepository repository;
    @Mock CommitmentWorkflowService workflow;
    @InjectMocks CommitmentService service;

    private static CommitmentStatus pending() {
        CommitmentStatus s = new CommitmentStatus();
        s.setCommitmentStatusId(1L);
        s.setStatusName("Pending");
        return s;
    }

    private Commitment row(Long id, Long version) {
        Commitment x = new Commitment();
        x.setCommitmentId(id);
        x.setVersion(version);
        x.setCommitmentStatusId(1L);
        x.setTargetValue(BigDecimal.TEN);
        x.setDueDate(LocalDate.now().plusDays(30));
        return x;
    }

    @Test
    void create_alwaysStartsPending() {
        when(workflow.status(CommitmentWorkflowService.PENDING)).thenReturn(pending());
        when(repository.save(any(Commitment.class))).thenAnswer(a -> a.getArgument(0));
        Commitment c = row(null, null);
        c.setCommitmentStatusId(9L);
        assertEquals(1L, service.create(c).getCommitmentStatusId());
    }

    @Test
    void create_dueDateInThePast_isRejected() {
        when(workflow.status(CommitmentWorkflowService.PENDING)).thenReturn(pending());
        Commitment c = row(null, null);
        c.setDueDate(LocalDate.now().minusDays(1));
        assertThrows(BusinessRuleException.class, () -> service.create(c));
        verify(repository, never()).save(any(Commitment.class));
    }

    @Test
    void update_changingTheStatus_isRejected() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        Commitment change = new Commitment();
        change.setCommitmentStatusId(2L);
        assertThrows(BusinessRuleException.class, () -> service.update(1L, change));
    }

    @Test
    void update_otherFields_keepsStoredVersion() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 4L)));
        when(repository.save(any(Commitment.class))).thenAnswer(a -> a.getArgument(0));
        Commitment change = new Commitment();
        change.setTargetName("Sell 100 units");
        Commitment result = service.update(1L, change);
        assertEquals("Sell 100 units", result.getTargetName());
        assertEquals(4L, result.getVersion());
    }

    @Test
    void delete_missing_throwsNotFound() {
        when(repository.findById(8L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.delete(8L));
    }
}

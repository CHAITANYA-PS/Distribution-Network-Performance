package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.CommitmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, Long> {
    List<CommitmentHistory> findByCommitmentIdOrderByActionAtAsc(Long commitmentId);
}

package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for CommitmentProgress. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class CommitmentProgressDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long progressId;

    @NotNull(groups=OnCreate.class, message="Commitment id is required")
    private Long commitmentId;

    @NotNull(groups=OnCreate.class, message="Progress value is required")
    @PositiveOrZero(message="Progress value must be 0 or greater")
    private BigDecimal progressValue;

    @NotNull(groups=OnCreate.class, message="Recorded by is required")
    private Long recordedBy;

    private OffsetDateTime recordedAt;

    private String remarks;
}

package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for DistributorCategory. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DistributorCategoryDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long distributorCategoryId;

    @NotNull(groups=OnCreate.class, message="Distributor id is required")
    private Long distributorId;

    @NotNull(groups=OnCreate.class, message="Category id is required")
    private Long categoryId;

    private OffsetDateTime assignedAt;

    @Size(max=20, message="Status must be at most 20 characters")
    @Pattern(regexp="Active|Inactive", message="Status must be one of: Active, Inactive")
    private String status;
}

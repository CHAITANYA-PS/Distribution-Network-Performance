package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.HealthParameterWeight;
import com.example.demo.distributor.repository.HealthParameterWeightRepository;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.util.Objects;

/**
 * Weights of the health parameters, written as fractions (0.25 = 25 %). The weights that are valid on the
 * same day may never add up to more than 1 (100 %); the health score needs them to be exactly 1.
 */
@Service
public class HealthParameterWeightService extends AbstractCrudService<HealthParameterWeight, Long> {
    private final HealthParameterWeightRepository weights;

    public HealthParameterWeightService(HealthParameterWeightRepository repository) {
        super(repository, HealthParameterWeight.class);
        this.weights = repository;
    }

    @Override
    protected void beforeCreate(HealthParameterWeight w) {
        check(w, null);
    }

    @Override
    protected void beforeUpdate(Long id, HealthParameterWeight w, HealthParameterWeight existing) {
        check(w, id);
    }

    private void check(HealthParameterWeight w, Long id) {
        if (w.getValidTo() != null && w.getValidFrom() != null && w.getValidTo().isBefore(w.getValidFrom())) {
            throw new BusinessRuleException("Valid to cannot be before valid from");
        }
        LocalDate day = w.getValidFrom() == null ? LocalDate.now() : w.getValidFrom();
        BigDecimal others = weights.findAll().stream()
                .filter(x -> !Objects.equals(x.getParameterWeightId(), id))
                .filter(x -> HealthScoreService.validOn(x, day))
                .map(HealthParameterWeight::getWeight).filter(Objects::nonNull)
                .reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal total = others.add(w.getWeight() == null ? BigDecimal.ZERO : w.getWeight());
        if (total.compareTo(BigDecimal.ONE) > 0) {
            throw new BusinessRuleException("Weights valid on " + day + " would total " + HealthScoreService.pct(total)
                    + "%; the total must not exceed 100% (other weights already use " + HealthScoreService.pct(others) + "%)");
        }
    }
}

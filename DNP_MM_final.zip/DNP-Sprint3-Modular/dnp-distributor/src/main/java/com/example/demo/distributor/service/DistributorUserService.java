package com.example.demo.distributor.service;

import com.example.demo.systemadmin.service.AbstractCrudService;

import com.example.demo.distributor.entity.DistributorUser;
import com.example.demo.distributor.repository.DistributorUserRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorUserService extends AbstractCrudService<DistributorUser, Long> {
    public DistributorUserService(DistributorUserRepository repository) {
        super(repository, DistributorUser.class);
    }

    /** The id is the user_id of an existing user (one-to-one sub-type of app_user), so the client supplies it. */
    @Override
    protected boolean idAssignedByClient() {
        return true;
    }
}

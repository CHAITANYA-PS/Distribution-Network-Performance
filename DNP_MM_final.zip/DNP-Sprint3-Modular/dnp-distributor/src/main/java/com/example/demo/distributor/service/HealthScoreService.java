package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.DistributorHealthAssessment;
import com.example.demo.distributor.entity.HealthAssessmentAlert;
import com.example.demo.distributor.entity.HealthParameter;
import com.example.demo.distributor.entity.HealthParameterWeight;
import com.example.demo.distributor.entity.HealthScoreHistory;
import com.example.demo.distributor.entity.RiskBand;
import com.example.demo.distributor.repository.DistributorHealthAssessmentRepository;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.distributor.repository.HealthAssessmentAlertRepository;
import com.example.demo.distributor.repository.HealthParameterRepository;
import com.example.demo.distributor.repository.HealthParameterWeightRepository;
import com.example.demo.distributor.repository.HealthScoreHistoryRepository;
import com.example.demo.distributor.repository.RiskBandRepository;
import com.example.demo.systemadmin.entity.ReportingPeriod;
import com.example.demo.systemadmin.repository.ReportingPeriodRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;
import java.util.function.Function;
import java.util.stream.Collectors;

/**
 * Distributor health score = sum over the active parameters of (assessment score 0-100 x parameter weight).
 * Weights must total exactly 100 %. A parameter without an assessment counts as 0 and is listed as missing.
 * The result is mapped to a risk band, saved in health_score_history (trend), and an alert is raised when it
 * is below health.alert.threshold.
 */
@Service
@Transactional
public class HealthScoreService implements BackgroundJob {
    private static final BigDecimal HUNDRED = BigDecimal.valueOf(100);

    private final HealthParameterWeightRepository weights;
    private final HealthParameterRepository parameters;
    private final DistributorHealthAssessmentRepository assessments;
    private final HealthScoreHistoryRepository history;
    private final HealthAssessmentAlertRepository alerts;
    private final RiskBandRepository bands;
    private final DistributorRepository distributors;
    private final ReportingPeriodRepository periods;
    private final SystemConfigService config;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public HealthScoreService(HealthParameterWeightRepository weights, HealthParameterRepository parameters,
            DistributorHealthAssessmentRepository assessments, HealthScoreHistoryRepository history, HealthAssessmentAlertRepository alerts,
            RiskBandRepository bands, DistributorRepository distributors, ReportingPeriodRepository periods, SystemConfigService config,
            NotificationGateway notifications, UserRoleResolver users) {
        this.weights = weights;
        this.parameters = parameters;
        this.assessments = assessments;
        this.history = history;
        this.alerts = alerts;
        this.bands = bands;
        this.distributors = distributors;
        this.periods = periods;
        this.config = config;
        this.notifications = notifications;
        this.users = users;
    }

    public record ParameterScore(Long parameterId, String parameterName, BigDecimal weightPercent, BigDecimal score,
            BigDecimal contribution, Long assessmentId) {
    }

    public record HealthScoreResult(Long distributorId, String distributorName, Long reportingPeriodId, BigDecimal totalScore,
            Long riskBandId, String riskCategory, List<ParameterScore> breakdown, List<String> missingParameters,
            boolean alertRaised, Long healthScoreHistoryId, OffsetDateTime calculatedAt) {
    }

    /** Calculates, stores and returns the score. reportingPeriodId is optional (latest assessments when empty). */
    public HealthScoreResult calculate(Long distributorId, Long reportingPeriodId) {
        Distributor d = distributors.findById(distributorId).orElseThrow(() -> new ResourceNotFoundException("Distributor not found: " + distributorId));
        LocalDate day = LocalDate.now();
        if (reportingPeriodId != null) {
            ReportingPeriod p = periods.findById(reportingPeriodId)
                    .orElseThrow(() -> new ResourceNotFoundException("Reporting period not found: " + reportingPeriodId));
            day = p.getEndDate() == null ? day : p.getEndDate();
        }
        final LocalDate on = day;
        List<HealthParameterWeight> active = weights.findAll().stream().filter(w -> validOn(w, on)).toList();
        BigDecimal totalWeight = active.stream().map(HealthParameterWeight::getWeight).filter(Objects::nonNull).reduce(BigDecimal.ZERO, BigDecimal::add);
        if (active.isEmpty() || totalWeight.subtract(BigDecimal.ONE).abs().compareTo(new BigDecimal("0.001")) > 0) {
            throw new BusinessRuleException("Health parameter weights valid on " + on + " total " + pct(totalWeight)
                    + "%; they must total exactly 100% before a score can be calculated");
        }
        Map<Long, HealthParameter> params = parameters.findAll().stream()
                .collect(Collectors.toMap(HealthParameter::getParameterId, Function.identity()));
        List<DistributorHealthAssessment> mine = assessments.findByDistributorId(distributorId).stream()
                .filter(a -> reportingPeriodId == null || reportingPeriodId.equals(a.getReportingPeriodId())).toList();
        List<ParameterScore> breakdown = new ArrayList<>();
        List<String> missing = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;
        Long lastAssessmentId = null;
        for (HealthParameterWeight w : active) {
            HealthParameter param = params.get(w.getParameterId());
            if (param != null && Boolean.FALSE.equals(param.getIsActive())) {
                continue;
            }
            String name = param == null ? "parameter " + w.getParameterId() : param.getParameterName();
            Optional<DistributorHealthAssessment> latest = mine.stream()
                    .filter(a -> Objects.equals(a.getParameterWeightId(), w.getParameterWeightId()))
                    .max(Comparator.comparing(a -> a.getAssessedAt() == null ? OffsetDateTime.MIN : a.getAssessedAt()));
            BigDecimal score = latest.map(DistributorHealthAssessment::getScore).orElse(BigDecimal.ZERO);
            if (latest.isEmpty()) {
                missing.add(name);
            } else {
                lastAssessmentId = latest.get().getAssessmentId();
            }
            BigDecimal contribution = score.multiply(w.getWeight()).setScale(2, RoundingMode.HALF_UP);
            total = total.add(contribution);
            breakdown.add(new ParameterScore(w.getParameterId(), name, pct(w.getWeight()), score, contribution,
                    latest.map(DistributorHealthAssessment::getAssessmentId).orElse(null)));
        }
        total = total.min(HUNDRED).setScale(2, RoundingMode.HALF_UP);
        RiskBand band = band(total);
        HealthScoreHistory h = new HealthScoreHistory();
        h.setDistributorId(distributorId);
        h.setReportingPeriodId(reportingPeriodId);
        h.setTotalScore(total);
        h.setRiskBandId(band == null ? null : band.getRiskBandId());
        h.setBreakdown(AuditTrail.snapshot(breakdown));
        h.setCalculatedBy(CurrentUser.id());
        h.setCalculatedAt(OffsetDateTime.now());
        h = history.save(h);
        BigDecimal threshold = config.decimal(SystemConfigService.HEALTH_ALERT_THRESHOLD, "50");
        boolean alert = total.compareTo(threshold) < 0;
        if (alert) {
            String msg = "Health score of " + d.getDistributorName() + " is " + total + ", below the alert level " + threshold
                    + (band == null ? "" : " (risk band " + band.getRiskCategory() + ")");
            if (lastAssessmentId != null) {
                HealthAssessmentAlert a = new HealthAssessmentAlert();
                a.setAssessmentId(lastAssessmentId);
                a.setThresholdValue(threshold);
                a.setMessage(msg.length() > 500 ? msg.substring(0, 500) : msg);
                a.setReadStatus(false);
                a.setCreatedAt(OffsetDateTime.now());
                alerts.save(a);
            }
            List<Long> to = new ArrayList<>(users.usersWithRole(Roles.SALES_MANAGER));
            to.addAll(users.usersWithRole(Roles.MANUFACTURER));
            notifications.notify(to, "Health score alert", msg);
        }
        return new HealthScoreResult(distributorId, d.getDistributorName(), reportingPeriodId, total, band == null ? null : band.getRiskBandId(),
                band == null ? null : band.getRiskCategory(), breakdown, missing, alert, h.getHealthScoreHistoryId(), h.getCalculatedAt());
    }

    /** All stored scores of a distributor, oldest first (for a trend chart). */
    @Transactional(readOnly = true)
    public List<HealthScoreHistory> trend(Long distributorId) {
        return history.findByDistributorIdOrderByCalculatedAtAsc(distributorId);
    }

    /** Active weights and whether they total 100 %. */
    @Transactional(readOnly = true)
    public Map<String, Object> weightCheck() {
        LocalDate today = LocalDate.now();
        Map<Long, HealthParameter> params = parameters.findAll().stream()
                .collect(Collectors.toMap(HealthParameter::getParameterId, Function.identity()));
        List<Map<String, Object>> rows = new ArrayList<>();
        BigDecimal total = BigDecimal.ZERO;
        for (HealthParameterWeight w : weights.findAll()) {
            if (!validOn(w, today)) {
                continue;
            }
            Map<String, Object> r = new LinkedHashMap<>();
            r.put("parameterWeightId", w.getParameterWeightId());
            r.put("parameter", params.containsKey(w.getParameterId()) ? params.get(w.getParameterId()).getParameterName() : w.getParameterId());
            r.put("weightPercent", pct(w.getWeight()));
            rows.add(r);
            total = total.add(w.getWeight() == null ? BigDecimal.ZERO : w.getWeight());
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("date", today.toString());
        out.put("totalPercent", pct(total));
        out.put("valid", total.subtract(BigDecimal.ONE).abs().compareTo(new BigDecimal("0.001")) <= 0);
        out.put("weights", rows);
        return out;
    }

    // ---- job

    @Override
    public String name() {
        return "health-score-recalculation";
    }

    @Override
    public String description() {
        return "Recalculates the health score of every Active distributor that has assessments";
    }

    @Override
    public Map<String, Object> run() {
        int done = 0;
        int alertsRaised = 0;
        List<String> errors = new ArrayList<>();
        for (Distributor d : distributors.findAll()) {
            if (!"Active".equalsIgnoreCase(d.getStatus()) || assessments.findByDistributorId(d.getDistributorId()).isEmpty()) {
                continue;
            }
            try {
                HealthScoreResult r = calculate(d.getDistributorId(), null);
                done++;
                if (r.alertRaised()) {
                    alertsRaised++;
                }
            } catch (BusinessRuleException e) {
                errors.add(e.getMessage());
                break;
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("scored", done);
        out.put("alerts", alertsRaised);
        if (!errors.isEmpty()) {
            out.put("error", errors.get(0));
        }
        return out;
    }

    // ---- helpers shared with the weight validation

    static boolean validOn(HealthParameterWeight w, LocalDate day) {
        return (w.getValidFrom() == null || !w.getValidFrom().isAfter(day)) && (w.getValidTo() == null || !w.getValidTo().isBefore(day));
    }

    static BigDecimal pct(BigDecimal fraction) {
        return fraction == null ? BigDecimal.ZERO : fraction.multiply(HUNDRED).setScale(2, RoundingMode.HALF_UP);
    }

    private RiskBand band(BigDecimal score) {
        return bands.findAll().stream()
                .filter(b -> b.getMinimumScore() != null && b.getMaximumScore() != null)
                .filter(b -> score.compareTo(b.getMinimumScore()) >= 0 && score.compareTo(b.getMaximumScore()) <= 0)
                .findFirst().orElse(null);
    }
}

package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for HealthAssessmentAlert. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class HealthAssessmentAlertDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long alertId;

    @NotNull(groups=OnCreate.class, message="Assessment id is required")
    private Long assessmentId;

    @NotNull(groups=OnCreate.class, message="Threshold value is required")
    @DecimalMin(value="0", message="Threshold value must be between 0 and 100")
    @DecimalMax(value="100", message="Threshold value must be between 0 and 100")
    private BigDecimal thresholdValue;

    @NotBlank(groups=OnCreate.class, message="Message is required")
    private String message;

    private Boolean readStatus;

    private OffsetDateTime createdAt;
}

package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for DistributorHealthAssessment. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DistributorHealthAssessmentDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long assessmentId;

    @NotNull(groups=OnCreate.class, message="Distributor id is required")
    private Long distributorId;

    @NotNull(groups=OnCreate.class, message="Parameter weight id is required")
    private Long parameterWeightId;

    @NotNull(groups=OnCreate.class, message="Reporting period id is required")
    private Long reportingPeriodId;

    @NotNull(groups=OnCreate.class, message="Score is required")
    @DecimalMin(value="0", message="Score must be between 0 and 100")
    @DecimalMax(value="100", message="Score must be between 0 and 100")
    private BigDecimal score;

    @NotNull(groups=OnCreate.class, message="Assessed by is required")
    private Long assessedBy;

    private OffsetDateTime assessedAt;

    private String remarks;
}

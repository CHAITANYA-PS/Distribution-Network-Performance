package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorOrder;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface DistributorOrderRepository extends JpaRepository<DistributorOrder, Long> {
    List<DistributorOrder> findByDistributorId(Long distributorId);
}

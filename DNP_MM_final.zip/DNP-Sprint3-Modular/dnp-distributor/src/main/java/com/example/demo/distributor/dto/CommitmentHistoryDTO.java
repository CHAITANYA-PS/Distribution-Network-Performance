package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.OffsetDateTime;

/**
 * Request and response body for CommitmentHistory. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class CommitmentHistoryDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long historyId;

    @NotNull(groups=OnCreate.class, message="Commitment id is required")
    private Long commitmentId;

    @NotBlank(groups=OnCreate.class, message="Action is required")
    @Size(max=100, message="Action must be at most 100 characters")
    private String action;

    @NotNull(groups=OnCreate.class, message="Action by is required")
    private Long actionBy;

    private String remarks;

    private OffsetDateTime actionAt;
}

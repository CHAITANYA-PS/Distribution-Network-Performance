package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.ContinuityAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface ContinuityAssessmentRepository extends JpaRepository<ContinuityAssessment, Long> {
    List<ContinuityAssessment> findByDistributorId(Long distributorId);
}

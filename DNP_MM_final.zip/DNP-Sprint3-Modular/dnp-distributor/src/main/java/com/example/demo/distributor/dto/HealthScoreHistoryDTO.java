package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.OffsetDateTime;

/**
 * Request and response body for HealthScoreHistory. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class HealthScoreHistoryDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long healthScoreHistoryId;

    @NotNull(groups=OnCreate.class, message="Distributor id is required")
    private Long distributorId;

    private Long reportingPeriodId;

    @NotNull(groups=OnCreate.class, message="Total score is required")
    @DecimalMin(value="0", message="Total score must be 0 or greater")
    @DecimalMax(value="100", message="Total score must be at most 100")
    private BigDecimal totalScore;

    private Long riskBandId;

    private String breakdown;

    private Long calculatedBy;

    private OffsetDateTime calculatedAt;
}

package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Commitment;
import com.example.demo.distributor.repository.CommitmentRepository;
import com.example.demo.systemadmin.service.AbstractCrudService;
import com.example.demo.systemadmin.service.BusinessRuleException;
import org.springframework.stereotype.Service;

import java.time.LocalDate;
import java.util.Objects;

/** Commitments. A new commitment starts Pending; status changes go through approve / reject (and auto-complete). */
@Service
public class CommitmentService extends AbstractCrudService<Commitment, Long> {
    private final CommitmentWorkflowService workflow;

    public CommitmentService(CommitmentRepository repository, CommitmentWorkflowService workflow) {
        super(repository, Commitment.class);
        this.workflow = workflow;
    }

    @Override
    protected void beforeCreate(Commitment c) {
        c.setCommitmentStatusId(workflow.status(CommitmentWorkflowService.PENDING).getCommitmentStatusId());
        if (c.getDueDate() != null && c.getDueDate().isBefore(LocalDate.now())) {
            throw new BusinessRuleException("Due date cannot be in the past");
        }
        if (c.getTargetValue() != null && c.getTargetValue().signum() <= 0) {
            throw new BusinessRuleException("Target value must be greater than 0");
        }
    }

    @Override
    protected void beforeUpdate(Long id, Commitment c, Commitment existing) {
        if (!Objects.equals(c.getCommitmentStatusId(), existing.getCommitmentStatusId())) {
            throw new BusinessRuleException("Use POST /api/v1/commitments/" + id + "/approve or /reject to change the status");
        }
    }
}

package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;

/**
 * Request and response body for HealthParameter. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class HealthParameterDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long parameterId;

    @NotBlank(groups=OnCreate.class, message="Parameter name is required")
    @Size(max=150, message="Parameter name must be at most 150 characters")
    private String parameterName;

    @Size(max=500, message="Description must be at most 500 characters")
    private String description;

    private Boolean isActive;
}

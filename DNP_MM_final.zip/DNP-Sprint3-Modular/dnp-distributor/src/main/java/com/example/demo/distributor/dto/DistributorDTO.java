package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * Request and response body for Distributor. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DistributorDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long distributorId;

    @NotBlank(groups=OnCreate.class, message="Distributor code is required")
    @Size(max=50)
    private String distributorCode;

    @NotBlank(groups=OnCreate.class, message="Distributor name is required")
    @Size(max=150)
    private String distributorName;

    @NotNull(groups=OnCreate.class, message="Region id is required")
    private Long regionId;

    @NotBlank(groups=OnCreate.class, message="Contact person is required")
    @Size(max=150, message="Contact person must be at most 150 characters")
    private String contactPerson;

    @Email(message="Email must be valid")
    @NotBlank(groups=OnCreate.class, message="Email is required")
    @Size(max=255, message="Email must be at most 255 characters")
    private String email;

    @Pattern(regexp="^[0-9+() -]{7,20}$", message="Phone must contain 7 to 20 valid characters")
    private String phone;

    @NotBlank(groups=OnCreate.class, message="Address is required")
    private String address;

    @Size(max=20, message="Status must be at most 20 characters")
    @Pattern(regexp="Pending|Active|Suspended|Inactive", message="Status must be one of: Pending, Active, Suspended, Inactive")
    private String status;

    private LocalDate onboardingDate;

    private OffsetDateTime createdAt;

    private OffsetDateTime updatedAt;
}

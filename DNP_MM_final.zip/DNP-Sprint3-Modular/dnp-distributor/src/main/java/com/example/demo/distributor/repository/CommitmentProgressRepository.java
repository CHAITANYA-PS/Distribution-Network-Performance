package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.CommitmentProgress;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface CommitmentProgressRepository extends JpaRepository<CommitmentProgress, Long> {
    List<CommitmentProgress> findByCommitmentId(Long commitmentId);
}

package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.ContinuityAssessment;
import com.example.demo.distributor.entity.Distributor;
import com.example.demo.distributor.entity.DistributorActivity;
import com.example.demo.distributor.entity.DistributorOrder;
import com.example.demo.distributor.entity.HealthScoreHistory;
import com.example.demo.distributor.entity.RiskLevel;
import com.example.demo.distributor.repository.ContinuityAssessmentRepository;
import com.example.demo.distributor.repository.DistributorActivityRepository;
import com.example.demo.distributor.repository.DistributorOrderRepository;
import com.example.demo.distributor.repository.DistributorRepository;
import com.example.demo.distributor.repository.HealthScoreHistoryRepository;
import com.example.demo.distributor.repository.RiskLevelRepository;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Locale;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

/**
 * Business continuity: finds Active distributors at risk - no activity or no order for continuity.inactive.days,
 * a health score below health.alert.threshold, or a latest continuity assessment with a high / critical risk
 * level - and gives a recommendation for each reason.
 */
@Service
@Transactional(readOnly = true)
public class ContinuityService implements BackgroundJob {
    private final DistributorRepository distributors;
    private final DistributorActivityRepository activities;
    private final DistributorOrderRepository orders;
    private final HealthScoreHistoryRepository scores;
    private final ContinuityAssessmentRepository assessments;
    private final RiskLevelRepository riskLevels;
    private final SystemConfigService config;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public ContinuityService(DistributorRepository distributors, DistributorActivityRepository activities, DistributorOrderRepository orders,
            HealthScoreHistoryRepository scores, ContinuityAssessmentRepository assessments, RiskLevelRepository riskLevels,
            SystemConfigService config, NotificationGateway notifications, UserRoleResolver users) {
        this.distributors = distributors;
        this.activities = activities;
        this.orders = orders;
        this.scores = scores;
        this.assessments = assessments;
        this.riskLevels = riskLevels;
        this.config = config;
        this.notifications = notifications;
        this.users = users;
    }

    public record ContinuityCheck(Long distributorId, String distributorName, String status, LocalDate lastActivity,
            LocalDate lastOrder, BigDecimal latestHealthScore, String latestRiskLevel, boolean atRisk,
            List<String> reasons, List<String> recommendations) {
    }

    public List<ContinuityCheck> atRisk() {
        List<ContinuityCheck> out = new ArrayList<>();
        for (Distributor d : distributors.findAll()) {
            if ("Active".equalsIgnoreCase(d.getStatus())) {
                ContinuityCheck c = check(d);
                if (c.atRisk()) {
                    out.add(c);
                }
            }
        }
        return out;
    }

    public ContinuityCheck check(Long distributorId) {
        return check(distributors.findById(distributorId).orElseThrow(() -> new ResourceNotFoundException("Distributor not found: " + distributorId)));
    }

    private ContinuityCheck check(Distributor d) {
        int days = config.integer(SystemConfigService.CONTINUITY_INACTIVE_DAYS, 30);
        BigDecimal threshold = config.decimal(SystemConfigService.HEALTH_ALERT_THRESHOLD, "50");
        LocalDate today = LocalDate.now();
        LocalDate lastActivity = activities.findByDistributorId(d.getDistributorId()).stream()
                .map(DistributorActivity::getActivityDate).filter(Objects::nonNull).map(t -> t.toLocalDate())
                .max(Comparator.naturalOrder()).orElse(null);
        LocalDate lastOrder = orders.findByDistributorId(d.getDistributorId()).stream()
                .map(DistributorOrder::getOrderDate).filter(Objects::nonNull).max(Comparator.naturalOrder()).orElse(null);
        List<HealthScoreHistory> hs = scores.findByDistributorIdOrderByCalculatedAtAsc(d.getDistributorId());
        BigDecimal score = hs.isEmpty() ? null : hs.get(hs.size() - 1).getTotalScore();
        Optional<ContinuityAssessment> latest = assessments.findByDistributorId(d.getDistributorId()).stream()
                .filter(a -> a.getAssessmentDate() != null)
                .max(Comparator.comparing(ContinuityAssessment::getAssessmentDate));
        String risk = latest.map(ContinuityAssessment::getRiskLevelId).flatMap(riskLevels::findById).map(RiskLevel::getRiskLevelName).orElse(null);
        List<String> reasons = new ArrayList<>();
        List<String> actions = new ArrayList<>();
        LocalDate since = d.getOnboardingDate() == null ? null : d.getOnboardingDate();
        boolean oldEnough = since == null || ChronoUnit.DAYS.between(since, today) > days;
        if (oldEnough && (lastActivity == null || ChronoUnit.DAYS.between(lastActivity, today) > days)) {
            reasons.add("No recorded activity for more than " + days + " days" + (lastActivity == null ? "" : " (last " + lastActivity + ")"));
            actions.add("Schedule a visit or call and record it as a distributor activity");
        }
        if (oldEnough && (lastOrder == null || ChronoUnit.DAYS.between(lastOrder, today) > days)) {
            reasons.add("No order for more than " + days + " days" + (lastOrder == null ? "" : " (last " + lastOrder + ")"));
            actions.add("Review stock and demand with the distributor; agree a commitment for the next period");
        }
        if (score != null && score.compareTo(threshold) < 0) {
            reasons.add("Health score " + score + " is below " + threshold);
            actions.add("Open a recovery plan with milestones for the weakest health parameters");
        }
        if (risk != null && (risk.toLowerCase(Locale.ROOT).contains("high") || risk.toLowerCase(Locale.ROOT).contains("critical"))) {
            reasons.add("Latest continuity assessment risk level is " + risk);
            actions.add("Escalate to the sales manager and review credit exposure before new orders");
        }
        return new ContinuityCheck(d.getDistributorId(), d.getDistributorName(), d.getStatus(), lastActivity, lastOrder, score, risk,
                !reasons.isEmpty(), reasons, actions);
    }

    @Override
    public String name() {
        return "continuity-check";
    }

    @Override
    public String description() {
        return "Finds Active distributors at continuity risk and notifies the sales managers";
    }

    @Override
    public Map<String, Object> run() {
        List<ContinuityCheck> risky = atRisk();
        if (!risky.isEmpty()) {
            notifications.notify(users.usersWithRole(Roles.SALES_MANAGER), "Continuity risk", risky.size()
                    + " distributor(s) at continuity risk: " + risky.stream().map(ContinuityCheck::distributorName).limit(10).toList());
        }
        return Map.of("distributorsAtRisk", risky.size());
    }
}

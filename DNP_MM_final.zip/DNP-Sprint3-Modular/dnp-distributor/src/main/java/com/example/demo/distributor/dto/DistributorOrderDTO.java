package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * Request and response body for DistributorOrder. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class DistributorOrderDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long orderId;

    @NotBlank(groups=OnCreate.class, message="Order number is required")
    @Size(max=50, message="Order number must be at most 50 characters")
    private String orderNumber;

    @NotNull(groups=OnCreate.class, message="Distributor id is required")
    private Long distributorId;

    @NotNull(groups=OnCreate.class, message="Order status id is required")
    private Long orderStatusId;

    @NotNull(groups=OnCreate.class, message="Order date is required")
    private LocalDate orderDate;

    @NotNull(groups=OnCreate.class, message="Created by is required")
    private Long createdBy;

    private OffsetDateTime createdAt;

    private OffsetDateTime updatedAt;
}

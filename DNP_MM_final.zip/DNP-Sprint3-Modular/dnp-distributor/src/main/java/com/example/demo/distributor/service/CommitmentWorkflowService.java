package com.example.demo.distributor.service;

import com.example.demo.distributor.entity.Commitment;
import com.example.demo.distributor.entity.CommitmentHistory;
import com.example.demo.distributor.entity.CommitmentProgress;
import com.example.demo.distributor.entity.CommitmentStatus;
import com.example.demo.distributor.repository.CommitmentHistoryRepository;
import com.example.demo.distributor.repository.CommitmentProgressRepository;
import com.example.demo.distributor.repository.CommitmentRepository;
import com.example.demo.distributor.repository.CommitmentStatusRepository;
import com.example.demo.systemadmin.security.CurrentUser;
import com.example.demo.systemadmin.security.Roles;
import com.example.demo.systemadmin.security.UserRoleResolver;
import com.example.demo.systemadmin.service.AuditTrail;
import com.example.demo.systemadmin.service.BackgroundJob;
import com.example.demo.systemadmin.service.BusinessRuleException;
import com.example.demo.systemadmin.service.LookupSupport;
import com.example.demo.systemadmin.service.NotificationGateway;
import com.example.demo.systemadmin.service.ResourceNotFoundException;
import com.example.demo.systemadmin.service.SystemConfigService;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.math.BigDecimal;
import java.math.RoundingMode;
import java.time.LocalDate;
import java.time.OffsetDateTime;
import java.time.temporal.ChronoUnit;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

/**
 * Commitment approval and tracking: Pending -> Approved / Rejected; Approved -> Completed automatically when the
 * recorded progress reaches the target. Completion % = total progress / target. Every action is in
 * commitment_history. The reminder job warns about commitments due soon and overdue ones.
 */
@Service
@Transactional
public class CommitmentWorkflowService implements BackgroundJob {
    public static final String PENDING = "Pending";
    public static final String APPROVED = "Approved";
    public static final String REJECTED = "Rejected";
    public static final String COMPLETED = "Completed";

    private final CommitmentRepository commitments;
    private final CommitmentStatusRepository statuses;
    private final CommitmentHistoryRepository history;
    private final CommitmentProgressRepository progress;
    private final SystemConfigService config;
    private final NotificationGateway notifications;
    private final UserRoleResolver users;

    public CommitmentWorkflowService(CommitmentRepository commitments, CommitmentStatusRepository statuses, CommitmentHistoryRepository history,
            CommitmentProgressRepository progress, SystemConfigService config, NotificationGateway notifications, UserRoleResolver users) {
        this.commitments = commitments;
        this.statuses = statuses;
        this.history = history;
        this.progress = progress;
        this.config = config;
        this.notifications = notifications;
        this.users = users;
    }

    public record Completion(Long commitmentId, String targetName, BigDecimal targetValue, BigDecimal achieved,
            BigDecimal completionPercent, String status, LocalDate dueDate, long daysLeft, boolean overdue) {
    }

    public CommitmentStatus status(String name) {
        return LookupSupport.findOrCreate(statuses, CommitmentStatus::getStatusName, name, () -> {
            CommitmentStatus s = new CommitmentStatus();
            s.setStatusName(name);
            s.setIsTerminal(REJECTED.equals(name) || COMPLETED.equals(name));
            return s;
        });
    }

    public Commitment approve(Long id, String remarks) {
        Commitment c = load(id);
        requireStatus(c, PENDING);
        c.setCommitmentStatusId(status(APPROVED).getCommitmentStatusId());
        c.setApprovedBy(CurrentUser.id());
        c.setApprovedAt(OffsetDateTime.now());
        c.setRejectionReason(null);
        return save(c, "APPROVED", remarks, "APPROVE");
    }

    public Commitment reject(Long id, String reason) {
        Commitment c = load(id);
        requireStatus(c, PENDING);
        c.setCommitmentStatusId(status(REJECTED).getCommitmentStatusId());
        c.setRejectionReason(reason);
        return save(c, "REJECTED", reason, "REJECT");
    }

    @Transactional(readOnly = true)
    public Completion completion(Long id) {
        Commitment c = load(id);
        BigDecimal achieved = progress.findByCommitmentId(id).stream().map(CommitmentProgress::getProgressValue)
                .filter(v -> v != null).reduce(BigDecimal.ZERO, BigDecimal::add);
        BigDecimal pct = c.getTargetValue() == null || c.getTargetValue().signum() == 0 ? BigDecimal.ZERO
                : achieved.multiply(BigDecimal.valueOf(100)).divide(c.getTargetValue(), 2, RoundingMode.HALF_UP);
        long days = c.getDueDate() == null ? 0 : ChronoUnit.DAYS.between(LocalDate.now(), c.getDueDate());
        String status = LookupSupport.nameOf(statuses, c.getCommitmentStatusId(), CommitmentStatus::getStatusName);
        return new Completion(id, c.getTargetName(), c.getTargetValue(), achieved, pct, status, c.getDueDate(), days,
                days < 0 && pct.compareTo(BigDecimal.valueOf(100)) < 0);
    }

    /** Called after progress is recorded: an approved commitment that reached 100 % becomes Completed. */
    public void checkCompleted(Long commitmentId) {
        Completion done = completion(commitmentId);
        if (LookupSupport.same(done.status(), APPROVED) && done.completionPercent().compareTo(BigDecimal.valueOf(100)) >= 0) {
            Commitment c = load(commitmentId);
            c.setCommitmentStatusId(status(COMPLETED).getCommitmentStatusId());
            save(c, "COMPLETED", "Target reached: " + done.achieved().stripTrailingZeros().toPlainString(), "STATUS_CHANGE");
        }
    }

    @Transactional(readOnly = true)
    public List<CommitmentHistory> history(Long id) {
        load(id);
        return history.findByCommitmentIdOrderByActionAtAsc(id);
    }

    // ---- reminder job

    @Override
    public String name() {
        return "commitment-reminders";
    }

    @Override
    public String description() {
        return "Reminds distributors of approved commitments due within commitment.reminder.days and reports overdue ones";
    }

    @Override
    public Map<String, Object> run() {
        int days = config.integer(SystemConfigService.COMMITMENT_REMINDER_DAYS, 7);
        int reminders = 0;
        int overdue = 0;
        for (Commitment c : commitments.findAll()) {
            String s = LookupSupport.nameOf(statuses, c.getCommitmentStatusId(), CommitmentStatus::getStatusName);
            if (!LookupSupport.same(s, APPROVED) || c.getDueDate() == null) {
                continue;
            }
            Completion done = completion(c.getCommitmentId());
            long left = ChronoUnit.DAYS.between(LocalDate.now(), c.getDueDate());
            if (left < 0) {
                overdue++;
                notifications.notify(users.usersWithRole(Roles.SALES_MANAGER), "Commitment overdue", "Commitment '" + c.getTargetName()
                        + "' of distributor " + c.getDistributorId() + " was due on " + c.getDueDate() + " and is at " + done.completionPercent() + "%");
            } else if (left <= days) {
                reminders++;
                notifications.notify(users.usersOfDistributor(c.getDistributorId()), "Commitment reminder", "Commitment '" + c.getTargetName()
                        + "' is due in " + left + " day(s) and is at " + done.completionPercent() + "%");
            }
        }
        Map<String, Object> out = new LinkedHashMap<>();
        out.put("reminderDays", days);
        out.put("remindersSent", reminders);
        out.put("overdue", overdue);
        return out;
    }

    // ---- helpers

    private Commitment load(Long id) {
        return commitments.findById(id).orElseThrow(() -> new ResourceNotFoundException("Commitment not found: " + id));
    }

    private void requireStatus(Commitment c, String expected) {
        String s = LookupSupport.nameOf(statuses, c.getCommitmentStatusId(), CommitmentStatus::getStatusName);
        if (!LookupSupport.same(s, expected)) {
            throw new BusinessRuleException("Commitment is " + s + "; only a " + expected + " commitment can be approved or rejected");
        }
    }

    private Commitment save(Commitment c, String action, String remarks, String auditAction) {
        c.setUpdatedAt(OffsetDateTime.now());
        Commitment saved = commitments.save(c);
        CommitmentHistory h = new CommitmentHistory();
        h.setCommitmentId(c.getCommitmentId());
        h.setAction(action);
        h.setActionBy(CurrentUser.id() == null ? c.getCreatedBy() : CurrentUser.id());
        h.setRemarks(remarks);
        h.setActionAt(OffsetDateTime.now());
        history.save(h);
        AuditTrail.record(auditAction, "Commitment", c.getCommitmentId(), null, Map.of("action", action, "remarks", remarks == null ? "" : remarks));
        notifications.notify(users.usersOfDistributor(c.getDistributorId()), "Commitment",
                "Commitment '" + c.getTargetName() + "' " + action.toLowerCase() + (remarks == null ? "" : ": " + remarks));
        return saved;
    }
}

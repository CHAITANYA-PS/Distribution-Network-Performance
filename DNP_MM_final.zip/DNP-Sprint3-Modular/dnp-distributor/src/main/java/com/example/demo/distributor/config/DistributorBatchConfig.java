package com.example.demo.distributor.config;

import com.example.demo.distributor.dto.DistributorCsvRow;
import com.example.demo.distributor.entity.Distributor; import com.example.demo.distributor.repository.DistributorRepository; import org.springframework.batch.core.job.Job; import org.springframework.batch.core.job.JobExecution; import org.springframework.batch.core.job.parameters.JobParametersBuilder; import org.springframework.batch.core.step.Step; import org.springframework.batch.core.job.builder.JobBuilder; import org.springframework.batch.core.repository.JobRepository; import org.springframework.batch.core.step.builder.StepBuilder; import org.springframework.batch.infrastructure.item.data.RepositoryItemWriter; import org.springframework.batch.infrastructure.item.data.builder.RepositoryItemWriterBuilder; import org.springframework.batch.infrastructure.item.file.FlatFileItemReader; import org.springframework.batch.infrastructure.item.file.builder.FlatFileItemReaderBuilder; import org.springframework.beans.factory.annotation.Value; import org.springframework.context.annotation.*; import org.springframework.core.io.FileSystemResource; import org.springframework.transaction.PlatformTransactionManager;
@Configuration public class DistributorBatchConfig {
 @Bean FlatFileItemReader<DistributorCsvRow> distributorReader(@Value("${dnp.batch.distributor-file:input/distributors.csv}") String f){return new FlatFileItemReaderBuilder<DistributorCsvRow>().name("distributorReader").resource(new FileSystemResource(f)).linesToSkip(1).delimited().names("distributorCode","distributorName","regionId","contactPerson","email","phone","address","status").targetType(DistributorCsvRow.class).build();}
 @Bean RepositoryItemWriter<Distributor> distributorWriter(DistributorRepository r){return new RepositoryItemWriterBuilder<Distributor>().repository(r).methodName("save").build();}
 @Bean Job distributorImportJob(JobRepository jr,PlatformTransactionManager tx,FlatFileItemReader<DistributorCsvRow> reader,RepositoryItemWriter<Distributor> writer){var processor=(org.springframework.batch.infrastructure.item.ItemProcessor<DistributorCsvRow,Distributor>) row->Distributor.builder().distributorCode(row.getDistributorCode()).distributorName(row.getDistributorName()).regionId(row.getRegionId()).contactPerson(row.getContactPerson()).email(row.getEmail()).phone(row.getPhone()).address(row.getAddress()).status(statusOf(row.getStatus())).onboardingDate(java.time.LocalDate.now()).createdAt(java.time.OffsetDateTime.now()).updatedAt(java.time.OffsetDateTime.now()).build(); Step step=new StepBuilder("distributorImportStep",jr).<DistributorCsvRow,Distributor>chunk(500,tx).reader(reader).processor(processor).writer(writer).build(); return new JobBuilder("distributorImportJob",jr).start(step).build();}

    /** CSV status to the database form: "ACTIVE"/"active" -> "Active"; empty -> "Active" (the distributor default). */
    static String statusOf(String raw) {
        if (raw == null || raw.isBlank()) {
            return "Active";
        }
        String t = raw.trim().toLowerCase();
        return Character.toUpperCase(t.charAt(0)) + t.substring(1);
    }
}

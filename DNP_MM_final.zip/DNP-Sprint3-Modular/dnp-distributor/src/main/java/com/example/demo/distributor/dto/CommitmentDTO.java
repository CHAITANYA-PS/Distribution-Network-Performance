package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;
import java.time.OffsetDateTime;

/**
 * Request and response body for Commitment. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class CommitmentDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long commitmentId;

    @NotNull(groups=OnCreate.class, message="Distributor id is required")
    private Long distributorId;

    @NotNull(groups=OnCreate.class, message="Measurement unit id is required")
    private Long measurementUnitId;

    @NotNull(groups=OnCreate.class, message="Commitment status id is required")
    private Long commitmentStatusId;

    @NotBlank(groups=OnCreate.class, message="Target name is required")
    @Size(max=200, message="Target name must be at most 200 characters")
    private String targetName;

    @NotNull(groups=OnCreate.class, message="Target value is required")
    @PositiveOrZero(message="Target value must be 0 or greater")
    private BigDecimal targetValue;

    @NotNull(groups=OnCreate.class, message="Due date is required")
    private LocalDate dueDate;

    @NotNull(groups=OnCreate.class, message="Created by is required")
    private Long createdBy;

    private OffsetDateTime createdAt;

    private OffsetDateTime updatedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long approvedBy;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private OffsetDateTime approvedAt;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    @Size(max=500, message="Rejection reason must be at most 500 characters")
    private String rejectionReason;
}

package com.example.demo.distributor.dto;

import com.fasterxml.jackson.annotation.JsonProperty;
import jakarta.validation.constraints.*;
import com.example.demo.systemadmin.entity.OnCreate;
import lombok.Getter;
import lombok.NoArgsConstructor;
import lombok.Setter;
import java.math.BigDecimal;
import java.time.LocalDate;

/**
 * Request and response body for HealthParameterWeight. Validation rules match the database constraints; fields marked
 * read-only are filled by the system and ignored when sent.
 */
@Getter
@Setter
@NoArgsConstructor
public class HealthParameterWeightDTO {
    /** Row version: send back the value you received when you update (optimistic locking). */
    @JsonProperty(access = JsonProperty.Access.READ_WRITE)
    private Long version;

    @JsonProperty(access = JsonProperty.Access.READ_ONLY)
    private Long parameterWeightId;

    @NotNull(groups=OnCreate.class, message="Parameter id is required")
    private Long parameterId;

    @NotNull(groups=OnCreate.class, message="Weight is required")
    @DecimalMin(value="0", message="Weight must be between 0 and 1")
    @DecimalMax(value="1", message="Weight must be between 0 and 1")
    private BigDecimal weight;

    @NotNull(groups=OnCreate.class, message="Valid from is required")
    private LocalDate validFrom;

    private LocalDate validTo;
}

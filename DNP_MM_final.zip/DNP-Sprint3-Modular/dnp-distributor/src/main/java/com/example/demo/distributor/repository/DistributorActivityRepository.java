package com.example.demo.distributor.repository;

import com.example.demo.distributor.entity.DistributorActivity;
import org.springframework.data.jpa.repository.JpaRepository;

import java.util.List;
import java.util.Optional;
public interface DistributorActivityRepository extends JpaRepository<DistributorActivity, Long> {
    List<DistributorActivity> findByDistributorId(Long distributorId);
}

package com.dsphere.dao.interfaces;import com.dsphere.model.CommitmentHistory;public interface CommitmentHistoryDao extends GenericDao<CommitmentHistory,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.DistributorHealthAssessment;public interface DistributorHealthAssessmentDao extends GenericDao<DistributorHealthAssessment,Long>{}

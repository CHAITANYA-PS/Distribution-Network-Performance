package com.dsphere.dao.interfaces;import com.dsphere.model.TransportationActivity;public interface TransportationActivityDao extends GenericDao<TransportationActivity,Long>{}

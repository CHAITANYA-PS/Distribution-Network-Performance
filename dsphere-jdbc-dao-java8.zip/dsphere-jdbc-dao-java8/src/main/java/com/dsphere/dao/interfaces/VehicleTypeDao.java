package com.dsphere.dao.interfaces;import com.dsphere.model.VehicleType;public interface VehicleTypeDao extends GenericDao<VehicleType,Long>{}

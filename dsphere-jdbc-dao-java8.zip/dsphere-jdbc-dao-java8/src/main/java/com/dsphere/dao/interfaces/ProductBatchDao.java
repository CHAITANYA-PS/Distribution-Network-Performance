package com.dsphere.dao.interfaces;import com.dsphere.model.ProductBatch;public interface ProductBatchDao extends GenericDao<ProductBatch,Long>{}

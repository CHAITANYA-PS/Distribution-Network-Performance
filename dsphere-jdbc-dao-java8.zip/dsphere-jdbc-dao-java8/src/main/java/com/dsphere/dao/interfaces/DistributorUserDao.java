package com.dsphere.dao.interfaces;import com.dsphere.model.DistributorUser;public interface DistributorUserDao extends GenericDao<DistributorUser,Long>{}

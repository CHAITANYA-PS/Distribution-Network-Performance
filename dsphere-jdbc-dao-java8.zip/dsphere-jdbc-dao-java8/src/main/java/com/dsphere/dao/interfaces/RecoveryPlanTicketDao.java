package com.dsphere.dao.interfaces;import com.dsphere.model.RecoveryPlanTicket;public interface RecoveryPlanTicketDao extends GenericDao<RecoveryPlanTicket,Long>{}

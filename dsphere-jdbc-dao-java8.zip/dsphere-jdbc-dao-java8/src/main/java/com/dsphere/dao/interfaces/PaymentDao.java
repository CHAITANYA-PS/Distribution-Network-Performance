package com.dsphere.dao.interfaces;import com.dsphere.model.Payment;public interface PaymentDao extends GenericDao<Payment,Long>{}

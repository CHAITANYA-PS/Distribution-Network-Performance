package com.dsphere.dao.interfaces;import com.dsphere.model.Distributor;public interface DistributorDao extends GenericDao<Distributor,Long>{}

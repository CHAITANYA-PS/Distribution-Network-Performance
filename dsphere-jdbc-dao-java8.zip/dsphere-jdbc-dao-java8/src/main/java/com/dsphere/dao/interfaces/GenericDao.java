package com.dsphere.dao.interfaces;
import java.util.List;import java.util.Optional;import java.util.function.Predicate;
public interface GenericDao<T,ID>{T save(T e);T update(T e);Optional<T> findById(ID id);List<T> findAll();List<T> filter(Predicate<T> p);boolean existsById(ID id);boolean deleteById(ID id);long count();}

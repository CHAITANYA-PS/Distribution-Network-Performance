package com.dsphere.dao.interfaces;import com.dsphere.model.InventoryDocument;public interface InventoryDocumentDao extends GenericDao<InventoryDocument,Long>{}

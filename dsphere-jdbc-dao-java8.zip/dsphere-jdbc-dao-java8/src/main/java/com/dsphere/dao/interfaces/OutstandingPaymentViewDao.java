package com.dsphere.dao.interfaces;import com.dsphere.model.OutstandingPaymentView;public interface OutstandingPaymentViewDao extends ReadOnlyDao<OutstandingPaymentView>{}

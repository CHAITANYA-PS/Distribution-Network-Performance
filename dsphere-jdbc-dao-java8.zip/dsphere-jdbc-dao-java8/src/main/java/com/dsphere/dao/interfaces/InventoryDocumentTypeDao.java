package com.dsphere.dao.interfaces;import com.dsphere.model.InventoryDocumentType;public interface InventoryDocumentTypeDao extends GenericDao<InventoryDocumentType,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.TicketCategory;public interface TicketCategoryDao extends GenericDao<TicketCategory,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.FinanceManager;public interface FinanceManagerDao extends GenericDao<FinanceManager,Long>{}

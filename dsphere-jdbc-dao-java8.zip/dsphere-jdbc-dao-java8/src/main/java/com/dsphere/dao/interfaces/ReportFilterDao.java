package com.dsphere.dao.interfaces;import com.dsphere.model.ReportFilter;public interface ReportFilterDao extends GenericDao<ReportFilter,Long>{}

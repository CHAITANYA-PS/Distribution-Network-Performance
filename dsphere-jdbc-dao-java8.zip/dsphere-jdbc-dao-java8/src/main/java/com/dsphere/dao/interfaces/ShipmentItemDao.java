package com.dsphere.dao.interfaces;import com.dsphere.model.ShipmentItem;public interface ShipmentItemDao extends GenericDao<ShipmentItem,Long>{}

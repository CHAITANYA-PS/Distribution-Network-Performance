package com.dsphere.dao.interfaces;import com.dsphere.model.ContinuityAssessment;public interface ContinuityAssessmentDao extends GenericDao<ContinuityAssessment,Long>{}

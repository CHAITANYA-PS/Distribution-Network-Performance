package com.dsphere.dao.interfaces;import com.dsphere.model.UserRole;public interface UserRoleDao extends GenericDao<UserRole,Long>{}

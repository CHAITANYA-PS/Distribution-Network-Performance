package com.dsphere.dao.interfaces;import com.dsphere.model.InvoiceStatus;public interface InvoiceStatusDao extends GenericDao<InvoiceStatus,Long>{}

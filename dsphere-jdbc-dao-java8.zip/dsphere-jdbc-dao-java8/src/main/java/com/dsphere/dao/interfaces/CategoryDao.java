package com.dsphere.dao.interfaces;import com.dsphere.model.Category;public interface CategoryDao extends GenericDao<Category,Long>{}

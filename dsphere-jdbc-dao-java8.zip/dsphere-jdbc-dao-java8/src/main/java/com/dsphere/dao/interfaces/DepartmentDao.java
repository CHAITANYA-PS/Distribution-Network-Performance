package com.dsphere.dao.interfaces;import com.dsphere.model.Department;public interface DepartmentDao extends GenericDao<Department,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.TicketPriority;public interface TicketPriorityDao extends GenericDao<TicketPriority,Long>{}

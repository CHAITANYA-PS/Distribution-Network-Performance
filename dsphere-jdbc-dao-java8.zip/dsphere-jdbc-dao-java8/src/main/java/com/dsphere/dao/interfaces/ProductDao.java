package com.dsphere.dao.interfaces;import com.dsphere.model.Product;public interface ProductDao extends GenericDao<Product,Long>{}

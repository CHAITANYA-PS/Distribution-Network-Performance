package com.dsphere.dao.interfaces;import com.dsphere.model.UserSession;public interface UserSessionDao extends GenericDao<UserSession,Long>{}

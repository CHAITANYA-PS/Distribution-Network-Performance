package com.dsphere.dao.interfaces;import com.dsphere.model.TicketComment;public interface TicketCommentDao extends GenericDao<TicketComment,Long>{}

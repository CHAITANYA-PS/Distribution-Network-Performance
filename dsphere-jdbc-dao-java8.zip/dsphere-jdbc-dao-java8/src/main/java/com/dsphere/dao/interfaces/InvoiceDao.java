package com.dsphere.dao.interfaces;import com.dsphere.model.Invoice;public interface InvoiceDao extends GenericDao<Invoice,Long>{}

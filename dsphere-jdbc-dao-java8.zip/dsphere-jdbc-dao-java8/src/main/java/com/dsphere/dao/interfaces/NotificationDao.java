package com.dsphere.dao.interfaces;import com.dsphere.model.Notification;public interface NotificationDao extends GenericDao<Notification,Long>{}

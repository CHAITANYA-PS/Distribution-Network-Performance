package com.dsphere.dao.interfaces;import com.dsphere.model.HealthParameterWeight;public interface HealthParameterWeightDao extends GenericDao<HealthParameterWeight,Long>{}

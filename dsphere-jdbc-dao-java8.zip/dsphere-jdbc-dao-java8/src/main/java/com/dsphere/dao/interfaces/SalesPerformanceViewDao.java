package com.dsphere.dao.interfaces;import com.dsphere.model.SalesPerformanceView;public interface SalesPerformanceViewDao extends ReadOnlyDao<SalesPerformanceView>{}

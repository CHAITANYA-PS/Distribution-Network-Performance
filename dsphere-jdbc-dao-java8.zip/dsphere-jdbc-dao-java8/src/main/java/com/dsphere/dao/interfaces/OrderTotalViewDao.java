package com.dsphere.dao.interfaces;import com.dsphere.model.OrderTotalView;public interface OrderTotalViewDao extends ReadOnlyDao<OrderTotalView>{}

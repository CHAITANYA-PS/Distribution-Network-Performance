package com.dsphere.dao.interfaces;import com.dsphere.model.MeasurementUnit;public interface MeasurementUnitDao extends GenericDao<MeasurementUnit,Long>{}

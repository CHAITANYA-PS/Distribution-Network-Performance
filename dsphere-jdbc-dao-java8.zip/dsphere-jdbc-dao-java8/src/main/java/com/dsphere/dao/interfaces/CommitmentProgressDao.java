package com.dsphere.dao.interfaces;import com.dsphere.model.CommitmentProgress;public interface CommitmentProgressDao extends GenericDao<CommitmentProgress,Long>{}

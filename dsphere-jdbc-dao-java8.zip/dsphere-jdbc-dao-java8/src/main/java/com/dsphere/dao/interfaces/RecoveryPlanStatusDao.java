package com.dsphere.dao.interfaces;import com.dsphere.model.RecoveryPlanStatus;public interface RecoveryPlanStatusDao extends GenericDao<RecoveryPlanStatus,Long>{}

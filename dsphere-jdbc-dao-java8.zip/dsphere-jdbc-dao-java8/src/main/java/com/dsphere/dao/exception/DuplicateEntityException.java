package com.dsphere.dao.exception;
public class DuplicateEntityException extends DaoException{private static final long serialVersionUID=1L;public DuplicateEntityException(String m,Throwable c){super(m,c);}}

package com.dsphere.dao.interfaces;import com.dsphere.model.ManufacturerUser;public interface ManufacturerUserDao extends GenericDao<ManufacturerUser,Long>{}

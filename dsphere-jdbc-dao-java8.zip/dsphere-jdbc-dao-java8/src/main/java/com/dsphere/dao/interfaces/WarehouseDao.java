package com.dsphere.dao.interfaces;import com.dsphere.model.Warehouse;public interface WarehouseDao extends GenericDao<Warehouse,Long>{}

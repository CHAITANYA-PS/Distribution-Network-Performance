package com.dsphere.dao.interfaces;import com.dsphere.model.AppUser;public interface AppUserDao extends GenericDao<AppUser,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.RecoveryManager;public interface RecoveryManagerDao extends GenericDao<RecoveryManager,Long>{}

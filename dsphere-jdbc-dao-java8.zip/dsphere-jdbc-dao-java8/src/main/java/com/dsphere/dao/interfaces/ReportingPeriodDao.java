package com.dsphere.dao.interfaces;import com.dsphere.model.ReportingPeriod;public interface ReportingPeriodDao extends GenericDao<ReportingPeriod,Long>{}

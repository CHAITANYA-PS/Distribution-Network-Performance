package com.dsphere.dao.interfaces;import com.dsphere.model.ReportFilterValue;public interface ReportFilterValueDao extends GenericDao<ReportFilterValue,Long>{}

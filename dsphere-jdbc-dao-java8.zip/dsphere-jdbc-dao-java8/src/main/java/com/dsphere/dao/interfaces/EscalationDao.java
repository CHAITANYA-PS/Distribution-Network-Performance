package com.dsphere.dao.interfaces;import com.dsphere.model.Escalation;public interface EscalationDao extends GenericDao<Escalation,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.ActivityType;public interface ActivityTypeDao extends GenericDao<ActivityType,Long>{}

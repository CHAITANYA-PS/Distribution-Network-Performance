package com.dsphere.dao.interfaces;import com.dsphere.model.HealthScoreView;public interface HealthScoreViewDao extends ReadOnlyDao<HealthScoreView>{}

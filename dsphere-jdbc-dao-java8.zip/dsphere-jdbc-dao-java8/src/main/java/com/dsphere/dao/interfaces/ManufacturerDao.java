package com.dsphere.dao.interfaces;import com.dsphere.model.Manufacturer;public interface ManufacturerDao extends GenericDao<Manufacturer,Long>{}

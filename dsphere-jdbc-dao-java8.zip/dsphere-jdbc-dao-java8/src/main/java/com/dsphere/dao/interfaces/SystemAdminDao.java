package com.dsphere.dao.interfaces;import com.dsphere.model.SystemAdmin;public interface SystemAdminDao extends GenericDao<SystemAdmin,Long>{}

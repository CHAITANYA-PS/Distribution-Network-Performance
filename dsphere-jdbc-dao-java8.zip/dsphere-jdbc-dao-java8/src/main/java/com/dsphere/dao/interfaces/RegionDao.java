package com.dsphere.dao.interfaces;import com.dsphere.model.Region;public interface RegionDao extends GenericDao<Region,Long>{}

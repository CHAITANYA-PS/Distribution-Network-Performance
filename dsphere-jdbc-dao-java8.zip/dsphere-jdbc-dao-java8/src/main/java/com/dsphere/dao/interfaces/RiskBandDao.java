package com.dsphere.dao.interfaces;import com.dsphere.model.RiskBand;public interface RiskBandDao extends GenericDao<RiskBand,Long>{}

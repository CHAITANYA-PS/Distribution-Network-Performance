package com.dsphere.dao.interfaces;import com.dsphere.model.MovementType;public interface MovementTypeDao extends GenericDao<MovementType,Long>{}

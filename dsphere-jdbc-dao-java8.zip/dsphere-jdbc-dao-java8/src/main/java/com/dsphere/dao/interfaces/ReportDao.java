package com.dsphere.dao.interfaces;import com.dsphere.model.Report;public interface ReportDao extends GenericDao<Report,Long>{}

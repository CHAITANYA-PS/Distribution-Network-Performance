package com.dsphere.dao.interfaces;import com.dsphere.model.TransportEmissionView;public interface TransportEmissionViewDao extends ReadOnlyDao<TransportEmissionView>{}

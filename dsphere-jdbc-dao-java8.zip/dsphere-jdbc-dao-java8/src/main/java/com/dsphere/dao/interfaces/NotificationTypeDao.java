package com.dsphere.dao.interfaces;import com.dsphere.model.NotificationType;public interface NotificationTypeDao extends GenericDao<NotificationType,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.Shipment;public interface ShipmentDao extends GenericDao<Shipment,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.CreditRiskAssessment;public interface CreditRiskAssessmentDao extends GenericDao<CreditRiskAssessment,Long>{}

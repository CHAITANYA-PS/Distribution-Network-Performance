package com.dsphere.dao.interfaces;import com.dsphere.model.DistributorOrder;public interface DistributorOrderDao extends GenericDao<DistributorOrder,Long>{}

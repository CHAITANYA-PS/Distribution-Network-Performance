package com.dsphere.dao.interfaces;import com.dsphere.model.DistributorCreditLimit;public interface DistributorCreditLimitDao extends GenericDao<DistributorCreditLimit,Long>{}

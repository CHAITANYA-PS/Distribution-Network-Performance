package com.dsphere.dao.interfaces;import com.dsphere.model.RecoveryPlan;public interface RecoveryPlanDao extends GenericDao<RecoveryPlan,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.Role;public interface RoleDao extends GenericDao<Role,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.DistributorCategory;public interface DistributorCategoryDao extends GenericDao<DistributorCategory,Long>{}

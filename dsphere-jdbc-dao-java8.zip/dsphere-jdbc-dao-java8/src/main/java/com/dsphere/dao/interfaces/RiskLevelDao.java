package com.dsphere.dao.interfaces;import com.dsphere.model.RiskLevel;public interface RiskLevelDao extends GenericDao<RiskLevel,Long>{}

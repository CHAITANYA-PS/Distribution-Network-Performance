package com.dsphere.dao.interfaces;import com.dsphere.model.ExchangeHistory;public interface ExchangeHistoryDao extends GenericDao<ExchangeHistory,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.ContinuityStatusType;public interface ContinuityStatusTypeDao extends GenericDao<ContinuityStatusType,Long>{}

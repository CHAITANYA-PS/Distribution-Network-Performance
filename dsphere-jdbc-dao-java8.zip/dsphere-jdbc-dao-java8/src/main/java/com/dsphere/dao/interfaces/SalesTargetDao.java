package com.dsphere.dao.interfaces;import com.dsphere.model.SalesTarget;public interface SalesTargetDao extends GenericDao<SalesTarget,Long>{}

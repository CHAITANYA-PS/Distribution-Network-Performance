package com.dsphere.dao.interfaces;import com.dsphere.model.InventoryMovement;public interface InventoryMovementDao extends GenericDao<InventoryMovement,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.TicketStatus;public interface TicketStatusDao extends GenericDao<TicketStatus,Long>{}

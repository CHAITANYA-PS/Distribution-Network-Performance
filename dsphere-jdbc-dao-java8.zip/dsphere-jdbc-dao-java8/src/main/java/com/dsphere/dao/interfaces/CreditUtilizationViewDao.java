package com.dsphere.dao.interfaces;import com.dsphere.model.CreditUtilizationView;public interface CreditUtilizationViewDao extends ReadOnlyDao<CreditUtilizationView>{}

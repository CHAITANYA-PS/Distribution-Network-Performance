package com.dsphere.dao.interfaces;import com.dsphere.model.Ticket;public interface TicketDao extends GenericDao<Ticket,Long>{}

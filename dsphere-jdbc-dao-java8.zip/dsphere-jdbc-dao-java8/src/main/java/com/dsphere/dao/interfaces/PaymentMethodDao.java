package com.dsphere.dao.interfaces;import com.dsphere.model.PaymentMethod;public interface PaymentMethodDao extends GenericDao<PaymentMethod,Long>{}

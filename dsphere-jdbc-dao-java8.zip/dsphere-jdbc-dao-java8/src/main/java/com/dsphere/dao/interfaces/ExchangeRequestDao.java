package com.dsphere.dao.interfaces;import com.dsphere.model.ExchangeRequest;public interface ExchangeRequestDao extends GenericDao<ExchangeRequest,Long>{}

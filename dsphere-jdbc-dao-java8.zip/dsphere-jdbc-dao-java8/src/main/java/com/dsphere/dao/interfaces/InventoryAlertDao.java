package com.dsphere.dao.interfaces;import com.dsphere.model.InventoryAlert;public interface InventoryAlertDao extends GenericDao<InventoryAlert,Long>{}

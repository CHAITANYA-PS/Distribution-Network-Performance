package com.dsphere.dao.interfaces;import com.dsphere.model.CommitmentStatus;public interface CommitmentStatusDao extends GenericDao<CommitmentStatus,Long>{}

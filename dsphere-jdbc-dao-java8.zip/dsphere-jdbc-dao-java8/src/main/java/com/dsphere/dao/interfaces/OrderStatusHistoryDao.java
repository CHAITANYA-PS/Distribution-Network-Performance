package com.dsphere.dao.interfaces;import com.dsphere.model.OrderStatusHistory;public interface OrderStatusHistoryDao extends GenericDao<OrderStatusHistory,Long>{}

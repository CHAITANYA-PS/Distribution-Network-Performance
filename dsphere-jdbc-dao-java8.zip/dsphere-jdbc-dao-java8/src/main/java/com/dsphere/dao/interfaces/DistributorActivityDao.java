package com.dsphere.dao.interfaces;import com.dsphere.model.DistributorActivity;public interface DistributorActivityDao extends GenericDao<DistributorActivity,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.HealthParameter;public interface HealthParameterDao extends GenericDao<HealthParameter,Long>{}

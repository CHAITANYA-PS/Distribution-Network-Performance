package com.dsphere.dao.interfaces;import com.dsphere.model.SalesManager;public interface SalesManagerDao extends GenericDao<SalesManager,Long>{}

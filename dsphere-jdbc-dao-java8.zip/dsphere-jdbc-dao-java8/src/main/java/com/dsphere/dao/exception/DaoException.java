package com.dsphere.dao.exception;
public class DaoException extends RuntimeException{private static final long serialVersionUID=1L;public DaoException(String m){super(m);}public DaoException(String m,Throwable c){super(m,c);}}

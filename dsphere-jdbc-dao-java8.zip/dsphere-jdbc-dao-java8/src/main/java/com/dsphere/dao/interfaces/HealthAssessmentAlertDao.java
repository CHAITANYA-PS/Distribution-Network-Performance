package com.dsphere.dao.interfaces;import com.dsphere.model.HealthAssessmentAlert;public interface HealthAssessmentAlertDao extends GenericDao<HealthAssessmentAlert,Long>{}

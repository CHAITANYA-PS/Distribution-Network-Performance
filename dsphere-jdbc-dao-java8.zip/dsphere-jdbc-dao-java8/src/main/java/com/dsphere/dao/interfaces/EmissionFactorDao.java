package com.dsphere.dao.interfaces;import com.dsphere.model.EmissionFactor;public interface EmissionFactorDao extends GenericDao<EmissionFactor,Long>{}

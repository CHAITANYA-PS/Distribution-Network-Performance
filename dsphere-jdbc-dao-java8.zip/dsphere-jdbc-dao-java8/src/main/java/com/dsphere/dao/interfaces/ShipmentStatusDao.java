package com.dsphere.dao.interfaces;import com.dsphere.model.ShipmentStatus;public interface ShipmentStatusDao extends GenericDao<ShipmentStatus,Long>{}

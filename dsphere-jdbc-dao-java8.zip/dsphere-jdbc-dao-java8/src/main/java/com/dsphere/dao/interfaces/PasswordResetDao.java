package com.dsphere.dao.interfaces;import com.dsphere.model.PasswordReset;public interface PasswordResetDao extends GenericDao<PasswordReset,Long>{}

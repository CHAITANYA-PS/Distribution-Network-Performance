package com.dsphere.dao.interfaces;import com.dsphere.model.ExchangeStatus;public interface ExchangeStatusDao extends GenericDao<ExchangeStatus,Long>{}

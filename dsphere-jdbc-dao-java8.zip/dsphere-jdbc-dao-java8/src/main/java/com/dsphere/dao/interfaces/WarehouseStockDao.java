package com.dsphere.dao.interfaces;import com.dsphere.model.WarehouseStock;public interface WarehouseStockDao extends GenericDao<WarehouseStock,Long>{}

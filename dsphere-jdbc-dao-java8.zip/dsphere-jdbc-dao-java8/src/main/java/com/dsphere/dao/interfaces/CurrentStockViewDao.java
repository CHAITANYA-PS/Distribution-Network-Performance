package com.dsphere.dao.interfaces;import com.dsphere.model.CurrentStockView;public interface CurrentStockViewDao extends ReadOnlyDao<CurrentStockView>{}

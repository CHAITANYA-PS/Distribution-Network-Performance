package com.dsphere.dao.interfaces;import com.dsphere.model.OrderItem;public interface OrderItemDao extends GenericDao<OrderItem,Long>{}

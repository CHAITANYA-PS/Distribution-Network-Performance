package com.dsphere.dao.interfaces;import com.dsphere.model.PaymentStatus;public interface PaymentStatusDao extends GenericDao<PaymentStatus,Long>{}

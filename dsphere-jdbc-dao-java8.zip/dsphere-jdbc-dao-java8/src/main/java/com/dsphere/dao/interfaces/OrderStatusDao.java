package com.dsphere.dao.interfaces;import com.dsphere.model.OrderStatus;public interface OrderStatusDao extends GenericDao<OrderStatus,Long>{}

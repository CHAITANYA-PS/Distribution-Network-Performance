package com.dsphere.dao.interfaces;import com.dsphere.model.Commitment;public interface CommitmentDao extends GenericDao<Commitment,Long>{}

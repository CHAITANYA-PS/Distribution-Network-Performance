package com.dsphere.dao.interfaces;import com.dsphere.model.SalesRecord;public interface SalesRecordDao extends GenericDao<SalesRecord,Long>{}

package com.dsphere.dao.interfaces;import com.dsphere.model.UserActivityLog;public interface UserActivityLogDao extends GenericDao<UserActivityLog,Long>{}

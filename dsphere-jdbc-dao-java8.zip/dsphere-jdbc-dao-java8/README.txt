Dsphere JDBC DAO Java 8 package

Includes 79 CRUD DAO interface/implementation pairs and 7 read-only view DAO pairs.
Uses PostgreSQL through JDBC. No in-memory persistence.

Eclipse: import as Existing Maven Project, edit src/main/resources/database.properties, add your existing com.dsphere.model package, Maven > Update Project.
Run V2__create_user_session.sql if user_session is not already present.

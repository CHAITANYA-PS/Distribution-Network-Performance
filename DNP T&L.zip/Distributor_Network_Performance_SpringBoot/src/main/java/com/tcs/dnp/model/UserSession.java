package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="user_session",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class UserSession {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="session_id")
 private Long sessionId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="session_token_hash")
 private String sessionTokenHash;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="expires_at")
 private OffsetDateTime expiresAt;
 @Column(name="revoked_at")
 private OffsetDateTime revokedAt;
 @Column(name="ip_address")
 private String ipAddress;
}
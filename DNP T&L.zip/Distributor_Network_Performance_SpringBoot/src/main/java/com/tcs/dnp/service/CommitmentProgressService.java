package com.tcs.dnp.service;

import com.tcs.dnp.model.CommitmentProgress;
import com.tcs.dnp.repository.CommitmentProgressRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class CommitmentProgressService {
    private final CommitmentProgressRepository repository;

    public CommitmentProgressService(CommitmentProgressRepository repository) {
        this.repository = repository;
    }

    public CommitmentProgress create(CommitmentProgress model) {
        model.setProgressId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public CommitmentProgress get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("CommitmentProgress not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<CommitmentProgress> getAll() {
        return repository.findAll();
    }

    public CommitmentProgress update(Long id, CommitmentProgress model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CommitmentProgress not found: " + id);
        }
        model.setProgressId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CommitmentProgress not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.CommitmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, Long> {
}

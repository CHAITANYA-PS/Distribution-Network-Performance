package com.tcs.dnp.service;

import com.tcs.dnp.model.EmissionFactor;
import com.tcs.dnp.repository.EmissionFactorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class EmissionFactorService {
    private final EmissionFactorRepository repository;

    public EmissionFactorService(EmissionFactorRepository repository) {
        this.repository = repository;
    }

    public EmissionFactor create(EmissionFactor model) {
        model.setEmissionFactorId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public EmissionFactor get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("EmissionFactor not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<EmissionFactor> getAll() {
        return repository.findAll();
    }

    public EmissionFactor update(Long id, EmissionFactor model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("EmissionFactor not found: " + id);
        }
        model.setEmissionFactorId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("EmissionFactor not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.InventoryDocument;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentRepository extends JpaRepository<InventoryDocument, Long> {
}

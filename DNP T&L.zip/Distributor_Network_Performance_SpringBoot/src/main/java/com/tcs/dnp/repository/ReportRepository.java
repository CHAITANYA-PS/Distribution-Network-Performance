package com.tcs.dnp.repository;

import com.tcs.dnp.model.Report;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportRepository extends JpaRepository<Report, Long> {
}

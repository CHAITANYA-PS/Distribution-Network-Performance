package com.tcs.dnp.repository;

import com.tcs.dnp.model.ReportingPeriod;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportingPeriodRepository extends JpaRepository<ReportingPeriod, Long> {
}

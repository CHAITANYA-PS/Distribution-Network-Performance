package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.HealthParameterWeight;
import com.tcs.dnp.service.HealthParameterWeightService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/health-parameter-weights")
public class HealthParameterWeightController {
    private final HealthParameterWeightService service;

    public HealthParameterWeightController(HealthParameterWeightService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<HealthParameterWeight> create(@Valid @RequestBody HealthParameterWeight model) {
        HealthParameterWeight saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/health-parameter-weights/" + saved.getParameterWeightId())).body(saved);
    }

    @GetMapping("/{id}")
    public HealthParameterWeight get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<HealthParameterWeight> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public HealthParameterWeight update(@PathVariable Long id, @Valid @RequestBody HealthParameterWeight model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

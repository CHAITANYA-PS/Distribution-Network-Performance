package com.tcs.dnp.service;

import com.tcs.dnp.model.InvoiceStatus;
import com.tcs.dnp.repository.InvoiceStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class InvoiceStatusService {
    private final InvoiceStatusRepository repository;

    public InvoiceStatusService(InvoiceStatusRepository repository) {
        this.repository = repository;
    }

    public InvoiceStatus create(InvoiceStatus model) {
        model.setInvoiceStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public InvoiceStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InvoiceStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<InvoiceStatus> getAll() {
        return repository.findAll();
    }

    public InvoiceStatus update(Long id, InvoiceStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InvoiceStatus not found: " + id);
        }
        model.setInvoiceStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InvoiceStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

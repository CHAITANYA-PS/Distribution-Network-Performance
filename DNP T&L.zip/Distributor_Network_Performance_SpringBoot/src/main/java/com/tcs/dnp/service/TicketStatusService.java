package com.tcs.dnp.service;

import com.tcs.dnp.model.TicketStatus;
import com.tcs.dnp.repository.TicketStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class TicketStatusService {
    private final TicketStatusRepository repository;

    public TicketStatusService(TicketStatusRepository repository) {
        this.repository = repository;
    }

    public TicketStatus create(TicketStatus model) {
        model.setTicketStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public TicketStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TicketStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<TicketStatus> getAll() {
        return repository.findAll();
    }

    public TicketStatus update(Long id, TicketStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketStatus not found: " + id);
        }
        model.setTicketStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

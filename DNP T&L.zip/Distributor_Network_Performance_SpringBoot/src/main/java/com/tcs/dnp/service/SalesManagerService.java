package com.tcs.dnp.service;

import com.tcs.dnp.model.SalesManager;
import com.tcs.dnp.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class SalesManagerService {
    private final SalesManagerRepository repository;

    public SalesManagerService(SalesManagerRepository repository) {
        this.repository = repository;
    }

    public SalesManager create(SalesManager model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public SalesManager get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SalesManager not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<SalesManager> getAll() {
        return repository.findAll();
    }

    public SalesManager update(Long id, SalesManager model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SalesManager not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SalesManager not found: " + id);
        }
        repository.deleteById(id);
    }
}

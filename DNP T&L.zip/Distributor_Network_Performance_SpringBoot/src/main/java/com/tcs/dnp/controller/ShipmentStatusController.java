package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.ShipmentStatus;
import com.tcs.dnp.service.ShipmentStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/shipment-statuss")
public class ShipmentStatusController {
    private final ShipmentStatusService service;

    public ShipmentStatusController(ShipmentStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ShipmentStatus> create(@Valid @RequestBody ShipmentStatus model) {
        ShipmentStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/shipment-statuss/" + saved.getShipmentStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public ShipmentStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ShipmentStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ShipmentStatus update(@PathVariable Long id, @Valid @RequestBody ShipmentStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

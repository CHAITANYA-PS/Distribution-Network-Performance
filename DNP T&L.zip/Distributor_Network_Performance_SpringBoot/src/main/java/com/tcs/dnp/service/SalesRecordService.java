package com.tcs.dnp.service;

import com.tcs.dnp.model.SalesRecord;
import com.tcs.dnp.repository.SalesRecordRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class SalesRecordService {
    private final SalesRecordRepository repository;

    public SalesRecordService(SalesRecordRepository repository) {
        this.repository = repository;
    }

    public SalesRecord create(SalesRecord model) {
        model.setSalesRecordId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public SalesRecord get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SalesRecord not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<SalesRecord> getAll() {
        return repository.findAll();
    }

    public SalesRecord update(Long id, SalesRecord model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SalesRecord not found: " + id);
        }
        model.setSalesRecordId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SalesRecord not found: " + id);
        }
        repository.deleteById(id);
    }
}

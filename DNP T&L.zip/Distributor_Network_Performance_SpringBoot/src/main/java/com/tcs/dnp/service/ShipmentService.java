package com.tcs.dnp.service;

import com.tcs.dnp.model.Shipment;
import com.tcs.dnp.repository.ShipmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ShipmentService {
    private final ShipmentRepository repository;

    public ShipmentService(ShipmentRepository repository) {
        this.repository = repository;
    }

    public Shipment create(Shipment model) {
        model.setShipmentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Shipment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Shipment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Shipment> getAll() {
        return repository.findAll();
    }

    public Shipment update(Long id, Shipment model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Shipment not found: " + id);
        }
        model.setShipmentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Shipment not found: " + id);
        }
        repository.deleteById(id);
    }
}

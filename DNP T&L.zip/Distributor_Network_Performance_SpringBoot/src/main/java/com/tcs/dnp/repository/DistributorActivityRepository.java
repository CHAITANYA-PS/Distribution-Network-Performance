package com.tcs.dnp.repository;

import com.tcs.dnp.model.DistributorActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorActivityRepository extends JpaRepository<DistributorActivity, Long> {
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.PasswordReset;
import com.tcs.dnp.repository.PasswordResetRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class PasswordResetService {
    private final PasswordResetRepository repository;

    public PasswordResetService(PasswordResetRepository repository) {
        this.repository = repository;
    }

    public PasswordReset create(PasswordReset model) {
        model.setResetId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public PasswordReset get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PasswordReset not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<PasswordReset> getAll() {
        return repository.findAll();
    }

    public PasswordReset update(Long id, PasswordReset model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PasswordReset not found: " + id);
        }
        model.setResetId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PasswordReset not found: " + id);
        }
        repository.deleteById(id);
    }
}

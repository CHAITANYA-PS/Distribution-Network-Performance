package com.tcs.dnp.service;

import com.tcs.dnp.model.WarehouseStock;
import com.tcs.dnp.repository.WarehouseStockRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class WarehouseStockService {
    private final WarehouseStockRepository repository;

    public WarehouseStockService(WarehouseStockRepository repository) {
        this.repository = repository;
    }

    public WarehouseStock create(WarehouseStock model) {
        model.setWarehouseStockId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public WarehouseStock get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("WarehouseStock not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<WarehouseStock> getAll() {
        return repository.findAll();
    }

    public WarehouseStock update(Long id, WarehouseStock model) {
        repository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("WarehouseStock not found: " + id));
        model.setWarehouseStockId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("WarehouseStock not found: " + id);
        }
        repository.deleteById(id);
    }
}

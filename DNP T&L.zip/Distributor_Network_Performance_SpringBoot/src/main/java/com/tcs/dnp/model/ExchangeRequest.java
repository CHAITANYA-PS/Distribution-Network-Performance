package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="exchange_request",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ExchangeRequest {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="exchange_id")
 private Long exchangeId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="product_id")
 private Long productId;
 @Column(name="requested_quantity")
 private BigDecimal requestedQuantity;
 @Column(name="source_location")
 private String sourceLocation;
 @Column(name="exchange_status_id")
 private Long exchangeStatusId;
 @Column(name="requested_by")
 private Long requestedBy;
 @Column(name="requested_at")
 private OffsetDateTime requestedAt;
}
package com.tcs.dnp.repository;

import com.tcs.dnp.model.RiskBand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskBandRepository extends JpaRepository<RiskBand, Long> {
}

package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="notification",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Notification {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="notification_id")
 private Long notificationId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="notification_type_id")
 private Long notificationTypeId;
 @Column(name="message")
 private String message;
 @Column(name="read_status")
 private Boolean readStatus;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
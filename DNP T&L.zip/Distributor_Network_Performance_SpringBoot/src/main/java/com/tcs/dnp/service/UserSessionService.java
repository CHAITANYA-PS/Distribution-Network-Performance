package com.tcs.dnp.service;

import com.tcs.dnp.model.UserSession;
import com.tcs.dnp.repository.UserSessionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class UserSessionService {
    private final UserSessionRepository repository;

    public UserSessionService(UserSessionRepository repository) {
        this.repository = repository;
    }

    public UserSession create(UserSession model) {
        model.setSessionId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public UserSession get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("UserSession not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<UserSession> getAll() {
        return repository.findAll();
    }

    public UserSession update(Long id, UserSession model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("UserSession not found: " + id);
        }
        model.setSessionId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("UserSession not found: " + id);
        }
        repository.deleteById(id);
    }
}

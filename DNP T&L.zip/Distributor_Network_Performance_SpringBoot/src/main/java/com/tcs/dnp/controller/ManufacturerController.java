package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.Manufacturer;
import com.tcs.dnp.service.ManufacturerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/manufacturers")
public class ManufacturerController {
    private final ManufacturerService service;

    public ManufacturerController(ManufacturerService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Manufacturer> create(@Valid @RequestBody Manufacturer model) {
        Manufacturer saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/manufacturers/" + saved.getManufacturerId())).body(saved);
    }

    @GetMapping("/{id}")
    public Manufacturer get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Manufacturer> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Manufacturer update(@PathVariable Long id, @Valid @RequestBody Manufacturer model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

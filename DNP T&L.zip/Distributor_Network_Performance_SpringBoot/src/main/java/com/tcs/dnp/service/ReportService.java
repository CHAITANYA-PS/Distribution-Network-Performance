package com.tcs.dnp.service;

import com.tcs.dnp.model.Report;
import com.tcs.dnp.repository.ReportRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ReportService {
    private final ReportRepository repository;

    public ReportService(ReportRepository repository) {
        this.repository = repository;
    }

    public Report create(Report model) {
        model.setReportId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Report get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Report> getAll() {
        return repository.findAll();
    }

    public Report update(Long id, Report model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Report not found: " + id);
        }
        model.setReportId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Report not found: " + id);
        }
        repository.deleteById(id);
    }
}

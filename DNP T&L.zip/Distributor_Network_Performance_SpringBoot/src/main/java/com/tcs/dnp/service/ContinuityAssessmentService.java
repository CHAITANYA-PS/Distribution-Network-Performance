package com.tcs.dnp.service;

import com.tcs.dnp.model.ContinuityAssessment;
import com.tcs.dnp.repository.ContinuityAssessmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ContinuityAssessmentService {
    private final ContinuityAssessmentRepository repository;

    public ContinuityAssessmentService(ContinuityAssessmentRepository repository) {
        this.repository = repository;
    }

    public ContinuityAssessment create(ContinuityAssessment model) {
        model.setContinuityAssessmentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ContinuityAssessment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ContinuityAssessment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ContinuityAssessment> getAll() {
        return repository.findAll();
    }

    public ContinuityAssessment update(Long id, ContinuityAssessment model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ContinuityAssessment not found: " + id);
        }
        model.setContinuityAssessmentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ContinuityAssessment not found: " + id);
        }
        repository.deleteById(id);
    }
}

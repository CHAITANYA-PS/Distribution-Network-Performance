package com.tcs.dnp.config;
import io.swagger.v3.oas.models.OpenAPI; import io.swagger.v3.oas.models.info.Info; import org.springframework.context.annotation.*;
@Configuration public class OpenApiConfig { @Bean OpenAPI dnpOpenApi(){return new OpenAPI().info(new Info().title("Distributor Network Performance API").version("v1").description("REST CRUD and batch APIs"));} }

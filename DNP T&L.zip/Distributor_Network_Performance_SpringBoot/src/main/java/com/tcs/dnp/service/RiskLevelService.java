package com.tcs.dnp.service;

import com.tcs.dnp.model.RiskLevel;
import com.tcs.dnp.repository.RiskLevelRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RiskLevelService {
    private final RiskLevelRepository repository;

    public RiskLevelService(RiskLevelRepository repository) {
        this.repository = repository;
    }

    public RiskLevel create(RiskLevel model) {
        model.setRiskLevelId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public RiskLevel get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskLevel not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RiskLevel> getAll() {
        return repository.findAll();
    }

    public RiskLevel update(Long id, RiskLevel model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RiskLevel not found: " + id);
        }
        model.setRiskLevelId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RiskLevel not found: " + id);
        }
        repository.deleteById(id);
    }
}

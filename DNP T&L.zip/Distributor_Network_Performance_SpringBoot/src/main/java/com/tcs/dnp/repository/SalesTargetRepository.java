package com.tcs.dnp.repository;

import com.tcs.dnp.model.SalesTarget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesTargetRepository extends JpaRepository<SalesTarget, Long> {
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.RecoveryManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryManagerRepository extends JpaRepository<RecoveryManager, Long> {
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.Invoice;
import com.tcs.dnp.repository.InvoiceRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class InvoiceService {
    private final InvoiceRepository repository;

    public InvoiceService(InvoiceRepository repository) {
        this.repository = repository;
    }

    public Invoice create(Invoice model) {
        model.setInvoiceId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Invoice get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Invoice not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Invoice> getAll() {
        return repository.findAll();
    }

    public Invoice update(Long id, Invoice model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Invoice not found: " + id);
        }
        model.setInvoiceId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Invoice not found: " + id);
        }
        repository.deleteById(id);
    }
}

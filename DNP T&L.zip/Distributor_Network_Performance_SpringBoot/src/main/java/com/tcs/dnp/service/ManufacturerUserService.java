package com.tcs.dnp.service;

import com.tcs.dnp.model.ManufacturerUser;
import com.tcs.dnp.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ManufacturerUserService {
    private final ManufacturerUserRepository repository;

    public ManufacturerUserService(ManufacturerUserRepository repository) {
        this.repository = repository;
    }

    public ManufacturerUser create(ManufacturerUser model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ManufacturerUser get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ManufacturerUser not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ManufacturerUser> getAll() {
        return repository.findAll();
    }

    public ManufacturerUser update(Long id, ManufacturerUser model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ManufacturerUser not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ManufacturerUser not found: " + id);
        }
        repository.deleteById(id);
    }
}

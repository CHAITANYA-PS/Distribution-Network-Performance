package com.tcs.dnp.repository;

import com.tcs.dnp.model.ShipmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ShipmentStatusRepository extends JpaRepository<ShipmentStatus, Long> {
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.DistributorActivity;
import com.tcs.dnp.repository.DistributorActivityRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorActivityService {
    private final DistributorActivityRepository repository;

    public DistributorActivityService(DistributorActivityRepository repository) {
        this.repository = repository;
    }

    public DistributorActivity create(DistributorActivity model) {
        model.setActivityId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public DistributorActivity get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorActivity not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<DistributorActivity> getAll() {
        return repository.findAll();
    }

    public DistributorActivity update(Long id, DistributorActivity model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorActivity not found: " + id);
        }
        model.setActivityId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorActivity not found: " + id);
        }
        repository.deleteById(id);
    }
}

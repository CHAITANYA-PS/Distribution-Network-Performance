package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="inventory_document_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InventoryDocumentType {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="inventory_document_type_id")
 private Long inventoryDocumentTypeId;
 @Column(name="document_type_name")
 private String documentTypeName;
}
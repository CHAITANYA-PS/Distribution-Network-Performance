package com.tcs.dnp.service;

import com.tcs.dnp.model.ReportFilter;
import com.tcs.dnp.repository.ReportFilterRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ReportFilterService {
    private final ReportFilterRepository repository;

    public ReportFilterService(ReportFilterRepository repository) {
        this.repository = repository;
    }

    public ReportFilter create(ReportFilter model) {
        model.setReportFilterId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ReportFilter get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ReportFilter not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ReportFilter> getAll() {
        return repository.findAll();
    }

    public ReportFilter update(Long id, ReportFilter model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ReportFilter not found: " + id);
        }
        model.setReportFilterId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ReportFilter not found: " + id);
        }
        repository.deleteById(id);
    }
}

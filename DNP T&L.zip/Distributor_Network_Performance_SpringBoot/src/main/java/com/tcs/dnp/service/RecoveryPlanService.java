package com.tcs.dnp.service;

import com.tcs.dnp.model.RecoveryPlan;
import com.tcs.dnp.repository.RecoveryPlanRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RecoveryPlanService {
    private final RecoveryPlanRepository repository;

    public RecoveryPlanService(RecoveryPlanRepository repository) {
        this.repository = repository;
    }

    public RecoveryPlan create(RecoveryPlan model) {
        model.setRecoveryPlanId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public RecoveryPlan get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RecoveryPlan not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RecoveryPlan> getAll() {
        return repository.findAll();
    }

    public RecoveryPlan update(Long id, RecoveryPlan model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryPlan not found: " + id);
        }
        model.setRecoveryPlanId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryPlan not found: " + id);
        }
        repository.deleteById(id);
    }
}

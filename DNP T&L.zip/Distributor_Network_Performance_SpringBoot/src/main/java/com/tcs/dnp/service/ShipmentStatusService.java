package com.tcs.dnp.service;

import com.tcs.dnp.model.ShipmentStatus;
import com.tcs.dnp.repository.ShipmentStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ShipmentStatusService {
    private final ShipmentStatusRepository repository;

    public ShipmentStatusService(ShipmentStatusRepository repository) {
        this.repository = repository;
    }

    public ShipmentStatus create(ShipmentStatus model) {
        model.setShipmentStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ShipmentStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ShipmentStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ShipmentStatus> getAll() {
        return repository.findAll();
    }

    public ShipmentStatus update(Long id, ShipmentStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ShipmentStatus not found: " + id);
        }
        model.setShipmentStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ShipmentStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

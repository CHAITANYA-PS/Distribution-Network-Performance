package com.tcs.dnp.service;

import com.tcs.dnp.model.SalesTarget;
import com.tcs.dnp.repository.SalesTargetRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class SalesTargetService {
    private final SalesTargetRepository repository;

    public SalesTargetService(SalesTargetRepository repository) {
        this.repository = repository;
    }

    public SalesTarget create(SalesTarget model) {
        model.setTargetId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public SalesTarget get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SalesTarget not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<SalesTarget> getAll() {
        return repository.findAll();
    }

    public SalesTarget update(Long id, SalesTarget model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SalesTarget not found: " + id);
        }
        model.setTargetId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SalesTarget not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.ReportingPeriod;
import com.tcs.dnp.repository.ReportingPeriodRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ReportingPeriodService {
    private final ReportingPeriodRepository repository;

    public ReportingPeriodService(ReportingPeriodRepository repository) {
        this.repository = repository;
    }

    public ReportingPeriod create(ReportingPeriod model) {
        model.setReportingPeriodId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ReportingPeriod get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ReportingPeriod not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ReportingPeriod> getAll() {
        return repository.findAll();
    }

    public ReportingPeriod update(Long id, ReportingPeriod model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ReportingPeriod not found: " + id);
        }
        model.setReportingPeriodId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ReportingPeriod not found: " + id);
        }
        repository.deleteById(id);
    }
}

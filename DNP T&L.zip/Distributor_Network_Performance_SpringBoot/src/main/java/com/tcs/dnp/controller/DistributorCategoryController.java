package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.DistributorCategory;
import com.tcs.dnp.service.DistributorCategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor-categorys")
public class DistributorCategoryController {
    private final DistributorCategoryService service;

    public DistributorCategoryController(DistributorCategoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DistributorCategory> create(@Valid @RequestBody DistributorCategory model) {
        DistributorCategory saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributor-categorys/" + saved.getDistributorCategoryId())).body(saved);
    }

    @GetMapping("/{id}")
    public DistributorCategory get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<DistributorCategory> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public DistributorCategory update(@PathVariable Long id, @Valid @RequestBody DistributorCategory model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

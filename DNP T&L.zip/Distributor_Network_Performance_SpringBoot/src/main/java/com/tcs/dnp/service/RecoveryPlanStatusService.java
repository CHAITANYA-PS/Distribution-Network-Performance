package com.tcs.dnp.service;

import com.tcs.dnp.model.RecoveryPlanStatus;
import com.tcs.dnp.repository.RecoveryPlanStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RecoveryPlanStatusService {
    private final RecoveryPlanStatusRepository repository;

    public RecoveryPlanStatusService(RecoveryPlanStatusRepository repository) {
        this.repository = repository;
    }

    public RecoveryPlanStatus create(RecoveryPlanStatus model) {
        model.setRecoveryStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public RecoveryPlanStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RecoveryPlanStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RecoveryPlanStatus> getAll() {
        return repository.findAll();
    }

    public RecoveryPlanStatus update(Long id, RecoveryPlanStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryPlanStatus not found: " + id);
        }
        model.setRecoveryStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryPlanStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

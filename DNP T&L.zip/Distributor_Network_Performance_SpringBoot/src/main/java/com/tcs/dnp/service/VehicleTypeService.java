package com.tcs.dnp.service;

import com.tcs.dnp.model.VehicleType;
import com.tcs.dnp.repository.VehicleTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class VehicleTypeService {
    private final VehicleTypeRepository repository;

    public VehicleTypeService(VehicleTypeRepository repository) {
        this.repository = repository;
    }

    public VehicleType create(VehicleType model) {
        model.setVehicleTypeId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public VehicleType get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("VehicleType not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<VehicleType> getAll() {
        return repository.findAll();
    }

    public VehicleType update(Long id, VehicleType model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("VehicleType not found: " + id);
        }
        model.setVehicleTypeId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("VehicleType not found: " + id);
        }
        repository.deleteById(id);
    }
}

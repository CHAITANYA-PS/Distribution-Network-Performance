package com.tcs.dnp.service;

import com.tcs.dnp.model.PaymentStatus;
import com.tcs.dnp.repository.PaymentStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class PaymentStatusService {
    private final PaymentStatusRepository repository;

    public PaymentStatusService(PaymentStatusRepository repository) {
        this.repository = repository;
    }

    public PaymentStatus create(PaymentStatus model) {
        model.setPaymentStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public PaymentStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PaymentStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<PaymentStatus> getAll() {
        return repository.findAll();
    }

    public PaymentStatus update(Long id, PaymentStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PaymentStatus not found: " + id);
        }
        model.setPaymentStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PaymentStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.Region;
import com.tcs.dnp.repository.RegionRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RegionService {
    private final RegionRepository repository;

    public RegionService(RegionRepository repository) {
        this.repository = repository;
    }

    public Region create(Region model) {
        model.setRegionId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Region get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Region not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Region> getAll() {
        return repository.findAll();
    }

    public Region update(Long id, Region model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Region not found: " + id);
        }
        model.setRegionId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Region not found: " + id);
        }
        repository.deleteById(id);
    }
}

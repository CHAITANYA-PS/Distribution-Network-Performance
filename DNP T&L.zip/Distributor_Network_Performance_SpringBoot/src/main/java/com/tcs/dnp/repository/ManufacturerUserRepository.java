package com.tcs.dnp.repository;

import com.tcs.dnp.model.ManufacturerUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerUserRepository extends JpaRepository<ManufacturerUser, Long> {
}

package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_order",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorOrder {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="order_id")
 private Long orderId;
 @Column(name="order_number")
 private String orderNumber;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="order_status_id")
 private Long orderStatusId;
 @Column(name="order_date")
 private LocalDate orderDate;
 @Column(name="created_by")
 private Long createdBy;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;
}
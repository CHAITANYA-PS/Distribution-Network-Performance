package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.RiskBand;
import com.tcs.dnp.service.RiskBandService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/risk-bands")
public class RiskBandController {
    private final RiskBandService service;

    public RiskBandController(RiskBandService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<RiskBand> create(@Valid @RequestBody RiskBand model) {
        RiskBand saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/risk-bands/" + saved.getRiskBandId())).body(saved);
    }

    @GetMapping("/{id}")
    public RiskBand get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<RiskBand> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public RiskBand update(@PathVariable Long id, @Valid @RequestBody RiskBand model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.Escalation;
import com.tcs.dnp.repository.EscalationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class EscalationService {
    private final EscalationRepository repository;

    public EscalationService(EscalationRepository repository) {
        this.repository = repository;
    }

    public Escalation create(Escalation model) {
        model.setEscalationId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Escalation get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Escalation not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Escalation> getAll() {
        return repository.findAll();
    }

    public Escalation update(Long id, Escalation model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Escalation not found: " + id);
        }
        model.setEscalationId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Escalation not found: " + id);
        }
        repository.deleteById(id);
    }
}

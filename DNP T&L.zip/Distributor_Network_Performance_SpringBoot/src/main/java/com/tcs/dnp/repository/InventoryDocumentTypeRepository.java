package com.tcs.dnp.repository;

import com.tcs.dnp.model.InventoryDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentTypeRepository extends JpaRepository<InventoryDocumentType, Long> {
}

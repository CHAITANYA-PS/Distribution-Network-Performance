package com.tcs.dnp.service;

import com.tcs.dnp.model.CommitmentStatus;
import com.tcs.dnp.repository.CommitmentStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class CommitmentStatusService {
    private final CommitmentStatusRepository repository;

    public CommitmentStatusService(CommitmentStatusRepository repository) {
        this.repository = repository;
    }

    public CommitmentStatus create(CommitmentStatus model) {
        model.setCommitmentStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public CommitmentStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("CommitmentStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<CommitmentStatus> getAll() {
        return repository.findAll();
    }

    public CommitmentStatus update(Long id, CommitmentStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CommitmentStatus not found: " + id);
        }
        model.setCommitmentStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CommitmentStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.TicketComment;
import com.tcs.dnp.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class TicketCommentService {
    private final TicketCommentRepository repository;

    public TicketCommentService(TicketCommentRepository repository) {
        this.repository = repository;
    }

    public TicketComment create(TicketComment model) {
        model.setCommentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public TicketComment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TicketComment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<TicketComment> getAll() {
        return repository.findAll();
    }

    public TicketComment update(Long id, TicketComment model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketComment not found: " + id);
        }
        model.setCommentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketComment not found: " + id);
        }
        repository.deleteById(id);
    }
}

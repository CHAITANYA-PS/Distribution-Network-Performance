package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.SalesManager;
import com.tcs.dnp.service.SalesManagerService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/sales-managers")
public class SalesManagerController {
    private final SalesManagerService service;

    public SalesManagerController(SalesManagerService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<SalesManager> create(@Valid @RequestBody SalesManager model) {
        SalesManager saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/sales-managers/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public SalesManager get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<SalesManager> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public SalesManager update(@PathVariable Long id, @Valid @RequestBody SalesManager model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

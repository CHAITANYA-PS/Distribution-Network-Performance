package com.tcs.dnp.service;

import com.tcs.dnp.model.Notification;
import com.tcs.dnp.repository.NotificationRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class NotificationService {
    private final NotificationRepository repository;

    public NotificationService(NotificationRepository repository) {
        this.repository = repository;
    }

    public Notification create(Notification model) {
        model.setNotificationId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Notification get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Notification not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Notification> getAll() {
        return repository.findAll();
    }

    public Notification update(Long id, Notification model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Notification not found: " + id);
        }
        model.setNotificationId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Notification not found: " + id);
        }
        repository.deleteById(id);
    }
}

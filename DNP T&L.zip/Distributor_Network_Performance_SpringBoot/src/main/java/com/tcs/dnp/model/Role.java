package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="role",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Role {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="role_id")
 private Long roleId;
 @Column(name="role_name")
 private String roleName;
 @Column(name="description")
 private String description;
 @Column(name="status")
 private String status;
}
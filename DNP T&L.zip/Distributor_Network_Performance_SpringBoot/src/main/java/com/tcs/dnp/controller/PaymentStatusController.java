package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.PaymentStatus;
import com.tcs.dnp.service.PaymentStatusService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/payment-statuss")
public class PaymentStatusController {
    private final PaymentStatusService service;

    public PaymentStatusController(PaymentStatusService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<PaymentStatus> create(@Valid @RequestBody PaymentStatus model) {
        PaymentStatus saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/payment-statuss/" + saved.getPaymentStatusId())).body(saved);
    }

    @GetMapping("/{id}")
    public PaymentStatus get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<PaymentStatus> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public PaymentStatus update(@PathVariable Long id, @Valid @RequestBody PaymentStatus model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

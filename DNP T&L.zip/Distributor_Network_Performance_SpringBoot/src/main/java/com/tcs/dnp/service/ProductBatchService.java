package com.tcs.dnp.service;

import com.tcs.dnp.model.ProductBatch;
import com.tcs.dnp.repository.ProductBatchRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ProductBatchService {
    private final ProductBatchRepository repository;

    public ProductBatchService(ProductBatchRepository repository) {
        this.repository = repository;
    }

    public ProductBatch create(ProductBatch model) {
        model.setProductBatchId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ProductBatch get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ProductBatch not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ProductBatch> getAll() {
        return repository.findAll();
    }

    public ProductBatch update(Long id, ProductBatch model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ProductBatch not found: " + id);
        }
        model.setProductBatchId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ProductBatch not found: " + id);
        }
        repository.deleteById(id);
    }
}

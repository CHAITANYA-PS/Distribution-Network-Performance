package com.tcs.dnp.service;

import com.tcs.dnp.model.Payment;
import com.tcs.dnp.repository.PaymentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class PaymentService {
    private final PaymentRepository repository;

    public PaymentService(PaymentRepository repository) {
        this.repository = repository;
    }

    public Payment create(Payment model) {
        model.setPaymentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Payment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Payment> getAll() {
        return repository.findAll();
    }

    public Payment update(Long id, Payment model) {
        repository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("Payment not found: " + id));
        model.setPaymentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Payment not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.InventoryDocumentType;
import com.tcs.dnp.repository.InventoryDocumentTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class InventoryDocumentTypeService {
    private final InventoryDocumentTypeRepository repository;

    public InventoryDocumentTypeService(InventoryDocumentTypeRepository repository) {
        this.repository = repository;
    }

    public InventoryDocumentType create(InventoryDocumentType model) {
        model.setInventoryDocumentTypeId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public InventoryDocumentType get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InventoryDocumentType not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<InventoryDocumentType> getAll() {
        return repository.findAll();
    }

    public InventoryDocumentType update(Long id, InventoryDocumentType model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryDocumentType not found: " + id);
        }
        model.setInventoryDocumentTypeId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryDocumentType not found: " + id);
        }
        repository.deleteById(id);
    }
}

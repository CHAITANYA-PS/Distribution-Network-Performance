package com.tcs.dnp.service;

import com.tcs.dnp.model.TicketCategory;
import com.tcs.dnp.repository.TicketCategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class TicketCategoryService {
    private final TicketCategoryRepository repository;

    public TicketCategoryService(TicketCategoryRepository repository) {
        this.repository = repository;
    }

    public TicketCategory create(TicketCategory model) {
        model.setTicketCategoryId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public TicketCategory get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TicketCategory not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<TicketCategory> getAll() {
        return repository.findAll();
    }

    public TicketCategory update(Long id, TicketCategory model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketCategory not found: " + id);
        }
        model.setTicketCategoryId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketCategory not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.CommitmentProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentProgressRepository extends JpaRepository<CommitmentProgress, Long> {
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.SalesRecord;
import com.tcs.dnp.service.SalesRecordService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/sales-records")
public class SalesRecordController {
    private final SalesRecordService service;

    public SalesRecordController(SalesRecordService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<SalesRecord> create(@Valid @RequestBody SalesRecord model) {
        SalesRecord saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/sales-records/" + saved.getSalesRecordId())).body(saved);
    }

    @GetMapping("/{id}")
    public SalesRecord get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<SalesRecord> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public SalesRecord update(@PathVariable Long id, @Valid @RequestBody SalesRecord model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.SalesManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesManagerRepository extends JpaRepository<SalesManager, Long> {
}

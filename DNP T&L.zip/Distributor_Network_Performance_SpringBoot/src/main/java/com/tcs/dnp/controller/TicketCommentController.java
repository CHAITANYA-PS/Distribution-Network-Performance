package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.TicketComment;
import com.tcs.dnp.service.TicketCommentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/ticket-comments")
public class TicketCommentController {
    private final TicketCommentService service;

    public TicketCommentController(TicketCommentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<TicketComment> create(@Valid @RequestBody TicketComment model) {
        TicketComment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/ticket-comments/" + saved.getCommentId())).body(saved);
    }

    @GetMapping("/{id}")
    public TicketComment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<TicketComment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public TicketComment update(@PathVariable Long id, @Valid @RequestBody TicketComment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

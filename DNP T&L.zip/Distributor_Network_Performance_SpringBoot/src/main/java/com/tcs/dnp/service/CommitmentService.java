package com.tcs.dnp.service;

import com.tcs.dnp.model.Commitment;
import com.tcs.dnp.repository.CommitmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class CommitmentService {
    private final CommitmentRepository repository;

    public CommitmentService(CommitmentRepository repository) {
        this.repository = repository;
    }

    public Commitment create(Commitment model) {
        model.setCommitmentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Commitment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Commitment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Commitment> getAll() {
        return repository.findAll();
    }

    public Commitment update(Long id, Commitment model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Commitment not found: " + id);
        }
        model.setCommitmentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Commitment not found: " + id);
        }
        repository.deleteById(id);
    }
}

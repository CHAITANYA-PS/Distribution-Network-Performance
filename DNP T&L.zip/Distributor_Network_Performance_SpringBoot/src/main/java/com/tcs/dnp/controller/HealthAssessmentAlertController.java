package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.HealthAssessmentAlert;
import com.tcs.dnp.service.HealthAssessmentAlertService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/health-assessment-alerts")
public class HealthAssessmentAlertController {
    private final HealthAssessmentAlertService service;

    public HealthAssessmentAlertController(HealthAssessmentAlertService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<HealthAssessmentAlert> create(@Valid @RequestBody HealthAssessmentAlert model) {
        HealthAssessmentAlert saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/health-assessment-alerts/" + saved.getAlertId())).body(saved);
    }

    @GetMapping("/{id}")
    public HealthAssessmentAlert get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<HealthAssessmentAlert> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public HealthAssessmentAlert update(@PathVariable Long id, @Valid @RequestBody HealthAssessmentAlert model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

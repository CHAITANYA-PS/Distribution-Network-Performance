package com.tcs.dnp.service;

import com.tcs.dnp.model.InventoryAlert;
import com.tcs.dnp.repository.InventoryAlertRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class InventoryAlertService {
    private final InventoryAlertRepository repository;

    public InventoryAlertService(InventoryAlertRepository repository) {
        this.repository = repository;
    }

    public InventoryAlert create(InventoryAlert model) {
        model.setAlertId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public InventoryAlert get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InventoryAlert not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<InventoryAlert> getAll() {
        return repository.findAll();
    }

    public InventoryAlert update(Long id, InventoryAlert model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryAlert not found: " + id);
        }
        model.setAlertId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryAlert not found: " + id);
        }
        repository.deleteById(id);
    }
}

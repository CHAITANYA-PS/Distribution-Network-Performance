package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.InventoryAlert;
import com.tcs.dnp.service.InventoryAlertService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory-alerts")
public class InventoryAlertController {
    private final InventoryAlertService service;

    public InventoryAlertController(InventoryAlertService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InventoryAlert> create(@Valid @RequestBody InventoryAlert model) {
        InventoryAlert saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/inventory-alerts/" + saved.getAlertId())).body(saved);
    }

    @GetMapping("/{id}")
    public InventoryAlert get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<InventoryAlert> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public InventoryAlert update(@PathVariable Long id, @Valid @RequestBody InventoryAlert model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

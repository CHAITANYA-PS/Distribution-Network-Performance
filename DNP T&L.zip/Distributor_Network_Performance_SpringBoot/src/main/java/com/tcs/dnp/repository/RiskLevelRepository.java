package com.tcs.dnp.repository;

import com.tcs.dnp.model.RiskLevel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskLevelRepository extends JpaRepository<RiskLevel, Long> {
}

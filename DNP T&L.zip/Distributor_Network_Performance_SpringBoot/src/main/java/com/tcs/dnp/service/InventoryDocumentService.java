package com.tcs.dnp.service;

import com.tcs.dnp.model.InventoryDocument;
import com.tcs.dnp.repository.InventoryDocumentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class InventoryDocumentService {
    private final InventoryDocumentRepository repository;

    public InventoryDocumentService(InventoryDocumentRepository repository) {
        this.repository = repository;
    }

    public InventoryDocument create(InventoryDocument model) {
        model.setInventoryDocumentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public InventoryDocument get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InventoryDocument not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<InventoryDocument> getAll() {
        return repository.findAll();
    }

    public InventoryDocument update(Long id, InventoryDocument model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryDocument not found: " + id);
        }
        model.setInventoryDocumentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryDocument not found: " + id);
        }
        repository.deleteById(id);
    }
}

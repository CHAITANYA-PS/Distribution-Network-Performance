package com.tcs.dnp.service;

import com.tcs.dnp.model.ExchangeStatus;
import com.tcs.dnp.repository.ExchangeStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ExchangeStatusService {
    private final ExchangeStatusRepository repository;

    public ExchangeStatusService(ExchangeStatusRepository repository) {
        this.repository = repository;
    }

    public ExchangeStatus create(ExchangeStatus model) {
        model.setExchangeStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ExchangeStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ExchangeStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ExchangeStatus> getAll() {
        return repository.findAll();
    }

    public ExchangeStatus update(Long id, ExchangeStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ExchangeStatus not found: " + id);
        }
        model.setExchangeStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ExchangeStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

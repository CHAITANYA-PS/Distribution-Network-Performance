package com.tcs.dnp.service;

import com.tcs.dnp.model.RecoveryPlanTicket;
import com.tcs.dnp.repository.RecoveryPlanTicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RecoveryPlanTicketService {
    private final RecoveryPlanTicketRepository repository;

    public RecoveryPlanTicketService(RecoveryPlanTicketRepository repository) {
        this.repository = repository;
    }

    public RecoveryPlanTicket create(RecoveryPlanTicket model) {
        model.setRecoveryPlanTicketId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public RecoveryPlanTicket get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RecoveryPlanTicket not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RecoveryPlanTicket> getAll() {
        return repository.findAll();
    }

    public RecoveryPlanTicket update(Long id, RecoveryPlanTicket model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryPlanTicket not found: " + id);
        }
        model.setRecoveryPlanTicketId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryPlanTicket not found: " + id);
        }
        repository.deleteById(id);
    }
}

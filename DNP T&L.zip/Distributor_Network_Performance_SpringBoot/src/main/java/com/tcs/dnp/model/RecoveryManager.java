package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="recovery_manager",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryManager {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="region_id")
 private Long regionId;
}
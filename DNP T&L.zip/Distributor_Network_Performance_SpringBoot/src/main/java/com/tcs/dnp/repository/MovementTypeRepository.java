package com.tcs.dnp.repository;

import com.tcs.dnp.model.MovementType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovementTypeRepository extends JpaRepository<MovementType, Long> {
}

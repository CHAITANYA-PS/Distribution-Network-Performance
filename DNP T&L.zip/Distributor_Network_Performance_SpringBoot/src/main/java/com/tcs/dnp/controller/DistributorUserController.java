package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.DistributorUser;
import com.tcs.dnp.service.DistributorUserService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/distributor-users")
public class DistributorUserController {
    private final DistributorUserService service;

    public DistributorUserController(DistributorUserService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<DistributorUser> create(@Valid @RequestBody DistributorUser model) {
        DistributorUser saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/distributor-users/" + saved.getUserId())).body(saved);
    }

    @GetMapping("/{id}")
    public DistributorUser get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<DistributorUser> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public DistributorUser update(@PathVariable Long id, @Valid @RequestBody DistributorUser model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

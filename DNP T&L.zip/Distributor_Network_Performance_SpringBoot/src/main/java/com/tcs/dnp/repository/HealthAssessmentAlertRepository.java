package com.tcs.dnp.repository;

import com.tcs.dnp.model.HealthAssessmentAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthAssessmentAlertRepository extends JpaRepository<HealthAssessmentAlert, Long> {
}

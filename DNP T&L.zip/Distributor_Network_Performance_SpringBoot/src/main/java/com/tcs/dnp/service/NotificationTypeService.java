package com.tcs.dnp.service;

import com.tcs.dnp.model.NotificationType;
import com.tcs.dnp.repository.NotificationTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class NotificationTypeService {
    private final NotificationTypeRepository repository;

    public NotificationTypeService(NotificationTypeRepository repository) {
        this.repository = repository;
    }

    public NotificationType create(NotificationType model) {
        model.setNotificationTypeId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public NotificationType get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("NotificationType not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<NotificationType> getAll() {
        return repository.findAll();
    }

    public NotificationType update(Long id, NotificationType model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("NotificationType not found: " + id);
        }
        model.setNotificationTypeId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("NotificationType not found: " + id);
        }
        repository.deleteById(id);
    }
}

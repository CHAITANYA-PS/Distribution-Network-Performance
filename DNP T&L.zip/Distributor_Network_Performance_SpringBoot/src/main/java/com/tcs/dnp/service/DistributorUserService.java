package com.tcs.dnp.service;

import com.tcs.dnp.model.DistributorUser;
import com.tcs.dnp.repository.DistributorUserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorUserService {
    private final DistributorUserRepository repository;

    public DistributorUserService(DistributorUserRepository repository) {
        this.repository = repository;
    }

    public DistributorUser create(DistributorUser model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public DistributorUser get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorUser not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<DistributorUser> getAll() {
        return repository.findAll();
    }

    public DistributorUser update(Long id, DistributorUser model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorUser not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorUser not found: " + id);
        }
        repository.deleteById(id);
    }
}

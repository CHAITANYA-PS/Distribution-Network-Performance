package com.tcs.dnp.service;

import com.tcs.dnp.model.Distributor;
import com.tcs.dnp.repository.DistributorRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorService {
    private final DistributorRepository repository;

    public DistributorService(DistributorRepository repository) {
        this.repository = repository;
    }

    public Distributor create(Distributor model) {
        model.setDistributorId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Distributor get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Distributor not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Distributor> getAll() {
        return repository.findAll();
    }

    public Distributor update(Long id, Distributor model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Distributor not found: " + id);
        }
        model.setDistributorId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Distributor not found: " + id);
        }
        repository.deleteById(id);
    }
}

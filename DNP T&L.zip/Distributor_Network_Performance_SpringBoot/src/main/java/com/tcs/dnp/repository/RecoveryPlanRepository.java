package com.tcs.dnp.repository;

import com.tcs.dnp.model.RecoveryPlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanRepository extends JpaRepository<RecoveryPlan, Long> {
}

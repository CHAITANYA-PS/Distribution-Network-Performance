package com.tcs.dnp.repository;

import com.tcs.dnp.model.DistributorUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorUserRepository extends JpaRepository<DistributorUser, Long> {
}

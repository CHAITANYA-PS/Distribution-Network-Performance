package com.tcs.dnp.service;

import com.tcs.dnp.model.OrderStatus;
import com.tcs.dnp.repository.OrderStatusRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class OrderStatusService {
    private final OrderStatusRepository repository;

    public OrderStatusService(OrderStatusRepository repository) {
        this.repository = repository;
    }

    public OrderStatus create(OrderStatus model) {
        model.setOrderStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public OrderStatus get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OrderStatus not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<OrderStatus> getAll() {
        return repository.findAll();
    }

    public OrderStatus update(Long id, OrderStatus model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("OrderStatus not found: " + id);
        }
        model.setOrderStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("OrderStatus not found: " + id);
        }
        repository.deleteById(id);
    }
}

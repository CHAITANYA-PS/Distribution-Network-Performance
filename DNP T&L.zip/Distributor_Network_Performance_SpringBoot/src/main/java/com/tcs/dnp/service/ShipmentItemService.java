package com.tcs.dnp.service;

import com.tcs.dnp.model.ShipmentItem;
import com.tcs.dnp.repository.ShipmentItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ShipmentItemService {
    private final ShipmentItemRepository repository;

    public ShipmentItemService(ShipmentItemRepository repository) {
        this.repository = repository;
    }

    public ShipmentItem create(ShipmentItem model) {
        model.setShipmentItemId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ShipmentItem get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ShipmentItem not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ShipmentItem> getAll() {
        return repository.findAll();
    }

    public ShipmentItem update(Long id, ShipmentItem model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ShipmentItem not found: " + id);
        }
        model.setShipmentItemId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ShipmentItem not found: " + id);
        }
        repository.deleteById(id);
    }
}

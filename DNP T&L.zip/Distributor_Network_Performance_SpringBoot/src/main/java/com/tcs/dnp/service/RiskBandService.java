package com.tcs.dnp.service;

import com.tcs.dnp.model.RiskBand;
import com.tcs.dnp.repository.RiskBandRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RiskBandService {
    private final RiskBandRepository repository;

    public RiskBandService(RiskBandRepository repository) {
        this.repository = repository;
    }

    public RiskBand create(RiskBand model) {
        model.setRiskBandId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public RiskBand get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RiskBand not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RiskBand> getAll() {
        return repository.findAll();
    }

    public RiskBand update(Long id, RiskBand model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RiskBand not found: " + id);
        }
        model.setRiskBandId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RiskBand not found: " + id);
        }
        repository.deleteById(id);
    }
}

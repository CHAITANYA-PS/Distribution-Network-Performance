package com.tcs.dnp.service;

import com.tcs.dnp.model.HealthAssessmentAlert;
import com.tcs.dnp.repository.HealthAssessmentAlertRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class HealthAssessmentAlertService {
    private final HealthAssessmentAlertRepository repository;

    public HealthAssessmentAlertService(HealthAssessmentAlertRepository repository) {
        this.repository = repository;
    }

    public HealthAssessmentAlert create(HealthAssessmentAlert model) {
        model.setAlertId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public HealthAssessmentAlert get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("HealthAssessmentAlert not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<HealthAssessmentAlert> getAll() {
        return repository.findAll();
    }

    public HealthAssessmentAlert update(Long id, HealthAssessmentAlert model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("HealthAssessmentAlert not found: " + id);
        }
        model.setAlertId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("HealthAssessmentAlert not found: " + id);
        }
        repository.deleteById(id);
    }
}

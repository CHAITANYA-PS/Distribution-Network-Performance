package com.tcs.dnp.service;

import com.tcs.dnp.model.DistributorCategory;
import com.tcs.dnp.repository.DistributorCategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorCategoryService {
    private final DistributorCategoryRepository repository;

    public DistributorCategoryService(DistributorCategoryRepository repository) {
        this.repository = repository;
    }

    public DistributorCategory create(DistributorCategory model) {
        model.setDistributorCategoryId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public DistributorCategory get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorCategory not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<DistributorCategory> getAll() {
        return repository.findAll();
    }

    public DistributorCategory update(Long id, DistributorCategory model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorCategory not found: " + id);
        }
        model.setDistributorCategoryId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorCategory not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.Role;
import com.tcs.dnp.repository.RoleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RoleService {
    private final RoleRepository repository;

    public RoleService(RoleRepository repository) {
        this.repository = repository;
    }

    public Role create(Role model) {
        model.setRoleId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Role get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Role not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Role> getAll() {
        return repository.findAll();
    }

    public Role update(Long id, Role model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Role not found: " + id);
        }
        model.setRoleId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Role not found: " + id);
        }
        repository.deleteById(id);
    }
}

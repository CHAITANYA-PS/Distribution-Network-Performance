package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="finance_manager",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class FinanceManager {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="department_id")
 private Long departmentId;
}
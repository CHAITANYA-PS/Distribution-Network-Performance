package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.CommitmentHistory;
import com.tcs.dnp.service.CommitmentHistoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/commitment-historys")
public class CommitmentHistoryController {
    private final CommitmentHistoryService service;

    public CommitmentHistoryController(CommitmentHistoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CommitmentHistory> create(@Valid @RequestBody CommitmentHistory model) {
        CommitmentHistory saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/commitment-historys/" + saved.getHistoryId())).body(saved);
    }

    @GetMapping("/{id}")
    public CommitmentHistory get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<CommitmentHistory> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public CommitmentHistory update(@PathVariable Long id, @Valid @RequestBody CommitmentHistory model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

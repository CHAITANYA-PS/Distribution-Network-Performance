package com.tcs.dnp.service;

import com.tcs.dnp.model.TicketPriority;
import com.tcs.dnp.repository.TicketPriorityRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class TicketPriorityService {
    private final TicketPriorityRepository repository;

    public TicketPriorityService(TicketPriorityRepository repository) {
        this.repository = repository;
    }

    public TicketPriority create(TicketPriority model) {
        model.setTicketPriorityId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public TicketPriority get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TicketPriority not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<TicketPriority> getAll() {
        return repository.findAll();
    }

    public TicketPriority update(Long id, TicketPriority model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketPriority not found: " + id);
        }
        model.setTicketPriorityId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TicketPriority not found: " + id);
        }
        repository.deleteById(id);
    }
}

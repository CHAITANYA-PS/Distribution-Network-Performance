package com.tcs.dnp.service;

import com.tcs.dnp.model.TransportationActivity;
import com.tcs.dnp.repository.TransportationActivityRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class TransportationActivityService {
    private final TransportationActivityRepository repository;

    public TransportationActivityService(TransportationActivityRepository repository) {
        this.repository = repository;
    }

    public TransportationActivity create(TransportationActivity model) {
        model.setTransportationActivityId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public TransportationActivity get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("TransportationActivity not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<TransportationActivity> getAll() {
        return repository.findAll();
    }

    public TransportationActivity update(Long id, TransportationActivity model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TransportationActivity not found: " + id);
        }
        model.setTransportationActivityId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("TransportationActivity not found: " + id);
        }
        repository.deleteById(id);
    }
}

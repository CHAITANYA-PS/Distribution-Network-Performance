package com.tcs.dnp.service;

import com.tcs.dnp.model.MovementType;
import com.tcs.dnp.repository.MovementTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class MovementTypeService {
    private final MovementTypeRepository repository;

    public MovementTypeService(MovementTypeRepository repository) {
        this.repository = repository;
    }

    public MovementType create(MovementType model) {
        model.setMovementTypeId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public MovementType get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MovementType not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<MovementType> getAll() {
        return repository.findAll();
    }

    public MovementType update(Long id, MovementType model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("MovementType not found: " + id);
        }
        model.setMovementTypeId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("MovementType not found: " + id);
        }
        repository.deleteById(id);
    }
}

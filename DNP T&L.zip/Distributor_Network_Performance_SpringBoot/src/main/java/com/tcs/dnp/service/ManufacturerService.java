package com.tcs.dnp.service;

import com.tcs.dnp.model.Manufacturer;
import com.tcs.dnp.repository.ManufacturerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ManufacturerService {
    private final ManufacturerRepository repository;

    public ManufacturerService(ManufacturerRepository repository) {
        this.repository = repository;
    }

    public Manufacturer create(Manufacturer model) {
        model.setManufacturerId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Manufacturer get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Manufacturer not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Manufacturer> getAll() {
        return repository.findAll();
    }

    public Manufacturer update(Long id, Manufacturer model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Manufacturer not found: " + id);
        }
        model.setManufacturerId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Manufacturer not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.SystemAdmin;
import com.tcs.dnp.repository.SystemAdminRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class SystemAdminService {
    private final SystemAdminRepository repository;

    public SystemAdminService(SystemAdminRepository repository) {
        this.repository = repository;
    }

    public SystemAdmin create(SystemAdmin model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public SystemAdmin get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("SystemAdmin not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<SystemAdmin> getAll() {
        return repository.findAll();
    }

    public SystemAdmin update(Long id, SystemAdmin model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SystemAdmin not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("SystemAdmin not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.repository;

import com.tcs.dnp.model.HealthParameter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterRepository extends JpaRepository<HealthParameter, Long> {
}

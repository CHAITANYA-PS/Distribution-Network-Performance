package com.tcs.dnp.service;

import com.tcs.dnp.model.Department;
import com.tcs.dnp.repository.DepartmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DepartmentService {
    private final DepartmentRepository repository;

    public DepartmentService(DepartmentRepository repository) {
        this.repository = repository;
    }

    public Department create(Department model) {
        model.setDepartmentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Department get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Department not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Department> getAll() {
        return repository.findAll();
    }

    public Department update(Long id, Department model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Department not found: " + id);
        }
        model.setDepartmentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Department not found: " + id);
        }
        repository.deleteById(id);
    }
}

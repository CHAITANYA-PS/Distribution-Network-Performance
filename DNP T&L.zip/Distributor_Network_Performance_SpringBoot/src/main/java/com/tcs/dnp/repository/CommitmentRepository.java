package com.tcs.dnp.repository;

import com.tcs.dnp.model.Commitment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentRepository extends JpaRepository<Commitment, Long> {
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.HealthParameter;
import com.tcs.dnp.repository.HealthParameterRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class HealthParameterService {
    private final HealthParameterRepository repository;

    public HealthParameterService(HealthParameterRepository repository) {
        this.repository = repository;
    }

    public HealthParameter create(HealthParameter model) {
        model.setParameterId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public HealthParameter get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("HealthParameter not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<HealthParameter> getAll() {
        return repository.findAll();
    }

    public HealthParameter update(Long id, HealthParameter model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("HealthParameter not found: " + id);
        }
        model.setParameterId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("HealthParameter not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.UserActivityLog;
import com.tcs.dnp.repository.UserActivityLogRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class UserActivityLogService {
    private final UserActivityLogRepository repository;

    public UserActivityLogService(UserActivityLogRepository repository) {
        this.repository = repository;
    }

    public UserActivityLog create(UserActivityLog model) {
        model.setLogId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public UserActivityLog get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("UserActivityLog not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<UserActivityLog> getAll() {
        return repository.findAll();
    }

    public UserActivityLog update(Long id, UserActivityLog model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("UserActivityLog not found: " + id);
        }
        model.setLogId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("UserActivityLog not found: " + id);
        }
        repository.deleteById(id);
    }
}

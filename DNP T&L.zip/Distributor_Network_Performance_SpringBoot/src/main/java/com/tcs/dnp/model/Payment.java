package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.LocalDate;
@Entity @Table(name="payment",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Payment {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="payment_id")
 private Long paymentId;
 @Column(name="invoice_id")
 private Long invoiceId;
 @Column(name="payment_method_id")
 private Long paymentMethodId;
 @Column(name="payment_status_id")
 private Long paymentStatusId;
 @Column(name="transaction_reference")
 private String transactionReference;
 @Column(name="payment_date")
 private LocalDate paymentDate;
 @Column(name="amount")
 private BigDecimal amount;
}
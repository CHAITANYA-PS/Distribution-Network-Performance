package com.tcs.dnp.service;

import com.tcs.dnp.model.ContinuityStatusType;
import com.tcs.dnp.repository.ContinuityStatusTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ContinuityStatusTypeService {
    private final ContinuityStatusTypeRepository repository;

    public ContinuityStatusTypeService(ContinuityStatusTypeRepository repository) {
        this.repository = repository;
    }

    public ContinuityStatusType create(ContinuityStatusType model) {
        model.setContinuityStatusId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ContinuityStatusType get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ContinuityStatusType not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ContinuityStatusType> getAll() {
        return repository.findAll();
    }

    public ContinuityStatusType update(Long id, ContinuityStatusType model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ContinuityStatusType not found: " + id);
        }
        model.setContinuityStatusId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ContinuityStatusType not found: " + id);
        }
        repository.deleteById(id);
    }
}

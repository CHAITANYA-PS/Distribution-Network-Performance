package com.tcs.dnp.service;

import com.tcs.dnp.model.Ticket;
import com.tcs.dnp.repository.TicketRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class TicketService {
    private final TicketRepository repository;

    public TicketService(TicketRepository repository) {
        this.repository = repository;
    }

    public Ticket create(Ticket model) {
        model.setTicketId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Ticket get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Ticket not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Ticket> getAll() {
        return repository.findAll();
    }

    public Ticket update(Long id, Ticket model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Ticket not found: " + id);
        }
        model.setTicketId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Ticket not found: " + id);
        }
        repository.deleteById(id);
    }
}

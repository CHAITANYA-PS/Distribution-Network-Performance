package com.tcs.dnp.service;

import com.tcs.dnp.model.Warehouse;
import com.tcs.dnp.repository.WarehouseRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class WarehouseService {
    private final WarehouseRepository repository;

    public WarehouseService(WarehouseRepository repository) {
        this.repository = repository;
    }

    public Warehouse create(Warehouse model) {
        model.setWarehouseId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Warehouse get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Warehouse not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Warehouse> getAll() {
        return repository.findAll();
    }

    public Warehouse update(Long id, Warehouse model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Warehouse not found: " + id);
        }
        model.setWarehouseId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Warehouse not found: " + id);
        }
        repository.deleteById(id);
    }
}

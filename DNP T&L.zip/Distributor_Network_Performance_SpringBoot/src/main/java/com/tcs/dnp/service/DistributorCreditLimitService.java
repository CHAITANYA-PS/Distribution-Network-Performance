package com.tcs.dnp.service;

import com.tcs.dnp.model.DistributorCreditLimit;
import com.tcs.dnp.repository.DistributorCreditLimitRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorCreditLimitService {
    private final DistributorCreditLimitRepository repository;

    public DistributorCreditLimitService(DistributorCreditLimitRepository repository) {
        this.repository = repository;
    }

    public DistributorCreditLimit create(DistributorCreditLimit model) {
        model.setCreditLimitId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public DistributorCreditLimit get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorCreditLimit not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<DistributorCreditLimit> getAll() {
        return repository.findAll();
    }

    public DistributorCreditLimit update(Long id, DistributorCreditLimit model) {
        repository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorCreditLimit not found: " + id));
        model.setCreditLimitId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorCreditLimit not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="recovery_plan_ticket",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RecoveryPlanTicket {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="recovery_plan_ticket_id")
 private Long recoveryPlanTicketId;
 @Column(name="recovery_plan_id")
 private Long recoveryPlanId;
 @Column(name="ticket_id")
 private Long ticketId;
}
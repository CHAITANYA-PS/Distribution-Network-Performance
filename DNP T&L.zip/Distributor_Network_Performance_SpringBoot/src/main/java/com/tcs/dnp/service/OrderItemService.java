package com.tcs.dnp.service;

import com.tcs.dnp.model.OrderItem;
import com.tcs.dnp.repository.OrderItemRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class OrderItemService {
    private final OrderItemRepository repository;

    public OrderItemService(OrderItemRepository repository) {
        this.repository = repository;
    }

    public OrderItem create(OrderItem model) {
        model.setOrderItemId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public OrderItem get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OrderItem not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<OrderItem> getAll() {
        return repository.findAll();
    }

    public OrderItem update(Long id, OrderItem model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("OrderItem not found: " + id);
        }
        model.setOrderItemId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("OrderItem not found: " + id);
        }
        repository.deleteById(id);
    }
}

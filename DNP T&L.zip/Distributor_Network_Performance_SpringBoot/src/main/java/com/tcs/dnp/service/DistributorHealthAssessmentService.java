package com.tcs.dnp.service;

import com.tcs.dnp.model.DistributorHealthAssessment;
import com.tcs.dnp.repository.DistributorHealthAssessmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorHealthAssessmentService {
    private final DistributorHealthAssessmentRepository repository;

    public DistributorHealthAssessmentService(DistributorHealthAssessmentRepository repository) {
        this.repository = repository;
    }

    public DistributorHealthAssessment create(DistributorHealthAssessment model) {
        model.setAssessmentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public DistributorHealthAssessment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorHealthAssessment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<DistributorHealthAssessment> getAll() {
        return repository.findAll();
    }

    public DistributorHealthAssessment update(Long id, DistributorHealthAssessment model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorHealthAssessment not found: " + id);
        }
        model.setAssessmentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorHealthAssessment not found: " + id);
        }
        repository.deleteById(id);
    }
}

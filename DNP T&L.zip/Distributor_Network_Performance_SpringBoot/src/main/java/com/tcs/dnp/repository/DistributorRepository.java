package com.tcs.dnp.repository;

import com.tcs.dnp.model.Distributor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorRepository extends JpaRepository<Distributor, Long> {
}

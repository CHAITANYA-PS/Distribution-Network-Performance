package com.tcs.dnp.repository;

import com.tcs.dnp.model.ExchangeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExchangeStatusRepository extends JpaRepository<ExchangeStatus, Long> {
}

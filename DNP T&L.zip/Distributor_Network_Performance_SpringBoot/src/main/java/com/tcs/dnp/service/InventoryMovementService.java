package com.tcs.dnp.service;

import com.tcs.dnp.model.InventoryMovement;
import com.tcs.dnp.repository.InventoryMovementRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class InventoryMovementService {
    private final InventoryMovementRepository repository;

    public InventoryMovementService(InventoryMovementRepository repository) {
        this.repository = repository;
    }

    public InventoryMovement create(InventoryMovement model) {
        model.setMovementId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public InventoryMovement get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("InventoryMovement not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<InventoryMovement> getAll() {
        return repository.findAll();
    }

    public InventoryMovement update(Long id, InventoryMovement model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryMovement not found: " + id);
        }
        model.setMovementId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("InventoryMovement not found: " + id);
        }
        repository.deleteById(id);
    }
}

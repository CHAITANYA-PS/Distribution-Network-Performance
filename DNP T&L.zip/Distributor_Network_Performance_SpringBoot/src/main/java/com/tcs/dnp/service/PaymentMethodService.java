package com.tcs.dnp.service;

import com.tcs.dnp.model.PaymentMethod;
import com.tcs.dnp.repository.PaymentMethodRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class PaymentMethodService {
    private final PaymentMethodRepository repository;

    public PaymentMethodService(PaymentMethodRepository repository) {
        this.repository = repository;
    }

    public PaymentMethod create(PaymentMethod model) {
        model.setPaymentMethodId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public PaymentMethod get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("PaymentMethod not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<PaymentMethod> getAll() {
        return repository.findAll();
    }

    public PaymentMethod update(Long id, PaymentMethod model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PaymentMethod not found: " + id);
        }
        model.setPaymentMethodId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("PaymentMethod not found: " + id);
        }
        repository.deleteById(id);
    }
}

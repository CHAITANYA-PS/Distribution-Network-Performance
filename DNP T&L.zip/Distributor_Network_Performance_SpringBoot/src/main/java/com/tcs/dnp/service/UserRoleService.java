package com.tcs.dnp.service;

import com.tcs.dnp.model.UserRole;
import com.tcs.dnp.repository.UserRoleRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class UserRoleService {
    private final UserRoleRepository repository;

    public UserRoleService(UserRoleRepository repository) {
        this.repository = repository;
    }

    public UserRole create(UserRole model) {
        model.setUserRoleId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public UserRole get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("UserRole not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<UserRole> getAll() {
        return repository.findAll();
    }

    public UserRole update(Long id, UserRole model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("UserRole not found: " + id);
        }
        model.setUserRoleId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("UserRole not found: " + id);
        }
        repository.deleteById(id);
    }
}

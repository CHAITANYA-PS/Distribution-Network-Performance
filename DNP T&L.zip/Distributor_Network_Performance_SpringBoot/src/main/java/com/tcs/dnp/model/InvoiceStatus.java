package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="invoice_status",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class InvoiceStatus {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="invoice_status_id")
 private Long invoiceStatusId;
 @Column(name="status_name")
 private String statusName;
}
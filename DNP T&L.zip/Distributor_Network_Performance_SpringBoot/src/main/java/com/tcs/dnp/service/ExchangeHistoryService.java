package com.tcs.dnp.service;

import com.tcs.dnp.model.ExchangeHistory;
import com.tcs.dnp.repository.ExchangeHistoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ExchangeHistoryService {
    private final ExchangeHistoryRepository repository;

    public ExchangeHistoryService(ExchangeHistoryRepository repository) {
        this.repository = repository;
    }

    public ExchangeHistory create(ExchangeHistory model) {
        model.setExchangeHistoryId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ExchangeHistory get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ExchangeHistory not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ExchangeHistory> getAll() {
        return repository.findAll();
    }

    public ExchangeHistory update(Long id, ExchangeHistory model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ExchangeHistory not found: " + id);
        }
        model.setExchangeHistoryId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ExchangeHistory not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.CreditRiskAssessment;
import com.tcs.dnp.service.CreditRiskAssessmentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/credit-risk-assessments")
public class CreditRiskAssessmentController {
    private final CreditRiskAssessmentService service;

    public CreditRiskAssessmentController(CreditRiskAssessmentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CreditRiskAssessment> create(@Valid @RequestBody CreditRiskAssessment model) {
        CreditRiskAssessment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/credit-risk-assessments/" + saved.getRiskAssessmentId())).body(saved);
    }

    @GetMapping("/{id}")
    public CreditRiskAssessment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<CreditRiskAssessment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public CreditRiskAssessment update(@PathVariable Long id, @Valid @RequestBody CreditRiskAssessment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

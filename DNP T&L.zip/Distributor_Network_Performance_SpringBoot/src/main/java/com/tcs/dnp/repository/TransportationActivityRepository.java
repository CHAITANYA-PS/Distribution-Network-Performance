package com.tcs.dnp.repository;

import com.tcs.dnp.model.TransportationActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransportationActivityRepository extends JpaRepository<TransportationActivity, Long> {
}

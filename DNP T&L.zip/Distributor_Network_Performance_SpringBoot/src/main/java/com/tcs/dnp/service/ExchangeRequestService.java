package com.tcs.dnp.service;

import com.tcs.dnp.model.ExchangeRequest;
import com.tcs.dnp.repository.ExchangeRequestRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ExchangeRequestService {
    private final ExchangeRequestRepository repository;

    public ExchangeRequestService(ExchangeRequestRepository repository) {
        this.repository = repository;
    }

    public ExchangeRequest create(ExchangeRequest model) {
        model.setExchangeId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ExchangeRequest get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ExchangeRequest not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ExchangeRequest> getAll() {
        return repository.findAll();
    }

    public ExchangeRequest update(Long id, ExchangeRequest model) {
        repository.findByIdForUpdate(id)
                .orElseThrow(() -> new ResourceNotFoundException("ExchangeRequest not found: " + id));
        model.setExchangeId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ExchangeRequest not found: " + id);
        }
        repository.deleteById(id);
    }
}

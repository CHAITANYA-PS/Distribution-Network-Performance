package com.tcs.dnp.service;

import com.tcs.dnp.model.CommitmentHistory;
import com.tcs.dnp.repository.CommitmentHistoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class CommitmentHistoryService {
    private final CommitmentHistoryRepository repository;

    public CommitmentHistoryService(CommitmentHistoryRepository repository) {
        this.repository = repository;
    }

    public CommitmentHistory create(CommitmentHistory model) {
        model.setHistoryId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public CommitmentHistory get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("CommitmentHistory not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<CommitmentHistory> getAll() {
        return repository.findAll();
    }

    public CommitmentHistory update(Long id, CommitmentHistory model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CommitmentHistory not found: " + id);
        }
        model.setHistoryId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CommitmentHistory not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.service;

import com.tcs.dnp.model.ActivityType;
import com.tcs.dnp.repository.ActivityTypeRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ActivityTypeService {
    private final ActivityTypeRepository repository;

    public ActivityTypeService(ActivityTypeRepository repository) {
        this.repository = repository;
    }

    public ActivityType create(ActivityType model) {
        model.setActivityTypeId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ActivityType get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ActivityType not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ActivityType> getAll() {
        return repository.findAll();
    }

    public ActivityType update(Long id, ActivityType model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ActivityType not found: " + id);
        }
        model.setActivityTypeId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ActivityType not found: " + id);
        }
        repository.deleteById(id);
    }
}

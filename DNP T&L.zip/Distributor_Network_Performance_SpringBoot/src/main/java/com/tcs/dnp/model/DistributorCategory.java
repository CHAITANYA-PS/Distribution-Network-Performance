package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_category",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorCategory {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="distributor_category_id")
 private Long distributorCategoryId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="category_id")
 private Long categoryId;
 @Column(name="assigned_at")
 private OffsetDateTime assignedAt;
 @Column(name="status")
 private String status;
}
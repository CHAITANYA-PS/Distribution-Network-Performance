package com.tcs.dnp.service;

import com.tcs.dnp.model.OrderStatusHistory;
import com.tcs.dnp.repository.OrderStatusHistoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class OrderStatusHistoryService {
    private final OrderStatusHistoryRepository repository;

    public OrderStatusHistoryService(OrderStatusHistoryRepository repository) {
        this.repository = repository;
    }

    public OrderStatusHistory create(OrderStatusHistory model) {
        model.setOrderStatusHistoryId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public OrderStatusHistory get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("OrderStatusHistory not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<OrderStatusHistory> getAll() {
        return repository.findAll();
    }

    public OrderStatusHistory update(Long id, OrderStatusHistory model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("OrderStatusHistory not found: " + id);
        }
        model.setOrderStatusHistoryId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("OrderStatusHistory not found: " + id);
        }
        repository.deleteById(id);
    }
}

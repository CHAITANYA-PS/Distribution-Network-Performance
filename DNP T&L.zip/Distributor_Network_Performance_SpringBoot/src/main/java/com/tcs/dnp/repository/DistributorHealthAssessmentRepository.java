package com.tcs.dnp.repository;

import com.tcs.dnp.model.DistributorHealthAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorHealthAssessmentRepository extends JpaRepository<DistributorHealthAssessment, Long> {
}

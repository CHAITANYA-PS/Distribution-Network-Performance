package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.SalesTarget;
import com.tcs.dnp.service.SalesTargetService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/sales-targets")
public class SalesTargetController {
    private final SalesTargetService service;

    public SalesTargetController(SalesTargetService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<SalesTarget> create(@Valid @RequestBody SalesTarget model) {
        SalesTarget saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/sales-targets/" + saved.getTargetId())).body(saved);
    }

    @GetMapping("/{id}")
    public SalesTarget get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<SalesTarget> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public SalesTarget update(@PathVariable Long id, @Valid @RequestBody SalesTarget model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

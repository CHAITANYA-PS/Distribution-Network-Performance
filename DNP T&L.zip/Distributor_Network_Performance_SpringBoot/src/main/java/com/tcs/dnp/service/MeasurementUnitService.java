package com.tcs.dnp.service;

import com.tcs.dnp.model.MeasurementUnit;
import com.tcs.dnp.repository.MeasurementUnitRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class MeasurementUnitService {
    private final MeasurementUnitRepository repository;

    public MeasurementUnitService(MeasurementUnitRepository repository) {
        this.repository = repository;
    }

    public MeasurementUnit create(MeasurementUnit model) {
        model.setMeasurementUnitId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public MeasurementUnit get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("MeasurementUnit not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<MeasurementUnit> getAll() {
        return repository.findAll();
    }

    public MeasurementUnit update(Long id, MeasurementUnit model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("MeasurementUnit not found: " + id);
        }
        model.setMeasurementUnitId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("MeasurementUnit not found: " + id);
        }
        repository.deleteById(id);
    }
}

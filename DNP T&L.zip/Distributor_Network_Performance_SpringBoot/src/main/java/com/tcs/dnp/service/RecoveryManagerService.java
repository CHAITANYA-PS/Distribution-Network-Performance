package com.tcs.dnp.service;

import com.tcs.dnp.model.RecoveryManager;
import com.tcs.dnp.repository.RecoveryManagerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class RecoveryManagerService {
    private final RecoveryManagerRepository repository;

    public RecoveryManagerService(RecoveryManagerRepository repository) {
        this.repository = repository;
    }

    public RecoveryManager create(RecoveryManager model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public RecoveryManager get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("RecoveryManager not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<RecoveryManager> getAll() {
        return repository.findAll();
    }

    public RecoveryManager update(Long id, RecoveryManager model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryManager not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("RecoveryManager not found: " + id);
        }
        repository.deleteById(id);
    }
}

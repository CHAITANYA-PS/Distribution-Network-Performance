package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.UserActivityLog;
import com.tcs.dnp.service.UserActivityLogService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/user-activity-logs")
public class UserActivityLogController {
    private final UserActivityLogService service;

    public UserActivityLogController(UserActivityLogService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<UserActivityLog> create(@Valid @RequestBody UserActivityLog model) {
        UserActivityLog saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/user-activity-logs/" + saved.getLogId())).body(saved);
    }

    @GetMapping("/{id}")
    public UserActivityLog get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<UserActivityLog> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public UserActivityLog update(@PathVariable Long id, @Valid @RequestBody UserActivityLog model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

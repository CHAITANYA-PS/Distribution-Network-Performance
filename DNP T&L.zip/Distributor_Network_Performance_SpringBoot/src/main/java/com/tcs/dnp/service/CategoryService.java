package com.tcs.dnp.service;

import com.tcs.dnp.model.Category;
import com.tcs.dnp.repository.CategoryRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class CategoryService {
    private final CategoryRepository repository;

    public CategoryService(CategoryRepository repository) {
        this.repository = repository;
    }

    public Category create(Category model) {
        model.setCategoryId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public Category get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Category not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<Category> getAll() {
        return repository.findAll();
    }

    public Category update(Long id, Category model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Category not found: " + id);
        }
        model.setCategoryId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("Category not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="continuity_status_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ContinuityStatusType {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="continuity_status_id")
 private Long continuityStatusId;
 @Column(name="status_name")
 private String statusName;
 @Column(name="description")
 private String description;
}
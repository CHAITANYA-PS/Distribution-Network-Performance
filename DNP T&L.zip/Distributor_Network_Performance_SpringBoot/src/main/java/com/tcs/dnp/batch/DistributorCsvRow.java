package com.tcs.dnp.batch;
import lombok.*; @Getter @Setter @NoArgsConstructor public class DistributorCsvRow { private String distributorCode; private String distributorName; private Long regionId; private String contactPerson; private String email; private String phone; private String address; private String status; }

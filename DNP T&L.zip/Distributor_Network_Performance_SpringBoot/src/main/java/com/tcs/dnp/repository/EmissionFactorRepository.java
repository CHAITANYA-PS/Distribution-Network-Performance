package com.tcs.dnp.repository;

import com.tcs.dnp.model.EmissionFactor;
import org.springframework.data.jpa.repository.JpaRepository;

public interface EmissionFactorRepository extends JpaRepository<EmissionFactor, Long> {
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.InventoryMovement;
import com.tcs.dnp.service.InventoryMovementService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory-movements")
public class InventoryMovementController {
    private final InventoryMovementService service;

    public InventoryMovementController(InventoryMovementService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InventoryMovement> create(@Valid @RequestBody InventoryMovement model) {
        InventoryMovement saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/inventory-movements/" + saved.getMovementId())).body(saved);
    }

    @GetMapping("/{id}")
    public InventoryMovement get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<InventoryMovement> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public InventoryMovement update(@PathVariable Long id, @Valid @RequestBody InventoryMovement model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

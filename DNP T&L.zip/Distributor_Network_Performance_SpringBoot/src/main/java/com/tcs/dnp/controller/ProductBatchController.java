package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.ProductBatch;
import com.tcs.dnp.service.ProductBatchService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/product-batchs")
public class ProductBatchController {
    private final ProductBatchService service;

    public ProductBatchController(ProductBatchService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ProductBatch> create(@Valid @RequestBody ProductBatch model) {
        ProductBatch saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/product-batchs/" + saved.getProductBatchId())).body(saved);
    }

    @GetMapping("/{id}")
    public ProductBatch get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ProductBatch> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ProductBatch update(@PathVariable Long id, @Valid @RequestBody ProductBatch model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="ticket_priority",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketPriority {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_priority_id")
 private Long ticketPriorityId;
 @Column(name="priority_name")
 private String priorityName;
 @Column(name="severity_rank")
 private Integer severityRank;
}
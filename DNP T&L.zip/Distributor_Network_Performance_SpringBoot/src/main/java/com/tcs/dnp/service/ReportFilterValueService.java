package com.tcs.dnp.service;

import com.tcs.dnp.model.ReportFilterValue;
import com.tcs.dnp.repository.ReportFilterValueRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class ReportFilterValueService {
    private final ReportFilterValueRepository repository;

    public ReportFilterValueService(ReportFilterValueRepository repository) {
        this.repository = repository;
    }

    public ReportFilterValue create(ReportFilterValue model) {
        model.setReportFilterValueId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public ReportFilterValue get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("ReportFilterValue not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<ReportFilterValue> getAll() {
        return repository.findAll();
    }

    public ReportFilterValue update(Long id, ReportFilterValue model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ReportFilterValue not found: " + id);
        }
        model.setReportFilterValueId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("ReportFilterValue not found: " + id);
        }
        repository.deleteById(id);
    }
}

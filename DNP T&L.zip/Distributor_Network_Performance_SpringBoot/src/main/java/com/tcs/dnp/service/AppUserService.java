package com.tcs.dnp.service;

import com.tcs.dnp.model.AppUser;
import com.tcs.dnp.repository.AppUserRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class AppUserService {
    private final AppUserRepository repository;

    public AppUserService(AppUserRepository repository) {
        this.repository = repository;
    }

    public AppUser create(AppUser model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public AppUser get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("AppUser not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<AppUser> getAll() {
        return repository.findAll();
    }

    public AppUser update(Long id, AppUser model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("AppUser not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("AppUser not found: " + id);
        }
        repository.deleteById(id);
    }
}

package com.tcs.dnp.model;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="activity_type",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ActivityType {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="activity_type_id")
 private Long activityTypeId;
 @Column(name="activity_type_name")
 private String activityTypeName;
 @Column(name="description")
 private String description;
}
package com.tcs.dnp.service;

import com.tcs.dnp.model.HealthParameterWeight;
import com.tcs.dnp.repository.HealthParameterWeightRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class HealthParameterWeightService {
    private final HealthParameterWeightRepository repository;

    public HealthParameterWeightService(HealthParameterWeightRepository repository) {
        this.repository = repository;
    }

    public HealthParameterWeight create(HealthParameterWeight model) {
        model.setParameterWeightId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public HealthParameterWeight get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("HealthParameterWeight not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<HealthParameterWeight> getAll() {
        return repository.findAll();
    }

    public HealthParameterWeight update(Long id, HealthParameterWeight model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("HealthParameterWeight not found: " + id);
        }
        model.setParameterWeightId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("HealthParameterWeight not found: " + id);
        }
        repository.deleteById(id);
    }
}

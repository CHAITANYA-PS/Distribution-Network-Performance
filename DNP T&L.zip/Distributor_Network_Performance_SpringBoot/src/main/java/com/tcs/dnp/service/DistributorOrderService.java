package com.tcs.dnp.service;

import com.tcs.dnp.model.DistributorOrder;
import com.tcs.dnp.repository.DistributorOrderRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class DistributorOrderService {
    private final DistributorOrderRepository repository;

    public DistributorOrderService(DistributorOrderRepository repository) {
        this.repository = repository;
    }

    public DistributorOrder create(DistributorOrder model) {
        model.setOrderId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public DistributorOrder get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("DistributorOrder not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<DistributorOrder> getAll() {
        return repository.findAll();
    }

    public DistributorOrder update(Long id, DistributorOrder model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorOrder not found: " + id);
        }
        model.setOrderId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("DistributorOrder not found: " + id);
        }
        repository.deleteById(id);
    }
}

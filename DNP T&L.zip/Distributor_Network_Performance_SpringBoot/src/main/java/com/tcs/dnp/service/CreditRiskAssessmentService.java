package com.tcs.dnp.service;

import com.tcs.dnp.model.CreditRiskAssessment;
import com.tcs.dnp.repository.CreditRiskAssessmentRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class CreditRiskAssessmentService {
    private final CreditRiskAssessmentRepository repository;

    public CreditRiskAssessmentService(CreditRiskAssessmentRepository repository) {
        this.repository = repository;
    }

    public CreditRiskAssessment create(CreditRiskAssessment model) {
        model.setRiskAssessmentId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public CreditRiskAssessment get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("CreditRiskAssessment not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<CreditRiskAssessment> getAll() {
        return repository.findAll();
    }

    public CreditRiskAssessment update(Long id, CreditRiskAssessment model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CreditRiskAssessment not found: " + id);
        }
        model.setRiskAssessmentId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("CreditRiskAssessment not found: " + id);
        }
        repository.deleteById(id);
    }
}

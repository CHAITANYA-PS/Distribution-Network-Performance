package com.tcs.dnp.repository;

import com.tcs.dnp.model.DistributorOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorOrderRepository extends JpaRepository<DistributorOrder, Long> {
}

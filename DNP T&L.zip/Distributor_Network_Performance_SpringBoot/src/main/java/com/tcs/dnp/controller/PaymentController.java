package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.Payment;
import com.tcs.dnp.service.PaymentService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/payments")
public class PaymentController {
    private final PaymentService service;

    public PaymentController(PaymentService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Payment> create(@Valid @RequestBody Payment model) {
        Payment saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/payments/" + saved.getPaymentId())).body(saved);
    }

    @GetMapping("/{id}")
    public Payment get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Payment> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Payment update(@PathVariable Long id, @Valid @RequestBody Payment model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.tcs.dnp.controller;

import jakarta.validation.Valid;

import com.tcs.dnp.model.Notification;
import com.tcs.dnp.service.NotificationService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/notifications")
public class NotificationController {
    private final NotificationService service;

    public NotificationController(NotificationService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Notification> create(@Valid @RequestBody Notification model) {
        Notification saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/notifications/" + saved.getNotificationId())).body(saved);
    }

    @GetMapping("/{id}")
    public Notification get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Notification> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Notification update(@PathVariable Long id, @Valid @RequestBody Notification model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

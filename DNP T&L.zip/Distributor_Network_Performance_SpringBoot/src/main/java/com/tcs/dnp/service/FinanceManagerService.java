package com.tcs.dnp.service;

import com.tcs.dnp.model.FinanceManager;
import com.tcs.dnp.repository.FinanceManagerRepository;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.tcs.dnp.exception.ResourceNotFoundException;

import java.util.List;

@Service
@Transactional
public class FinanceManagerService {
    private final FinanceManagerRepository repository;

    public FinanceManagerService(FinanceManagerRepository repository) {
        this.repository = repository;
    }

    public FinanceManager create(FinanceManager model) {
        model.setUserId(null);
        return repository.save(model);
    }

    @Transactional(readOnly = true)
    public FinanceManager get(Long id) {
        return repository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("FinanceManager not found: " + id));
    }

    @Transactional(readOnly = true)
    public List<FinanceManager> getAll() {
        return repository.findAll();
    }

    public FinanceManager update(Long id, FinanceManager model) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("FinanceManager not found: " + id);
        }
        model.setUserId(id);
        return repository.save(model);
    }

    public void delete(Long id) {
        if (!repository.existsById(id)) {
            throw new ResourceNotFoundException("FinanceManager not found: " + id);
        }
        repository.deleteById(id);
    }
}

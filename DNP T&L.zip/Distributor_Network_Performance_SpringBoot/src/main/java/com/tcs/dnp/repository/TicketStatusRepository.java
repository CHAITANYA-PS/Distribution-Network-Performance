package com.tcs.dnp.repository;

import com.tcs.dnp.model.TicketStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketStatusRepository extends JpaRepository<TicketStatus, Long> {
}

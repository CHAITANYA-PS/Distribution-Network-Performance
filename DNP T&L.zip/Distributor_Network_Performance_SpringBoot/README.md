# Distributor Network Performance - Spring Boot Backend

Generated from the original Core Java/JDBC project as a compile-ready Java 17 Spring Boot 3.3.5 REST backend. It contains 79 DTO-backed JPA modules with entity, DTO, mapper, repository, service, controller and exception handling.

## PostgreSQL configuration
Edit `src/main/resources/application.yml`. For a separate PostgreSQL domain, do not hard-code the password. Set environment variables based on `.env.example`:

```bash
export DB_HOST=db.company-domain.com
export DB_PORT=5432
export DB_NAME=dsphere_db
export DB_SCHEMA=dsphere
export DB_USERNAME=dnp_app
export DB_PASSWORD='replace-me'
```

The JDBC URL is assembled as `jdbc:postgresql://${DB_HOST}:${DB_PORT}/${DB_NAME}`. If your provider gives one complete URL, replace `spring.datasource.url` directly. Ensure the remote PostgreSQL firewall/allow-list accepts the backend host and TLS settings required by that domain.

## Run
```bash
mvn clean test
mvn spring-boot:run
```

Example API: `GET /api/v1/distributors`, `POST /api/v1/distributors`.

## Database safety
The default `JPA_DDL_AUTO=validate` checks mappings without changing your existing schema. Do not use `create` or `create-drop` against the shared database. If the existing schema is incomplete, apply database migrations separately and switch to `validate`.

## Architecture
Controller -> DTO -> Service -> Mapper -> Spring Data JPA Repository -> PostgreSQL (`dsphere` schema).

## Added production/review features
- Standard JSON error model and global exception handling
- Jakarta validation on Distributor requests
- OpenAPI JSON at `/v3/api-docs` and Swagger UI at `/swagger-ui.html`
- Spring Batch CSV import at `POST /api/v1/batch/distributors/import`, chunk size 500
- Postman collection under `postman/` with positive, negative and batch tests
- MockMvc controller tests under `src/test/java`

For a shared PostgreSQL domain, keep `BATCH_INITIALIZE_SCHEMA=never`. Ask the DBA to install Spring Batch metadata tables before running batch. For an isolated development database only, set `BATCH_INITIALIZE_SCHEMA=always`.

## Transactions and locking
- Service classes use `@Transactional`; list/get methods use `readOnly=true`.
- All JPA models include `@Version` for optimistic locking. Apply `src/main/resources/db/migration/V3__add_optimistic_lock_versions.sql` before startup because `ddl-auto=validate` will not add columns.
- `WarehouseStock`, `DistributorCreditLimit`, `Payment`, and `ExchangeRequest` repositories use `PESSIMISTIC_WRITE` for critical updates with a requested 5-second lock timeout.
- Optimistic conflicts return HTTP 409 JSON. Pessimistic lock timeouts return HTTP 423 JSON.
- Keep transactions short and do not call external systems while a pessimistic lock is held.

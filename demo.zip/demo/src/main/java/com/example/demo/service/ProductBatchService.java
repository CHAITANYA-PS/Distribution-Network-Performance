package com.example.demo.service;

import com.example.demo.entity.ProductBatch;
import com.example.demo.repository.ProductBatchRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductBatchService extends AbstractCrudService<ProductBatch, Long> {
    public ProductBatchService(ProductBatchRepository repository) {
        super(repository, ProductBatch.class);
    }
}

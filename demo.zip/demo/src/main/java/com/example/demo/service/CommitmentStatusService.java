package com.example.demo.service;

import com.example.demo.entity.CommitmentStatus;
import com.example.demo.repository.CommitmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentStatusService extends AbstractCrudService<CommitmentStatus, Long> {
    public CommitmentStatusService(CommitmentStatusRepository repository) {
        super(repository, CommitmentStatus.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.TicketStatus;
import com.example.demo.repository.TicketStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketStatusService extends AbstractCrudService<TicketStatus, Long> {
    public TicketStatusService(TicketStatusRepository repository) {
        super(repository, TicketStatus.class);
    }
}

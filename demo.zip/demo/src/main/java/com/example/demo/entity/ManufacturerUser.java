package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="manufacturer_user",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class ManufacturerUser implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="manufacturer_id")
 private Long manufacturerId;
}
package com.example.demo.service;

import com.example.demo.entity.Report;
import com.example.demo.repository.ReportRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportService extends AbstractCrudService<Report, Long> {
    public ReportService(ReportRepository repository) {
        super(repository, Report.class);
    }
}

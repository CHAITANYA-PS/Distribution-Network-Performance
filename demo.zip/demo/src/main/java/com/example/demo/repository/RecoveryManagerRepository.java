package com.example.demo.repository;

import com.example.demo.entity.RecoveryManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryManagerRepository extends JpaRepository<RecoveryManager, Long> {
}

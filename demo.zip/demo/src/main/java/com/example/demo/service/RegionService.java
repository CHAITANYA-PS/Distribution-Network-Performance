package com.example.demo.service;

import com.example.demo.entity.Region;
import com.example.demo.repository.RegionRepository;
import org.springframework.stereotype.Service;

@Service
public class RegionService extends AbstractCrudService<Region, Long> {
    public RegionService(RegionRepository repository) {
        super(repository, Region.class);
    }
}

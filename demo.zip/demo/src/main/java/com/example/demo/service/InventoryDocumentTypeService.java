package com.example.demo.service;

import com.example.demo.entity.InventoryDocumentType;
import com.example.demo.repository.InventoryDocumentTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentTypeService extends AbstractCrudService<InventoryDocumentType, Long> {
    public InventoryDocumentTypeService(InventoryDocumentTypeRepository repository) {
        super(repository, InventoryDocumentType.class);
    }
}

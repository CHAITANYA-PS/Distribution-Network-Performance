package com.example.demo.repository;

import com.example.demo.entity.DistributorUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorUserRepository extends JpaRepository<DistributorUser, Long> {
}

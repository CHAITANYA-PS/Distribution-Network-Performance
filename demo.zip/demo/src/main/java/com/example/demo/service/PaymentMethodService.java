package com.example.demo.service;

import com.example.demo.entity.PaymentMethod;
import com.example.demo.repository.PaymentMethodRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentMethodService extends AbstractCrudService<PaymentMethod, Long> {
    public PaymentMethodService(PaymentMethodRepository repository) {
        super(repository, PaymentMethod.class);
    }
}

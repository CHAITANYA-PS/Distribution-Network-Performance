package com.example.demo.service;

import com.example.demo.entity.HealthParameter;
import com.example.demo.repository.HealthParameterRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterService extends AbstractCrudService<HealthParameter, Long> {
    public HealthParameterService(HealthParameterRepository repository) {
        super(repository, HealthParameter.class);
    }
}

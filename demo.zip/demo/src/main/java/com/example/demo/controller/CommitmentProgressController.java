package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.CommitmentProgress;
import com.example.demo.service.CommitmentProgressService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/commitment-progresses")
public class CommitmentProgressController {
    private final CommitmentProgressService service;

    public CommitmentProgressController(CommitmentProgressService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<CommitmentProgress> create(@Valid @RequestBody CommitmentProgress model) {
        CommitmentProgress saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/commitment-progresses/" + saved.getProgressId())).body(saved);
    }

    @GetMapping("/{id}")
    public CommitmentProgress get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<CommitmentProgress> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public CommitmentProgress update(@PathVariable Long id, @Valid @RequestBody CommitmentProgress model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

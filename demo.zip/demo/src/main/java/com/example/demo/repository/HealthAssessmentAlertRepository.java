package com.example.demo.repository;

import com.example.demo.entity.HealthAssessmentAlert;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthAssessmentAlertRepository extends JpaRepository<HealthAssessmentAlert, Long> {
}

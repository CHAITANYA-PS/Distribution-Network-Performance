package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal; import java.time.OffsetDateTime;
@Entity @Table(name="sales_target",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class SalesTarget implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="target_id")
 private Long targetId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="reporting_period_id")
 private Long reportingPeriodId;
 @Column(name="target_value")
 private BigDecimal targetValue;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
}
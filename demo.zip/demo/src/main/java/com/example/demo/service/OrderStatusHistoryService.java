package com.example.demo.service;

import com.example.demo.entity.OrderStatusHistory;
import com.example.demo.repository.OrderStatusHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusHistoryService extends AbstractCrudService<OrderStatusHistory, Long> {
    public OrderStatusHistoryService(OrderStatusHistoryRepository repository) {
        super(repository, OrderStatusHistory.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.RiskLevel;
import com.example.demo.repository.RiskLevelRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskLevelService extends AbstractCrudService<RiskLevel, Long> {
    public RiskLevelService(RiskLevelRepository repository) {
        super(repository, RiskLevel.class);
    }
}

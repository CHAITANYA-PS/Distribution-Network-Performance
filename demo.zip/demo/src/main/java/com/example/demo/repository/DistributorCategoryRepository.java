package com.example.demo.repository;

import com.example.demo.entity.DistributorCategory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorCategoryRepository extends JpaRepository<DistributorCategory, Long> {
}

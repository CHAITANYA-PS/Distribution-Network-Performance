package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.InventoryDocumentType;
import com.example.demo.service.InventoryDocumentTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/inventory-document-types")
public class InventoryDocumentTypeController {
    private final InventoryDocumentTypeService service;

    public InventoryDocumentTypeController(InventoryDocumentTypeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<InventoryDocumentType> create(@Valid @RequestBody InventoryDocumentType model) {
        InventoryDocumentType saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/inventory-document-types/" + saved.getInventoryDocumentTypeId())).body(saved);
    }

    @GetMapping("/{id}")
    public InventoryDocumentType get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<InventoryDocumentType> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public InventoryDocumentType update(@PathVariable Long id, @Valid @RequestBody InventoryDocumentType model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.service;

import com.example.demo.entity.Ticket;
import com.example.demo.repository.TicketRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketService extends AbstractCrudService<Ticket, Long> {
    public TicketService(TicketRepository repository) {
        super(repository, Ticket.class);
    }
}

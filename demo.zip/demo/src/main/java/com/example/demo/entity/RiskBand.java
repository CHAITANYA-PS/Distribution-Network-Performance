package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.math.BigDecimal;
@Entity @Table(name="risk_band",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class RiskBand implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="risk_band_id")
 private Long riskBandId;
 @Column(name="risk_category")
 private String riskCategory;
 @Column(name="minimum_score")
 private BigDecimal minimumScore;
 @Column(name="maximum_score")
 private BigDecimal maximumScore;
}
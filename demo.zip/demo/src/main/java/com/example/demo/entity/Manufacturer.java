package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="manufacturer",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Manufacturer implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="manufacturer_id")
 private Long manufacturerId;
 @Column(name="manufacturer_code")
 private String manufacturerCode;
 @Column(name="manufacturer_name")
 private String manufacturerName;
 @Column(name="email")
 private String email;
 @Column(name="phone")
 private String phone;
 @Column(name="address")
 private String address;
 @Column(name="status")
 private String status;
}
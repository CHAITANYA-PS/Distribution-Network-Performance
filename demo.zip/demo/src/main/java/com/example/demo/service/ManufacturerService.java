package com.example.demo.service;

import com.example.demo.entity.Manufacturer;
import com.example.demo.repository.ManufacturerRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerService extends AbstractCrudService<Manufacturer, Long> {
    public ManufacturerService(ManufacturerRepository repository) {
        super(repository, Manufacturer.class);
    }
}

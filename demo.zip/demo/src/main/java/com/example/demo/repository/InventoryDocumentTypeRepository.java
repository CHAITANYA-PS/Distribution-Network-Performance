package com.example.demo.repository;

import com.example.demo.entity.InventoryDocumentType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentTypeRepository extends JpaRepository<InventoryDocumentType, Long> {
}

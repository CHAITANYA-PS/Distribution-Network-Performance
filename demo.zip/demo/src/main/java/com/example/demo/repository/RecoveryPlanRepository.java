package com.example.demo.repository;

import com.example.demo.entity.RecoveryPlan;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanRepository extends JpaRepository<RecoveryPlan, Long> {
}

package com.example.demo.service;

import com.example.demo.entity.Warehouse;
import com.example.demo.repository.WarehouseRepository;
import org.springframework.stereotype.Service;

@Service
public class WarehouseService extends AbstractCrudService<Warehouse, Long> {
    public WarehouseService(WarehouseRepository repository) {
        super(repository, Warehouse.class);
    }
}

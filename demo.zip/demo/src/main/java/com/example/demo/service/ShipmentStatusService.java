package com.example.demo.service;

import com.example.demo.entity.ShipmentStatus;
import com.example.demo.repository.ShipmentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentStatusService extends AbstractCrudService<ShipmentStatus, Long> {
    public ShipmentStatusService(ShipmentStatusRepository repository) {
        super(repository, ShipmentStatus.class);
    }
}

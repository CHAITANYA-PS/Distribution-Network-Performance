package com.example.demo.repository;

import com.example.demo.entity.CommitmentHistory;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentHistoryRepository extends JpaRepository<CommitmentHistory, Long> {
}

package com.example.demo.controller;

import com.example.demo.entity.TransportEmissionView;
import com.example.demo.service.TransportEmissionViewService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Read-only endpoints over the TransportEmissionView database view. */
@RestController
@RequestMapping("/api/v1/views/transport-emissions")
public class TransportEmissionViewController {
    private final TransportEmissionViewService service;

    public TransportEmissionViewController(TransportEmissionViewService service) {
        this.service = service;
    }

    @GetMapping
    public List<TransportEmissionView> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public TransportEmissionView get(@PathVariable Long id) {
        return service.get(id);
    }
}

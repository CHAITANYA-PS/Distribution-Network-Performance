package com.example.demo.service;

import com.example.demo.entity.PaymentStatus;
import com.example.demo.repository.PaymentStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class PaymentStatusService extends AbstractCrudService<PaymentStatus, Long> {
    public PaymentStatusService(PaymentStatusRepository repository) {
        super(repository, PaymentStatus.class);
    }
}

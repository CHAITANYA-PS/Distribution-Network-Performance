package com.example.demo.service;

import com.example.demo.entity.RecoveryPlan;
import com.example.demo.repository.RecoveryPlanRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanService extends AbstractCrudService<RecoveryPlan, Long> {
    public RecoveryPlanService(RecoveryPlanRepository repository) {
        super(repository, RecoveryPlan.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.Invoice;
import com.example.demo.repository.InvoiceRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceService extends AbstractCrudService<Invoice, Long> {
    public InvoiceService(InvoiceRepository repository) {
        super(repository, Invoice.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.DistributorCategory;
import com.example.demo.repository.DistributorCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorCategoryService extends AbstractCrudService<DistributorCategory, Long> {
    public DistributorCategoryService(DistributorCategoryRepository repository) {
        super(repository, DistributorCategory.class);
    }
}

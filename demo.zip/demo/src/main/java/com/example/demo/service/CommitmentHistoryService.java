package com.example.demo.service;

import com.example.demo.entity.CommitmentHistory;
import com.example.demo.repository.CommitmentHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentHistoryService extends AbstractCrudService<CommitmentHistory, Long> {
    public CommitmentHistoryService(CommitmentHistoryRepository repository) {
        super(repository, CommitmentHistory.class);
    }
}

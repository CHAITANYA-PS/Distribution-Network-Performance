package com.example.demo.service;

import com.example.demo.entity.InventoryMovement;
import com.example.demo.repository.InventoryMovementRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryMovementService extends AbstractCrudService<InventoryMovement, Long> {
    public InventoryMovementService(InventoryMovementRepository repository) {
        super(repository, InventoryMovement.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.UserActivityLog;
import com.example.demo.repository.UserActivityLogRepository;
import org.springframework.stereotype.Service;

@Service
public class UserActivityLogService extends AbstractCrudService<UserActivityLog, Long> {
    public UserActivityLogService(UserActivityLogRepository repository) {
        super(repository, UserActivityLog.class);
    }
}

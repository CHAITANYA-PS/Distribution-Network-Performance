package com.example.demo.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.Immutable; import java.io.Serializable; import java.math.BigDecimal;
/** Read-only mapping of the database view dsphere.order_total_view. */
@Entity @Immutable @Table(name="order_total_view",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class OrderTotalView implements Serializable {
 private static final long serialVersionUID = 1L;
 @Id
 @Column(name="order_id")
 private Long orderId;
 @Column(name="customer_name")
 private String customerName;
 @Column(name="total_items")
 private Integer totalItems;
 @Column(name="total_amount")
 private BigDecimal totalAmount;
 @Column(name="order_status")
 private String orderStatus;
}

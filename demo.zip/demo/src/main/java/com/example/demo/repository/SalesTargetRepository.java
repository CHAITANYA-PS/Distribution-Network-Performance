package com.example.demo.repository;

import com.example.demo.entity.SalesTarget;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesTargetRepository extends JpaRepository<SalesTarget, Long> {
}

package com.example.demo.service;

import com.example.demo.entity.DistributorUser;
import com.example.demo.repository.DistributorUserRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorUserService extends AbstractCrudService<DistributorUser, Long> {
    public DistributorUserService(DistributorUserRepository repository) {
        super(repository, DistributorUser.class);
    }
}

package com.example.demo.controller;

import com.example.demo.entity.OrderTotalView;
import com.example.demo.service.OrderTotalViewService;
import org.springframework.web.bind.annotation.*;

import java.util.List;

/** Read-only endpoints over the OrderTotalView database view. */
@RestController
@RequestMapping("/api/v1/views/order-totals")
public class OrderTotalViewController {
    private final OrderTotalViewService service;

    public OrderTotalViewController(OrderTotalViewService service) {
        this.service = service;
    }

    @GetMapping
    public List<OrderTotalView> getAll() {
        return service.getAll();
    }

    @GetMapping("/{id}")
    public OrderTotalView get(@PathVariable Long id) {
        return service.get(id);
    }
}

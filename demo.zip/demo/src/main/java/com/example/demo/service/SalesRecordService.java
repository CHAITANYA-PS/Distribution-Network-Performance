package com.example.demo.service;

import com.example.demo.entity.SalesRecord;
import com.example.demo.repository.SalesRecordRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesRecordService extends AbstractCrudService<SalesRecord, Long> {
    public SalesRecordService(SalesRecordRepository repository) {
        super(repository, SalesRecord.class);
    }
}

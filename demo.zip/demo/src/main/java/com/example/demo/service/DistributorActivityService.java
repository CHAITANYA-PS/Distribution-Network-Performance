package com.example.demo.service;

import com.example.demo.entity.DistributorActivity;
import com.example.demo.repository.DistributorActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorActivityService extends AbstractCrudService<DistributorActivity, Long> {
    public DistributorActivityService(DistributorActivityRepository repository) {
        super(repository, DistributorActivity.class);
    }
}

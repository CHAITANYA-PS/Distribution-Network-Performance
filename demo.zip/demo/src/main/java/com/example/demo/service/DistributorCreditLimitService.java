package com.example.demo.service;

import com.example.demo.service.BusinessRuleException;
import com.example.demo.entity.DistributorCreditLimit;
import com.example.demo.repository.DistributorCreditLimitRepository;
import org.springframework.stereotype.Service;

import java.util.Optional;

@Service
public class DistributorCreditLimitService extends AbstractCrudService<DistributorCreditLimit, Long> {
    private final DistributorCreditLimitRepository limits;

    public DistributorCreditLimitService(DistributorCreditLimitRepository repository) {
        super(repository, DistributorCreditLimit.class);
        this.limits = repository;
    }

    @Override
    protected Optional<DistributorCreditLimit> findForUpdate(Long id) {
        return limits.findByIdForUpdate(id);
    }

    @Override
    protected void beforeCreate(DistributorCreditLimit l) {
        check(l);
    }

    @Override
    protected void beforeUpdate(Long id, DistributorCreditLimit l, DistributorCreditLimit existing) {
        check(l);
    }

    private void check(DistributorCreditLimit l) {
        if (l.getCreditLimit() == null || l.getCreditLimit().signum() < 0) {
            throw new BusinessRuleException("Credit limit must be zero or greater");
        }
        if (l.getValidFrom() != null && l.getValidTo() != null && l.getValidTo().isBefore(l.getValidFrom())) {
            throw new BusinessRuleException("validTo must not be before validFrom");
        }
    }
}

package com.example.demo.service;

import com.example.demo.entity.Commitment;
import com.example.demo.repository.CommitmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentService extends AbstractCrudService<Commitment, Long> {
    public CommitmentService(CommitmentRepository repository) {
        super(repository, Commitment.class);
    }
}

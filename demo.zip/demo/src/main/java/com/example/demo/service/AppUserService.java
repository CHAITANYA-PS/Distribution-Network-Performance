package com.example.demo.service;

import com.example.demo.entity.AppUser;
import com.example.demo.repository.AppUserRepository;
import org.springframework.stereotype.Service;

@Service
public class AppUserService extends AbstractCrudService<AppUser, Long> {
    public AppUserService(AppUserRepository repository) {
        super(repository, AppUser.class);
    }
}

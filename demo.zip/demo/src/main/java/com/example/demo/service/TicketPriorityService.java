package com.example.demo.service;

import com.example.demo.entity.TicketPriority;
import com.example.demo.repository.TicketPriorityRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketPriorityService extends AbstractCrudService<TicketPriority, Long> {
    public TicketPriorityService(TicketPriorityRepository repository) {
        super(repository, TicketPriority.class);
    }
}

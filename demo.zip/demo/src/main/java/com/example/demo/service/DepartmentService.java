package com.example.demo.service;

import com.example.demo.entity.Department;
import com.example.demo.repository.DepartmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DepartmentService extends AbstractCrudService<Department, Long> {
    public DepartmentService(DepartmentRepository repository) {
        super(repository, Department.class);
    }
}

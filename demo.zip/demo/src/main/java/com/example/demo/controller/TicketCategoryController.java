package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.TicketCategory;
import com.example.demo.service.TicketCategoryService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/ticket-categories")
public class TicketCategoryController {
    private final TicketCategoryService service;

    public TicketCategoryController(TicketCategoryService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<TicketCategory> create(@Valid @RequestBody TicketCategory model) {
        TicketCategory saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/ticket-categories/" + saved.getTicketCategoryId())).body(saved);
    }

    @GetMapping("/{id}")
    public TicketCategory get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<TicketCategory> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public TicketCategory update(@PathVariable Long id, @Valid @RequestBody TicketCategory model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.OrderItem;
import com.example.demo.service.OrderItemService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/order-items")
public class OrderItemController {
    private final OrderItemService service;

    public OrderItemController(OrderItemService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<OrderItem> create(@Valid @RequestBody OrderItem model) {
        OrderItem saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/order-items/" + saved.getOrderItemId())).body(saved);
    }

    @GetMapping("/{id}")
    public OrderItem get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<OrderItem> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public OrderItem update(@PathVariable Long id, @Valid @RequestBody OrderItem model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

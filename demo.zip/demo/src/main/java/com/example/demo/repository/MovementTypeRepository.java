package com.example.demo.repository;

import com.example.demo.entity.MovementType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface MovementTypeRepository extends JpaRepository<MovementType, Long> {
}

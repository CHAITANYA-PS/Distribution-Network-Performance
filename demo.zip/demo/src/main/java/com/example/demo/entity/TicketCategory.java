package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="ticket_category",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TicketCategory implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="ticket_category_id")
 private Long ticketCategoryId;
 @Column(name="category_name")
 private String categoryName;
}
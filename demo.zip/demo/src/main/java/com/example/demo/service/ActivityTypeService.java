package com.example.demo.service;

import com.example.demo.entity.ActivityType;
import com.example.demo.repository.ActivityTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ActivityTypeService extends AbstractCrudService<ActivityType, Long> {
    public ActivityTypeService(ActivityTypeRepository repository) {
        super(repository, ActivityType.class);
    }
}

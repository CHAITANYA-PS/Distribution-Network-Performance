package com.example.demo.service;

import com.example.demo.entity.DistributorOrder;
import com.example.demo.repository.DistributorOrderRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorOrderService extends AbstractCrudService<DistributorOrder, Long> {
    public DistributorOrderService(DistributorOrderRepository repository) {
        super(repository, DistributorOrder.class);
    }
}

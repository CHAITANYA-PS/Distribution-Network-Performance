package com.example.demo.service;

import com.example.demo.entity.ExchangeStatus;
import com.example.demo.repository.ExchangeStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeStatusService extends AbstractCrudService<ExchangeStatus, Long> {
    public ExchangeStatusService(ExchangeStatusRepository repository) {
        super(repository, ExchangeStatus.class);
    }
}

package com.example.demo.repository;

import com.example.demo.entity.CommitmentStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentStatusRepository extends JpaRepository<CommitmentStatus, Long> {
}

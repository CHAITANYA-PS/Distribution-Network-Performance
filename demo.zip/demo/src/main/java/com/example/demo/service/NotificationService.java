package com.example.demo.service;

import com.example.demo.entity.Notification;
import com.example.demo.repository.NotificationRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationService extends AbstractCrudService<Notification, Long> {
    public NotificationService(NotificationRepository repository) {
        super(repository, Notification.class);
    }
}

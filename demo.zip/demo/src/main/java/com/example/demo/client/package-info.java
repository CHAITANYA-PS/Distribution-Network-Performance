/**
 * Clients that call external systems (REST/HTTP clients, integrations).
 * Intentionally empty for now - kept so the package structure matches the project template.
 */
package com.example.demo.client;

package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.UserRole;
import com.example.demo.service.UserRoleService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/user-roles")
public class UserRoleController {
    private final UserRoleService service;

    public UserRoleController(UserRoleService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<UserRole> create(@Valid @RequestBody UserRole model) {
        UserRole saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/user-roles/" + saved.getUserRoleId())).body(saved);
    }

    @GetMapping("/{id}")
    public UserRole get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<UserRole> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public UserRole update(@PathVariable Long id, @Valid @RequestBody UserRole model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

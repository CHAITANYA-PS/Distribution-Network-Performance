package com.example.demo.repository;

import com.example.demo.entity.RiskBand;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskBandRepository extends JpaRepository<RiskBand, Long> {
}

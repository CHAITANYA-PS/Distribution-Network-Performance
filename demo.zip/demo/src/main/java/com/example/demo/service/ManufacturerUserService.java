package com.example.demo.service;

import com.example.demo.entity.ManufacturerUser;
import com.example.demo.repository.ManufacturerUserRepository;
import org.springframework.stereotype.Service;

@Service
public class ManufacturerUserService extends AbstractCrudService<ManufacturerUser, Long> {
    public ManufacturerUserService(ManufacturerUserRepository repository) {
        super(repository, ManufacturerUser.class);
    }
}

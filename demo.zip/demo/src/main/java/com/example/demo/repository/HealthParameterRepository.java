package com.example.demo.repository;

import com.example.demo.entity.HealthParameter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterRepository extends JpaRepository<HealthParameter, Long> {
}

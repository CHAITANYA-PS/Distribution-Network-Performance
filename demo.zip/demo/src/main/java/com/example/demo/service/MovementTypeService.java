package com.example.demo.service;

import com.example.demo.entity.MovementType;
import com.example.demo.repository.MovementTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class MovementTypeService extends AbstractCrudService<MovementType, Long> {
    public MovementTypeService(MovementTypeRepository repository) {
        super(repository, MovementType.class);
    }
}

package com.example.demo.entity.locking;

import jakarta.persistence.Id;

import java.lang.reflect.Field;

/** Reads and writes the {@code @Id} field of a JPA model so generic services need no per-entity code. */
public final class EntityIdAccessor {
    private EntityIdAccessor() {
    }

    public static void setId(Object entity, Object id) {
        Field f = idField(entity.getClass());
        try {
            f.set(entity, id);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("Cannot set id on " + entity.getClass().getSimpleName(), e);
        }
    }

    public static Object getId(Object entity) {
        Field f = idField(entity.getClass());
        try {
            return f.get(entity);
        } catch (IllegalAccessException e) {
            throw new IllegalStateException("Cannot read id of " + entity.getClass().getSimpleName(), e);
        }
    }

    private static Field idField(Class<?> type) {
        for (Class<?> c = type; c != null && c != Object.class; c = c.getSuperclass()) {
            for (Field f : c.getDeclaredFields()) {
                if (f.isAnnotationPresent(Id.class)) {
                    f.setAccessible(true);
                    return f;
                }
            }
        }
        throw new IllegalStateException("No @Id field on " + type.getName());
    }
}

package com.example.demo.repository;

import com.example.demo.entity.HealthParameterWeight;
import org.springframework.data.jpa.repository.JpaRepository;

public interface HealthParameterWeightRepository extends JpaRepository<HealthParameterWeight, Long> {
}

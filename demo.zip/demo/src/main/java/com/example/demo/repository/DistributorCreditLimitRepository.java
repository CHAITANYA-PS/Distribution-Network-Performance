package com.example.demo.repository;

import com.example.demo.entity.DistributorCreditLimit;
import org.springframework.data.jpa.repository.JpaRepository;
import jakarta.persistence.LockModeType;
import jakarta.persistence.QueryHint;
import org.springframework.data.jpa.repository.Lock;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.jpa.repository.QueryHints;
import org.springframework.data.repository.query.Param;
import java.util.Optional;

public interface DistributorCreditLimitRepository extends JpaRepository<DistributorCreditLimit, Long> {
    @Lock(LockModeType.PESSIMISTIC_WRITE)
    @QueryHints(@QueryHint(name = "jakarta.persistence.lock.timeout", value = "5000"))
    @Query("select x from DistributorCreditLimit x where x.creditLimitId = :id")
    Optional<DistributorCreditLimit> findByIdForUpdate(@Param("id") Long id);

}


package com.example.demo.service;

import com.example.demo.entity.Shipment;
import com.example.demo.repository.ShipmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentService extends AbstractCrudService<Shipment, Long> {
    public ShipmentService(ShipmentRepository repository) {
        super(repository, Shipment.class);
    }
}

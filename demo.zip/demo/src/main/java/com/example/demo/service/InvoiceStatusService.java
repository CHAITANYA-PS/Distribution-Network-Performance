package com.example.demo.service;

import com.example.demo.entity.InvoiceStatus;
import com.example.demo.repository.InvoiceStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class InvoiceStatusService extends AbstractCrudService<InvoiceStatus, Long> {
    public InvoiceStatusService(InvoiceStatusRepository repository) {
        super(repository, InvoiceStatus.class);
    }
}

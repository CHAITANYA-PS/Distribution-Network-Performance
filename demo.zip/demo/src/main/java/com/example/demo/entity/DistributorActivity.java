package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="distributor_activity",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class DistributorActivity implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="activity_id")
 private Long activityId;
 @Column(name="distributor_id")
 private Long distributorId;
 @Column(name="activity_type_id")
 private Long activityTypeId;
 @Column(name="activity_date")
 private OffsetDateTime activityDate;
 @Column(name="recorded_by")
 private Long recordedBy;
 @Column(name="remarks")
 private String remarks;
}
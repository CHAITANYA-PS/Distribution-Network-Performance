package com.example.demo.service;

import com.example.demo.entity.InventoryAlert;
import com.example.demo.repository.InventoryAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryAlertService extends AbstractCrudService<InventoryAlert, Long> {
    public InventoryAlertService(InventoryAlertRepository repository) {
        super(repository, InventoryAlert.class);
    }
}

package com.example.demo.controller;

import jakarta.validation.Valid;
import com.example.demo.entity.Commitment;
import com.example.demo.service.CommitmentService;
import com.example.demo.entity.EmissionFactor;
import com.example.demo.service.EmissionFactorService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

/** Sustainability commitments and emission factors. Controller only maps HTTP to service calls; all rules live in the services package. */
@RestController
@RequestMapping("/api/v1/sustainability")
public class SustainabilityController {
    private final CommitmentService commitmentService;
    private final EmissionFactorService emissionFactorService;

    public SustainabilityController(CommitmentService commitmentService, EmissionFactorService emissionFactorService) {
        this.commitmentService = commitmentService;
        this.emissionFactorService = emissionFactorService;
    }

    @PostMapping("/commitments")
    public ResponseEntity<Commitment> createCommitment(@Valid @RequestBody Commitment model) {
        Commitment saved = commitmentService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/sustainability/commitments/" + saved.getCommitmentId())).body(saved);
    }

    @GetMapping("/commitments")
    public List<Commitment> getAllCommitment() {
        return commitmentService.getAll();
    }

    @GetMapping("/commitments/{id}")
    public Commitment getCommitment(@PathVariable Long id) {
        return commitmentService.get(id);
    }

    @PutMapping("/commitments/{id}")
    public Commitment updateCommitment(@PathVariable Long id, @Valid @RequestBody Commitment model) {
        return commitmentService.update(id, model);
    }

    @DeleteMapping("/commitments/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteCommitment(@PathVariable Long id) {
        commitmentService.delete(id);
    }

    @PostMapping("/emission-factors")
    public ResponseEntity<EmissionFactor> createEmissionFactor(@Valid @RequestBody EmissionFactor model) {
        EmissionFactor saved = emissionFactorService.create(model);
        return ResponseEntity.created(URI.create("/api/v1/sustainability/emission-factors/" + saved.getEmissionFactorId())).body(saved);
    }

    @GetMapping("/emission-factors")
    public List<EmissionFactor> getAllEmissionFactor() {
        return emissionFactorService.getAll();
    }

    @GetMapping("/emission-factors/{id}")
    public EmissionFactor getEmissionFactor(@PathVariable Long id) {
        return emissionFactorService.get(id);
    }

    @PutMapping("/emission-factors/{id}")
    public EmissionFactor updateEmissionFactor(@PathVariable Long id, @Valid @RequestBody EmissionFactor model) {
        return emissionFactorService.update(id, model);
    }

    @DeleteMapping("/emission-factors/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void deleteEmissionFactor(@PathVariable Long id) {
        emissionFactorService.delete(id);
    }
}

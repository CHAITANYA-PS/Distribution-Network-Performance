package com.example.demo.dto;

import java.time.OffsetDateTime;
import java.util.Map;

/**
 * Standard JSON error body returned for every failure.
 * {@code code} is a stable machine-readable value, {@code fieldErrors} is present for validation errors only.
 */
public record ApiErrorResponse(OffsetDateTime timestamp, int status, String error, String code,
                               String message, String path, Map<String, String> fieldErrors) {
}

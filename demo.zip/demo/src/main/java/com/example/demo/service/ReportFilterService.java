package com.example.demo.service;

import com.example.demo.entity.ReportFilter;
import com.example.demo.repository.ReportFilterRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterService extends AbstractCrudService<ReportFilter, Long> {
    public ReportFilterService(ReportFilterRepository repository) {
        super(repository, ReportFilter.class);
    }
}

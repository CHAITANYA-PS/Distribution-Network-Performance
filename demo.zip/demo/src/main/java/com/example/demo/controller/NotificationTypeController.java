package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.NotificationType;
import com.example.demo.service.NotificationTypeService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/notification-types")
public class NotificationTypeController {
    private final NotificationTypeService service;

    public NotificationTypeController(NotificationTypeService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<NotificationType> create(@Valid @RequestBody NotificationType model) {
        NotificationType saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/notification-types/" + saved.getNotificationTypeId())).body(saved);
    }

    @GetMapping("/{id}")
    public NotificationType get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<NotificationType> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public NotificationType update(@PathVariable Long id, @Valid @RequestBody NotificationType model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.service;

import com.example.demo.entity.CreditRiskAssessment;
import com.example.demo.repository.CreditRiskAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class CreditRiskAssessmentService extends AbstractCrudService<CreditRiskAssessment, Long> {
    public CreditRiskAssessmentService(CreditRiskAssessmentRepository repository) {
        super(repository, CreditRiskAssessment.class);
    }
}

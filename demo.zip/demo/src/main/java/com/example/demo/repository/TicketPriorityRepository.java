package com.example.demo.repository;

import com.example.demo.entity.TicketPriority;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TicketPriorityRepository extends JpaRepository<TicketPriority, Long> {
}

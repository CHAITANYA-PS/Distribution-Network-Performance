package com.example.demo.service;

import com.example.demo.entity.RecoveryPlanTicket;
import com.example.demo.repository.RecoveryPlanTicketRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanTicketService extends AbstractCrudService<RecoveryPlanTicket, Long> {
    public RecoveryPlanTicketService(RecoveryPlanTicketRepository repository) {
        super(repository, RecoveryPlanTicket.class);
    }
}

package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="user_role",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class UserRole implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_role_id")
 private Long userRoleId;
 @Column(name="user_id")
 private Long userId;
 @Column(name="role_id")
 private Long roleId;
 @Column(name="assigned_at")
 private OffsetDateTime assignedAt;
}
package com.example.demo.service;

import com.example.demo.entity.VehicleType;
import com.example.demo.repository.VehicleTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class VehicleTypeService extends AbstractCrudService<VehicleType, Long> {
    public VehicleTypeService(VehicleTypeRepository repository) {
        super(repository, VehicleType.class);
    }
}

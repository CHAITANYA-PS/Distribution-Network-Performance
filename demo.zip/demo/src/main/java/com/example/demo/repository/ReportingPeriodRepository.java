package com.example.demo.repository;

import com.example.demo.entity.ReportingPeriod;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportingPeriodRepository extends JpaRepository<ReportingPeriod, Long> {
}

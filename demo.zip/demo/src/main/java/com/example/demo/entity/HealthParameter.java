package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="health_parameter",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class HealthParameter implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="parameter_id")
 private Long parameterId;
 @Column(name="parameter_name")
 private String parameterName;
 @Column(name="description")
 private String description;
 @Column(name="is_active")
 private Boolean isActive;
}
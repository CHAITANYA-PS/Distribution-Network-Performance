package com.example.demo.repository;

import com.example.demo.entity.ReportFilterValue;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportFilterValueRepository extends JpaRepository<ReportFilterValue, Long> {
}

package com.example.demo.repository;

import com.example.demo.entity.TransportationActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface TransportationActivityRepository extends JpaRepository<TransportationActivity, Long> {
}

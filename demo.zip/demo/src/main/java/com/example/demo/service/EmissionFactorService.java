package com.example.demo.service;

import com.example.demo.entity.EmissionFactor;
import com.example.demo.repository.EmissionFactorRepository;
import org.springframework.stereotype.Service;

@Service
public class EmissionFactorService extends AbstractCrudService<EmissionFactor, Long> {
    public EmissionFactorService(EmissionFactorRepository repository) {
        super(repository, EmissionFactor.class);
    }
}

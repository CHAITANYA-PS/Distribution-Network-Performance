package com.example.demo.service;

import com.example.demo.entity.RiskBand;
import com.example.demo.repository.RiskBandRepository;
import org.springframework.stereotype.Service;

@Service
public class RiskBandService extends AbstractCrudService<RiskBand, Long> {
    public RiskBandService(RiskBandRepository repository) {
        super(repository, RiskBand.class);
    }
}

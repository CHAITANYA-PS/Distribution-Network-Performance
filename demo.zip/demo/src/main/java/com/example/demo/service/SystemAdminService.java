package com.example.demo.service;

import com.example.demo.entity.SystemAdmin;
import com.example.demo.repository.SystemAdminRepository;
import org.springframework.stereotype.Service;

@Service
public class SystemAdminService extends AbstractCrudService<SystemAdmin, Long> {
    public SystemAdminService(SystemAdminRepository repository) {
        super(repository, SystemAdmin.class);
    }
}

package com.example.demo.repository;

import com.example.demo.entity.SalesManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface SalesManagerRepository extends JpaRepository<SalesManager, Long> {
}

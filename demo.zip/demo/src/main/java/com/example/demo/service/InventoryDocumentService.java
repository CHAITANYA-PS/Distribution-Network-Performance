package com.example.demo.service;

import com.example.demo.entity.InventoryDocument;
import com.example.demo.repository.InventoryDocumentRepository;
import org.springframework.stereotype.Service;

@Service
public class InventoryDocumentService extends AbstractCrudService<InventoryDocument, Long> {
    public InventoryDocumentService(InventoryDocumentRepository repository) {
        super(repository, InventoryDocument.class);
    }
}

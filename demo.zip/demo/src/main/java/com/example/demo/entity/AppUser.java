package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="app_user",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class AppUser implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="email")
 private String email;
 @Column(name="user_name")
 private String userName;
 @Column(name="password_hash")
 private String passwordHash;
 @Column(name="phone")
 private String phone;
 @Column(name="mfa_enabled")
 private Boolean mfaEnabled;
 @Column(name="status")
 private String status;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;
}
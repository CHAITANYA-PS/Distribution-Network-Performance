package com.example.demo.service;

import com.example.demo.entity.MeasurementUnit;
import com.example.demo.repository.MeasurementUnitRepository;
import org.springframework.stereotype.Service;

@Service
public class MeasurementUnitService extends AbstractCrudService<MeasurementUnit, Long> {
    public MeasurementUnitService(MeasurementUnitRepository repository) {
        super(repository, MeasurementUnit.class);
    }
}

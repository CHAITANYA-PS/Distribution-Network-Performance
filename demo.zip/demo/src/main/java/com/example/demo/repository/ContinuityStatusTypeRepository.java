package com.example.demo.repository;

import com.example.demo.entity.ContinuityStatusType;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityStatusTypeRepository extends JpaRepository<ContinuityStatusType, Long> {
}

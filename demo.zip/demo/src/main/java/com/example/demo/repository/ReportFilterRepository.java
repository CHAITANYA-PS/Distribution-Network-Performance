package com.example.demo.repository;

import com.example.demo.entity.ReportFilter;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ReportFilterRepository extends JpaRepository<ReportFilter, Long> {
}

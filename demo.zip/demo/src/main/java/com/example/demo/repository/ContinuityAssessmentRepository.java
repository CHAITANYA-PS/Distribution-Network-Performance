package com.example.demo.repository;

import com.example.demo.entity.ContinuityAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ContinuityAssessmentRepository extends JpaRepository<ContinuityAssessment, Long> {
}

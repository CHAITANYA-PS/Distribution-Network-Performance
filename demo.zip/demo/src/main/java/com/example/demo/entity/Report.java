package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*; import java.time.OffsetDateTime;
@Entity @Table(name="report",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Report implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="report_id")
 private Long reportId;
 @Column(name="report_name")
 private String reportName;
 @Column(name="module")
 private String module;
 @Column(name="format")
 private String format;
 @Column(name="generated_by")
 private Long generatedBy;
 @Column(name="generated_at")
 private OffsetDateTime generatedAt;
 @Column(name="file_path")
 private String filePath;
}
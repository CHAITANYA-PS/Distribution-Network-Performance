package com.example.demo.service;

import com.example.demo.entity.TicketCategory;
import com.example.demo.repository.TicketCategoryRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCategoryService extends AbstractCrudService<TicketCategory, Long> {
    public TicketCategoryService(TicketCategoryRepository repository) {
        super(repository, TicketCategory.class);
    }
}

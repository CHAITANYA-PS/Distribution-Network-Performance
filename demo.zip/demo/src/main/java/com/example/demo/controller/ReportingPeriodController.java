package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.ReportingPeriod;
import com.example.demo.service.ReportingPeriodService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/reporting-periods")
public class ReportingPeriodController {
    private final ReportingPeriodService service;

    public ReportingPeriodController(ReportingPeriodService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<ReportingPeriod> create(@Valid @RequestBody ReportingPeriod model) {
        ReportingPeriod saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/reporting-periods/" + saved.getReportingPeriodId())).body(saved);
    }

    @GetMapping("/{id}")
    public ReportingPeriod get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<ReportingPeriod> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public ReportingPeriod update(@PathVariable Long id, @Valid @RequestBody ReportingPeriod model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

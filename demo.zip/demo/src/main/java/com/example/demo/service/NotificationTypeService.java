package com.example.demo.service;

import com.example.demo.entity.NotificationType;
import com.example.demo.repository.NotificationTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class NotificationTypeService extends AbstractCrudService<NotificationType, Long> {
    public NotificationTypeService(NotificationTypeRepository repository) {
        super(repository, NotificationType.class);
    }
}

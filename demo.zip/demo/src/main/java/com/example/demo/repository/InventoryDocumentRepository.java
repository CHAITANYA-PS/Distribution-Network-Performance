package com.example.demo.repository;

import com.example.demo.entity.InventoryDocument;
import org.springframework.data.jpa.repository.JpaRepository;

public interface InventoryDocumentRepository extends JpaRepository<InventoryDocument, Long> {
}

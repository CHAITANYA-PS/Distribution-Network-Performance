package com.example.demo.repository;

import com.example.demo.entity.RecoveryPlanStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanStatusRepository extends JpaRepository<RecoveryPlanStatus, Long> {
}

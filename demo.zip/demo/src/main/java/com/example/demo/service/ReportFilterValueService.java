package com.example.demo.service;

import com.example.demo.entity.ReportFilterValue;
import com.example.demo.repository.ReportFilterValueRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportFilterValueService extends AbstractCrudService<ReportFilterValue, Long> {
    public ReportFilterValueService(ReportFilterValueRepository repository) {
        super(repository, ReportFilterValue.class);
    }
}

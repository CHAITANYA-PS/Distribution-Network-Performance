package com.example.demo.service;

import com.example.demo.entity.PasswordReset;
import com.example.demo.repository.PasswordResetRepository;
import org.springframework.stereotype.Service;

@Service
public class PasswordResetService extends AbstractCrudService<PasswordReset, Long> {
    public PasswordResetService(PasswordResetRepository repository) {
        super(repository, PasswordReset.class);
    }
}

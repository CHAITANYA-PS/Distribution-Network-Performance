package com.example.demo.service;

import com.example.demo.entity.OrderStatus;
import com.example.demo.repository.OrderStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderStatusService extends AbstractCrudService<OrderStatus, Long> {
    public OrderStatusService(OrderStatusRepository repository) {
        super(repository, OrderStatus.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.CommitmentProgress;
import com.example.demo.repository.CommitmentProgressRepository;
import org.springframework.stereotype.Service;

@Service
public class CommitmentProgressService extends AbstractCrudService<CommitmentProgress, Long> {
    public CommitmentProgressService(CommitmentProgressRepository repository) {
        super(repository, CommitmentProgress.class);
    }
}

package com.example.demo.repository;

import com.example.demo.entity.ExchangeStatus;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ExchangeStatusRepository extends JpaRepository<ExchangeStatus, Long> {
}

package com.example.demo.service;

import com.example.demo.entity.FinanceManager;
import com.example.demo.repository.FinanceManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class FinanceManagerService extends AbstractCrudService<FinanceManager, Long> {
    public FinanceManagerService(FinanceManagerRepository repository) {
        super(repository, FinanceManager.class);
    }
}

package com.example.demo.service;

import com.example.demo.entity.ShipmentItem;
import com.example.demo.repository.ShipmentItemRepository;
import org.springframework.stereotype.Service;

@Service
public class ShipmentItemService extends AbstractCrudService<ShipmentItem, Long> {
    public ShipmentItemService(ShipmentItemRepository repository) {
        super(repository, ShipmentItem.class);
    }
}

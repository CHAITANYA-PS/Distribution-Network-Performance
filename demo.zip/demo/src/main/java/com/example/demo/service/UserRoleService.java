package com.example.demo.service;

import com.example.demo.entity.UserRole;
import com.example.demo.repository.UserRoleRepository;
import org.springframework.stereotype.Service;

@Service
public class UserRoleService extends AbstractCrudService<UserRole, Long> {
    public UserRoleService(UserRoleRepository repository) {
        super(repository, UserRole.class);
    }
}

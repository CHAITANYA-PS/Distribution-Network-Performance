package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import jakarta.validation.constraints.*; import lombok.*; import java.time.LocalDate; import java.time.OffsetDateTime;
@Entity @Table(name="distributor",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class Distributor implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="distributor_id")
 private Long distributorId;
 @NotBlank(message="Distributor code is required")
 @Size(max=50)
 @Column(name="distributor_code")
 private String distributorCode;
 @NotBlank(message="Distributor name is required")
 @Size(max=150)
 @Column(name="distributor_name")
 private String distributorName;
 @Column(name="region_id")
 private Long regionId;
 @Column(name="contact_person")
 private String contactPerson;
 @Email(message="Email must be valid")
 @Column(name="email")
 private String email;
 @Pattern(regexp="^[0-9+() -]{7,20}$", message="Phone must contain 7 to 20 valid characters")
 @Column(name="phone")
 private String phone;
 @Column(name="address")
 private String address;
 @Column(name="status")
 private String status;
 @Column(name="onboarding_date")
 private LocalDate onboardingDate;
 @Column(name="created_at")
 private OffsetDateTime createdAt;
 @Column(name="updated_at")
 private OffsetDateTime updatedAt;
}
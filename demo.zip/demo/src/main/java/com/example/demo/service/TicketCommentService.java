package com.example.demo.service;

import com.example.demo.entity.TicketComment;
import com.example.demo.repository.TicketCommentRepository;
import org.springframework.stereotype.Service;

@Service
public class TicketCommentService extends AbstractCrudService<TicketComment, Long> {
    public TicketCommentService(TicketCommentRepository repository) {
        super(repository, TicketComment.class);
    }
}

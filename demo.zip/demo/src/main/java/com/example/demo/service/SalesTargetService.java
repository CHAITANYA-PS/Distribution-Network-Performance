package com.example.demo.service;

import com.example.demo.entity.SalesTarget;
import com.example.demo.repository.SalesTargetRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesTargetService extends AbstractCrudService<SalesTarget, Long> {
    public SalesTargetService(SalesTargetRepository repository) {
        super(repository, SalesTarget.class);
    }
}

package com.example.demo.repository;

import com.example.demo.entity.FinanceManager;
import org.springframework.data.jpa.repository.JpaRepository;

public interface FinanceManagerRepository extends JpaRepository<FinanceManager, Long> {
}

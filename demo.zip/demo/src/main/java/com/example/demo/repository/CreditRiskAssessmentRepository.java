package com.example.demo.repository;

import com.example.demo.entity.CreditRiskAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CreditRiskAssessmentRepository extends JpaRepository<CreditRiskAssessment, Long> {
}

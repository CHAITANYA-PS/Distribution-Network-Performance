package com.example.demo.service;

import com.example.demo.entity.ExchangeHistory;
import com.example.demo.repository.ExchangeHistoryRepository;
import org.springframework.stereotype.Service;

@Service
public class ExchangeHistoryService extends AbstractCrudService<ExchangeHistory, Long> {
    public ExchangeHistoryService(ExchangeHistoryRepository repository) {
        super(repository, ExchangeHistory.class);
    }
}

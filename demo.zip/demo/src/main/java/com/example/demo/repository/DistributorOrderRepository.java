package com.example.demo.repository;

import com.example.demo.entity.DistributorOrder;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorOrderRepository extends JpaRepository<DistributorOrder, Long> {
}

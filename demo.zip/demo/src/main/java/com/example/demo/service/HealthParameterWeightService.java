package com.example.demo.service;

import com.example.demo.entity.HealthParameterWeight;
import com.example.demo.repository.HealthParameterWeightRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthParameterWeightService extends AbstractCrudService<HealthParameterWeight, Long> {
    public HealthParameterWeightService(HealthParameterWeightRepository repository) {
        super(repository, HealthParameterWeight.class);
    }
}

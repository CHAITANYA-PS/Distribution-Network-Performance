package com.example.demo.service;

import com.example.demo.entity.Product;
import com.example.demo.repository.ProductRepository;
import org.springframework.stereotype.Service;

@Service
public class ProductService extends AbstractCrudService<Product, Long> {
    public ProductService(ProductRepository repository) {
        super(repository, Product.class);
    }
}

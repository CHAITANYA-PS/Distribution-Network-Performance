package com.example.demo.repository;

import com.example.demo.entity.RecoveryPlanTicket;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RecoveryPlanTicketRepository extends JpaRepository<RecoveryPlanTicket, Long> {
}

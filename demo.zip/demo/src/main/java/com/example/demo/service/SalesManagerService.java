package com.example.demo.service;

import com.example.demo.entity.SalesManager;
import com.example.demo.repository.SalesManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class SalesManagerService extends AbstractCrudService<SalesManager, Long> {
    public SalesManagerService(SalesManagerRepository repository) {
        super(repository, SalesManager.class);
    }
}

package com.example.demo.service;

import com.example.demo.service.BusinessRuleException;
import com.example.demo.entity.ExchangeRequest;
import com.example.demo.repository.ExchangeRequestRepository;
import org.springframework.stereotype.Service;

import java.time.OffsetDateTime;
import java.util.Optional;

@Service
public class ExchangeRequestService extends AbstractCrudService<ExchangeRequest, Long> {
    private final ExchangeRequestRepository requests;

    public ExchangeRequestService(ExchangeRequestRepository repository) {
        super(repository, ExchangeRequest.class);
        this.requests = repository;
    }

    @Override
    protected Optional<ExchangeRequest> findForUpdate(Long id) {
        return requests.findByIdForUpdate(id);
    }

    @Override
    protected void beforeCreate(ExchangeRequest r) {
        checkQuantity(r);
        if (r.getRequestedAt() == null) {
            r.setRequestedAt(OffsetDateTime.now());
        }
    }

    @Override
    protected void beforeUpdate(Long id, ExchangeRequest r, ExchangeRequest existing) {
        checkQuantity(r);
    }

    private void checkQuantity(ExchangeRequest r) {
        if (r.getRequestedQuantity() == null || r.getRequestedQuantity().signum() <= 0) {
            throw new BusinessRuleException("Requested quantity must be greater than zero");
        }
    }
}

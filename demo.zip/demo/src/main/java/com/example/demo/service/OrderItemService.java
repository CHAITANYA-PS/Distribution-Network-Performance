package com.example.demo.service;

import com.example.demo.entity.OrderItem;
import com.example.demo.repository.OrderItemRepository;
import org.springframework.stereotype.Service;

@Service
public class OrderItemService extends AbstractCrudService<OrderItem, Long> {
    public OrderItemService(OrderItemRepository repository) {
        super(repository, OrderItem.class);
    }
}

package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.Warehouse;
import com.example.demo.service.WarehouseService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/warehouses")
public class WarehouseController {
    private final WarehouseService service;

    public WarehouseController(WarehouseService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<Warehouse> create(@Valid @RequestBody Warehouse model) {
        Warehouse saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/warehouses/" + saved.getWarehouseId())).body(saved);
    }

    @GetMapping("/{id}")
    public Warehouse get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<Warehouse> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public Warehouse update(@PathVariable Long id, @Valid @RequestBody Warehouse model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

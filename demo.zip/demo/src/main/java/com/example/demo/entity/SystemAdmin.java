package com.example.demo.entity;
import com.example.demo.entity.locking.VersionedEntity;
import jakarta.persistence.*; import lombok.*;
@Entity @Table(name="system_admin",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class SystemAdmin implements VersionedEntity {
 @Version
 @Column(name="version", nullable=false)
 private Long version;
 @Id
 @GeneratedValue(strategy=GenerationType.IDENTITY)
 @Column(name="user_id")
 private Long userId;
 @Column(name="admin_level")
 private String adminLevel;
}
package com.example.demo.service;

import com.example.demo.entity.ContinuityStatusType;
import com.example.demo.repository.ContinuityStatusTypeRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityStatusTypeService extends AbstractCrudService<ContinuityStatusType, Long> {
    public ContinuityStatusTypeService(ContinuityStatusTypeRepository repository) {
        super(repository, ContinuityStatusType.class);
    }
}

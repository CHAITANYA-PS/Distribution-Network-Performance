package com.example.demo.repository;

import com.example.demo.entity.RiskLevel;
import org.springframework.data.jpa.repository.JpaRepository;

public interface RiskLevelRepository extends JpaRepository<RiskLevel, Long> {
}

package com.example.demo.repository;

import com.example.demo.entity.CommitmentProgress;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentProgressRepository extends JpaRepository<CommitmentProgress, Long> {
}

package com.example.demo.service;

import com.example.demo.entity.RecoveryPlanStatus;
import com.example.demo.repository.RecoveryPlanStatusRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryPlanStatusService extends AbstractCrudService<RecoveryPlanStatus, Long> {
    public RecoveryPlanStatusService(RecoveryPlanStatusRepository repository) {
        super(repository, RecoveryPlanStatus.class);
    }
}

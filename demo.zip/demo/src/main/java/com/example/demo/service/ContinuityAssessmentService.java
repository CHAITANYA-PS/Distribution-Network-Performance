package com.example.demo.service;

import com.example.demo.entity.ContinuityAssessment;
import com.example.demo.repository.ContinuityAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class ContinuityAssessmentService extends AbstractCrudService<ContinuityAssessment, Long> {
    public ContinuityAssessmentService(ContinuityAssessmentRepository repository) {
        super(repository, ContinuityAssessment.class);
    }
}

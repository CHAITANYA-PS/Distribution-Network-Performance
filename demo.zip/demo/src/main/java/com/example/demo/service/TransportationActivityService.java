package com.example.demo.service;

import com.example.demo.entity.TransportationActivity;
import com.example.demo.repository.TransportationActivityRepository;
import org.springframework.stereotype.Service;

@Service
public class TransportationActivityService extends AbstractCrudService<TransportationActivity, Long> {
    public TransportationActivityService(TransportationActivityRepository repository) {
        super(repository, TransportationActivity.class);
    }
}

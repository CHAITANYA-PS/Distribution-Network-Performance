package com.example.demo.service;

import com.example.demo.entity.DistributorHealthAssessment;
import com.example.demo.repository.DistributorHealthAssessmentRepository;
import org.springframework.stereotype.Service;

@Service
public class DistributorHealthAssessmentService extends AbstractCrudService<DistributorHealthAssessment, Long> {
    public DistributorHealthAssessmentService(DistributorHealthAssessmentRepository repository) {
        super(repository, DistributorHealthAssessment.class);
    }
}

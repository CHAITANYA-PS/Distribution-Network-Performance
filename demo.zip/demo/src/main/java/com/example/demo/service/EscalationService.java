package com.example.demo.service;

import com.example.demo.entity.Escalation;
import com.example.demo.repository.EscalationRepository;
import org.springframework.stereotype.Service;

@Service
public class EscalationService extends AbstractCrudService<Escalation, Long> {
    public EscalationService(EscalationRepository repository) {
        super(repository, Escalation.class);
    }
}

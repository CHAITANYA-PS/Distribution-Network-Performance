package com.example.demo.controller;

import jakarta.validation.Valid;

import com.example.demo.entity.PaymentMethod;
import com.example.demo.service.PaymentMethodService;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.net.URI;
import java.util.List;

@RestController
@RequestMapping("/api/v1/payment-methods")
public class PaymentMethodController {
    private final PaymentMethodService service;

    public PaymentMethodController(PaymentMethodService service) {
        this.service = service;
    }

    @PostMapping
    public ResponseEntity<PaymentMethod> create(@Valid @RequestBody PaymentMethod model) {
        PaymentMethod saved = service.create(model);
        return ResponseEntity.created(URI.create("/api/v1/payment-methods/" + saved.getPaymentMethodId())).body(saved);
    }

    @GetMapping("/{id}")
    public PaymentMethod get(@PathVariable Long id) {
        return service.get(id);
    }

    @GetMapping
    public List<PaymentMethod> getAll() {
        return service.getAll();
    }

    @PutMapping("/{id}")
    public PaymentMethod update(@PathVariable Long id, @Valid @RequestBody PaymentMethod model) {
        return service.update(id, model);
    }

    @DeleteMapping("/{id}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void delete(@PathVariable Long id) {
        service.delete(id);
    }
}

package com.example.demo.entity;
import jakarta.persistence.*; import lombok.*; import org.hibernate.annotations.Immutable; import java.io.Serializable; 
/** Read-only mapping of the database view dsphere.transport_emission_view. */
@Entity @Immutable @Table(name="transport_emission_view",schema="dsphere") @Getter @Setter @NoArgsConstructor @AllArgsConstructor @Builder public class TransportEmissionView implements Serializable {
 private static final long serialVersionUID = 1L;
 @Id
 @Column(name="transport_id")
 private Long transportId;
 @Column(name="vehicle_type")
 private String vehicleType;
 @Column(name="fuel_type")
 private String fuelType;
 @Column(name="distance_travelled")
 private Double distanceTravelled;
 @Column(name="fuel_consumed")
 private Double fuelConsumed;
 @Column(name="emission_value")
 private Double emissionValue;
 @Column(name="emission_unit")
 private String emissionUnit;
}

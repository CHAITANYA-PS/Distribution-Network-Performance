package com.example.demo.service;

import com.example.demo.entity.ReportingPeriod;
import com.example.demo.repository.ReportingPeriodRepository;
import org.springframework.stereotype.Service;

@Service
public class ReportingPeriodService extends AbstractCrudService<ReportingPeriod, Long> {
    public ReportingPeriodService(ReportingPeriodRepository repository) {
        super(repository, ReportingPeriod.class);
    }
}

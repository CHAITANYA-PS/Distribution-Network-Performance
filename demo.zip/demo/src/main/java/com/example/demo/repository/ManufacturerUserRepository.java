package com.example.demo.repository;

import com.example.demo.entity.ManufacturerUser;
import org.springframework.data.jpa.repository.JpaRepository;

public interface ManufacturerUserRepository extends JpaRepository<ManufacturerUser, Long> {
}

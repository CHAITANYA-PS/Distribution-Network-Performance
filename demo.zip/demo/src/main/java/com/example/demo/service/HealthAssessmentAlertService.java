package com.example.demo.service;

import com.example.demo.entity.HealthAssessmentAlert;
import com.example.demo.repository.HealthAssessmentAlertRepository;
import org.springframework.stereotype.Service;

@Service
public class HealthAssessmentAlertService extends AbstractCrudService<HealthAssessmentAlert, Long> {
    public HealthAssessmentAlertService(HealthAssessmentAlertRepository repository) {
        super(repository, HealthAssessmentAlert.class);
    }
}

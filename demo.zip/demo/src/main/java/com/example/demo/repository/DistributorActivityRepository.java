package com.example.demo.repository;

import com.example.demo.entity.DistributorActivity;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorActivityRepository extends JpaRepository<DistributorActivity, Long> {
}

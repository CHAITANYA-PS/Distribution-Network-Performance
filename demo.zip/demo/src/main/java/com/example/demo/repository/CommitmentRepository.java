package com.example.demo.repository;

import com.example.demo.entity.Commitment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface CommitmentRepository extends JpaRepository<Commitment, Long> {
}

package com.example.demo.service;

import com.example.demo.entity.UserSession;
import com.example.demo.repository.UserSessionRepository;
import org.springframework.stereotype.Service;

@Service
public class UserSessionService extends AbstractCrudService<UserSession, Long> {
    public UserSessionService(UserSessionRepository repository) {
        super(repository, UserSession.class);
    }
}

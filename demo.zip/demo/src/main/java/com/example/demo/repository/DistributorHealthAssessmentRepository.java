package com.example.demo.repository;

import com.example.demo.entity.DistributorHealthAssessment;
import org.springframework.data.jpa.repository.JpaRepository;

public interface DistributorHealthAssessmentRepository extends JpaRepository<DistributorHealthAssessment, Long> {
}

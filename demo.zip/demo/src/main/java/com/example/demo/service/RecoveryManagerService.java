package com.example.demo.service;

import com.example.demo.entity.RecoveryManager;
import com.example.demo.repository.RecoveryManagerRepository;
import org.springframework.stereotype.Service;

@Service
public class RecoveryManagerService extends AbstractCrudService<RecoveryManager, Long> {
    public RecoveryManagerService(RecoveryManagerRepository repository) {
        super(repository, RecoveryManager.class);
    }
}

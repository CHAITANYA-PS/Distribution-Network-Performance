package com.example.demo.service;

import com.example.demo.service.BusinessRuleException;
import com.example.demo.service.ResourceNotFoundException;
import com.example.demo.entity.UserSession;
import com.example.demo.repository.UserSessionRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** Logic-only test: the repository is a Mockito mock, no database is used. */
@ExtendWith(MockitoExtension.class)
class UserSessionServiceTest {
    @Mock UserSessionRepository repository;
    @InjectMocks UserSessionService service;

    private UserSession row(Long id, Long version) {
        UserSession x = new UserSession();
        x.setSessionId(id);
        x.setVersion(version);
        return x;
    }

    @Test
    void create_clearsClientIdAndVersion_thenSaves() {
        when(repository.save(any(UserSession.class))).thenAnswer(a -> a.getArgument(0));
        UserSession result = service.create(row(99L, 5L));
        assertNull(result.getSessionId());
        assertNull(result.getVersion());
        verify(repository).save(any(UserSession.class));
    }

    @Test
    void create_nullBody_isRejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(null));
        verifyNoInteractions(repository);
    }

    @Test
    void get_existing_returnsRow() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 0L)));
        assertEquals(1L, service.get(1L).getSessionId());
    }

    @Test
    void get_missing_throwsNotFound() {
        when(repository.findById(2L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.get(2L));
    }

    @Test
    void getAll_returnsEveryRow() {
        when(repository.findAll()).thenReturn(List.of(row(1L, 0L), row(2L, 0L)));
        assertEquals(2, service.getAll().size());
    }

    @Test
    void update_existing_keepsPathIdAndStoredVersion() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        when(repository.save(any(UserSession.class))).thenAnswer(a -> a.getArgument(0));
        UserSession result = service.update(1L, row(null, null));
        assertEquals(1L, result.getSessionId());
        assertEquals(3L, result.getVersion());
    }

    @Test
    void update_staleVersion_raisesOptimisticLockFailure() {
        when(repository.findById(1L)).thenReturn(Optional.of(row(1L, 3L)));
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> service.update(1L, row(null, 2L)));
        verify(repository, never()).save(any(UserSession.class));
    }

    @Test
    void update_missing_throwsNotFound() {
        when(repository.findById(9L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(9L, row(null, null)));
    }

    @Test
    void delete_existing_deletesById() {
        when(repository.existsById(1L)).thenReturn(true);
        service.delete(1L);
        verify(repository).deleteById(1L);
    }

    @Test
    void delete_missing_throwsNotFoundAndDeletesNothing() {
        when(repository.existsById(8L)).thenReturn(false);
        assertThrows(ResourceNotFoundException.class, () -> service.delete(8L));
        verify(repository, never()).deleteById(any());
    }
}

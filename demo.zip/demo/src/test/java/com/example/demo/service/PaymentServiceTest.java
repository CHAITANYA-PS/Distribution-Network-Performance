package com.example.demo.service;

import com.example.demo.service.BusinessRuleException;
import com.example.demo.service.ResourceNotFoundException;
import com.example.demo.entity.Invoice;
import com.example.demo.entity.Payment;
import com.example.demo.repository.InvoiceRepository;
import com.example.demo.repository.PaymentRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class PaymentServiceTest {
    @Mock PaymentRepository payments;
    @Mock InvoiceRepository invoices;
    @InjectMocks PaymentService service;

    private Payment pay(String amount) {
        Payment p = new Payment();
        p.setInvoiceId(5L);
        p.setAmount(amount == null ? null : new BigDecimal(amount));
        return p;
    }

    private Invoice invoice(String amount) {
        Invoice i = new Invoice();
        i.setInvoiceId(5L);
        i.setInvoiceAmount(amount == null ? null : new BigDecimal(amount));
        return i;
    }

    @Test
    void create_withinBalance_locksInvoiceAndSaves() {
        when(invoices.findByIdForUpdate(5L)).thenReturn(Optional.of(invoice("1000")));
        when(payments.sumPaidForInvoiceExcluding(5L, -1L)).thenReturn(new BigDecimal("400"));
        when(payments.save(any(Payment.class))).thenAnswer(a -> a.getArgument(0));
        Payment r = service.create(pay("600"));
        assertNotNull(r.getPaymentDate());
        verify(invoices).findByIdForUpdate(5L);
    }

    @Test
    void create_overBalance_rejected() {
        when(invoices.findByIdForUpdate(5L)).thenReturn(Optional.of(invoice("1000")));
        when(payments.sumPaidForInvoiceExcluding(5L, -1L)).thenReturn(new BigDecimal("600"));
        assertThrows(BusinessRuleException.class, () -> service.create(pay("500")));
        verify(payments, never()).save(any());
    }

    @Test
    void create_zeroAmount_rejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(pay("0")));
        verifyNoInteractions(invoices);
    }

    @Test
    void create_nullAmount_rejected() {
        assertThrows(BusinessRuleException.class, () -> service.create(pay(null)));
    }

    @Test
    void create_missingInvoiceId_rejected() {
        Payment p = pay("1");
        p.setInvoiceId(null);
        assertThrows(BusinessRuleException.class, () -> service.create(p));
    }

    @Test
    void create_unknownInvoice_notFound() {
        when(invoices.findByIdForUpdate(5L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.create(pay("1")));
    }

    @Test
    void create_invoiceWithoutAmount_rejected() {
        when(invoices.findByIdForUpdate(5L)).thenReturn(Optional.of(invoice(null)));
        assertThrows(BusinessRuleException.class, () -> service.create(pay("1")));
    }

    @Test
    void update_usesPessimisticLock_andExcludesItself() {
        Payment existing = pay("100");
        existing.setPaymentId(3L);
        existing.setVersion(1L);
        when(payments.findByIdForUpdate(3L)).thenReturn(Optional.of(existing));
        when(invoices.findByIdForUpdate(5L)).thenReturn(Optional.of(invoice("1000")));
        when(payments.sumPaidForInvoiceExcluding(eq(5L), eq(3L))).thenReturn(new BigDecimal("500"));
        when(payments.save(any(Payment.class))).thenAnswer(a -> a.getArgument(0));
        Payment r = service.update(3L, pay("450"));
        assertEquals(3L, r.getPaymentId());
        assertEquals(1L, r.getVersion());
        verify(payments).findByIdForUpdate(3L);
    }
}

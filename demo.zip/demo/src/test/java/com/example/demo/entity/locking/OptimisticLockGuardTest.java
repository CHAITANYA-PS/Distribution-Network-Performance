package com.example.demo.entity.locking;

import com.example.demo.entity.Region;
import org.junit.jupiter.api.Test;
import org.springframework.orm.ObjectOptimisticLockingFailureException;

import static org.junit.jupiter.api.Assertions.*;

class OptimisticLockGuardTest {
    @Test void sameVersion_passes() { assertDoesNotThrow(() -> OptimisticLockGuard.verify(Region.class, 1L, 2L, 2L)); }
    @Test void noClientVersion_skipsCheck() { assertDoesNotThrow(() -> OptimisticLockGuard.verify(Region.class, 1L, null, 2L)); }
    @Test void differentVersion_conflicts() {
        assertThrows(ObjectOptimisticLockingFailureException.class, () -> OptimisticLockGuard.verify(Region.class, 1L, 1L, 2L));
    }
    @Test void idAccessor_roundTrip() {
        Region r = new Region();
        EntityIdAccessor.setId(r, 42L);
        assertEquals(42L, EntityIdAccessor.getId(r));
        assertThrows(IllegalStateException.class, () -> EntityIdAccessor.getId("no id here"));
    }
}

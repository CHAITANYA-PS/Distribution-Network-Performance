package com.example.demo.service;

import com.example.demo.service.BusinessRuleException;
import com.example.demo.service.ResourceNotFoundException;
import com.example.demo.entity.DistributorCreditLimit;
import com.example.demo.repository.DistributorCreditLimitRepository;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.math.BigDecimal;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

/** DistributorCreditLimit rows are updated under a PESSIMISTIC_WRITE lock, so update() must use findByIdForUpdate. */
@ExtendWith(MockitoExtension.class)
class DistributorCreditLimitServiceTest {
    @Mock DistributorCreditLimitRepository repository;
    @InjectMocks DistributorCreditLimitService service;

    private DistributorCreditLimit valid() {
        DistributorCreditLimit s = new DistributorCreditLimit();
        s.setCreditLimit(new BigDecimal("100"));
        return s;
    }

    @Test
    void create_valid_saves() {
        when(repository.save(any(DistributorCreditLimit.class))).thenAnswer(a -> a.getArgument(0));
        assertNotNull(service.create(valid()));
    }

    @Test
    void create_invalid_rejected() {
        DistributorCreditLimit s = new DistributorCreditLimit();
        s.setCreditLimit(new BigDecimal("-1"));
        assertThrows(BusinessRuleException.class, () -> service.create(s));
        verify(repository, never()).save(any());
    }

    @Test
    void update_takesRowLock() {
        DistributorCreditLimit existing = new DistributorCreditLimit();
        existing.setCreditLimitId(1L);
        existing.setVersion(2L);
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.of(existing));
        when(repository.save(any(DistributorCreditLimit.class))).thenAnswer(a -> a.getArgument(0));
        DistributorCreditLimit r = service.update(1L, valid());
        assertEquals(2L, r.getVersion());
        verify(repository).findByIdForUpdate(1L);
        verify(repository, never()).findById(any());
    }

    @Test
    void update_missing_notFound() {
        when(repository.findByIdForUpdate(1L)).thenReturn(Optional.empty());
        assertThrows(ResourceNotFoundException.class, () -> service.update(1L, valid()));
    }
}

package com.example.demo.controller;

import com.example.demo.service.ResourceNotFoundException;
import com.example.demo.entity.DistributorActivity;
import com.example.demo.service.DistributorActivityService;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.eq;
import static org.mockito.Mockito.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(DistributorActivityController.class)
class DistributorActivityControllerTest {
    private static final String URL = "/api/v1/distributor-activities";
    @Autowired MockMvc mvc;
    @MockBean DistributorActivityService service;

    private DistributorActivity saved() {
        DistributorActivity x = new DistributorActivity();
        x.setActivityId(1L);
        x.setVersion(0L);
        return x;
    }

    @Test
    void post_returns201WithLocation() throws Exception {
        when(service.create(any())).thenReturn(saved());
        mvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isCreated())
                .andExpect(header().string("Location", URL + "/1"));
    }

    @Test
    void getAll_returns200() throws Exception {
        when(service.getAll()).thenReturn(List.of(saved()));
        mvc.perform(get(URL)).andExpect(status().isOk()).andExpect(jsonPath("$[0].version").value(0));
    }

    @Test
    void getById_returns200() throws Exception {
        when(service.get(1L)).thenReturn(saved());
        mvc.perform(get(URL + "/1")).andExpect(status().isOk()).andExpect(jsonPath("$.activityId").value(1));
    }

    @Test
    void getById_missing_returnsErrorModel404() throws Exception {
        when(service.get(7L)).thenThrow(new ResourceNotFoundException("DistributorActivity not found: 7"));
        mvc.perform(get(URL + "/7")).andExpect(status().isNotFound())
                .andExpect(jsonPath("$.status").value(404))
                .andExpect(jsonPath("$.code").value("RESOURCE_NOT_FOUND"))
                .andExpect(jsonPath("$.path").value(URL + "/7"));
    }

    @Test
    void put_returns200() throws Exception {
        when(service.update(eq(1L), any())).thenReturn(saved());
        mvc.perform(put(URL + "/1").contentType(MediaType.APPLICATION_JSON).content("{}"))
                .andExpect(status().isOk());
    }

    @Test
    void delete_returns204() throws Exception {
        mvc.perform(delete(URL + "/1")).andExpect(status().isNoContent());
        verify(service).delete(1L);
    }

    @Test
    void malformedJson_returns400ErrorModel() throws Exception {
        mvc.perform(post(URL).contentType(MediaType.APPLICATION_JSON).content("{bad"))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.code").value("MALFORMED_REQUEST"));
    }
}
